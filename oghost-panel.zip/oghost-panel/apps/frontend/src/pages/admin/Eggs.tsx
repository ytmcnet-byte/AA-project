import { useState } from 'react';
import { Copy, Download, Pencil, Plus, RotateCcw, Trash2, Upload } from 'lucide-react';
import { useApi, useAction, toast } from '../../lib/hooks';
import { api } from '../../lib/api';
import { Card, Confirm, ErrorBox, Field, Loading, Modal, Notice, PageHeader, Spinner, Switch, Table } from '../../components/ui';

const INSTALLERS = ['vanilla', 'paper', 'purpur', 'pufferfish', 'folia', 'spigot', 'fabric', 'quilt', 'forge', 'neoforge', 'velocity', 'waterfall', 'bungeecord', 'bedrock', 'pocketmine', 'minestom', 'custom', 'none'];
const blank = { slug: '', name: '', category: 'custom', description: '', installer: 'custom', runtime: 'java', javaMin: 17, javaMax: undefined, startup: '{{JAVA}} -Xms{{XMS}}M -Xmx{{XMX}}M -jar {{SERVER_JAR}} nogui', stopCommand: 'stop', doneRegex: 'Done \\(', variables: [{ key: 'SERVER_JAR', name: 'Server JAR', description: '', default: 'server.jar', userEditable: true, rules: '' }], configFiles: {}, notes: '' };

export function EggsAdmin() {
  const { data, error, loading, reload } = useApi<any>('/api/admin/eggs'); const { busy, run } = useAction();
  const [ed, setEd] = useState<any>(null); const [rm, setRm] = useState<any>(null);
  const importFile = async (file: File) => run('imp', async () => { const j = JSON.parse(await file.text()); const r = await api('POST', '/api/admin/eggs/import', j); reload(); toast(`Imported as ${r.slug}${r.warnings?.length ? ` — ${r.warnings.join(' ')}` : ''}`, r.warnings?.length ? 'info' : 'success'); });
  if (loading) return <Loading />; if (error) return <ErrorBox error={error} onRetry={reload} />;
  return <><PageHeader title="Eggs" subtitle="Software definitions. Each egg has its own installer, Java range, startup command and stop command." actions={<><label className="btn-secondary cursor-pointer"><Upload className="h-4 w-4" />Import<input type="file" accept=".json" className="hidden" onChange={e => e.target.files?.[0] && importFile(e.target.files[0])} /></label><button className="btn-primary" onClick={() => setEd({ def: structuredClone(blank) })}><Plus className="h-4 w-4" />New egg</button></>} />
    <Notice className="mb-4">Pterodactyl eggs (PTDL_v1/v2) can be imported, but only their variables and startup command are converted. Docker install scripts are not compatible, so review the result before use.</Notice>
    <Card><Table><thead><tr><th>Name</th><th>Category</th><th>Installer</th><th>Java</th><th>Startup</th><th>Servers</th><th /></tr></thead><tbody>{data.eggs.map((e: any) => <tr key={e.id}>
      <td><div className="font-semibold">{e.name}{e.is_builtin ? <span className="ml-2 badge border-ink-600 text-ink-400">built-in</span> : null}</div><div className="font-mono text-xs text-ink-400">{e.slug}</div></td><td>{e.category}</td><td>{e.definition.installer}</td>
      <td>{e.definition.runtime === 'java' ? `${e.definition.javaMin || '?'}${e.definition.javaMax ? `–${e.definition.javaMax}` : '+'}` : e.definition.runtime}</td><td className="max-w-xs truncate font-mono text-xs" title={e.definition.startup}>{e.definition.startup}</td><td>{e.servers}</td>
      <td className="whitespace-nowrap text-right"><button className="btn-ghost btn-sm px-1.5" title="Edit" onClick={() => setEd({ id: e.id, builtin: !!e.is_builtin, def: { ...blank, ...structuredClone(e.definition) } })}><Pencil className="h-4 w-4" /></button>
        <button className="btn-ghost btn-sm px-1.5" title="Duplicate" onClick={() => run('dup', () => api('POST', `/api/admin/eggs/${e.id}/duplicate`).then(reload), 'Duplicated')}><Copy className="h-4 w-4" /></button>
        <a className="btn-ghost btn-sm px-1.5" title="Export" href={`/api/admin/eggs/${e.id}/export`}><Download className="h-4 w-4" /></a>
        {e.is_builtin ? <button className="btn-ghost btn-sm px-1.5" title="Reset to default" onClick={() => run('rs', () => api('POST', `/api/admin/eggs/${e.id}/reset`).then(reload), 'Reset to default')}><RotateCcw className="h-4 w-4" /></button> : <button className="btn-ghost btn-sm px-1.5 text-red-400" title="Delete" onClick={() => setRm(e)}><Trash2 className="h-4 w-4" /></button>}</td></tr>)}</tbody></Table></Card>
    {ed && <EggEditor ed={ed} onClose={() => setEd(null)} onSaved={() => { setEd(null); reload(); }} />}
    <Confirm open={!!rm} onClose={() => setRm(null)} danger title="Delete egg" confirmLabel="Delete" busy={busy === 'd'} onConfirm={() => run('d', () => api('DELETE', `/api/admin/eggs/${rm.id}`).then(() => { setRm(null); reload(); }), 'Deleted')}>Eggs used by servers or store plans cannot be deleted.</Confirm>
  </>;
}

function EggEditor({ ed, onClose, onSaved }: { ed: any; onClose: () => void; onSaved: () => void }) {
  const [d, setD] = useState<any>(ed.def); const [cfg, setCfg] = useState(JSON.stringify(ed.def.configFiles || {}, null, 2)); const { busy, run } = useAction();
  const set = (k: string, v: any) => setD({ ...d, [k]: v });
  const setVar = (i: number, k: string, v: any) => set('variables', d.variables.map((x: any, j: number) => (j === i ? { ...x, [k]: v } : x)));
  const save = () => run('s', async () => {
    let configFiles: any; try { configFiles = JSON.parse(cfg || '{}'); } catch { throw new Error('Config files must be valid JSON'); }
    const body = { ...d, configFiles, javaMin: d.runtime === 'java' && d.javaMin ? Number(d.javaMin) : undefined, javaMax: d.runtime === 'java' && d.javaMax ? Number(d.javaMax) : undefined, doneRegex: d.doneRegex || undefined, notes: d.notes || undefined, variables: d.variables.map((v: any) => ({ ...v, description: v.description || undefined, rules: v.rules || undefined })) };
    if (ed.id) await api('PUT', `/api/admin/eggs/${ed.id}`, body); else await api('POST', '/api/admin/eggs', body); onSaved();
  }, 'Egg saved');
  return <Modal open onClose={onClose} wide title={ed.id ? `Edit ${d.name}` : 'New egg'} footer={<><button className="btn-secondary" onClick={onClose}>Cancel</button><button className="btn-primary" disabled={!!busy} onClick={save}>{busy && <Spinner />}Save</button></>}>
    <div className="grid gap-4 sm:grid-cols-2">
      <Field label="Name"><input className="input" value={d.name} onChange={e => set('name', e.target.value)} /></Field>
      <Field label="Slug" hint={ed.builtin ? 'Built-in slugs cannot change' : 'lowercase, digits, dashes'}><input className="input font-mono" disabled={ed.builtin} value={d.slug} onChange={e => set('slug', e.target.value)} /></Field>
      <Field label="Category"><select className="input" value={d.category} onChange={e => set('category', e.target.value)}>{['minecraft-java', 'minecraft-bedrock', 'proxy', 'custom'].map(c => <option key={c}>{c}</option>)}</select></Field>
      <Field label="Installer" hint="Which built-in installer downloads the software"><select className="input" value={d.installer} onChange={e => set('installer', e.target.value)}>{INSTALLERS.map(c => <option key={c}>{c}</option>)}</select></Field>
      <Field label="Runtime"><select className="input" value={d.runtime} onChange={e => set('runtime', e.target.value)}><option value="java">Java</option><option value="native">Native binary</option><option value="php">PHP (PocketMine)</option></select></Field>
      {d.runtime === 'java' && <div className="grid grid-cols-2 gap-2"><Field label="Java min"><input className="input" type="number" value={d.javaMin ?? ''} onChange={e => set('javaMin', e.target.value)} /></Field><Field label="Java max"><input className="input" type="number" value={d.javaMax ?? ''} onChange={e => set('javaMax', e.target.value)} /></Field></div>}
      <Field label="Startup command" className="sm:col-span-2" hint="Placeholders: {{JAVA}} {{XMS}} {{XMX}} {{PORT}} {{IP}} plus variables. Arguments are passed directly to the process; no shell is used."><textarea className="input font-mono text-xs" value={d.startup} onChange={e => set('startup', e.target.value)} /></Field>
      <Field label="Stop command" hint="Sent to the console for a graceful stop (e.g. stop, end)"><input className="input font-mono" value={d.stopCommand} onChange={e => set('stopCommand', e.target.value)} /></Field>
      <Field label="Started when output matches (regex)"><input className="input font-mono" value={d.doneRegex || ''} onChange={e => set('doneRegex', e.target.value)} /></Field>
      <Field label="Description" className="sm:col-span-2"><textarea className="input" value={d.description} onChange={e => set('description', e.target.value)} /></Field>
      <Field label="Notes shown to admins" className="sm:col-span-2"><textarea className="input" value={d.notes || ''} onChange={e => set('notes', e.target.value)} /></Field>
    </div>
    <div className="mt-6"><div className="mb-2 flex items-center justify-between"><h3 className="font-semibold">Variables</h3><button className="btn-secondary btn-sm" onClick={() => set('variables', [...d.variables, { key: 'NEW_VAR', name: 'New variable', description: '', default: '', userEditable: true, rules: '' }])}><Plus className="h-4 w-4" />Add</button></div>
      <div className="space-y-3">{d.variables.map((v: any, i: number) => <div key={i} className="grid gap-2 rounded-lg border border-ink-700 p-3 sm:grid-cols-6">
        <input className="input font-mono text-xs sm:col-span-1" placeholder="KEY" value={v.key} onChange={e => setVar(i, 'key', e.target.value.toUpperCase())} />
        <input className="input text-xs sm:col-span-2" placeholder="Name" value={v.name} onChange={e => setVar(i, 'name', e.target.value)} />
        <input className="input font-mono text-xs sm:col-span-1" placeholder="Default" value={v.default} onChange={e => setVar(i, 'default', e.target.value)} />
        <input className="input font-mono text-xs sm:col-span-2" placeholder="Rules, e.g. regex:^[0-9.]+$" value={v.rules || ''} onChange={e => setVar(i, 'rules', e.target.value)} />
        <input className="input text-xs sm:col-span-4" placeholder="Description" value={v.description || ''} onChange={e => setVar(i, 'description', e.target.value)} />
        <div className="flex items-center justify-between sm:col-span-2"><Switch checked={v.userEditable} onChange={x => setVar(i, 'userEditable', x)} label="Customer can edit" /><button className="btn-ghost btn-sm text-red-400" onClick={() => set('variables', d.variables.filter((_: any, j: number) => j !== i))}><Trash2 className="h-4 w-4" /></button></div>
      </div>)}</div></div>
    <Field label="Config file values (JSON)" className="mt-6" hint={'Applied before every start, e.g. {"server.properties": {"server-port": "{{PORT}}"}}'}><textarea className="input min-h-28 font-mono text-xs" value={cfg} onChange={e => setCfg(e.target.value)} /></Field>
  </Modal>;
}
