import { useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { LifeBuoy, Paperclip, Send } from 'lucide-react';
import { useApi, useAction } from '../lib/hooks';
import { patch, post, upload } from '../lib/api';
import { bytes, date, ago, cls } from '../lib/format';
import { Badge, Card, Empty, ErrorBox, Field, Loading, Modal, Notice, PageHeader, Spinner, Table } from '../components/ui';

export function Tickets({ admin = false }: { admin?: boolean }) {
  const [status, setStatus] = useState(''); const [mine, setMine] = useState(false);
  const qs = admin ? `?all=1${status ? `&status=${status}` : ''}${mine ? '&assigned=me' : ''}` : status ? `?status=${status}` : '';
  const { data, error, loading, reload } = useApi<any>(`/api/tickets${qs}`, [qs], 30000); const [open, setOpen] = useState(false);
  const base = admin ? '/admin/tickets' : '/tickets';
  return (
    <>
      <PageHeader title={admin ? 'Support tickets' : 'Support'} subtitle={admin ? 'All customer tickets.' : 'Get help from the OGHOST team.'} actions={!admin && <button className="btn-primary" onClick={() => setOpen(true)}>New ticket</button>} />
      <div className="mb-4 flex flex-wrap items-center gap-2"><select className="input w-auto" value={status} onChange={e => setStatus(e.target.value)}><option value="">All statuses</option>{['open', 'awaiting_staff', 'awaiting_customer', 'closed'].map(s => <option key={s} value={s}>{s.replace('_', ' ')}</option>)}</select>{admin && <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={mine} onChange={e => setMine(e.target.checked)} />Assigned to me</label>}</div>
      {loading ? <Loading /> : error ? <ErrorBox error={error} onRetry={reload} /> : !data.tickets.length ? <div className="card"><Empty title="No tickets" icon={<LifeBuoy className="h-8 w-8" />} /></div> :
        <Card><Table><thead><tr><th>#</th><th>Subject</th>{admin && <th>Customer</th>}<th>Category</th><th>Priority</th><th>Status</th><th>Updated</th></tr></thead><tbody>{data.tickets.map((t: any) => <tr key={t.id}><td>{t.id}</td><td><Link className="link" to={`${base}/${t.id}`}>{t.subject}</Link><div className="text-xs text-ink-500">{t.messages} message{t.messages == 1 ? '' : 's'}</div></td>{admin && <td className="text-xs">{t.email}</td>}<td>{t.category}</td><td><Badge value={t.priority} /></td><td><Badge value={t.status} label={t.status.replace('_', ' ')} /></td><td className="text-xs">{ago(t.updated_at)}</td></tr>)}</tbody></Table></Card>}
      {open && <NewTicket categories={data?.categories || []} onClose={() => setOpen(false)} />}
    </>
  );
}
function NewTicket({ categories, onClose }: { categories: string[]; onClose: () => void }) {
  const servers = useApi<any>('/api/servers'); const nav = useNavigate(); const { busy, run } = useAction();
  const [f, setF] = useState({ subject: '', category: 'technical', priority: 'normal', serverId: '', message: '' }); const [files, setFiles] = useState<File[]>([]);
  const submit = () => run('t', async () => {
    const r = await post('/api/tickets', { ...f, serverId: f.serverId ? Number(f.serverId) : null });
    for (const file of files) await upload(`/api/tickets/${r.id}/messages/${r.messageId}/attachments?filename=${encodeURIComponent(file.name)}`, file, undefined, 'POST');
    nav(`/tickets/${r.id}`);
  }, 'Ticket created');
  return (
    <Modal open onClose={onClose} title="New support ticket" wide footer={<><button className="btn-secondary" onClick={onClose}>Cancel</button><button className="btn-primary" disabled={!!busy || f.subject.length < 3 || !f.message.trim()} onClick={submit}>{busy && <Spinner />}Submit</button></>}>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Subject" className="sm:col-span-2"><input className="input" value={f.subject} maxLength={200} onChange={e => setF({ ...f, subject: e.target.value })} /></Field>
        <Field label="Category"><select className="input" value={f.category} onChange={e => setF({ ...f, category: e.target.value })}>{(categories.length ? categories : ['billing', 'technical', 'server', 'security', 'abuse', 'sales', 'other']).map(c => <option key={c} value={c}>{c}</option>)}</select></Field>
        <Field label="Priority"><select className="input" value={f.priority} onChange={e => setF({ ...f, priority: e.target.value })}>{['low', 'normal', 'high', 'urgent'].map(c => <option key={c}>{c}</option>)}</select></Field>
        <Field label="Related server" className="sm:col-span-2"><select className="input" value={f.serverId} onChange={e => setF({ ...f, serverId: e.target.value })}><option value="">None</option>{servers.data?.servers?.map((s: any) => <option key={s.id} value={s.id}>{s.name} (Node {s.node_id} / #{s.node_server_id})</option>)}</select></Field>
        <Field label="Message" className="sm:col-span-2"><textarea className="input min-h-36" value={f.message} onChange={e => setF({ ...f, message: e.target.value })} /></Field>
        <Field label="Attachments" hint="Images, PDF, text and log files up to 10 MB, max 5." className="sm:col-span-2"><input type="file" multiple className="text-sm" onChange={e => setFiles(Array.from(e.target.files || []).slice(0, 5))} /></Field>
      </div>
    </Modal>
  );
}
export function TicketDetail({ admin = false }: { admin?: boolean }) {
  const { id } = useParams(); const { data, error, loading, reload } = useApi<any>(`/api/tickets/${id}`, [id], 20000); const { busy, run } = useAction();
  const [msg, setMsg] = useState(''); const [files, setFiles] = useState<File[]>([]);
  if (loading) return <Loading />; if (error) return <ErrorBox error={error} />;
  const t = data.ticket; const staff = data.staff && admin;
  const send = () => run('send', async () => { const r = await post(`/api/tickets/${t.id}/messages`, { message: msg }); for (const f of files) await upload(`/api/tickets/${t.id}/messages/${r.id}/attachments?filename=${encodeURIComponent(f.name)}`, f, undefined, 'POST'); setMsg(''); setFiles([]); reload(); });
  const upd = (b: any) => run('upd', () => patch(`/api/tickets/${t.id}`, b).then(reload), 'Ticket updated');
  return (
    <>
      <PageHeader title={<>#{t.id} · {t.subject}</>} subtitle={<span className="flex flex-wrap items-center gap-2"><Badge value={t.status} label={t.status.replace('_', ' ')} /><Badge value={t.priority} />{t.category}{t.server_id && <Link className="link" to={`/server/${t.server_id}`}>Server #{t.server_id}</Link>}</span>}
        actions={<>{t.status !== 'closed' ? <button className="btn-secondary btn-sm" onClick={() => upd({ status: 'closed' })}>Close ticket</button> : <button className="btn-secondary btn-sm" onClick={() => upd({ status: staff ? 'open' : 'awaiting_staff' })}>Reopen</button>}</>} />
      {staff && <Card className="mb-4"><div className="flex flex-wrap gap-4"><Field label="Status"><select className="input" value={t.status} onChange={e => upd({ status: e.target.value })}>{['open', 'awaiting_staff', 'awaiting_customer', 'closed'].map(s => <option key={s} value={s}>{s.replace('_', ' ')}</option>)}</select></Field><Field label="Priority"><select className="input" value={t.priority} onChange={e => upd({ priority: e.target.value })}>{['low', 'normal', 'high', 'urgent'].map(s => <option key={s}>{s}</option>)}</select></Field><Field label="Assigned to"><select className="input" value={t.assigned_to || ''} onChange={e => upd({ assignedTo: e.target.value ? Number(e.target.value) : null })}><option value="">Unassigned</option>{data.staffUsers?.map((u: any) => <option key={u.id} value={u.id}>{u.username}</option>)}</select></Field></div></Card>}
      <div className="space-y-3">{data.messages.map((m: any) => (
        <div key={m.id} className={cls('card card-pad', m.is_staff ? 'border-brand-900/70 bg-brand-950/20' : '')}>
          <div className="mb-2 flex items-center gap-2 text-sm"><span className="font-semibold text-white">{m.name || m.username}</span>{!!m.is_staff && <span className="badge bg-brand-900/60 text-brand-300">Staff</span>}<span className="text-xs text-ink-500">{date(m.created_at)}</span></div>
          <div className="whitespace-pre-wrap break-words text-sm text-zinc-200">{m.body}</div>
          {m.attachments.length > 0 && <div className="mt-3 flex flex-wrap gap-2">{m.attachments.map((a: any) => <a key={a.id} className="btn-secondary btn-sm" href={`/api/tickets/${t.id}/attachments/${a.id}`}><Paperclip className="h-3.5 w-3.5" />{a.filename} <span className="text-ink-500">{bytes(a.size_bytes)}</span></a>)}</div>}
        </div>))}</div>
      {t.status === 'closed' && !staff ? <Notice className="mt-4">This ticket is closed. Reopen it to reply.</Notice> :
        <Card className="mt-4" title="Reply"><textarea className="input min-h-28" value={msg} onChange={e => setMsg(e.target.value)} placeholder="Write a reply…" /><div className="mt-3 flex flex-wrap items-center justify-between gap-2"><input type="file" multiple className="text-sm" onChange={e => setFiles(Array.from(e.target.files || []).slice(0, 5))} /><button className="btn-primary" disabled={!msg.trim() || !!busy} onClick={send}>{busy === 'send' ? <Spinner /> : <Send className="h-4 w-4" />}Send</button></div></Card>}
    </>
  );
}
