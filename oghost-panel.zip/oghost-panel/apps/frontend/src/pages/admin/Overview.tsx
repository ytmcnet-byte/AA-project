import { Link } from 'react-router-dom';
import { Activity, AlertTriangle, CreditCard, HardDrive, LifeBuoy, Server, ShieldAlert, Users } from 'lucide-react';
import { useApi } from '../../lib/hooks';
import { ago, bytes, money, pct } from '../../lib/format';
import { Badge, Bar, Card, Empty, ErrorBox, Loading, Notice, PageHeader, Stat, Table } from '../../components/ui';

/** Small dependency-free bar chart for the last 30 days. Values come straight from the API. */
export function DayBars({ points, format = (v: number) => String(v) }: { points: Array<{ day: string; v: number }>; format?: (v: number) => string }) {
  const days: Array<{ day: string; v: number }> = [];
  for (let i = 29; i >= 0; i--) { const d = new Date(Date.now() - i * 86400000).toISOString().slice(0, 10); days.push({ day: d, v: points.filter(p => String(p.day).slice(0, 10) === d).reduce((a, p) => a + p.v, 0) }); }
  const max = Math.max(1, ...days.map(d => d.v)); const total = days.reduce((a, d) => a + d.v, 0);
  return <div><div className="mb-2 text-sm text-ink-400">Last 30 days: <span className="font-semibold text-ink-100">{format(total)}</span></div>
    <svg viewBox="0 0 300 80" className="h-24 w-full" preserveAspectRatio="none">{days.map((d, i) => { const h = (d.v / max) * 76; return <rect key={d.day} x={i * 10 + 1} y={80 - h} width={8} height={Math.max(h, d.v ? 1 : 0.5)} rx={1.5} className={d.v ? 'fill-brand-600' : 'fill-ink-700'}><title>{`${d.day}: ${format(d.v)}`}</title></rect>; })}</svg></div>;
}

export function AdminOverview() {
  const { data: d, error, loading, reload } = useApi<any>('/api/admin/overview', [], 15000);
  if (loading) return <Loading />; if (error) return <ErrorBox error={error} onRetry={reload} />;
  const rev = (rows: any[]) => rows.length ? rows.map(r => money(r.cents, r.currency)).join(' + ') : money(0);
  const cur = d.revenueDaily[0]?.currency || 'INR';
  return <>
    <PageHeader title="Overview" subtitle="Live figures from the database and node heartbeats. Refreshes every 15 seconds." />
    {(d.securityOpen > 0 || d.securityPendingReviews > 0) && <Notice kind="error" className="mb-4"><Link to="/admin/security" className="font-semibold underline">OGHOST Security Center</Link>: {d.securityOpen} open incident(s), {d.securityPendingReviews} file(s) awaiting review.</Notice>}
    {d.failedJobs24h > 0 && <Notice kind="warn" className="mb-4">{d.failedJobs24h} background job(s) failed in the last 24 hours. <Link to="/admin/jobs" className="underline">View jobs</Link></Notice>}
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
      <Stat label="Users" value={d.users} sub={`${d.usersLast30d} new in 30 days`} icon={<Users className="h-4 w-4" />} />
      <Stat label="Servers" value={d.servers} sub={`${d.serversRunning} running · ${d.serversSuspended} suspended`} icon={<Server className="h-4 w-4" />} />
      <Stat label="Nodes online" value={`${d.nodesOnline} / ${d.nodes.length}`} icon={<HardDrive className="h-4 w-4" />} />
      <Stat label="Revenue (30 days)" value={rev(d.revenue30d)} sub={`All time: ${rev(d.revenueAll)}`} icon={<CreditCard className="h-4 w-4" />} />
      <Stat label="Active services" value={d.activeServices} sub={`${d.pendingOrders} pending orders`} icon={<Activity className="h-4 w-4" />} />
      <Stat label="Unpaid invoices" value={d.unpaidInvoices} sub={<Link className="link" to="/admin/orders?tab=payments">{d.paymentsAwaitingApproval} payment(s) awaiting approval</Link>} icon={<AlertTriangle className="h-4 w-4" />} />
      <Stat label="Open tickets" value={d.openTickets} icon={<LifeBuoy className="h-4 w-4" />} />
      <Stat label="Security" value={d.securityOpen} sub={`open incidents · ${d.backups} completed backups`} icon={<ShieldAlert className="h-4 w-4" />} />
    </div>
    <div className="mt-6 grid gap-6 lg:grid-cols-2">
      <Card title="Sign-ups"><DayBars points={d.signups.map((s: any) => ({ day: s.day, v: Number(s.c) }))} /></Card>
      <Card title={`Revenue (${cur})`}><DayBars points={d.revenueDaily.filter((r: any) => r.currency === cur).map((r: any) => ({ day: r.day, v: Number(r.cents) }))} format={v => money(v, cur)} /></Card>
    </div>
    <Card title="Nodes" className="mt-6" actions={<Link to="/admin/nodes" className="btn-secondary btn-sm">Manage</Link>}>
      {!d.nodes.length ? <Empty title="No nodes yet"><Link className="link" to="/admin/nodes">Add a node</Link> to start hosting servers.</Empty> :
        <Table><thead><tr><th>Node</th><th>Status</th><th>CPU</th><th>Memory</th><th>Disk</th><th>Agent</th><th>Heartbeat</th></tr></thead><tbody>{d.nodes.map((n: any) => <tr key={n.id}>
          <td><Link className="link" to={`/admin/nodes/${n.id}`}>{n.name}</Link><div className="text-xs text-ink-400">#{n.id}</div></td>
          <td><Badge value={n.emergency ? 'high_risk' : n.maintenance ? 'suspicious' : n.status} label={n.emergency ? 'emergency' : n.maintenance ? 'maintenance' : n.status} /></td>
          <td className="w-32">{n.cpu == null ? '—' : <>{pct(n.cpu)} <span className="text-xs text-ink-400">of {n.cores} cores</span><Bar value={n.cpu} max={100} /></>}</td>
          <td className="w-40">{n.memTotal == null ? '—' : <>{bytes(n.memUsed)} / {bytes(n.memTotal)}<Bar value={n.memUsed} max={n.memTotal} /></>}</td>
          <td className="w-40">{n.diskTotal == null ? '—' : <>{bytes(n.diskUsed)} / {bytes(n.diskTotal)}<Bar value={n.diskUsed} max={n.diskTotal} /></>}</td>
          <td className="text-xs">{n.version ? `v${n.version} · ${n.arch}` : '—'}</td><td className="text-xs">{ago(n.lastHeartbeatAt)}</td></tr>)}</tbody></Table>}
    </Card>
    <Card title="Server states" className="mt-6"><div className="flex flex-wrap gap-2">{d.serverStates.length ? d.serverStates.map((s: any) => <Link key={s.state} to={`/admin/servers?state=${s.state}`}><Badge value={s.state} label={`${s.state.replace(/_/g, ' ')}: ${s.c}`} /></Link>) : <span className="text-sm text-ink-400">No servers yet.</span>}</div></Card>
  </>;
}
