import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';

const ROOT = process.env.OGHOST_ROOT || process.cwd();
function loadEnv(file: string) {
  if (!fs.existsSync(file)) return;
  for (const line of fs.readFileSync(file, 'utf8').split('\n')) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/); if (!m) continue;
    if (process.env[m[1]] === undefined) process.env[m[1]] = m[2].replace(/^["']|["']$/g, '');
  }
}
loadEnv(process.env.OGHOST_ENV_FILE || path.join(ROOT, '.env'));
const e = (k: string, d = '') => process.env[k] ?? d;
const expand = (p: string) => p.replace(/^~(?=$|\/)/, os.homedir());

export const config = {
  root: ROOT,
  env: e('NODE_ENV', 'production'),
  appUrl: e('APP_URL', 'http://localhost:8080').replace(/\/$/, ''),
  host: e('HOST', '0.0.0.0'),
  port: Number(e('PORT', '8080')),
  trustProxy: e('TRUST_PROXY', 'loopback'),
  appKey: e('APP_KEY'),
  sessionHours: Number(e('SESSION_TTL_HOURS', '72')),
  db: { host: e('DB_HOST', '127.0.0.1'), port: Number(e('DB_PORT', '3306')), user: e('DB_USER', 'oghost'), password: e('DB_PASSWORD'), database: e('DB_NAME', 'oghost'), socketPath: e('DB_SOCKET') || undefined },
  dataRoot: path.resolve(expand(e('DATA_ROOT', path.join(ROOT, '.server')))),
  frontendDir: path.resolve(expand(e('FRONTEND_DIR', path.join(ROOT, 'apps/frontend/dist')))),
  extensionsDir: path.resolve(expand(e('EXTENSIONS_DIR', path.join(ROOT, 'extensions')))),
  uploadsDir: path.resolve(expand(e('UPLOADS_DIR', path.join(ROOT, '.server/metadata/uploads')))),
  migrationsDir: path.resolve(expand(e('MIGRATIONS_DIR', path.join(ROOT, 'database/migrations')))),
  nodeOfflineSeconds: Number(e('NODE_OFFLINE_SECONDS', '60')),
  devMailLog: e('MAIL_LOG_ONLY', '') === '1',
  driveApiBase: e('GOOGLE_DRIVE_API_BASE', 'https://www.googleapis.com'),
  googleOauthBase: e('GOOGLE_OAUTH_BASE', 'https://oauth2.googleapis.com'),
  /** Overridable for tests only (tests/mocks). */
  linkvertiseApiBase: e('LINKVERTISE_API_BASE', 'https://publisher.linkvertise.com'),
  discordApiBase: e('DISCORD_API_BASE', 'https://discord.com'),
  linkvertiseLinkBase: e('LINKVERTISE_LINK_BASE', 'https://link-to.net'),
  googleAuthUrl: e('GOOGLE_AUTH_URL', 'https://accounts.google.com/o/oauth2/v2/auth'),
};
export const isSecure = () => config.appUrl.startsWith('https://');
if (!config.appKey || config.appKey.length < 32) {
  if (process.argv[2] !== 'keygen') { console.error('[panel] APP_KEY is missing or too short. Run: node dist/panel.mjs keygen'); process.exit(1); }
}
fs.mkdirSync(config.dataRoot, { recursive: true, mode: 0o750 });
for (const d of ['nodes', 'backups', 'temporary', 'metadata']) fs.mkdirSync(path.join(config.dataRoot, d), { recursive: true, mode: 0o750 });
fs.mkdirSync(config.uploadsDir, { recursive: true, mode: 0o750 });
