import type { Request, Response, NextFunction } from 'express';
import bcrypt from 'bcryptjs';
import { randomToken, sha256, safeEqual } from '@oghost/shared';
import { one, exec, parse } from '../db';
import { config, isSecure } from '../config';
import { HttpError, forbidden } from './http';
import { getSetting } from '../services/settings';

export const COOKIE = 'oghost_session';
export interface AuthUser { id: number; uuid: string; email: string; username: string; name: string | null; avatar_url: string | null; role_id: number; role_slug: string; role_name: string; permissions: string[]; email_verified: boolean; totp_enabled: boolean; firebase_uid: string | null; has_password: boolean; }
declare global { namespace Express { interface Request { user?: AuthUser; sessionId?: string; csrf?: string; apiKey?: { id: number; scopes: string[] }; twoFactorPending?: boolean; } } }

export const hashPassword = (p: string) => bcrypt.hash(p, 12);
export const verifyPassword = (p: string, h: string | null) => (h ? bcrypt.compare(p, h) : Promise.resolve(false));
export function passwordPolicy(p: string) { if (p.length < 10) throw new HttpError(422, 'Password must be at least 10 characters'); if (!/[A-Za-z]/.test(p) || !/[0-9]/.test(p)) throw new HttpError(422, 'Password must contain letters and numbers'); }

export async function createSession(req: Request, res: Response, userId: number, twoFactorPending = false) {
  const token = randomToken(32); const id = sha256(token); const csrf = randomToken(32);
  const expires = new Date(Date.now() + (twoFactorPending ? 10 * 60_000 : config.sessionHours * 3600_000));
  await exec('INSERT INTO sessions (id, user_id, csrf_token, ip, user_agent, two_factor_pending, expires_at) VALUES (?, ?, ?, ?, ?, ?, ?)', [id, userId, csrf, req.ip, String(req.headers['user-agent'] || '').slice(0, 300), twoFactorPending ? 1 : 0, expires]);
  res.cookie(COOKIE, token, { httpOnly: true, secure: isSecure(), sameSite: 'lax', path: '/', expires });
  return { id, csrf };
}
export async function destroySession(req: Request, res: Response) {
  if (req.sessionId) await exec('DELETE FROM sessions WHERE id = ?', [req.sessionId]);
  res.clearCookie(COOKIE, { path: '/' });
}

const USER_SQL = `SELECT u.id, u.uuid, u.email, u.username, u.name, u.avatar_url, u.role_id, u.email_verified_at, u.totp_enabled, u.firebase_uid, u.password_hash IS NOT NULL AS has_password, u.suspended, r.slug AS role_slug, r.name AS role_name, r.permissions FROM users u JOIN roles r ON r.id = u.role_id WHERE u.id = ?`;
export async function loadUserById(id: number): Promise<AuthUser | null> {
  const u: any = await one(USER_SQL, [id]); if (!u || u.suspended) return null;
  return { id: u.id, uuid: u.uuid, email: u.email, username: u.username, name: u.name, avatar_url: u.avatar_url, role_id: u.role_id, role_slug: u.role_slug, role_name: u.role_name, permissions: parse(u.permissions, []), email_verified: !!u.email_verified_at, totp_enabled: !!u.totp_enabled, firebase_uid: u.firebase_uid, has_password: !!u.has_password };
}

/** Resolves the caller from the session cookie or an API key (Authorization: Bearer ogh_...). */
export async function authenticate(req: Request, _res: Response, next: NextFunction) {
  try {
    const authz = String(req.headers.authorization || '');
    if (authz.startsWith('Bearer ogh_')) {
      const key = authz.slice(7); const [, prefix, secret] = key.split('_');
      const row: any = prefix && secret ? await one('SELECT * FROM api_keys WHERE prefix = ?', [prefix]) : null;
      if (!row || !safeEqual(row.key_hash, sha256(secret)) || (row.expires_at && new Date(row.expires_at) < new Date())) throw new HttpError(401, 'Invalid API key');
      const ips = parse<string[] | null>(row.allowed_ips, null); if (ips?.length && !ips.includes(req.ip || '')) throw new HttpError(403, 'API key not allowed from this IP');
      const user = await loadUserById(row.user_id); if (!user) throw new HttpError(401, 'API key owner is disabled');
      req.user = user; req.apiKey = { id: row.id, scopes: parse(row.scopes, []) };
      exec('UPDATE api_keys SET last_used_at = NOW() WHERE id = ?', [row.id]).catch(() => {});
      return next();
    }
    const token = req.cookies?.[COOKIE];
    if (token) {
      const s: any = await one('SELECT * FROM sessions WHERE id = ? AND expires_at > NOW()', [sha256(token)]);
      if (s) {
        const user = await loadUserById(s.user_id);
        if (user) {
          req.sessionId = s.id; req.csrf = s.csrf_token; req.twoFactorPending = !!s.two_factor_pending;
          if (!s.two_factor_pending) req.user = user; else (req as any).pendingUser = user;
          if (Date.now() - new Date(s.last_seen_at).getTime() > 5 * 60_000) exec('UPDATE sessions SET last_seen_at = NOW(), ip = ? WHERE id = ?', [req.ip, s.id]).catch(() => {});
        }
      }
    }
    next();
  } catch (e) { next(e); }
}

/** CSRF: cookie-authenticated state-changing requests must echo the per-session token in X-CSRF-Token. */
export function csrf(req: Request, _res: Response, next: NextFunction) {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method) || req.apiKey || !req.sessionId) return next();
  const t = String(req.headers['x-csrf-token'] || '');
  if (!req.csrf || !safeEqual(t, req.csrf)) return next(new HttpError(419, 'CSRF token mismatch. Refresh the page.'));
  next();
}

export function requireAuth(req: Request, _res: Response, next: NextFunction) { if (!req.user) return next(new HttpError(401, 'Authentication required')); next(); }
export async function requireVerified(req: Request, _res: Response, next: NextFunction) {
  if (!req.user) return next(new HttpError(401, 'Authentication required'));
  if (!req.user.email_verified && (await getSetting('app.requireEmailVerification'))) return next(new HttpError(403, 'Please verify your email address first', { code: 'EMAIL_UNVERIFIED' }));
  next();
}
/** A permission implies its children: 'admin.users' grants 'admin.users.read'; 'admin.*' grants every admin permission. */
export const hasPerm = (u: AuthUser | undefined, perm: string) => {
  if (!u) return false; const P = u.permissions; if (P.includes('*') || P.includes(perm)) return true;
  const parts = perm.split('.'); for (let i = parts.length - 1; i >= 1; i--) { const pre = parts.slice(0, i).join('.'); if ((i >= 2 && P.includes(pre)) || P.includes(pre + '.*')) return true; }
  return false;
};
export const isAdmin = (u?: AuthUser) => !!u && u.permissions.some(p => p === '*' || p.startsWith('admin.'));
export function scopeOk(req: Request, scope: string) { if (!req.apiKey) return true; const s = req.apiKey.scopes; return s.includes('*') || s.includes(scope) || s.includes(scope.split('.')[0] + '.*'); }
export const requirePerm = (perm: string) => (req: Request, _res: Response, next: NextFunction) => {
  if (!req.user) return next(new HttpError(401, 'Authentication required'));
  if (!hasPerm(req.user, perm)) return next(forbidden());
  if (!scopeOk(req, perm)) return next(forbidden('API key lacks the required scope'));
  next();
};
export const requireScope = (scope: string) => (req: Request, _res: Response, next: NextFunction) => (scopeOk(req, scope) ? next() : next(forbidden(`API key lacks scope ${scope}`)));

export const ADMIN_PERMISSIONS = ['admin.overview', 'admin.users', 'admin.users.read', 'admin.roles', 'admin.servers', 'admin.nodes', 'admin.eggs', 'admin.plugins', 'admin.extensions', 'admin.store', 'admin.orders', 'admin.payments', 'admin.settings', 'admin.security', 'admin.audit', 'admin.tickets', 'admin.announcements', 'admin.databases', 'admin.apikeys', 'admin.drive', 'admin.coins'];
export const SERVER_PERMISSIONS = ['control.console', 'control.start', 'control.stop', 'control.restart', 'file.read', 'file.write', 'file.delete', 'file.archive', 'file.sftp', 'backup.read', 'backup.create', 'backup.restore', 'backup.delete', 'backup.download', 'schedule.read', 'schedule.manage', 'database.read', 'database.manage', 'database.view_password', 'allocation.read', 'allocation.manage', 'startup.read', 'startup.update', 'startup.java', 'startup.version', 'plugin.read', 'plugin.manage', 'settings.rename', 'settings.reinstall', 'user.read', 'user.manage', 'activity.read', 'drive.manage'];

/** Coarse API-key scope gate per API area (fine-grained permission checks still run inside every route). */
export function apiKeyGate(req: Request, _res: Response, next: NextFunction) {
  if (!req.apiKey) return next();
  const p = req.originalUrl.split('?')[0]; const w = !['GET', 'HEAD', 'OPTIONS'].includes(req.method) ? 'write' : 'read';
  const area = p.split('/')[2] || '';
  let scope: string | null = null;
  if (area === 'servers') scope = /^\/api\/servers\/\d+\/files\//.test(p) ? `files.${w}` : `servers.${w}`;
  else if (area === 'store') scope = `store.${w}`;
  else if (area === 'tickets') scope = `tickets.${w}`;
  else if (area === 'coins') scope = `coins.${w}`;
  else if (area === 'extensions') scope = `extensions.${w}`;
  else if (area === 'admin') scope = 'admin.*';
  else if (area === 'auth' && p === '/api/auth/me' && w === 'read') return next();
  else if (area === 'account' && w === 'read' && p === '/api/account/notifications') return next();
  else if (area === 'docs' || area === 'announcements') return next();
  else return next(forbidden('API keys cannot be used for this endpoint (use a browser session)'));
  if (scope === 'admin.*') { const s = req.apiKey.scopes; if (!s.includes('*') && !s.some(x => x.startsWith('admin'))) return next(forbidden('API key lacks admin scope')); return next(); }
  return scopeOk(req, scope) ? next() : next(forbidden(`API key lacks scope ${scope}`));
}
