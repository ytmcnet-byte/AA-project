#!/usr/bin/env bash
# OGHOST launcher (non-root). Usage: scripts/run.sh panel|agent
# - panel: reads <root>/.env (or $OGHOST_ENV_FILE)
# - agent: reads ~/oghost-agent/agent.env (or $AGENT_ENV_FILE)
# Private CA support: Node's fetch only trusts extra CAs given at process start, so this
# launcher exports NODE_EXTRA_CA_CERTS from PANEL_CA (agent) or NODE_CA_FILE (panel).
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
what="${1:-}"
getv() { [ -f "$2" ] && sed -n "s/^[[:space:]]*$1[[:space:]]*=[[:space:]]*//p" "$2" | tail -n1 | sed -e 's/^["'\'']//' -e 's/["'\'']$//' -e "s|^~|$HOME|" || true; }
case "$what" in
  panel)
    export OGHOST_ROOT="$ROOT"; ENVF="${OGHOST_ENV_FILE:-$ROOT/.env}"; export OGHOST_ENV_FILE="$ENVF"
    ca="$(getv NODE_CA_FILE "$ENVF")"; [ -n "$ca" ] && export NODE_EXTRA_CA_CERTS="$ca"
    cd "$ROOT"; exec node dist/panel.mjs serve ;;
  agent)
    ENVF="${AGENT_ENV_FILE:-$HOME/oghost-agent/agent.env}"; export AGENT_ENV_FILE="$ENVF"
    [ -f "$ENVF" ] || { echo "[agent] $ENVF not found. Run: bash installer/install.sh --agent" >&2; exit 1; }
    ca="$(getv PANEL_CA "$ENVF")"; [ -n "$ca" ] && export NODE_EXTRA_CA_CERTS="$ca"
    cd "$(dirname "$ENVF")"; exec node "$ROOT/dist/agent.mjs" ;;
  *) echo "Usage: $0 panel|agent" >&2; exit 1 ;;
esac
