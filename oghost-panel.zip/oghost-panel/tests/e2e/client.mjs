// Minimal API client for end-to-end tests against a running panel (cookie session + CSRF).
export function client(base = process.env.PANEL_URL || 'http://127.0.0.1:8080') {
  let cookie = ''; let csrf = '';
  async function call(method, path, body, opts = {}) {
    const headers = { ...(opts.headers || {}) };
    if (cookie) headers.cookie = cookie;
    if (csrf && method !== 'GET') headers['x-csrf-token'] = csrf;
    let payload;
    if (body !== undefined && !(body instanceof Buffer)) { headers['content-type'] = 'application/json'; payload = JSON.stringify(body); } else payload = body;
    const r = await fetch(base + path, { method, headers, body: payload, redirect: 'manual' });
    const sc = r.headers.get('set-cookie'); if (sc) cookie = sc.split(';')[0];
    const ct = r.headers.get('content-type') || '';
    const data = ct.includes('json') ? await r.json() : opts.raw ? Buffer.from(await r.arrayBuffer()) : await r.text();
    if (!r.ok && !opts.allowError) throw Object.assign(new Error(`${method} ${path} -> ${r.status}: ${JSON.stringify(data)}`), { status: r.status, data });
    return opts.allowError ? { status: r.status, data } : data;
  }
  return {
    call, get: (p, o) => call('GET', p, undefined, o), post: (p, b, o) => call('POST', p, b ?? {}, o), put: (p, b, o) => call('PUT', p, b, o), patch: (p, b, o) => call('PATCH', p, b, o), del: (p, o) => call('DELETE', p, undefined, o),
    async login(login, password) { await call('POST', '/api/auth/login', { login, password }); const me = await call('GET', '/api/auth/me'); csrf = me.csrf; return me; },
    get cookie() { return cookie; },
  };
}
export const sleep = (ms) => new Promise(r => setTimeout(r, ms));
export async function waitFor(fn, { timeout = 60000, interval = 1000, label = 'condition' } = {}) {
  const t0 = Date.now(); let last;
  while (Date.now() - t0 < timeout) { try { last = await fn(); if (last) return last; } catch (e) { last = e; } await sleep(interval); }
  throw new Error(`Timed out waiting for ${label}: ${last?.message || JSON.stringify(last)}`);
}
