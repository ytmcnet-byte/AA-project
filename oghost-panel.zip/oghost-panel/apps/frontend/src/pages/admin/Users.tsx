import { useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { Plus, Search } from 'lucide-react';
import { useApi, useAction } from '../../lib/hooks';
import { api } from '../../lib/api';
import { ago, date } from '../../lib/format';
import { useAuth } from '../../lib/auth';
import { Badge, Card, Confirm, Empty, ErrorBox, Field, Loading, Modal, Notice, PageHeader, Pager, Spinner, Switch, Table } from '../../components/ui';

export function UsersAdmin() {
  const [page, setPage] = useState(1); const [search, setSearch] = useState(''); const nav = useNavigate();
  const { data, error, loading, reload } = useApi<any>(`/api/admin/users?page=${page}&per_page=25&search=${encodeURIComponent(search)}`);
  const roles = useApi<any>('/api/admin/roles'); const { busy, run } = useAction();
  const [create, setCreate] = useState<any>(null);
  return <><PageHeader title="Users" actions={<button className="btn-primary" onClick={() => setCreate({ email: '', username: '', name: '', roleId: roles.data?.roles?.find((r: any) => r.slug === 'customer')?.id, password: '', emailVerified: true })}><Plus className="h-4 w-4" />New user</button>} />
    <Card title={<div className="relative"><Search className="absolute left-3 top-2.5 h-4 w-4 text-ink-500" /><input className="input w-72 pl-9" placeholder="Search email, username, name or ID" value={search} onChange={e => { setSearch(e.target.value); setPage(1); }} /></div>}>
      {loading ? <Loading /> : error ? <ErrorBox error={error} onRetry={reload} /> : !data.users.length ? <Empty title="No users found" /> :
        <Table><thead><tr><th>ID</th><th>User</th><th>Role</th><th>Servers</th><th>Security</th><th>Last login</th><th>Created</th></tr></thead><tbody>{data.users.map((u: any) => <tr key={u.id} className="cursor-pointer hover:bg-ink-800/50" onClick={() => nav(`/admin/users/${u.id}`)}>
          <td>{u.id}</td><td><div className="font-semibold">{u.username}{u.suspended ? <Badge value="suspended" className="ml-2" /> : null}</div><div className="text-xs text-ink-400">{u.email}</div></td><td>{u.role_name}</td><td>{u.servers}</td>
          <td className="text-xs">{u.totp_enabled ? '2FA' : 'no 2FA'}{u.google_linked ? ' · Google' : ''}{!u.email_verified_at ? ' · unverified' : ''}</td><td className="text-xs">{ago(u.last_login_at)}</td><td className="text-xs">{date(u.created_at)}</td></tr>)}</tbody></Table>}
      <Pager page={page} setPage={setPage} hasMore={(data?.users?.length || 0) >= 25 && page * 25 < (data?.total || 0)} />
    </Card>
    <Modal open={!!create} onClose={() => setCreate(null)} title="New user" footer={<><button className="btn-secondary" onClick={() => setCreate(null)}>Cancel</button><button className="btn-primary" disabled={!!busy} onClick={() => run('c', async () => { const r = await api('POST', '/api/admin/users', { ...create, name: create.name || null, password: create.password || undefined }); setCreate(null); nav(`/admin/users/${r.id}`); }, 'User created')}>{busy && <Spinner />}Create</button></>}>
      {create && <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Email"><input className="input" type="email" value={create.email} onChange={e => setCreate({ ...create, email: e.target.value })} /></Field>
        <Field label="Username"><input className="input" value={create.username} onChange={e => setCreate({ ...create, username: e.target.value })} /></Field>
        <Field label="Name"><input className="input" value={create.name} onChange={e => setCreate({ ...create, name: e.target.value })} /></Field>
        <Field label="Role"><select className="input" value={create.roleId ?? ''} onChange={e => setCreate({ ...create, roleId: Number(e.target.value) })}>{roles.data?.roles?.map((r: any) => <option key={r.id} value={r.id}>{r.name}</option>)}</select></Field>
        <Field label="Password" hint="Leave empty for Google-only sign-in or a password reset email"><input className="input" type="password" autoComplete="new-password" value={create.password} onChange={e => setCreate({ ...create, password: e.target.value })} /></Field>
        <div className="flex items-end"><Switch checked={create.emailVerified} onChange={v => setCreate({ ...create, emailVerified: v })} label="Email verified" /></div>
      </div>}
    </Modal>
  </>;
}

export function UserDetailAdmin() {
  const { id } = useParams(); const nav = useNavigate(); const { user: me } = useAuth();
  const { data, error, loading, reload } = useApi<any>(`/api/admin/users/${id}`); const roles = useApi<any>('/api/admin/roles'); const { busy, run } = useAction();
  const [form, setForm] = useState<any>(null); const [del, setDel] = useState(false);
  if (loading) return <Loading />; if (error) return <ErrorBox error={error} onRetry={reload} />;
  const u = data.user; const f = form || { email: u.email, username: u.username, name: u.name || '', roleId: u.role_id, password: '', emailVerified: !!u.email_verified_at };
  const set = (k: string, v: any) => setForm({ ...f, [k]: v });
  const patch = (b: any, msg: string) => run('p', () => api('PATCH', `/api/admin/users/${id}`, b).then(() => { setForm(null); reload(); }), msg);
  const self = me?.id === u.id;
  return <><PageHeader title={u.username} subtitle={<>{u.email} · user #{u.id} · joined {date(u.created_at)}</>} actions={<>{u.suspended ? <button className="btn-secondary" onClick={() => patch({ suspended: false }, 'User unsuspended')}>Unsuspend</button> : !self && <button className="btn-secondary" onClick={() => patch({ suspended: true }, 'User suspended and signed out')}>Suspend</button>}{!self && <button className="btn-danger" onClick={() => setDel(true)}>Delete</button>}</>} />
    {u.suspended ? <Notice kind="error" className="mb-4">This account is suspended and cannot sign in.</Notice> : null}
    <div className="grid gap-6 lg:grid-cols-3">
      <Card title="Account" className="lg:col-span-2">
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Email"><input className="input" value={f.email} onChange={e => set('email', e.target.value)} /></Field>
          <Field label="Username"><input className="input" value={f.username} onChange={e => set('username', e.target.value)} /></Field>
          <Field label="Name"><input className="input" value={f.name} onChange={e => set('name', e.target.value)} /></Field>
          <Field label="Role"><select className="input" disabled={self} value={f.roleId} onChange={e => set('roleId', Number(e.target.value))}>{roles.data?.roles?.map((r: any) => <option key={r.id} value={r.id}>{r.name}</option>)}</select></Field>
          <Field label="New password" hint="Changing it signs the user out everywhere"><input className="input" type="password" autoComplete="new-password" value={f.password} onChange={e => set('password', e.target.value)} /></Field>
          <div className="flex items-end"><Switch checked={f.emailVerified} onChange={v => set('emailVerified', v)} label="Email verified" /></div>
        </div>
        <div className="mt-4 flex justify-end"><button className="btn-primary" disabled={!form || !!busy} onClick={() => patch({ ...f, name: f.name || null, password: f.password || undefined, roleId: f.roleId !== u.role_id ? f.roleId : undefined }, 'Saved')}>{busy && <Spinner />}Save changes</button></div>
      </Card>
      <Card title="Security">
        <dl className="space-y-2 text-sm">
          <div className="flex justify-between"><dt className="text-ink-400">Two-factor</dt><dd>{u.totp_enabled ? 'Enabled' : 'Off'}</dd></div>
          <div className="flex justify-between"><dt className="text-ink-400">Google account</dt><dd>{u.google_linked ? 'Linked' : 'Not linked'}</dd></div>
          <div className="flex justify-between"><dt className="text-ink-400">Last login</dt><dd>{ago(u.last_login_at)}</dd></div>
        </dl>
        <div className="mt-4 flex flex-wrap gap-2">{u.totp_enabled ? <button className="btn-secondary btn-sm" onClick={() => patch({ disable2fa: true }, '2FA disabled')}>Disable 2FA</button> : null}<button className="btn-secondary btn-sm" onClick={() => run('s', () => api('DELETE', `/api/admin/users/${id}/sessions`).then(reload), 'All sessions revoked')}>Sign out everywhere</button></div>
      </Card>
    </div>
    <div className="mt-6 grid gap-6 lg:grid-cols-2">
      <Card title={`Servers (${data.servers.length})`}>{!data.servers.length ? <Empty title="No servers" /> : <Table><tbody>{data.servers.map((s: any) => <tr key={s.id}><td><Link className="link" to={`/admin/servers/${s.id}`}>{s.name}</Link></td><td className="font-mono text-xs">{s.node_id}/{s.node_server_id}</td><td><Badge value={s.state} /></td></tr>)}</tbody></Table>}</Card>
      <Card title="Services">{!data.services.length ? <Empty title="No services" /> : <Table><tbody>{data.services.map((s: any) => <tr key={s.id}><td>Service #{s.id}</td><td>Plan #{s.plan_id}</td><td><Badge value={s.status} /></td><td className="text-xs">due {date(s.next_due_at)}</td></tr>)}</tbody></Table>}</Card>
      <Card title="Active sessions" className="lg:col-span-2">{!data.sessions.length ? <Empty title="No active sessions" /> : <Table><thead><tr><th>IP</th><th>Device</th><th>Last seen</th><th>Expires</th></tr></thead><tbody>{data.sessions.map((s: any) => <tr key={s.id}><td className="font-mono text-xs">{s.ip}</td><td className="max-w-md truncate text-xs">{s.user_agent}</td><td>{ago(s.last_seen_at)}</td><td className="text-xs">{date(s.expires_at)}</td></tr>)}</tbody></Table>}</Card>
    </div>
    <Confirm open={del} onClose={() => setDel(false)} danger title="Delete user" phrase={u.username} confirmLabel="Delete" busy={busy === 'd'} onConfirm={() => run('d', async () => { const r = await api('DELETE', `/api/admin/users/${id}`); nav('/admin/users'); return r; }, 'User deleted')}>
      Users who own servers must have them deleted or transferred first. If the user has invoices or tickets, personal data is anonymised and the financial records are kept.
    </Confirm>
  </>;
}
