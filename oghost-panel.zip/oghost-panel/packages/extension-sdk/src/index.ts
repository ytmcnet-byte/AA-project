/**
 * OGHOST Extension SDK.
 *
 * Extensions are inspired by Blueprint for Pterodactyl but use their own format. Pterodactyl/Blueprint packages
 * (PHP/Laravel/React) are NOT directly compatible and cannot be installed as-is; they must be ported to this SDK.
 *
 * TRUST MODEL: extension server code runs inside the panel process with the same privileges as the panel. Only
 * install extensions you trust. The permission list in the manifest restricts which SDK capabilities the context
 * exposes and is shown to the administrator before enabling, but it is not a sandbox for malicious code.
 * Extension UI pages are rendered in a sandboxed iframe and talk to their own API routes only.
 */
export const SDK_VERSION = 1;

export type ExtensionPermission = 'routes' | 'storage' | 'settings' | 'events' | 'notifications' | 'ui' | 'servers:read' | 'users:read';
export interface ExtensionSettingDef { key: string; label: string; type: 'string' | 'number' | 'boolean' | 'secret'; default?: string | number | boolean; description?: string; }
export interface ExtensionUiPage { id: string; title: string; file: string; area: 'admin' | 'client' | 'server'; icon?: string; permission?: string; }
export interface ExtensionManifest {
  identifier: string; name: string; version: string; description?: string; author?: string; website?: string;
  sdk: number; permissions: ExtensionPermission[]; server?: string; ui?: ExtensionUiPage[]; settings?: ExtensionSettingDef[];
}
export type PanelEvent = 'server.created' | 'server.deleted' | 'server.suspended' | 'invoice.paid' | 'order.created' | 'security.incident' | 'node.offline' | 'ticket.created' | 'user.registered';

/** Minimal request/response shapes (Express-compatible) so extensions do not need to depend on express types. */
export interface ExtRequest { method: string; path: string; params: Record<string, string>; query: Record<string, unknown>; body: any; user?: { id: number; email: string; username: string; permissions: string[] }; }
export interface ExtResponse { status(code: number): ExtResponse; json(data: unknown): void; send(data: unknown): void; setHeader(k: string, v: string): void; }
export type ExtHandler = (req: ExtRequest, res: ExtResponse) => unknown | Promise<unknown>;
export interface ExtRouter { get(path: string, h: ExtHandler): void; post(path: string, h: ExtHandler): void; put(path: string, h: ExtHandler): void; patch(path: string, h: ExtHandler): void; delete(path: string, h: ExtHandler): void; }

export interface ExtensionContext {
  manifest: ExtensionManifest;
  log: (...args: unknown[]) => void;
  /** Routes are mounted at /api/extensions/<identifier>/... and always require an authenticated user. */
  router: ExtRouter;
  /** Routes mounted at /api/extensions/<identifier>/admin/... which require the admin.extensions permission. */
  adminRouter: ExtRouter;
  storage: { get<T = unknown>(key: string): Promise<T | null>; set(key: string, value: unknown): Promise<void>; delete(key: string): Promise<void>; list(prefix?: string): Promise<string[]> };
  settings: { get<T = unknown>(key: string): Promise<T> };
  events: { on(event: PanelEvent, handler: (data: any) => void | Promise<void>): void };
  notifications: { notifyUser(userId: number, title: string, body: string, link?: string): Promise<void> };
  servers: { get(id: number): Promise<{ id: number; name: string; ownerId: number; nodeId: number; nodeServerId: number; state: string } | null>; listForUser(userId: number): Promise<Array<{ id: number; name: string; state: string }>> };
  users: { get(id: number): Promise<{ id: number; email: string; username: string } | null> };
}
export interface Extension { register(ctx: ExtensionContext): void | Promise<void>; unregister?(): void | Promise<void>; }
export const defineExtension = (e: Extension) => e;

const ID = /^[a-z][a-z0-9-]{1,63}$/;
const PERMS: ExtensionPermission[] = ['routes', 'storage', 'settings', 'events', 'notifications', 'ui', 'servers:read', 'users:read'];
/** Validates a manifest and returns a list of problems (empty = valid). */
export function validateManifest(m: any): string[] {
  const e: string[] = [];
  if (!m || typeof m !== 'object') return ['manifest must be an object'];
  if (!ID.test(m.identifier || '')) e.push('identifier must match ^[a-z][a-z0-9-]{1,63}$');
  if (!m.name || String(m.name).length > 100) e.push('name is required (max 100 chars)');
  if (!/^\d+\.\d+\.\d+([-+][\w.]+)?$/.test(m.version || '')) e.push('version must be semver (e.g. 1.0.0)');
  if (m.sdk !== SDK_VERSION) e.push(`sdk must be ${SDK_VERSION}`);
  if (!Array.isArray(m.permissions) || m.permissions.some((p: string) => !PERMS.includes(p as ExtensionPermission))) e.push(`permissions must be a subset of ${PERMS.join(', ')}`);
  if (m.server && (typeof m.server !== 'string' || m.server.includes('..') || m.server.startsWith('/') || !/\.(mjs|js)$/.test(m.server))) e.push('server must be a relative .mjs/.js path inside the extension');
  for (const p of m.ui || []) { if (!/^[a-z0-9-]{1,40}$/.test(p.id || '') || !p.title || typeof p.file !== 'string' || p.file.includes('..') || p.file.startsWith('/') || !['admin', 'client', 'server'].includes(p.area)) e.push(`invalid ui page ${JSON.stringify(p).slice(0, 80)}`); }
  for (const s of m.settings || []) if (!/^[a-zA-Z0-9_.-]{1,80}$/.test(s.key || '') || !['string', 'number', 'boolean', 'secret'].includes(s.type)) e.push(`invalid setting ${s.key}`);
  if (m.ui?.length && !m.permissions?.includes('ui')) e.push('ui pages require the "ui" permission');
  if (m.server && !m.permissions?.length) e.push('server code must declare at least one permission');
  return e;
}
