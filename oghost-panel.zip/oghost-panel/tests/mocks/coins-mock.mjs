// Local mock of the Linkvertise anti-bypass API and Discord OAuth2 for testing OGCoins without real accounts.
// Start the panel with LINKVERTISE_API_BASE=DISCORD_API_BASE=http://127.0.0.1:<port>.
//   Linkvertise: POST /api/v1/anti_bypassing?token=&hash=  -> "TRUE" once for an issued hash (token must match), else "FALSE"
//   Discord:     POST /api/oauth2/token (authorization_code), GET /api/users/@me, POST /api/oauth2/token/revoke
// Control: POST /__mock/lv/issue {hash} ; POST /__mock/discord/code {code, user:{id, username}} ; GET /__mock/state
import http from 'node:http';
import crypto from 'node:crypto';
export function startCoinsMock(port = 0, { lvToken = 'lv-e2e-token', discordSecret = 'dc-e2e-secret' } = {}) {
  const st = { hashes: new Set(), lvCalls: [], codes: new Map(), tokens: new Map(), revoked: [] };
  const server = http.createServer(async (req, res) => {
    const u = new URL(req.url, 'http://x'); const chunks = []; for await (const c of req) chunks.push(c); const raw = Buffer.concat(chunks).toString();
    const json = (code, b) => { res.writeHead(code, { 'content-type': 'application/json' }); res.end(JSON.stringify(b)); };
    const form = () => Object.fromEntries(new URLSearchParams(raw));
    if (u.pathname === '/__mock/state') return json(200, { lvCalls: st.lvCalls, revoked: st.revoked });
    if (u.pathname === '/__mock/lv/issue') { st.hashes.add(JSON.parse(raw).hash); return json(200, { ok: true }); }
    if (u.pathname === '/__mock/discord/code') { const b = JSON.parse(raw); st.codes.set(b.code, b.user); return json(200, { ok: true }); }
    if (u.pathname === '/api/v1/anti_bypassing' && req.method === 'POST') {
      const token = u.searchParams.get('token'); const hash = u.searchParams.get('hash'); st.lvCalls.push(hash);
      const ok = token === lvToken && st.hashes.delete(hash); // single use, like the real API
      res.writeHead(200, { 'content-type': 'text/plain' }); return res.end(ok ? 'TRUE' : 'FALSE');
    }
    if (u.pathname === '/api/oauth2/token' && req.method === 'POST') {
      const f = form(); if (f.client_secret !== discordSecret || f.grant_type !== 'authorization_code') return json(401, { error: 'invalid_client' });
      const user = st.codes.get(f.code); if (!user) return json(400, { error: 'invalid_grant' }); st.codes.delete(f.code);
      const at = 'dc-at-' + crypto.randomBytes(8).toString('hex'); st.tokens.set(at, user);
      return json(200, { access_token: at, token_type: 'Bearer', expires_in: 604800, scope: 'identify' });
    }
    if (u.pathname === '/api/oauth2/token/revoke') { const t = form().token; st.revoked.push(t); st.tokens.delete(t); return json(200, {}); }
    if (u.pathname === '/api/users/@me') { const user = st.tokens.get((req.headers.authorization || '').replace(/^Bearer /, '')); return user ? json(200, user) : json(401, { message: '401: Unauthorized' }); }
    json(404, { error: 'not found' });
  });
  return new Promise(r => server.listen(port, '127.0.0.1', () => r({ port: server.address().port, state: st, close: () => new Promise(x => server.close(x)) })));
}
