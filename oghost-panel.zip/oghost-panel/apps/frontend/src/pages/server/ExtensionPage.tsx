import { useEffect, useRef, useState } from 'react';
import { useParams } from 'react-router-dom';
import { api } from '../../lib/api';
import { useAuth } from '../../lib/auth';
import { Notice } from '../../components/ui';
import { useServer } from './ServerLayout';

/** Hosts an extension UI page in a sandboxed iframe (opaque origin, no direct network access).
 * The only capability granted is a request relay restricted to /api/extensions/<identifier>/... */
export function ExtensionFrame({ identifier, page, context }: { identifier: string; page: { file: string; title: string }; context: Record<string, unknown> }) {
  const ref = useRef<HTMLIFrameElement>(null);
  useEffect(() => {
    const onMsg = async (e: MessageEvent) => {
      if (e.source !== ref.current?.contentWindow) return; const d = e.data || {};
      const reply = (m: any) => ref.current?.contentWindow?.postMessage(m, '*');
      if (d.type === 'oghost:ready') reply({ type: 'oghost:context', context });
      if (d.type === 'oghost:request') {
        const path = String(d.path || ''); const method = String(d.method || 'GET').toUpperCase();
        if (!/^\/[A-Za-z0-9/_\-.?=&%]*$/.test(path) || path.includes('..') || !['GET', 'POST', 'PUT', 'PATCH', 'DELETE'].includes(method)) return reply({ type: 'oghost:response', id: d.id, ok: false, error: 'Invalid request' });
        try { const data = await api(method, `/api/extensions/${encodeURIComponent(identifier)}${path}`, method === 'GET' ? undefined : d.body ?? {}); reply({ type: 'oghost:response', id: d.id, ok: true, data }); }
        catch (err: any) { reply({ type: 'oghost:response', id: d.id, ok: false, error: err.message }); }
      }
    };
    window.addEventListener('message', onMsg); return () => window.removeEventListener('message', onMsg);
  }, [identifier, JSON.stringify(context)]);
  return <iframe ref={ref} title={page.title} src={`/extensions-ui/${encodeURIComponent(identifier)}/${page.file}`} sandbox="allow-scripts allow-forms" className="h-[70vh] w-full rounded-xl border border-ink-800 bg-ink-900" referrerPolicy="no-referrer" />;
}

export function useExtensionPages(identifier: string) {
  const [pages, setPages] = useState<any[] | null>(null);
  useEffect(() => { api('GET', '/api/extensions').then((r: any) => setPages(r.extensions.find((e: any) => e.identifier === identifier)?.ui || [])).catch(() => setPages([])); }, [identifier]);
  return pages;
}

export function ServerExtensionPage() {
  const { identifier, pageId } = useParams(); const { server } = useServer(); const { user } = useAuth();
  const pages = useExtensionPages(identifier!); const page = pages?.find((p: any) => p.id === pageId);
  if (pages && !page) return <Notice kind="warn">This extension page is not available.</Notice>;
  if (!page) return null;
  return <ExtensionFrame identifier={identifier!} page={page} context={{ area: 'server', serverId: server.id, serverName: server.name, nodeId: server.nodeId, nodeServerId: server.nodeServerId, userId: user?.id, username: user?.username }} />;
}
