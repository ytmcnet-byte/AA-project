import fs from 'node:fs';
import path from 'node:path';
import { EventEmitter } from 'node:events';
import { spawn, execFile, type ChildProcess } from 'node:child_process';
import { renderStartup, pickJava, requiredJavaFor, type AgentServerSpec, type ServerState, safeResolve } from '@oghost/shared';
import { config, serverDir, dirs } from './config';
import { DiskAccount, fmt } from './disk';
import { CpuSampler, processTree } from './procfs';
import { detectCpulimit, javaList } from './java';
import { runInstaller } from './installer';
import { report } from './reporter';
import { quotaHook, type QuotaResult } from './quota';
import { preStartScan } from './security';

const sampler = new CpuSampler();
let cpulimitFlags: { children: string | null } | null = null;
async function cpulimitInfo(bin: string) {
  if (cpulimitFlags) return cpulimitFlags;
  const help: string = await new Promise(r => execFile(bin, ['--help'], { timeout: 3000 }, (_e, o, er) => r(`${o}${er}`)));
  cpulimitFlags = { children: /--monitor-forks/.test(help) ? '-m' : /--include-children/.test(help) ? '-i' : null };
  return cpulimitFlags;
}

export class ServerInstance extends EventEmitter {
  state: ServerState = 'offline';
  proc: ChildProcess | null = null;
  cpulimitProc: ChildProcess | null = null;
  console: string[] = [];
  disk: DiskAccount;
  stats = { cpu: 0, memory: 0, diskBytes: 0, startedAt: 0, processes: 0 };
  private stopRequested = false; private killTimer: NodeJS.Timeout | null = null;
  private crashes: number[] = []; oomDetected = false; lastExit: { code: number | null; signal: string | null; at: number; reason: string } | null = null;
  busy: string | null = null; // install / backup / restore / version-change lock

  constructor(public spec: AgentServerSpec) {
    super(); this.setMaxListeners(100);
    fs.mkdirSync(this.dir, { recursive: true, mode: 0o750 });
    this.disk = new DiskAccount(this.dir, spec.diskMb * 1024 * 1024);
    this.disk.rescan().then(n => (this.stats.diskBytes = n));
  }
  get id() { return this.spec.id; }
  get dir() { return serverDir(this.spec.id); }
  get pid() { return this.proc?.pid ?? null; }

  quota: QuotaResult | null = null; private quotaMb = -1;
  updateSpec(spec: AgentServerSpec) {
    if (spec.diskMb !== this.quotaMb) { this.quotaMb = spec.diskMb; void quotaHook('set', spec.id, this.dir, spec.diskMb).then(r => { this.quota = r; if (r) this.log(`[OGHOST] Kernel quota hook: ${r.applied ? 'applied' : 'not applied'} (${r.message})`); }); }
    this.spec = spec; this.disk.limitBytes = spec.diskMb * 1024 * 1024;
    fs.writeFileSync(path.join(dirs.metadata, `server-${spec.id}.json`), JSON.stringify(spec, null, 2), { mode: 0o600 });
    if ((spec.suspended || spec.securityBlocked) && this.isActive()) { this.log('[OGHOST] Server suspended or security-blocked: stopping.'); this.kill('suspended'); }
  }

  log(line: string) {
    this.console.push(line); if (this.console.length > config.maxConsoleLines) this.console.splice(0, this.console.length - config.maxConsoleLines);
    this.emit('console', line);
  }
  setState(s: ServerState) { if (this.state === s) return; this.state = s; this.emit('state', s); report('state', this.id, { state: s }); }
  isActive() { return ['starting', 'running', 'stopping'].includes(this.state); }

  async install(reinstall = false) {
    if (this.isActive()) throw Object.assign(new Error('Stop the server before (re)installing'), { status: 409 });
    if (this.busy) throw Object.assign(new Error(`Server is busy: ${this.busy}`), { status: 409 });
    this.busy = 'install'; this.setState('installing'); this.console = [];
    try {
      const javaPath = await this.resolveJava(false);
      const res = await runInstaller({ dir: this.dir, spec: this.spec, disk: this.disk, javaPath, log: l => this.log(`[installer] ${l}`) });
      await this.disk.rescan(); this.stats.diskBytes = this.disk.used;
      this.setState('offline'); report('installed', this.id, { ...res, reinstall });
      return res;
    } catch (e: any) {
      this.log(`[installer] FAILED: ${e.message}`); this.setState('install_failed'); report('install_failed', this.id, { error: e.message }); throw e;
    } finally { this.busy = null; }
  }

  async resolveJava(required = true): Promise<string | null> {
    if (this.spec.egg.runtime !== 'java') return null;
    const list = await javaList();
    if (this.spec.javaPath) {
      const j = list.find(x => x.path === this.spec.javaPath) || (fs.existsSync(this.spec.javaPath) ? { path: this.spec.javaPath } : null);
      if (j) return j.path; if (required) throw Object.assign(new Error(`Selected Java executable not found on node: ${this.spec.javaPath}`), { status: 422 });
    }
    const min = this.spec.egg.javaMin || 8;
    const mc = this.spec.installedVersion || (this.spec.variables.MC_VERSION !== 'latest' ? this.spec.variables.MC_VERSION : null);
    const pick = pickJava(list, { eggMin: min, mcVersion: mc });
    if (!pick && required) throw Object.assign(new Error(`No compatible Java detected on this node (needs Java ${Math.max(min, requiredJavaFor(mc || undefined) || 0)}+${mc ? ` for Minecraft ${mc}` : ''}). Install it (e.g. into ~/java) or select one in Startup.`), { status: 422 });
    if (pick && required) this.log(`[OGHOST] Using Java ${pick.major} (${pick.path})${mc ? ` for Minecraft ${mc}` : ''}`);
    return pick?.path ?? null;
  }

  private applyConfigFiles() {
    const files = this.spec.egg.configFiles || {};
    const ctx: Record<string, string> = { PORT: String(this.spec.primaryPort), PORT_V6: String(this.spec.primaryPort + 1), IP: this.spec.ip, ...this.spec.variables };
    for (const [file, kv] of Object.entries(files)) {
      const abs = safeResolve(this.dir, file);
      if (file === 'eula.txt') continue; // never auto-accept the EULA on behalf of the customer
      const isProps = /\.properties$/.test(file);
      if (!isProps) { if (!fs.existsSync(abs)) continue; let txt = fs.readFileSync(abs, 'utf8'); for (const [k, v] of Object.entries(kv)) { const val = v.replace(/\{\{(\w+)\}\}/g, (_, t) => ctx[t] ?? ''); txt = txt.replace(new RegExp(`^(\\s*${k}\\s*[:=]\\s*).*$`, 'm'), `$1${val}`); } fs.writeFileSync(abs, txt); continue; }
      let lines = fs.existsSync(abs) ? fs.readFileSync(abs, 'utf8').split('\n') : [];
      for (const [k, v] of Object.entries(kv)) {
        const val = v.replace(/\{\{(\w+)\}\}/g, (_, t) => ctx[t] ?? '');
        const i = lines.findIndex(l => l.startsWith(`${k}=`)); if (i >= 0) lines[i] = `${k}=${val}`; else lines.push(`${k}=${val}`);
      }
      fs.writeFileSync(abs, lines.join('\n'));
    }
  }

  async start() {
    if (this.isActive()) throw Object.assign(new Error('Server is already running'), { status: 409 });
    if (this.busy) throw Object.assign(new Error(`Server is busy: ${this.busy}`), { status: 409 });
    if (this.spec.suspended) throw Object.assign(new Error('Server is suspended'), { status: 403 });
    if (this.spec.securityBlocked) throw Object.assign(new Error('Server execution is blocked by the OGHOST Security Center pending review'), { status: 403 });
    await this.disk.rescan();
    if (this.disk.exceeded()) throw Object.assign(new Error(`Disk allocation exceeded (${fmt(this.disk.used)} / ${fmt(this.disk.limitBytes)}). Free space before starting.`), { status: 507 });
    if (process.getuid?.() === 0 && !config.runAsUidBase) throw Object.assign(new Error('Agent is running as root: refusing to start customer processes as root. Set RUN_AS_UID_BASE or run the agent as a normal user.'), { status: 500 });

    this.setState('starting'); this.stopRequested = false; this.oomDetected = false;
    try {
      const scan = await preStartScan(this);
      if (scan.blocked) { this.setState('offline'); throw Object.assign(new Error(scan.message), { status: 403 }); }
      const javaPath = await this.resolveJava(true);
      this.applyConfigFiles();
      const ctx: Record<string, string | number> = { JAVA: javaPath || '', XMS: this.spec.xmsMb, XMX: this.spec.xmxMb, PORT: this.spec.primaryPort, IP: this.spec.ip, SERVER_JAR: this.spec.variables.SERVER_JAR || 'server.jar', JVM_FLAGS: '', ...this.spec.variables };
      const argv = renderStartup(this.spec.startup, ctx);
      let cmd = argv[0];
      if (this.spec.egg.runtime !== 'java') {
        cmd = path.isAbsolute(cmd) ? cmd : safeResolve(this.dir, cmd);
        if (!fs.existsSync(cmd)) throw Object.assign(new Error(`Executable not found: ${argv[0]}`), { status: 422 });
      }
      const env: Record<string, string> = { PATH: '/usr/local/bin:/usr/bin:/bin', HOME: this.dir, LANG: 'C.UTF-8', TERM: 'xterm-256color', SERVER_MEMORY: String(this.spec.memoryMb), SERVER_PORT: String(this.spec.primaryPort), SERVER_IP: this.spec.ip, OGHOST_SERVER_ID: String(this.id) };
      if (this.spec.egg.runtime === 'native') env.LD_LIBRARY_PATH = this.dir;
      const opts: any = { cwd: this.dir, env, stdio: ['pipe', 'pipe', 'pipe'], detached: true };
      if (process.getuid?.() === 0 && config.runAsUidBase) { opts.uid = config.runAsUidBase + this.id; opts.gid = config.runAsUidBase + this.id; }
      this.log(`\x1b[33m[OGHOST]\x1b[0m Starting: ${[path.basename(cmd), ...argv.slice(1)].join(' ')}`);
      const p = spawn(cmd, argv.slice(1), opts); this.proc = p; this.stats.startedAt = Date.now(); sampler.reset(this.id);
      const doneRe = this.spec.egg.doneRegex ? new RegExp(this.spec.egg.doneRegex) : null;
      let partial = '';
      const onData = (d: Buffer) => {
        const text = partial + d.toString('utf8'); const lines = text.split(/\r?\n/); partial = lines.pop() || '';
        for (const l of lines) {
          this.log(l);
          if (this.state === 'starting' && doneRe && doneRe.test(l)) this.setState('running');
          if (/java\.lang\.OutOfMemoryError/.test(l)) { this.oomDetected = true; report('oom', this.id, { line: l.slice(0, 300) }); }
          if (/You need to agree to the EULA/i.test(l)) this.log('\x1b[31m[OGHOST]\x1b[0m EULA not accepted. Edit eula.txt in the File Manager and set eula=true after reading https://aka.ms/MinecraftEULA');
        }
      };
      p.stdout!.on('data', onData); p.stderr!.on('data', onData);
      p.on('error', (e) => { this.log(`[OGHOST] Failed to launch: ${e.message}`); });
      p.on('exit', (code, signal) => this.onExit(code, signal));
      if (!doneRe) setTimeout(() => this.state === 'starting' && this.setState('running'), 5000);
      setTimeout(() => this.state === 'starting' && this.proc === p && this.setState('running'), 10 * 60_000);
      await this.applyCpuLimit();
    } catch (e) { if (this.state === 'starting' && !this.proc) this.setState('offline'); throw e; }
  }

  async applyCpuLimit() {
    this.cpulimitProc?.kill(); this.cpulimitProc = null;
    if (!this.proc?.pid || !this.spec.cpuPercent) return;
    const bin = detectCpulimit();
    if (!bin) { this.log(`[OGHOST] cpulimit not found: CPU limit ${this.spec.cpuPercent}% is NOT enforced (monitoring only).`); return; }
    const f = await cpulimitInfo(bin);
    const args = ['-p', String(this.proc.pid), '-l', String(this.spec.cpuPercent), '-z', '-q']; if (f.children) args.push(f.children);
    const cl = spawn(bin, args, { stdio: 'ignore' }); this.cpulimitProc = cl;
    cl.on('exit', () => { if (this.cpulimitProc === cl) this.cpulimitProc = null; });
    this.log(`[OGHOST] cpulimit applied to PID ${this.proc.pid}: ${this.spec.cpuPercent}% (best-effort throttling, not kernel isolation)`);
  }

  private onExit(code: number | null, signal: NodeJS.Signals | null) {
    if (this.killTimer) clearTimeout(this.killTimer); this.killTimer = null;
    this.cpulimitProc?.kill(); this.cpulimitProc = null; this.proc = null; this.stats.cpu = 0; this.stats.memory = 0;
    const expected = this.stopRequested;
    let reason = expected ? 'stopped' : 'crashed';
    if (this.oomDetected) reason = 'java-out-of-memory'; else if (!expected && signal === 'SIGKILL') reason = 'killed (possible kernel OOM or external kill)';
    this.lastExit = { code, signal, at: Date.now(), reason };
    this.log(`\x1b[33m[OGHOST]\x1b[0m Process exited (code ${code ?? '-'}${signal ? `, signal ${signal}` : ''}): ${reason}`);
    if (expected || code === 0 && !this.oomDetected) { this.setState('offline'); return; }
    this.setState('crashed'); report('crash', this.id, this.lastExit);
    this.crashes = [...this.crashes.filter(t => Date.now() - t < 10 * 60_000), Date.now()];
    if (this.spec.autoRestart && this.crashes.length <= 3 && !this.spec.suspended && !this.spec.securityBlocked) {
      this.log('[OGHOST] Auto-restart in 5 seconds...'); setTimeout(() => this.state === 'crashed' && this.start().catch(e => this.log(`[OGHOST] Auto-restart failed: ${e.message}`)), 5000);
    } else if (this.crashes.length > 3) this.log('[OGHOST] Crash loop detected (more than 3 crashes in 10 minutes). Auto-restart disabled until manual start.');
  }

  stop() {
    if (!this.proc) { this.setState('offline'); return; }
    this.stopRequested = true; this.setState('stopping');
    try { this.proc.stdin!.write(`${this.spec.stopCommand}\n`); } catch { /* */ }
    this.killTimer = setTimeout(() => { this.log('[OGHOST] Graceful stop timed out after 60s, killing.'); this.kill('timeout'); }, 60_000);
  }
  kill(_why = 'manual') {
    this.stopRequested = true;
    if (!this.proc?.pid) { this.setState('offline'); return; }
    const pids = processTree(this.proc.pid).map(p => p.pid);
    try { process.kill(-this.proc.pid, 'SIGKILL'); } catch { /* group gone */ }
    for (const pid of pids) { try { process.kill(pid, 'SIGKILL'); } catch { /* */ } } // descendants that left the group (still our tree)
  }
  async restart() {
    if (this.proc) {
      const done = new Promise<void>(res => { const h = (st: ServerState) => { if (st === 'offline' || st === 'crashed') { this.off('state', h); res(); } }; this.on('state', h); });
      this.stop(); await done;
    }
    await this.start();
  }
  command(cmd: string) {
    if (!this.proc || this.state === 'stopping') throw Object.assign(new Error('Server is not running'), { status: 409 });
    const c = String(cmd).replace(/[\r\n]+/g, ' ').slice(0, 4096); this.proc.stdin!.write(c + '\n');
  }

  sampleStats() {
    if (!this.proc?.pid) return this.stats;
    const tree = processTree(this.proc.pid);
    this.stats.cpu = sampler.sample(this.id, tree);
    this.stats.memory = tree.reduce((s, p) => s + p.rss, 0); this.stats.processes = tree.length;
    return this.stats;
  }
}
