import { Router } from 'express';
import net from 'node:net';
import { encryptSecret, decryptSecret, randomToken, BUILTIN_EGGS, type EggDefinition } from '@oghost/shared';
import { q, one, exec, json, parse, tx } from '../../db';
import { body, patchBody, z, HttpError, idParam, paginate } from '../../lib/http';
import { requirePerm } from '../../lib/auth';
import { config } from '../../config';
import { audit } from '../../services/audit';
import { getNode, agent, nodeSecret, type NodeRow } from '../../services/nodes';
import { nodeCapacity } from '../../services/servers';
import { testHost } from '../../services/databases';
import { notify } from '../../services/notify';

export const infraAdmin = Router();

// ---------------------------------------------------------------- locations
infraAdmin.get('/locations', requirePerm('admin.nodes'), async (_req, res) => res.json({ locations: await q('SELECT l.*, (SELECT COUNT(*) FROM nodes n WHERE n.location_id = l.id) AS nodes FROM locations l ORDER BY l.id') }));
const locSchema = z.object({ short: z.string().regex(/^[a-z0-9-]{2,32}$/), name: z.string().min(1).max(100) });
infraAdmin.post('/locations', requirePerm('admin.nodes'), async (req, res) => { const b = body(locSchema, req); const r = await exec('INSERT INTO locations (short, name) VALUES (?, ?)', [b.short, b.name]).catch((e: any) => { if (e.code === 'ER_DUP_ENTRY') throw new HttpError(409, 'Short code already used'); throw e; }); await audit(req, 'admin.location.create', { type: 'location', id: r.insertId }, b); res.status(201).json({ id: r.insertId }); });
infraAdmin.patch('/locations/:id', requirePerm('admin.nodes'), async (req, res) => { const b = patchBody(locSchema.partial(), req); await exec('UPDATE locations SET short = COALESCE(?, short), name = COALESCE(?, name) WHERE id = ?', [b.short ?? null, b.name ?? null, idParam(req)]); res.json({ ok: true }); });
infraAdmin.delete('/locations/:id', requirePerm('admin.nodes'), async (req, res) => { const c = await one<any>('SELECT COUNT(*) AS c FROM nodes WHERE location_id = ?', [idParam(req)]); if (Number(c.c)) throw new HttpError(409, 'Location still has nodes'); await exec('DELETE FROM locations WHERE id = ?', [idParam(req)]); res.json({ ok: true }); });

// ---------------------------------------------------------------- nodes
const publicNode = async (n: NodeRow) => { const hb = parse<any>((n as any).heartbeat, null); const cap = await nodeCapacity(n); const { secret_enc, heartbeat, ...rest } = n as any; return { ...rest, capacity: cap, heartbeat: hb, allocations: Number((await one<any>('SELECT COUNT(*) AS c, SUM(server_id IS NULL) AS free FROM allocations WHERE node_id = ?', [n.id]))?.c || 0) }; };
infraAdmin.get('/nodes', requirePerm('admin.nodes'), async (_req, res) => { const rows = await q<NodeRow>('SELECT n.*, l.name AS location_name FROM nodes n JOIN locations l ON l.id = n.location_id ORDER BY n.id'); res.json({ nodes: await Promise.all(rows.map(publicNode)) }); });
infraAdmin.get('/nodes/:id', requirePerm('admin.nodes'), async (req, res) => { const n = await getNode(idParam(req)); res.json({ node: await publicNode(n), servers: await q('SELECT id, name, node_server_id, state, memory_mb, disk_mb FROM servers WHERE node_id = ? ORDER BY node_server_id', [n.id]), reservations: await q('SELECT * FROM node_id_reservations WHERE node_id = ?', [n.id]) }); });
const nodeSchema = z.object({ name: z.string().min(1).max(100), locationId: z.number().int(), fqdn: z.string().min(1).max(255).regex(/^[a-zA-Z0-9.-]+$/, 'Hostname or IP only'), scheme: z.enum(['http', 'https']).default('https'), port: z.number().int().min(1).max(65535).default(8443), publicIp: z.string().min(1).max(64), memoryMb: z.number().int().min(256), memoryOverallocate: z.number().int().min(-100).max(1000).default(0), diskMb: z.number().int().min(1024), diskOverallocate: z.number().int().min(-100).max(1000).default(0), cpuPercent: z.number().int().min(0).default(0), maxServers: z.number().int().min(0).default(0) });
function agentEnv(n: NodeRow, secret: string) {
  return [
    '# OGHOST node agent configuration. Keep this file private (chmod 600).', `NODE_ID=${n.id}`, `NODE_SECRET=${secret}`, `PANEL_URL=${config.appUrl}`,
    'AGENT_HOST=0.0.0.0', `AGENT_PORT=${n.port}`,
    n.scheme === 'https' ? '# TLS is required for scheme=https. Paths to a certificate/key readable by the agent user:\nAGENT_TLS_CERT=~/oghost-agent/tls/cert.pem\nAGENT_TLS_KEY=~/oghost-agent/tls/key.pem' : '# WARNING: scheme=http sends node traffic unencrypted. Use only on a private network or behind a TLS tunnel.',
    '# If the panel uses a private/self-signed CA: PANEL_CA=~/oghost-agent/tls/panel-ca.pem (exported as NODE_EXTRA_CA_CERTS by the launcher)',
    'DATA_ROOT=~/oghost-agent/.server', 'CPULIMIT_PATH=~/bin/cpulimit', '# JAVA_SEARCH_PATHS=~/java:/opt/java', 'DISK_EXCEEDED_ACTION=warn', '# QUOTA_HOOK=~/oghost-agent/quota-hook.sh  (optional host-admin kernel quota integration)', '',
  ].join('\n');
}
infraAdmin.post('/nodes', requirePerm('admin.nodes'), async (req, res) => {
  const b = body(nodeSchema, req); const secret = randomToken(32);
  const r = await exec('INSERT INTO nodes (name, location_id, fqdn, scheme, port, public_ip, secret_enc, memory_mb, memory_overalloc, disk_mb, disk_overalloc, cpu_percent, max_servers) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', [b.name, b.locationId, b.fqdn, b.scheme, b.port, b.publicIp, encryptSecret(secret, config.appKey), b.memoryMb, b.memoryOverallocate, b.diskMb, b.diskOverallocate, b.cpuPercent, b.maxServers]);
  const n = await getNode(r.insertId); await audit(req, 'admin.node.create', { type: 'node', id: n.id }, { name: b.name, fqdn: b.fqdn });
  res.status(201).json({ id: n.id, agentEnv: agentEnv(n, secret) });
});
infraAdmin.patch('/nodes/:id', requirePerm('admin.nodes'), async (req, res) => {
  const n = await getNode(idParam(req)); const b = patchBody(nodeSchema.partial(), req);
  const map: Record<string, unknown> = { name: b.name, location_id: b.locationId, fqdn: b.fqdn, scheme: b.scheme, port: b.port, public_ip: b.publicIp, memory_mb: b.memoryMb, memory_overalloc: b.memoryOverallocate, disk_mb: b.diskMb, disk_overalloc: b.diskOverallocate, cpu_percent: b.cpuPercent, max_servers: b.maxServers };
  const keys = Object.keys(map).filter(k => map[k] !== undefined); if (keys.length) await exec(`UPDATE nodes SET ${keys.map(k => `${k} = ?`).join(', ')} WHERE id = ?`, [...keys.map(k => map[k]), n.id]);
  await audit(req, 'admin.node.update', { type: 'node', id: n.id }, b); res.json({ ok: true });
});
infraAdmin.get('/nodes/:id/configuration', requirePerm('admin.nodes'), async (req, res) => { const n = await getNode(idParam(req)); await audit(req, 'admin.node.view_config', { type: 'node', id: n.id }); res.json({ agentEnv: agentEnv(n, nodeSecret(n)) }); });
infraAdmin.post('/nodes/:id/rotate-secret', requirePerm('admin.nodes'), async (req, res) => {
  const n = await getNode(idParam(req)); const secret = randomToken(32);
  await exec('UPDATE nodes SET secret_enc = ? WHERE id = ?', [encryptSecret(secret, config.appKey), n.id]); await audit(req, 'admin.node.rotate_secret', { type: 'node', id: n.id });
  res.json({ agentEnv: agentEnv(n, secret), note: 'Update agent.env on the node and restart the agent; until then the node will appear offline.' });
});
infraAdmin.post('/nodes/:id/maintenance', requirePerm('admin.nodes'), async (req, res) => {
  const n = await getNode(idParam(req)); const b = body(z.object({ maintenance: z.boolean().optional(), emergency: z.boolean().optional(), stopServers: z.boolean().default(false), notifyOwners: z.boolean().default(true), message: z.string().max(500).optional() }), req);
  await exec('UPDATE nodes SET maintenance = COALESCE(?, maintenance), emergency = COALESCE(?, emergency) WHERE id = ?', [b.maintenance === undefined ? null : b.maintenance ? 1 : 0, b.emergency === undefined ? null : b.emergency ? 1 : 0, n.id]);
  let stopped = 0; const failures: string[] = [];
  if (b.stopServers || b.emergency) for (const s of await q<any>("SELECT id, node_server_id FROM servers WHERE node_id = ? AND state IN ('running','starting')", [n.id])) {
    await agent(n, 'POST', `/api/servers/${s.node_server_id}/power`, { action: b.emergency ? 'kill' : 'stop' }, { serverId: s.node_server_id }).then(() => stopped++).catch((e: any) => failures.push(`${s.id}: ${e.message}`));
  }
  if (b.notifyOwners && (b.maintenance || b.emergency)) for (const o of await q<any>('SELECT DISTINCT owner_id FROM servers WHERE node_id = ?', [n.id])) await notify(o.owner_id, 'maintenance', `Maintenance on node ${n.name}`, b.message || (b.emergency ? 'Emergency maintenance is in progress. Servers on this node are stopped and cannot be started until it ends.' : 'Scheduled maintenance is in progress. New servers will not be placed on this node.'), { email: !!b.emergency });
  await audit(req, 'admin.node.maintenance', { type: 'node', id: n.id }, { ...b, stopped, failures }); res.json({ ok: true, stopped, failures });
});
infraAdmin.get('/nodes/:id/system', requirePerm('admin.nodes'), async (req, res) => { const n = await getNode(idParam(req)); res.json(await agent(n, 'GET', '/api/system', undefined, { timeoutMs: 8000 })); });
infraAdmin.get('/nodes/:id/java', requirePerm('admin.nodes'), async (req, res) => { const n = await getNode(idParam(req)); res.json(await agent(n, 'GET', `/api/java${req.query.refresh ? '?refresh=1' : ''}`, undefined, { timeoutMs: 30000 })); });
infraAdmin.delete('/nodes/:id', requirePerm('admin.nodes'), async (req, res) => {
  const n = await getNode(idParam(req)); const c = await one<any>('SELECT COUNT(*) AS c FROM servers WHERE node_id = ?', [n.id]); if (Number(c.c)) throw new HttpError(409, 'Node still hosts servers. Transfer or delete them first.');
  const r = await one<any>('SELECT COUNT(*) AS c FROM node_id_reservations WHERE node_id = ?', [n.id]); if (Number(r.c)) throw new HttpError(409, 'Node has incomplete deletions/transfers (reserved IDs). Bring it online so they can finish.');
  await exec('DELETE FROM nodes WHERE id = ?', [n.id]); await audit(req, 'admin.node.delete', { type: 'node', id: n.id }, { name: n.name }); res.json({ ok: true });
});

// ---------------------------------------------------------------- allocations
infraAdmin.get('/nodes/:id/allocations', requirePerm('admin.nodes'), async (req, res) => res.json({ allocations: await q('SELECT a.*, s.name AS server_name, s.node_server_id FROM allocations a LEFT JOIN servers s ON s.id = a.server_id WHERE a.node_id = ? ORDER BY a.ip, a.port', [idParam(req)]) }));
function parsePorts(spec: string) {
  const out = new Set<number>();
  for (const part of spec.split(',').map(s => s.trim()).filter(Boolean)) {
    const m = part.match(/^(\d+)(?:-(\d+))?$/); if (!m) throw new HttpError(422, `Invalid port range "${part}"`);
    const a = Number(m[1]); const b = Number(m[2] || m[1]); if (a < 1024 || b > 65535 || b < a) throw new HttpError(422, `Ports must be within 1024-65535 ("${part}"). Non-root agents cannot bind privileged ports.`);
    if (b - a > 1000) throw new HttpError(422, 'At most 1000 ports per range'); for (let p = a; p <= b; p++) out.add(p);
  }
  return [...out];
}
infraAdmin.post('/nodes/:id/allocations', requirePerm('admin.nodes'), async (req, res) => {
  const n = await getNode(idParam(req)); const b = body(z.object({ ip: z.string().min(1).max(64), ports: z.string().min(1).max(500), alias: z.string().max(255).optional(), protocol: z.enum(['tcp', 'udp', 'tcp+udp']).default('tcp+udp') }), req);
  if (net.isIP(b.ip) === 0) throw new HttpError(422, 'IP must be an IPv4/IPv6 address (use 0.0.0.0 to bind all interfaces)');
  let created = 0; for (const p of parsePorts(b.ports)) { const r = await exec('INSERT IGNORE INTO allocations (node_id, ip, port, alias, protocol) VALUES (?, ?, ?, ?, ?)', [n.id, b.ip, p, b.alias ?? null, b.protocol]); created += r.affectedRows; }
  await audit(req, 'admin.allocation.create', { type: 'node', id: n.id }, { ...b, created }); res.status(201).json({ created });
});
infraAdmin.patch('/allocations/:id', requirePerm('admin.nodes'), async (req, res) => { const b = body(z.object({ alias: z.string().max(255).nullable().optional(), notes: z.string().max(255).nullable().optional() }), req); await exec('UPDATE allocations SET alias = IF(? = 1, ?, alias), notes = IF(? = 1, ?, notes) WHERE id = ?', [b.alias !== undefined ? 1 : 0, b.alias ?? null, b.notes !== undefined ? 1 : 0, b.notes ?? null, idParam(req)]); res.json({ ok: true }); });
infraAdmin.delete('/allocations/:id', requirePerm('admin.nodes'), async (req, res) => { const r = await exec('DELETE FROM allocations WHERE id = ? AND server_id IS NULL', [idParam(req)]); if (!r.affectedRows) throw new HttpError(409, 'Allocation is assigned to a server or does not exist'); res.json({ ok: true }); });

const PRIVATE = [/^10\./, /^127\./, /^192\.168\./, /^172\.(1[6-9]|2\d|3[01])\./, /^169\.254\./, /^100\.(6[4-9]|[7-9]\d|1[01]\d|12[0-7])\./, /^::1$/, /^f[cd]/i, /^fe80/i];
const tcpProbe = (host: string, port: number, ms = 4000) => new Promise<{ ok: boolean; error?: string; banner?: string }>(resolve => {
  const s = net.connect({ host, port }); let banner = ''; const t = setTimeout(() => { s.destroy(); resolve({ ok: false, error: 'timeout' }); }, ms);
  s.on('connect', () => setTimeout(() => { clearTimeout(t); s.destroy(); resolve({ ok: true, banner }); }, 300)); s.on('data', d => { banner += d.toString().slice(0, 40); });
  s.on('error', (e: any) => { clearTimeout(t); resolve({ ok: false, error: e.code || e.message }); });
});
/**
 * Reachability check. The panel connects to <node public IP>:<port>. For free ports the agent first opens a short-lived
 * probe listener. The result reflects reachability FROM THE PANEL'S NETWORK; if the panel shares the host or LAN with the
 * node this does not prove public-internet reachability, and the result says so. TCP only (UDP cannot be verified this way).
 */
infraAdmin.post('/nodes/:id/allocations/check', requirePerm('admin.nodes'), async (req, res) => {
  const n = await getNode(idParam(req)); const b = body(z.object({ ids: z.array(z.number().int()).max(50).optional() }), req);
  const allocs = await q<any>(`SELECT a.*, s.state FROM allocations a LEFT JOIN servers s ON s.id = a.server_id WHERE a.node_id = ? ${b.ids?.length ? 'AND a.id IN (?)' : ''} ORDER BY a.port LIMIT 50`, b.ids?.length ? [n.id, b.ids] : [n.id]);
  const target = n.public_ip; const privateTarget = PRIVATE.some(r => r.test(target));
  const panelLocal = ['localhost', '127.0.0.1', '::1'].includes(n.fqdn) || PRIVATE.some(r => r.test(n.fqdn));
  const results: any[] = [];
  for (const a of allocs) {
    let mode = 'server'; let note = '';
    if (privateTarget) { results.push({ id: a.id, port: a.port, reachable: 'unreachable', note: `Public IP ${target} is a private/loopback address; not reachable from the internet` }); await exec("UPDATE allocations SET reachable = 'unreachable', checked_at = NOW() WHERE id = ?", [a.id]); continue; }
    if (!(a.server_id && a.state === 'running')) { mode = 'probe'; const p: any = await agent(n, 'POST', '/api/system/probe-listen', { port: a.port, ip: a.ip, seconds: 8 }).catch((e: any) => ({ listening: false, error: e.message })); if (!p.listening) { results.push({ id: a.id, port: a.port, reachable: 'unknown', note: p.inUse ? 'Port is in use by another process on the node' : `Probe failed: ${p.error}` }); continue; } }
    const r = await tcpProbe(target, a.port);
    const status = r.ok ? 'reachable' : 'unreachable'; if (!r.ok) note = `TCP connect failed (${r.error}) - check the host firewall / provider security group / NAT port forwarding`;
    if (panelLocal) note = `${note} Tested from the panel's own network; verify from outside for public reachability.`.trim();
    await exec('UPDATE allocations SET reachable = ?, checked_at = NOW() WHERE id = ?', [status, a.id]);
    results.push({ id: a.id, port: a.port, reachable: status, mode, note, udp: a.protocol !== 'tcp' ? 'UDP cannot be verified by a TCP probe' : undefined });
  }
  res.json({ target, results });
});

// ---------------------------------------------------------------- eggs
const varSchema = z.object({ key: z.string().regex(/^[A-Z][A-Z0-9_]{0,63}$/), name: z.string().min(1).max(100), description: z.string().max(500).optional(), default: z.string().max(1000), userEditable: z.boolean(), rules: z.string().max(300).optional() });
const eggSchema = z.object({ slug: z.string().regex(/^[a-z0-9-]{2,64}$/), name: z.string().min(1).max(100), category: z.enum(['minecraft-java', 'minecraft-bedrock', 'proxy', 'custom']), description: z.string().max(2000).default(''),
  installer: z.enum(['vanilla', 'paper', 'purpur', 'folia', 'velocity', 'waterfall', 'fabric', 'quilt', 'forge', 'neoforge', 'pufferfish', 'bungeecord', 'spigot', 'bedrock', 'pocketmine', 'minestom', 'custom', 'none']), runtime: z.enum(['java', 'native', 'php']),
  javaMin: z.number().int().min(8).max(99).optional(), javaMax: z.number().int().min(8).max(99).optional(), startup: z.string().min(1).max(1000), stopCommand: z.string().max(100), doneRegex: z.string().max(300).optional(),
  variables: z.array(varSchema).max(50), configFiles: z.record(z.string(), z.record(z.string(), z.string())).optional(), notes: z.string().max(4000).optional(), installScript: z.string().max(20000).optional() });
const validRegex = (d: { doneRegex?: string; variables: Array<{ rules?: string }> }) => { if (d.doneRegex) try { new RegExp(d.doneRegex); } catch { throw new HttpError(422, 'doneRegex is not a valid regular expression'); } };
infraAdmin.get('/eggs', requirePerm('admin.eggs'), async (_req, res) => res.json({ eggs: (await q<any>('SELECT e.*, (SELECT COUNT(*) FROM servers s WHERE s.egg_id = e.id) AS servers FROM eggs e ORDER BY e.category, e.name')).map(e => ({ ...e, definition: parse(e.definition, {}) })) }));
infraAdmin.get('/eggs/:id', requirePerm('admin.eggs'), async (req, res) => { const e: any = await one('SELECT * FROM eggs WHERE id = ?', [idParam(req)]); if (!e) throw new HttpError(404, 'Egg not found'); res.json({ egg: { ...e, definition: parse(e.definition, {}) } }); });
async function saveEgg(d: EggDefinition, id?: number) {
  validRegex(d);
  if (id) { await exec('UPDATE eggs SET slug = ?, name = ?, category = ?, definition = ? WHERE id = ?', [d.slug, d.name, d.category, json(d), id]); return id; }
  const r = await exec('INSERT INTO eggs (slug, name, category, definition) VALUES (?, ?, ?, ?)', [d.slug, d.name, d.category, json(d)]).catch((e: any) => { if (e.code === 'ER_DUP_ENTRY') throw new HttpError(409, `An egg with slug "${d.slug}" already exists`); throw e; });
  return r.insertId;
}
infraAdmin.post('/eggs', requirePerm('admin.eggs'), async (req, res) => { const d = body(eggSchema, req) as EggDefinition; const id = await saveEgg(d); await audit(req, 'admin.egg.create', { type: 'egg', id }, { slug: d.slug }); res.status(201).json({ id }); });
infraAdmin.put('/eggs/:id', requirePerm('admin.eggs'), async (req, res) => { const id = idParam(req); const e: any = await one('SELECT * FROM eggs WHERE id = ?', [id]); if (!e) throw new HttpError(404, 'Egg not found'); const d = body(eggSchema, req) as EggDefinition; if (e.is_builtin && d.slug !== e.slug) throw new HttpError(409, 'Built-in egg slugs cannot change'); await saveEgg(d, id); await audit(req, 'admin.egg.update', { type: 'egg', id }); res.json({ ok: true, note: 'Existing servers keep their startup command until it is reset on the Startup page.' }); });
infraAdmin.post('/eggs/:id/duplicate', requirePerm('admin.eggs'), async (req, res) => {
  const e: any = await one('SELECT * FROM eggs WHERE id = ?', [idParam(req)]); if (!e) throw new HttpError(404, 'Egg not found'); const d = parse<EggDefinition>(e.definition, {} as EggDefinition);
  let slug = `${d.slug}-copy`; for (let i = 2; await one('SELECT id FROM eggs WHERE slug = ?', [slug]); i++) slug = `${d.slug}-copy-${i}`;
  const id = await saveEgg({ ...d, slug, name: `${d.name} (copy)` }); await audit(req, 'admin.egg.duplicate', { type: 'egg', id }, { from: e.id }); res.status(201).json({ id });
});
infraAdmin.post('/eggs/:id/reset', requirePerm('admin.eggs'), async (req, res) => { const e: any = await one('SELECT * FROM eggs WHERE id = ? AND is_builtin = 1', [idParam(req)]); if (!e) throw new HttpError(404, 'Built-in egg not found'); const d = BUILTIN_EGGS.find(x => x.slug === e.slug); if (!d) throw new HttpError(404, 'No default definition'); await saveEgg(d, e.id); res.json({ ok: true }); });
infraAdmin.delete('/eggs/:id', requirePerm('admin.eggs'), async (req, res) => {
  const e: any = await one('SELECT * FROM eggs WHERE id = ?', [idParam(req)]); if (!e) throw new HttpError(404, 'Egg not found'); if (e.is_builtin) throw new HttpError(409, 'Built-in eggs cannot be deleted (you can edit or duplicate them)');
  const c = await one<any>('SELECT (SELECT COUNT(*) FROM servers WHERE egg_id = ?) + (SELECT COUNT(*) FROM plans WHERE egg_id = ?) AS c', [e.id, e.id]); if (Number(c.c)) throw new HttpError(409, 'Egg is used by servers or store plans');
  await exec('DELETE FROM eggs WHERE id = ?', [e.id]); await audit(req, 'admin.egg.delete', { type: 'egg', id: e.id }, { slug: e.slug }); res.json({ ok: true });
});
infraAdmin.get('/eggs/:id/export', requirePerm('admin.eggs'), async (req, res) => { const e: any = await one('SELECT * FROM eggs WHERE id = ?', [idParam(req)]); if (!e) throw new HttpError(404, 'Egg not found'); res.setHeader('Content-Disposition', `attachment; filename="egg-${e.slug}.json"`); res.json({ format: 'oghost-egg', version: 1, exported_at: new Date().toISOString(), definition: parse(e.definition, {}) }); });
/**
 * Import an OGHOST egg export, or convert a Pterodactyl egg (PTDL_v1/v2) into a "custom" OGHOST egg. Pterodactyl install
 * scripts are written for Docker install containers and are NOT imported; the converted egg must be reviewed by an admin.
 */
infraAdmin.post('/eggs/import', requirePerm('admin.eggs'), async (req, res) => {
  const raw: any = req.body; let d: any; const warnings: string[] = [];
  if (raw?.format === 'oghost-egg') d = raw.definition;
  else if (raw?.meta?.version?.startsWith?.('PTDL_')) {
    const vars = (raw.variables || []).map((v: any) => ({ key: String(v.env_variable).toUpperCase().replace(/[^A-Z0-9_]/g, '_').slice(0, 64), name: String(v.name || v.env_variable).slice(0, 100), description: String(v.description || '').slice(0, 500), default: String(v.default_value ?? ''), userEditable: !!v.user_editable, rules: typeof v.rules === 'string' ? v.rules.slice(0, 300) : undefined }));
    const startup = String(raw.startup || '').replace(/\{\{SERVER_MEMORY\}\}M?/g, '{{XMX}}M').replace(/\{\{SERVER_PORT\}\}/g, '{{PORT}}').replace(/\$\{?SERVER_MEMORY\}?/g, '{{XMX}}').replace(/^java\b/, '{{JAVA}}');
    let doneRegex: string | undefined; try { const st = JSON.parse(raw.config?.startup || '{}'); doneRegex = st.done ? String(Array.isArray(st.done) ? st.done[0] : st.done).replace(/[.*+?^${}()|[\]\\]/g, '\\$&') : undefined; } catch { /* ignore */ }
    d = { slug: String(raw.name || 'imported').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 56) + '-ptdl', name: String(raw.name || 'Imported egg').slice(0, 100), category: 'custom', description: String(raw.description || '').slice(0, 2000), installer: 'custom', runtime: /java|\{\{JAVA\}\}/.test(startup) ? 'java' : 'native', startup, stopCommand: String(raw.config?.stop || 'stop').replace(/^\^C$/, 'stop'), doneRegex, variables: vars, notes: 'Converted from a Pterodactyl egg. Docker images and install scripts were not imported; upload the server files or set SERVER_JAR and review the startup command.' };
    warnings.push('Pterodactyl install scripts and Docker images are not compatible and were not imported.', 'Review the startup command and variables before using this egg.');
  } else d = raw?.definition || raw;
  const def = eggSchema.parse(d) as EggDefinition; let slug = def.slug; for (let i = 2; await one('SELECT id FROM eggs WHERE slug = ?', [slug]); i++) slug = `${def.slug}-${i}`;
  const id = await saveEgg({ ...def, slug }); await audit(req, 'admin.egg.import', { type: 'egg', id }, { slug, warnings }); res.status(201).json({ id, slug, warnings });
});

// ---------------------------------------------------------------- plugin repositories
const repoSchema = z.object({ name: z.string().min(1).max(100), type: z.enum(['modrinth', 'hangar', 'spiget', 'github', 'custom']), baseUrl: z.string().url().max(300).nullable().optional(), downloadHosts: z.array(z.string().regex(/^[a-z0-9.-]+$/i)).max(20).optional(), enabled: z.boolean().default(true) });
infraAdmin.get('/plugin-repositories', requirePerm('admin.plugins'), async (_req, res) => res.json({ repositories: (await q<any>('SELECT * FROM plugin_repositories ORDER BY id')).map(r => ({ ...r, download_hosts: parse(r.download_hosts, []) })) }));
infraAdmin.post('/plugin-repositories', requirePerm('admin.plugins'), async (req, res) => {
  const b = body(repoSchema, req); if (b.type === 'custom' && (!b.baseUrl || !b.baseUrl.startsWith('https://'))) throw new HttpError(422, 'Custom repositories need an https:// base URL');
  const r = await exec('INSERT INTO plugin_repositories (name, type, base_url, download_hosts, enabled) VALUES (?, ?, ?, ?, ?)', [b.name, b.type, b.baseUrl ?? null, json(b.downloadHosts || []), b.enabled ? 1 : 0]);
  await audit(req, 'admin.plugin_repo.create', { type: 'plugin_repository', id: r.insertId }, b); res.status(201).json({ id: r.insertId });
});
infraAdmin.patch('/plugin-repositories/:id', requirePerm('admin.plugins'), async (req, res) => { const b = patchBody(repoSchema.partial(), req); await exec('UPDATE plugin_repositories SET name = COALESCE(?, name), base_url = COALESCE(?, base_url), download_hosts = COALESCE(?, download_hosts), enabled = COALESCE(?, enabled) WHERE id = ?', [b.name ?? null, b.baseUrl ?? null, b.downloadHosts ? json(b.downloadHosts) : null, b.enabled === undefined ? null : b.enabled ? 1 : 0, idParam(req)]); res.json({ ok: true }); });
infraAdmin.delete('/plugin-repositories/:id', requirePerm('admin.plugins'), async (req, res) => { await exec('DELETE FROM plugin_repositories WHERE id = ?', [idParam(req)]); res.json({ ok: true }); });

// ---------------------------------------------------------------- database hosts (credentials never leave the panel)
const hostSchema = z.object({ name: z.string().min(1).max(100), host: z.string().min(1).max(255), port: z.number().int().min(1).max(65535).default(3306), publicHost: z.string().max(255).nullable().optional(), username: z.string().min(1).max(100), password: z.string().max(200), nodeId: z.number().int().nullable().optional(), maxDatabases: z.number().int().min(0).default(0) });
infraAdmin.get('/database-hosts', requirePerm('admin.databases'), async (_req, res) => res.json({ hosts: await q('SELECT h.id, h.name, h.host, h.port, h.public_host, h.username, h.node_id, h.max_databases, h.created_at, (SELECT COUNT(*) FROM server_databases d WHERE d.host_id = h.id) AS `databases` FROM database_hosts h ORDER BY h.id') }));
infraAdmin.post('/database-hosts', requirePerm('admin.databases'), async (req, res) => {
  const b = body(hostSchema, req); await testHost(b);
  const r = await exec('INSERT INTO database_hosts (name, host, port, public_host, username, password_enc, node_id, max_databases) VALUES (?, ?, ?, ?, ?, ?, ?, ?)', [b.name, b.host, b.port, b.publicHost ?? null, b.username, encryptSecret(b.password, config.appKey), b.nodeId ?? null, b.maxDatabases]);
  await audit(req, 'admin.database_host.create', { type: 'database_host', id: r.insertId }, { name: b.name, host: b.host }); res.status(201).json({ id: r.insertId });
});
infraAdmin.patch('/database-hosts/:id', requirePerm('admin.databases'), async (req, res) => {
  const id = idParam(req); const h: any = await one('SELECT * FROM database_hosts WHERE id = ?', [id]); if (!h) throw new HttpError(404, 'Host not found');
  const b = patchBody(hostSchema.partial(), req); const merged = { host: b.host ?? h.host, port: b.port ?? h.port, username: b.username ?? h.username, password: b.password || decryptSecret(h.password_enc, config.appKey) };
  if (b.host || b.port || b.username || b.password) await testHost(merged);
  await exec('UPDATE database_hosts SET name = COALESCE(?, name), host = ?, port = ?, public_host = COALESCE(?, public_host), username = ?, password_enc = ?, node_id = ?, max_databases = COALESCE(?, max_databases) WHERE id = ?', [b.name ?? null, merged.host, merged.port, b.publicHost ?? null, merged.username, encryptSecret(merged.password, config.appKey), b.nodeId === undefined ? h.node_id : b.nodeId, b.maxDatabases ?? null, id]);
  await audit(req, 'admin.database_host.update', { type: 'database_host', id }); res.json({ ok: true });
});
infraAdmin.post('/database-hosts/:id/test', requirePerm('admin.databases'), async (req, res) => { const h: any = await one('SELECT * FROM database_hosts WHERE id = ?', [idParam(req)]); if (!h) throw new HttpError(404, 'Host not found'); res.json(await testHost({ host: h.host, port: h.port, username: h.username, password: decryptSecret(h.password_enc, config.appKey) })); });
infraAdmin.delete('/database-hosts/:id', requirePerm('admin.databases'), async (req, res) => { const c = await one<any>('SELECT COUNT(*) AS c FROM server_databases WHERE host_id = ?', [idParam(req)]); if (Number(c.c)) throw new HttpError(409, 'Host still has databases'); await exec('DELETE FROM database_hosts WHERE id = ?', [idParam(req)]); res.json({ ok: true }); });
