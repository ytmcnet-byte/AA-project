import { q } from '../db';
import { HttpError } from '../lib/http';

const UA = { 'User-Agent': 'OGHOST-Panel/1.0 (plugin installer)', Accept: 'application/json' };
async function get(url: string) { const r = await fetch(url, { headers: UA }); if (!r.ok) throw new HttpError(502, `${new URL(url).hostname} returned ${r.status}`); return r.json() as Promise<any>; }
export const HOSTS: Record<string, string[]> = { modrinth: ['cdn.modrinth.com'], hangar: ['hangarcdn.papermc.io', 'hangar.papermc.io'], spiget: ['api.spiget.org', 'cdn.spiget.org'], github: ['github.com', 'objects.githubusercontent.com', 'release-assets.githubusercontent.com'] };

export function loaderInfo(installer: string) {
  if (['fabric'].includes(installer)) return { folder: 'mods', modrinth: ['fabric'], hangar: null, kind: 'mod' };
  if (installer === 'quilt') return { folder: 'mods', modrinth: ['quilt', 'fabric'], hangar: null, kind: 'mod' };
  if (installer === 'forge') return { folder: 'mods', modrinth: ['forge'], hangar: null, kind: 'mod' };
  if (installer === 'neoforge') return { folder: 'mods', modrinth: ['neoforge'], hangar: null, kind: 'mod' };
  if (installer === 'velocity') return { folder: 'plugins', modrinth: ['velocity'], hangar: 'VELOCITY', kind: 'plugin' };
  if (['waterfall', 'bungeecord'].includes(installer)) return { folder: 'plugins', modrinth: ['bungeecord', 'waterfall'], hangar: 'WATERFALL', kind: 'plugin' };
  if (installer === 'folia') return { folder: 'plugins', modrinth: ['folia'], hangar: 'PAPER', kind: 'plugin' };
  return { folder: 'plugins', modrinth: ['paper', 'spigot', 'bukkit', 'purpur'], hangar: 'PAPER', kind: 'plugin' };
}

export interface PluginHit { source: string; id: string; slug: string; name: string; description: string; author: string; downloads: number; icon: string | null; url: string; categories: string[]; }
export interface PluginVersion { id: string; name: string; gameVersions: string[]; loaders: string[]; date: string; downloadable: boolean; file?: { url: string; filename: string; hash?: { algo: 'sha1' | 'sha256' | 'sha512'; value: string } }; dependencies: Array<{ id: string; name?: string; required: boolean }>; }

export async function searchPlugins(source: string, query: string, installer: string, gameVersion?: string, category?: string): Promise<PluginHit[]> {
  const L = loaderInfo(installer);
  if (source === 'modrinth') {
    const facets: string[][] = [[`project_type:${L.kind}`], L.modrinth.map(l => `categories:${l}`)]; if (gameVersion && gameVersion !== 'latest') facets.push([`versions:${gameVersion}`]); if (category) facets.push([`categories:${category}`]);
    const d = await get(`https://api.modrinth.com/v2/search?limit=24&index=relevance&query=${encodeURIComponent(query)}&facets=${encodeURIComponent(JSON.stringify(facets))}`);
    return d.hits.map((h: any) => ({ source, id: h.project_id, slug: h.slug, name: h.title, description: h.description, author: h.author, downloads: h.downloads, icon: h.icon_url || null, url: `https://modrinth.com/${h.project_type}/${h.slug}`, categories: h.categories }));
  }
  if (source === 'hangar') {
    if (!L.hangar) return [];
    const d = await get(`https://hangar.papermc.io/api/v1/projects?limit=24&platform=${L.hangar}&q=${encodeURIComponent(query)}${gameVersion && gameVersion !== 'latest' ? `&version=${encodeURIComponent(gameVersion)}` : ''}${category ? `&category=${encodeURIComponent(category)}` : ''}`);
    return d.result.map((p: any) => ({ source, id: `${p.namespace.owner}/${p.namespace.slug}`, slug: p.namespace.slug, name: p.name, description: p.description, author: p.namespace.owner, downloads: p.stats?.downloads ?? 0, icon: p.avatarUrl || null, url: `https://hangar.papermc.io/${p.namespace.owner}/${p.namespace.slug}`, categories: [p.category] }));
  }
  if (source === 'spiget') {
    if (L.kind === 'mod') return [];
    const d = await get(`https://api.spiget.org/v2/search/resources/${encodeURIComponent(query || 'a')}?field=name&size=24&sort=-downloads&fields=id,name,tag,downloads,icon,external,premium,file,author`);
    return d.filter((r: any) => !r.premium).map((r: any) => ({ source, id: String(r.id), slug: String(r.id), name: r.name, description: r.tag, author: String(r.author?.id ?? ''), downloads: r.downloads, icon: r.icon?.url ? `https://www.spigotmc.org/${r.icon.url}` : null, url: `https://www.spigotmc.org/resources/${r.id}/`, categories: r.external ? ['external-download'] : [] }));
  }
  if (source === 'github') {
    if (!/^[\w.-]+\/[\w.-]+$/.test(query)) { const d = await get(`https://api.github.com/search/repositories?per_page=20&q=${encodeURIComponent(`${query} minecraft ${L.kind} in:name,description`)}`); return d.items.map((r: any) => ({ source, id: r.full_name, slug: r.name, name: r.name, description: r.description || '', author: r.owner.login, downloads: r.stargazers_count, icon: r.owner.avatar_url, url: r.html_url, categories: ['github'] })); }
    const r = await get(`https://api.github.com/repos/${query}`); return [{ source, id: r.full_name, slug: r.name, name: r.name, description: r.description || '', author: r.owner.login, downloads: r.stargazers_count, icon: r.owner.avatar_url, url: r.html_url, categories: ['github'] }];
  }
  const repo: any = (await q('SELECT * FROM plugin_repositories WHERE id = ? AND enabled = 1 AND type = ?', [Number(source.replace('custom:', '')), 'custom']))[0];
  if (!repo) throw new HttpError(400, 'Unknown plugin source');
  const idx = await get(repo.base_url); return (idx.plugins || []).filter((p: any) => !query || `${p.name} ${p.description}`.toLowerCase().includes(query.toLowerCase())).map((p: any) => ({ source, id: p.id, slug: p.id, name: p.name, description: p.description || '', author: p.author || repo.name, downloads: 0, icon: p.icon || null, url: p.url || repo.base_url, categories: p.categories || [] }));
}

export async function pluginVersions(source: string, id: string, installer: string, gameVersion?: string): Promise<PluginVersion[]> {
  const L = loaderInfo(installer);
  if (source === 'modrinth') {
    const params = `loaders=${encodeURIComponent(JSON.stringify(L.modrinth))}${gameVersion && gameVersion !== 'latest' ? `&game_versions=${encodeURIComponent(JSON.stringify([gameVersion]))}` : ''}`;
    const d = await get(`https://api.modrinth.com/v2/project/${encodeURIComponent(id)}/version?${params}`);
    return d.slice(0, 50).map((v: any) => { const f = v.files.find((x: any) => x.primary) || v.files[0]; return { id: v.id, name: v.version_number, gameVersions: v.game_versions, loaders: v.loaders, date: v.date_published, downloadable: !!f && /\.jar$/i.test(f.filename), file: f ? { url: f.url, filename: f.filename, hash: { algo: 'sha512', value: f.hashes.sha512 } } : undefined, dependencies: (v.dependencies || []).filter((x: any) => x.project_id && x.dependency_type !== 'incompatible').map((x: any) => ({ id: x.project_id, required: x.dependency_type === 'required' })) }; });
  }
  if (source === 'hangar') {
    const d = await get(`https://hangar.papermc.io/api/v1/projects/${id.split('/').pop()}/versions?limit=30&platform=${L.hangar}`);
    return d.result.map((v: any) => { const dl = v.downloads?.[L.hangar!]; return { id: v.name, name: v.name, gameVersions: v.platformDependencies?.[L.hangar!] || [], loaders: [String(L.hangar).toLowerCase()], date: v.createdAt, downloadable: !!dl?.downloadUrl, file: dl?.downloadUrl ? { url: dl.downloadUrl, filename: dl.fileInfo?.name || `${id.split('/').pop()}-${v.name}.jar`, hash: dl.fileInfo?.sha256Hash ? { algo: 'sha256', value: dl.fileInfo.sha256Hash } : undefined } : undefined, dependencies: (v.pluginDependencies?.[L.hangar!] || []).map((p: any) => ({ id: p.name, name: p.name, required: p.required })) }; });
  }
  if (source === 'spiget') {
    const r = await get(`https://api.spiget.org/v2/resources/${encodeURIComponent(id)}?fields=id,name,external,premium,file,testedVersions,version`);
    const ok = !r.external && !r.premium && r.file?.type === '.jar';
    return [{ id: String(r.version?.id ?? 'latest'), name: 'latest', gameVersions: r.testedVersions || [], loaders: ['spigot'], date: new Date().toISOString(), downloadable: ok, file: ok ? { url: `https://api.spiget.org/v2/resources/${r.id}/download`, filename: `${r.name.replace(/[^A-Za-z0-9._-]/g, '')}-${r.id}.jar` } : undefined, dependencies: [] }];
  }
  if (source === 'github') {
    const d = await get(`https://api.github.com/repos/${id}/releases?per_page=20`);
    return d.filter((r: any) => !r.draft).map((r: any) => { const a = r.assets.find((x: any) => /\.jar$/i.test(x.name) && !/sources|javadoc/i.test(x.name)); return { id: String(r.id), name: r.tag_name, gameVersions: [], loaders: [], date: r.published_at, downloadable: !!a, file: a ? { url: a.browser_download_url, filename: a.name, hash: a.digest?.startsWith('sha256:') ? { algo: 'sha256', value: a.digest.slice(7) } : undefined } : undefined, dependencies: [] }; });
  }
  const repo: any = (await q('SELECT * FROM plugin_repositories WHERE id = ? AND enabled = 1', [Number(source.replace('custom:', ''))]))[0]; if (!repo) throw new HttpError(400, 'Unknown plugin source');
  const idx = await get(repo.base_url); const p = (idx.plugins || []).find((x: any) => x.id === id); if (!p) throw new HttpError(404, 'Plugin not in repository');
  return (p.versions || []).map((v: any) => ({ id: v.id, name: v.name, gameVersions: v.gameVersions || [], loaders: v.loaders || [], date: v.date || '', downloadable: !!v.url, file: { url: v.url, filename: v.filename || `${p.id}-${v.name}.jar`, hash: v.sha256 ? { algo: 'sha256', value: v.sha256 } : undefined }, dependencies: v.dependencies || [] }));
}

export async function downloadHosts(source: string): Promise<string[]> {
  if (HOSTS[source]) return HOSTS[source];
  const repo: any = (await q('SELECT download_hosts FROM plugin_repositories WHERE id = ?', [Number(source.replace('custom:', ''))]))[0];
  const h = typeof repo?.download_hosts === 'string' ? JSON.parse(repo.download_hosts) : repo?.download_hosts; if (!h?.length) throw new HttpError(400, 'Repository has no approved download hosts'); return h;
}
