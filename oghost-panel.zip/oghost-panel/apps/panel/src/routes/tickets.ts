import { Router } from 'express';
import express from 'express';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { q, one, exec } from '../db';
import { body, z, HttpError, idParam, paginate } from '../lib/http';
import { requireAuth, hasPerm } from '../lib/auth';
import { config } from '../config';
import { notify, notifyAdmins } from '../services/notify';
import { audit } from '../services/audit';
import { dispatchWebhook } from '../services/webhooks';

export const ticketsRouter = Router();
ticketsRouter.use(requireAuth);
const CATEGORIES = ['billing', 'technical', 'server', 'security', 'abuse', 'sales', 'other'];
const ATTACH_DIR = path.join(config.uploadsDir, 'tickets');
const ALLOWED_EXT: Record<string, string> = { '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.gif': 'image/gif', '.webp': 'image/webp', '.txt': 'text/plain', '.log': 'text/plain', '.json': 'application/json', '.yml': 'text/plain', '.yaml': 'text/plain', '.properties': 'text/plain', '.pdf': 'application/pdf', '.zip': 'application/zip' };
const MAX_ATTACH = 10 * 1024 * 1024;
const isStaff = (req: any) => hasPerm(req.user, 'admin.tickets');

async function loadTicket(req: any) {
  const t: any = await one('SELECT t.*, u.email, u.username FROM tickets t JOIN users u ON u.id = t.user_id WHERE t.id = ?', [idParam(req)]);
  if (!t || (t.user_id !== req.user.id && !isStaff(req))) throw new HttpError(404, 'Ticket not found');
  return t;
}

ticketsRouter.get('/', async (req, res) => {
  const p = paginate(req); const staffView = isStaff(req) && req.query.all === '1'; const cond: string[] = []; const v: any[] = [];
  if (!staffView) { cond.push('t.user_id = ?'); v.push(req.user!.id); }
  if (req.query.status) { cond.push('t.status = ?'); v.push(req.query.status); }
  if (staffView && req.query.assigned === 'me') { cond.push('t.assigned_to = ?'); v.push(req.user!.id); }
  res.json({ tickets: await q(`SELECT t.id, t.user_id, u.email, t.server_id, t.category, t.subject, t.priority, t.status, t.assigned_to, t.created_at, t.updated_at, (SELECT COUNT(*) FROM ticket_messages m WHERE m.ticket_id = t.id) AS messages FROM tickets t JOIN users u ON u.id = t.user_id ${cond.length ? 'WHERE ' + cond.join(' AND ') : ''} ORDER BY FIELD(t.status, 'open', 'awaiting_staff', 'awaiting_customer', 'closed'), t.updated_at DESC LIMIT ? OFFSET ?`, [...v, p.limit, p.offset]), categories: CATEGORIES });
});
ticketsRouter.post('/', async (req, res) => {
  const b = body(z.object({ subject: z.string().trim().min(3).max(200), category: z.enum(CATEGORIES as [string, ...string[]]), priority: z.enum(['low', 'normal', 'high', 'urgent']).default('normal'), serverId: z.number().int().nullable().optional(), message: z.string().trim().min(1).max(20000) }), req);
  if (b.serverId) { const s: any = await one('SELECT owner_id FROM servers WHERE id = ?', [b.serverId]); const sub = await one('SELECT id FROM server_subusers WHERE server_id = ? AND user_id = ?', [b.serverId, req.user!.id]); if (!s || (s.owner_id !== req.user!.id && !sub)) throw new HttpError(422, 'Server not found'); }
  const open = await one<any>("SELECT COUNT(*) AS c FROM tickets WHERE user_id = ? AND status <> 'closed'", [req.user!.id]); if (Number(open.c) >= 20 && !isStaff(req)) throw new HttpError(429, 'Too many open tickets');
  const t = await exec('INSERT INTO tickets (user_id, server_id, category, subject, priority, status) VALUES (?, ?, ?, ?, ?, ?)', [req.user!.id, b.serverId ?? null, b.category, b.subject, b.priority, 'awaiting_staff']);
  const m = await exec('INSERT INTO ticket_messages (ticket_id, user_id, body, is_staff) VALUES (?, ?, ?, 0)', [t.insertId, req.user!.id, b.message]);
  await notifyAdmins('admin.tickets', 'ticket', `New ticket #${t.insertId}: ${b.subject}`, `${b.category} / ${b.priority}`, { link: `/admin/tickets/${t.insertId}`, email: b.priority === 'urgent' });
  void dispatchWebhook('ticket.created', { ticketId: t.insertId, userId: req.user!.id, category: b.category, priority: b.priority });
  res.status(201).json({ id: t.insertId, messageId: m.insertId });
});
ticketsRouter.get('/:id', async (req, res) => {
  const t = await loadTicket(req);
  const msgs = await q<any>('SELECT m.id, m.user_id, u.username, u.name, u.avatar_url, m.body, m.is_staff, m.created_at FROM ticket_messages m JOIN users u ON u.id = m.user_id WHERE m.ticket_id = ? ORDER BY m.id', [t.id]);
  const att = msgs.length ? await q<any>('SELECT id, message_id, filename, size_bytes, mime FROM ticket_attachments WHERE message_id IN (?)', [msgs.map(m => m.id)]) : [];
  res.json({ ticket: t, messages: msgs.map(m => ({ ...m, attachments: att.filter(a => a.message_id === m.id) })), staff: isStaff(req), staffUsers: isStaff(req) ? await q("SELECT u.id, u.username FROM users u JOIN roles r ON r.id = u.role_id WHERE JSON_CONTAINS(r.permissions, '\"admin.tickets\"') OR JSON_CONTAINS(r.permissions, '\"*\"')") : undefined });
});
ticketsRouter.post('/:id/messages', async (req, res) => {
  const t = await loadTicket(req); const b = body(z.object({ message: z.string().trim().min(1).max(20000) }), req);
  if (t.status === 'closed' && !isStaff(req)) throw new HttpError(409, 'Ticket is closed. Open a new ticket.');
  const staff = isStaff(req) && t.user_id !== req.user!.id;
  const m = await exec('INSERT INTO ticket_messages (ticket_id, user_id, body, is_staff) VALUES (?, ?, ?, ?)', [t.id, req.user!.id, b.message, staff ? 1 : 0]);
  await exec('UPDATE tickets SET status = ?, updated_at = NOW() WHERE id = ?', [staff ? 'awaiting_customer' : 'awaiting_staff', t.id]);
  if (staff) await notify(t.user_id, 'ticket', `Reply on ticket #${t.id}`, b.message.slice(0, 300), { link: `/tickets/${t.id}`, email: true });
  else if (t.assigned_to) await notify(t.assigned_to, 'ticket', `Customer replied on #${t.id}`, b.message.slice(0, 300), { link: `/admin/tickets/${t.id}` });
  else await notifyAdmins('admin.tickets', 'ticket', `Customer replied on #${t.id}`, b.message.slice(0, 200), { link: `/admin/tickets/${t.id}` });
  res.status(201).json({ id: m.insertId });
});
/** Raw upload: POST /tickets/:id/messages/:mid/attachments?filename=x.png (body = file bytes, max 10 MB). */
ticketsRouter.post('/:id/messages/:mid/attachments', express.raw({ type: '*/*', limit: MAX_ATTACH }), async (req, res) => {
  const t = await loadTicket(req); const m: any = await one('SELECT * FROM ticket_messages WHERE id = ? AND ticket_id = ?', [idParam(req, 'mid'), t.id]);
  if (!m || m.user_id !== req.user!.id) throw new HttpError(404, 'Message not found');
  const n = await one<any>('SELECT COUNT(*) AS c FROM ticket_attachments WHERE message_id = ?', [m.id]); if (Number(n.c) >= 5) throw new HttpError(409, 'At most 5 attachments per message');
  const name = path.basename(String(req.query.filename || '')).replace(/[^\w.\- ]/g, '_').slice(0, 200); const ext = path.extname(name).toLowerCase();
  if (!name || !ALLOWED_EXT[ext]) throw new HttpError(415, `Allowed file types: ${Object.keys(ALLOWED_EXT).join(', ')}`);
  const data = req.body as Buffer; if (!Buffer.isBuffer(data) || !data.length) throw new HttpError(400, 'Empty file');
  fs.mkdirSync(ATTACH_DIR, { recursive: true, mode: 0o750 }); const stored = crypto.randomBytes(32).toString('hex');
  fs.writeFileSync(path.join(ATTACH_DIR, stored), data, { mode: 0o640 });
  const r = await exec('INSERT INTO ticket_attachments (message_id, filename, stored_name, size_bytes, mime) VALUES (?, ?, ?, ?, ?)', [m.id, name, stored, data.length, ALLOWED_EXT[ext]]);
  res.status(201).json({ id: r.insertId, filename: name, size: data.length });
});
ticketsRouter.get('/:id/attachments/:aid', async (req, res) => {
  const t = await loadTicket(req);
  const a: any = await one('SELECT a.* FROM ticket_attachments a JOIN ticket_messages m ON m.id = a.message_id WHERE a.id = ? AND m.ticket_id = ?', [idParam(req, 'aid'), t.id]); if (!a) throw new HttpError(404, 'Attachment not found');
  const file = path.join(ATTACH_DIR, a.stored_name); if (!/^[a-f0-9]{64}$/.test(a.stored_name) || !fs.existsSync(file)) throw new HttpError(404, 'File missing');
  res.setHeader('Content-Type', a.mime); res.setHeader('X-Content-Type-Options', 'nosniff'); res.setHeader('Content-Security-Policy', "default-src 'none'; sandbox");
  res.setHeader('Content-Disposition', `${a.mime.startsWith('image/') && req.query.inline ? 'inline' : 'attachment'}; filename="${a.filename.replace(/"/g, '')}"`);
  fs.createReadStream(file).pipe(res);
});
ticketsRouter.patch('/:id', async (req, res) => {
  const t = await loadTicket(req); const b = body(z.object({ status: z.enum(['open', 'awaiting_staff', 'awaiting_customer', 'closed']).optional(), priority: z.enum(['low', 'normal', 'high', 'urgent']).optional(), assignedTo: z.number().int().nullable().optional() }), req);
  if (!isStaff(req)) { if (b.priority || b.assignedTo !== undefined || (b.status && b.status !== 'closed' && b.status !== 'awaiting_staff')) throw new HttpError(403, 'Customers can only close or reopen tickets'); }
  await exec('UPDATE tickets SET status = COALESCE(?, status), priority = COALESCE(?, priority), assigned_to = IF(? = 1, ?, assigned_to) WHERE id = ?', [b.status ?? null, b.priority ?? null, b.assignedTo !== undefined ? 1 : 0, b.assignedTo ?? null, t.id]);
  if (b.assignedTo) await notify(b.assignedTo, 'ticket', `Ticket #${t.id} assigned to you`, t.subject, { link: `/admin/tickets/${t.id}` });
  if (isStaff(req) && b.status === 'closed' && t.user_id !== req.user!.id) await notify(t.user_id, 'ticket', `Ticket #${t.id} closed`, t.subject, { link: `/tickets/${t.id}` });
  await audit(req, 'ticket.update', { type: 'ticket', id: t.id }, b); res.json({ ok: true });
});
