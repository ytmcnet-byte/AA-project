import yauzl from 'yauzl';
import crypto from 'node:crypto';
import fs from 'node:fs';
import type { SecurityLevel } from './types';

export interface ScanFinding { severity: 'info' | 'low' | 'medium' | 'high'; category: string; rule: string; entry: string; detail: string; }
export interface ScanResult {
  level: SecurityLevel; sha256: string; size: number; minecraft: { detected: boolean; software: string[]; mainClass: string | null };
  findings: ScanFinding[]; entriesScanned: number; bytesScanned: number; truncated: boolean; trusted: boolean; scannerVersion: string; reason: string;
}

export const SCANNER_VERSION = '1.3.0';

/** Known legitimate Minecraft server/proxy signatures (class paths and manifest main classes). */
const MC_SIGNATURES: Array<[string, RegExp]> = [
  ['Vanilla', /^net\/minecraft\/server\/(Main|MinecraftServer)\.class$/],
  ['Vanilla bundler', /^net\/minecraft\/bundler\/Main\.class$/],
  ['Paperclip (Paper/Purpur/Folia/Pufferfish)', /^io\/papermc\/paperclip\//],
  ['Paper', /^io\/papermc\/paper\//],
  ['Purpur', /^org\/purpurmc\//],
  ['Pufferfish', /^gg\/pufferfish\//],
  ['CraftBukkit/Spigot', /^org\/bukkit\/craftbukkit\//],
  ['Spigot', /^org\/spigotmc\//],
  ['Bukkit API', /^org\/bukkit\/Bukkit\.class$/],
  ['Fabric', /^net\/fabricmc\/(loader|installer)\//],
  ['Quilt', /^org\/quiltmc\/(loader|installer)\//],
  ['Forge', /^net\/minecraftforge\//],
  ['Forge (modlauncher)', /^cpw\/mods\//],
  ['NeoForge', /^net\/neoforged\//],
  ['Velocity', /^com\/velocitypowered\/proxy\//],
  ['BungeeCord/Waterfall', /^net\/md_5\/bungee\//],
  ['Minestom', /^net\/minestom\/server\//],
  ['Bundled server jar', /^META-INF\/versions\/[^/]+\/(server|paper|purpur|folia|pufferfish)-[^/]+\.jar$/],
  ['Bundler metadata', /^META-INF\/(versions|libraries)\.list$/],
  ['Mojang server data', /^data\/minecraft\//],
];
const MC_MAIN_CLASSES = /^(net\.minecraft\.server\.Main|net\.minecraft\.bundler\.Main|io\.papermc\.paperclip\.(Main|Paperclip)|org\.bukkit\.craftbukkit\.(bootstrap\.)?Main|net\.fabricmc\.(loader\.launch\.server\.FabricServerLauncher|installer\.ServerLauncher)|org\.quiltmc\.loader\.impl\.launch\.server\.QuiltServerLauncher|com\.velocitypowered\.proxy\.Velocity|net\.md_5\.bungee\.Bootstrap|net\.minecraftforge\.[\w.]+|net\.neoforged\.[\w.]+|cpw\.mods\.[\w.]+)$/;

interface Rule { id: string; category: string; severity: ScanFinding['severity']; needle: string; }
const R = (category: string, severity: ScanFinding['severity'], ...needles: string[]): Rule[] => needles.map(n => ({ id: `${category}:${n}`, category, severity, needle: n.toLowerCase() }));
/** Byte-level signatures searched case-insensitively in class files, resources and nested archives. */
export const RULES: Rule[] = [
  ...R('crypto-mining', 'high', 'stratum+tcp://', 'stratum+ssl://', 'stratum2+tcp', 'mining.subscribe', 'mining.authorize', 'xmrig', 'cryptonight', 'randomx_', 'librandomx', 'donate-level', 'supportxmr.com', 'moneroocean', 'minexmr', 'nanopool.org', 'hashvault.pro', 'c3pool', 'herominers', 'unmineable', 'nicehash', 'ethermine', '2miners.com', 'f2pool', 'coinhive', 'cpuminer', 'ccminer', 'nbminer', 'lolminer', 't-rex miner', 'srbminer', 'xmr-stak'),
  ...R('tunnel-proxy', 'medium', 'ngrok.io', 'ngrok-agent', 'frpc.ini', 'fatedier/frp', 'cloudflared', 'trycloudflare.com', 'v2ray', 'xray-core', 'shadowsocks', 'trojan-go', 'sing-box', 'go-gost', 'jpillora/chisel', 'pinggy.io', 'localtonet', 'bore.pub'),
  ...R('remote-shell', 'high', 'bash -i >& /dev/tcp', '/dev/tcp/', 'sh -i 2>&1', 'nc -e /bin/sh', 'mkfifo /tmp/', 'gotty', 'tsl0922/ttyd', 'sshx.io', 'tmate.io', 'pty.spawn'),
  ...R('vps-software', 'medium', 'proot-distro', 'proot -0', 'qemu-system-', 'noVNC', 'x11vnc', 'tightvncserver', 'code-server', 'pterodactyl/wings'),
  ...R('dropper', 'low', 'chmod +x', 'chmod 777', '/tmp/.x', 'curl -s http', 'wget -q http', 'base64 -d |'),
];

const KNOWN_NATIVE = /^(META-INF\/native\/|META-INF\/natives\/|natives\/|linux\/|org\/sqlite\/native\/|com\/sun\/jna\/|net\/minecraft\/|io\/netty\/|lwjgl|oshi|darwin|win32)|\.(so|dll|dylib|jnilib)$/i;
const DATA_LISTS = /(^|\/)(public[-_]suffix[-_]list[^/]*|effective_tld_names[^/]*|publicsuffixes\.gz|tld[-_]?list[^/]*)$/i;
const ENTRY_LIMIT = 30000, PER_ENTRY_LIMIT = 16 * 1024 * 1024, TOTAL_LIMIT = 512 * 1024 * 1024, NEST_DEPTH = 2;

function openZip(src: string | Buffer): Promise<yauzl.ZipFile> {
  return new Promise((res, rej) => {
    const cb = (e: Error | null, z?: yauzl.ZipFile) => (e || !z ? rej(e || new Error('zip')) : res(z));
    if (typeof src === 'string') yauzl.open(src, { lazyEntries: true, autoClose: true }, cb);
    else yauzl.fromBuffer(src, { lazyEntries: true }, cb);
  });
}
function readEntry(z: yauzl.ZipFile, e: yauzl.Entry, limit: number): Promise<Buffer> {
  return new Promise((res, rej) => z.openReadStream(e, (err, s) => {
    if (err || !s) return rej(err);
    const chunks: Buffer[] = []; let n = 0;
    s.on('data', (c: Buffer) => { n += c.length; if (n <= limit) chunks.push(c); else s.destroy(); });
    s.on('end', () => res(Buffer.concat(chunks))); s.on('close', () => res(Buffer.concat(chunks))); s.on('error', rej);
  }));
}

export async function hashFile(file: string) {
  return new Promise<string>((res, rej) => { const h = crypto.createHash('sha256'); fs.createReadStream(file).on('data', d => h.update(d)).on('end', () => res(h.digest('hex'))).on('error', rej); });
}

/**
 * Static JAR analysis. The JAR is NEVER executed. Classification:
 *  - high_risk: crypto-mining or remote-shell signatures
 *  - suspicious: no recognised Minecraft server signature, tunnel/VPS software, or unknown embedded executables
 *  - safe: recognised Minecraft server software and no risky findings (or SHA-256 is on the trusted list)
 */
export async function scanJar(file: string, trustedHashes: Set<string> = new Set()): Promise<ScanResult> {
  const stat = fs.statSync(file);
  const sha256 = await hashFile(file);
  const result: ScanResult = { level: 'safe', sha256, size: stat.size, minecraft: { detected: false, software: [], mainClass: null }, findings: [], entriesScanned: 0, bytesScanned: 0, truncated: false, trusted: trustedHashes.has(sha256), scannerVersion: SCANNER_VERSION, reason: '' };
  if (result.trusted) { result.reason = 'SHA-256 is on the administrator trusted software list'; result.minecraft.detected = true; return result; }
  const software = new Set<string>(); const seenRules = new Set<string>();

  const walk = async (src: string | Buffer, prefix: string, depth: number) => {
    let z: yauzl.ZipFile;
    try { z = await openZip(src); } catch { result.findings.push({ severity: 'medium', category: 'archive', rule: 'not-a-zip', entry: prefix || '(root)', detail: 'File is not a valid JAR/ZIP archive' }); return; }
    await new Promise<void>((resolve) => {
      z.on('end', () => resolve()); z.on('error', () => resolve());
      z.on('entry', async (e: yauzl.Entry) => {
        try {
          const name = e.fileName; const full = prefix + name;
          if (result.entriesScanned++ > ENTRY_LIMIT || result.bytesScanned > TOTAL_LIMIT) { result.truncated = true; z.close(); return resolve(); }
          if (name.endsWith('/')) return z.readEntry();
          for (const [label, re] of MC_SIGNATURES) if (re.test(name)) software.add(label);
          const interesting = /\.(class|jar|zip|properties|json|txt|yml|yaml|sh|py|js|cfg|conf|ini|toml|MF)$/i.test(name) || !name.includes('.') || /\.(so|bin|exe|elf)$/i.test(name);
          if (!interesting) return z.readEntry();
          const buf = await readEntry(z, e, PER_ENTRY_LIMIT);
          result.bytesScanned += buf.length;
          if (name === 'META-INF/MANIFEST.MF' && !prefix) {
            const m = buf.toString('utf8').match(/^Main-Class:\s*(\S+)/m);
            if (m) { result.minecraft.mainClass = m[1]; if (MC_MAIN_CLASSES.test(m[1])) software.add(`Main-Class ${m[1]}`); }
          }
          if (buf.length >= 4 && buf[0] === 0x7f && buf[1] === 0x45 && buf[2] === 0x4c && buf[3] === 0x46) {
            if (!KNOWN_NATIVE.test(name)) result.findings.push({ severity: 'medium', category: 'embedded-executable', rule: 'elf-binary', entry: full, detail: 'Embedded Linux executable outside known native-library locations' });
          }
          if (/\.(sh|py)$/i.test(name) && !prefix) result.findings.push({ severity: 'low', category: 'embedded-script', rule: 'script', entry: full, detail: 'Shell/Python script bundled in JAR' });
          const isArchive = /\.(jar|zip)$/i.test(name);
          // Never match signatures against compressed archive bytes (random matches); nested archives are walked instead.
          // Public-suffix / TLD data lists legitimately contain tunnel-provider domains.
          const skipSignatures = isArchive || DATA_LISTS.test(name);
          const hay = skipSignatures ? '' : buf.toString('latin1').toLowerCase();
          for (const r of skipSignatures ? [] : RULES) {
            if (seenRules.has(r.id + full)) continue;
            const at = hay.indexOf(r.needle);
            if (at >= 0) { seenRules.add(r.id + full); result.findings.push({ severity: r.severity, category: r.category, rule: r.needle, entry: full, detail: `Signature found: …${hay.slice(Math.max(0, at - 24), at + r.needle.length + 24).replace(/[^\x20-\x7e]/g, '.')}…` }); }
          }
          if (isArchive && depth < NEST_DEPTH && buf.length > 22) await walk(buf, full + '!/', depth + 1);
        } catch { /* unreadable entry: continue */ }
        z.readEntry();
      });
      z.readEntry();
    });
  };
  await walk(file, '', 0);

  result.minecraft.software = [...software];
  result.minecraft.detected = software.size > 0;
  const high = result.findings.filter(f => f.severity === 'high');
  const medium = result.findings.filter(f => f.severity === 'medium');
  if (high.length) { result.level = 'high_risk'; result.reason = `Prohibited software signatures: ${[...new Set(high.map(f => f.category))].join(', ')}`; }
  else if (!result.minecraft.detected) { result.level = 'suspicious'; result.reason = 'No recognised Minecraft server signature (may be custom/obfuscated software; administrator review required)'; }
  else if (medium.length) { result.level = 'suspicious'; result.reason = `Minecraft software detected but with risky findings: ${[...new Set(medium.map(f => f.category))].join(', ')}`; }
  else { result.level = 'safe'; result.reason = `Recognised: ${result.minecraft.software.slice(0, 3).join(', ')}`; }
  return result;
}
