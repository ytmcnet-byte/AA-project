-- IDs whose directories still exist on a node although no servers row points at them
-- (e.g. the source side of a transfer until the old directory is confirmed deleted).
CREATE TABLE node_id_reservations (
  node_id INT UNSIGNED NOT NULL,
  node_server_id INT UNSIGNED NOT NULL,
  reason VARCHAR(100) NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (node_id, node_server_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
