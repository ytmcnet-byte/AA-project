import { Router } from 'express';
import fs from 'node:fs';
import path from 'node:path';
import QRCode from 'qrcode';
import { generateTotpSecret, verifyTotp, encryptSecret, decryptSecret, randomToken, sha256 } from '@oghost/shared';
import { one, exec, q, json } from '../db';
import { body, z, HttpError, bad, idParam } from '../lib/http';
import { requireAuth, hashPassword, verifyPassword, passwordPolicy, loadUserById, destroySession, hasPerm } from '../lib/auth';
import { audit } from '../services/audit';
import { sendVerification } from './auth';
import { config } from '../config';
import { deleteFirebaseUser, verifyFirebaseIdToken } from '../services/firebase';

export const accountRouter = Router();
accountRouter.use(requireAuth);

accountRouter.patch('/profile', async (req, res) => {
  const b = body(z.object({ name: z.string().max(100).nullable().optional(), username: z.string().regex(/^[a-zA-Z0-9_.-]{3,32}$/).optional() }), req);
  if (b.username) await exec('UPDATE users SET username = ? WHERE id = ?', [b.username, req.user!.id]);
  if (b.name !== undefined) await exec('UPDATE users SET name = ? WHERE id = ?', [b.name, req.user!.id]);
  await audit(req, 'account.profile_updated', { type: 'user', id: req.user!.id }, b); res.json({ user: await loadUserById(req.user!.id) });
});
accountRouter.post('/avatar', async (req, res) => {
  const b = body(z.object({ dataUrl: z.string().max(1_500_000) }), req);
  const m = b.dataUrl.match(/^data:image\/(png|jpeg|webp);base64,([A-Za-z0-9+/=]+)$/); if (!m) throw bad('Avatar must be a PNG, JPEG or WebP image');
  const buf = Buffer.from(m[2], 'base64'); if (buf.length > 1024 * 1024) throw bad('Avatar must be under 1 MB');
  const magic = buf.subarray(0, 4).toString('hex'); if (!/^(89504e47|ffd8ff|52494646)/.test(magic)) throw bad('File content is not a valid image');
  const dir = path.join(config.uploadsDir, 'avatars'); fs.mkdirSync(dir, { recursive: true });
  const name = `${req.user!.uuid}-${Date.now()}.${m[1] === 'jpeg' ? 'jpg' : m[1]}`; fs.writeFileSync(path.join(dir, name), buf);
  await exec('UPDATE users SET avatar_url = ? WHERE id = ?', [`/uploads/avatars/${name}`, req.user!.id]); res.json({ user: await loadUserById(req.user!.id) });
});
accountRouter.post('/email', async (req, res) => {
  const b = body(z.object({ email: z.string().email().max(191), password: z.string().optional() }), req);
  const u: any = await one('SELECT password_hash FROM users WHERE id = ?', [req.user!.id]);
  if (u.password_hash && !(await verifyPassword(b.password || '', u.password_hash))) throw new HttpError(401, 'Current password is incorrect');
  await exec('UPDATE users SET email = ?, email_verified_at = NULL WHERE id = ?', [b.email.toLowerCase(), req.user!.id]);
  await sendVerification({ id: req.user!.id, email: b.email.toLowerCase() }); await audit(req, 'account.email_changed', { type: 'user', id: req.user!.id });
  res.json({ user: await loadUserById(req.user!.id) });
});
accountRouter.post('/password', async (req, res) => {
  const b = body(z.object({ current: z.string().optional(), password: z.string().max(200) }), req); passwordPolicy(b.password);
  const u: any = await one('SELECT password_hash FROM users WHERE id = ?', [req.user!.id]);
  if (u.password_hash && !(await verifyPassword(b.current || '', u.password_hash))) throw new HttpError(401, 'Current password is incorrect');
  await exec('UPDATE users SET password_hash = ? WHERE id = ?', [await hashPassword(b.password), req.user!.id]);
  await exec('DELETE FROM sessions WHERE user_id = ? AND id <> ?', [req.user!.id, req.sessionId ?? '']);
  await audit(req, 'account.password_changed', { type: 'user', id: req.user!.id }); res.json({ ok: true });
});

// ---- Two-factor authentication (TOTP)
accountRouter.post('/2fa/setup', async (req, res) => {
  if (req.user!.totp_enabled) throw bad('Two-factor authentication is already enabled');
  const secret = generateTotpSecret();
  await exec('UPDATE users SET totp_secret_enc = ? WHERE id = ?', [encryptSecret(secret, config.appKey), req.user!.id]);
  const uri = `otpauth://totp/OGHOST:${encodeURIComponent(req.user!.email)}?secret=${secret}&issuer=OGHOST&algorithm=SHA1&digits=6&period=30`;
  res.json({ secret, uri, qr: await QRCode.toDataURL(uri) });
});
accountRouter.post('/2fa/enable', async (req, res) => {
  const { code } = body(z.object({ code: z.string() }), req); const u: any = await one('SELECT totp_secret_enc FROM users WHERE id = ?', [req.user!.id]);
  if (!u.totp_secret_enc || !verifyTotp(decryptSecret(u.totp_secret_enc, config.appKey), code)) throw new HttpError(422, 'Invalid code');
  const codes = Array.from({ length: 8 }, () => randomToken(5));
  await exec('UPDATE users SET totp_enabled = 1, recovery_codes = ? WHERE id = ?', [json(codes.map(c => sha256(c))), req.user!.id]);
  await audit(req, 'account.2fa_enabled', { type: 'user', id: req.user!.id }); res.json({ ok: true, recoveryCodes: codes });
});
accountRouter.post('/2fa/disable', async (req, res) => {
  const { code } = body(z.object({ code: z.string() }), req); const u: any = await one('SELECT totp_secret_enc FROM users WHERE id = ?', [req.user!.id]);
  if (!u.totp_secret_enc || !verifyTotp(decryptSecret(u.totp_secret_enc, config.appKey), code)) throw new HttpError(422, 'Invalid code');
  await exec('UPDATE users SET totp_enabled = 0, totp_secret_enc = NULL, recovery_codes = NULL WHERE id = ?', [req.user!.id]);
  await audit(req, 'account.2fa_disabled', { type: 'user', id: req.user!.id }); res.json({ ok: true });
});

// ---- Sessions
accountRouter.get('/sessions', async (req, res) => res.json({ sessions: (await q('SELECT id, ip, user_agent, created_at, last_seen_at, expires_at FROM sessions WHERE user_id = ? AND expires_at > NOW() ORDER BY last_seen_at DESC', [req.user!.id])).map((s: any) => ({ ...s, id: s.id.slice(0, 16), current: s.id === req.sessionId })) }));
accountRouter.delete('/sessions/:prefix', async (req, res) => { await exec('DELETE FROM sessions WHERE user_id = ? AND id LIKE ? AND id <> ?', [req.user!.id, `${String(req.params.prefix).replace(/[^a-f0-9]/g, '')}%`, req.sessionId ?? '']); res.json({ ok: true }); });
accountRouter.delete('/sessions', async (req, res) => { await exec('DELETE FROM sessions WHERE user_id = ? AND id <> ?', [req.user!.id, req.sessionId ?? '']); res.json({ ok: true }); });

// ---- API keys
export const API_SCOPES = ['servers.read', 'servers.write', 'files.read', 'files.write', 'store.read', 'store.write', 'coins.read', 'coins.write', 'admin.*', 'users.read', 'users.write', 'nodes.read', 'nodes.write', 'plugins.read', 'plugins.write', 'extensions.read', 'extensions.write', 'tickets.read', 'tickets.write'];
accountRouter.get('/api-keys', async (req, res) => res.json({ keys: await q('SELECT id, name, prefix, scopes, allowed_ips, last_used_at, expires_at, created_at FROM api_keys WHERE user_id = ?', [req.user!.id]), scopes: API_SCOPES }));
accountRouter.post('/api-keys', async (req, res) => {
  if (req.apiKey) throw new HttpError(403, 'API keys cannot create API keys');
  const b = body(z.object({ name: z.string().min(1).max(100), scopes: z.array(z.string()).min(1), allowedIps: z.array(z.string()).optional(), expiresDays: z.number().int().min(1).max(3650).optional() }), req);
  for (const s of b.scopes) { if (!API_SCOPES.includes(s)) throw bad(`Unknown scope ${s}`); if (s.startsWith('admin') && !hasPerm(req.user, 'admin.apikeys')) throw new HttpError(403, 'Admin scopes require the admin.apikeys permission'); }
  const prefix = randomToken(6); const secret = randomToken(24);
  await exec('INSERT INTO api_keys (user_id, name, prefix, key_hash, scopes, allowed_ips, expires_at) VALUES (?, ?, ?, ?, ?, ?, ?)', [req.user!.id, b.name, prefix, sha256(secret), json(b.scopes), b.allowedIps ? json(b.allowedIps) : null, b.expiresDays ? new Date(Date.now() + b.expiresDays * 86400_000) : null]);
  await audit(req, 'account.api_key_created', { type: 'api_key', id: prefix }, { scopes: b.scopes });
  res.status(201).json({ key: `ogh_${prefix}_${secret}`, prefix, note: 'Copy this key now. It will not be shown again.' });
});
accountRouter.delete('/api-keys/:id', async (req, res) => { await exec('DELETE FROM api_keys WHERE id = ? AND user_id = ?', [idParam(req), req.user!.id]); res.json({ ok: true }); });

// ---- Notifications
accountRouter.get('/notifications', async (req, res) => res.json({ notifications: await q('SELECT * FROM notifications WHERE user_id = ? ORDER BY id DESC LIMIT 100', [req.user!.id]), unread: (await one<any>('SELECT COUNT(*) AS c FROM notifications WHERE user_id = ? AND read_at IS NULL', [req.user!.id]))!.c }));
accountRouter.post('/notifications/read', async (req, res) => { const ids: number[] = (req.body?.ids || []).map(Number).filter(Number.isInteger); if (ids.length) await exec(`UPDATE notifications SET read_at = NOW() WHERE user_id = ? AND id IN (${ids.map(() => '?').join(',')})`, [req.user!.id, ...ids]); else await exec('UPDATE notifications SET read_at = NOW() WHERE user_id = ? AND read_at IS NULL', [req.user!.id]); res.json({ ok: true }); });

accountRouter.post('/google/unlink', async (req, res) => { if (!req.user!.has_password) throw bad('Set a password before unlinking Google, or you would lose access'); await exec('UPDATE users SET firebase_uid = NULL WHERE id = ?', [req.user!.id]); await audit(req, 'auth.google_unlinked', { type: 'user', id: req.user!.id }); res.json({ user: await loadUserById(req.user!.id) }); });

accountRouter.post('/delete', async (req, res) => {
  const b = body(z.object({ password: z.string().optional(), idToken: z.string().optional(), confirm: z.literal('DELETE') }), req);
  const u: any = await one('SELECT password_hash, firebase_uid FROM users WHERE id = ?', [req.user!.id]);
  if (u.password_hash) { if (!(await verifyPassword(b.password || '', u.password_hash))) throw new HttpError(401, 'Password is incorrect'); }
  else { const t = await verifyFirebaseIdToken(b.idToken || ''); if (t.uid !== u.firebase_uid || Date.now() / 1000 - t.auth_time > 300) throw new HttpError(401, 'Please re-authenticate with Google (within the last 5 minutes)'); }
  const servers: any = await one("SELECT COUNT(*) AS c FROM servers WHERE owner_id = ?", [req.user!.id]); if (Number(servers.c)) throw new HttpError(409, 'Delete or transfer your servers before deleting your account');
  const svc: any = await one("SELECT COUNT(*) AS c FROM services WHERE user_id = ? AND status IN ('active','pending','suspended')", [req.user!.id]); if (Number(svc.c)) throw new HttpError(409, 'Cancel active services before deleting your account');
  if (hasPerm(req.user, '*')) { const others: any = await one("SELECT COUNT(*) AS c FROM users u JOIN roles r ON r.id = u.role_id WHERE r.slug = 'super_admin' AND u.id <> ?", [req.user!.id]); if (!Number(others.c)) throw new HttpError(409, 'You are the last super admin'); }
  await audit(req, 'account.deleted', { type: 'user', id: req.user!.id });
  if (u.firebase_uid) await deleteFirebaseUser(u.firebase_uid);
  // Keep financial records (orders/invoices/payments) by anonymising instead of hard-deleting if any exist
  const fin: any = await one('SELECT (SELECT COUNT(*) FROM invoices WHERE user_id = ?) + (SELECT COUNT(*) FROM orders WHERE user_id = ?) + (SELECT COUNT(*) FROM services WHERE user_id = ?) + (SELECT COUNT(*) FROM tickets WHERE user_id = ?) AS c', [req.user!.id, req.user!.id, req.user!.id, req.user!.id]);
  await destroySession(req, res);
  if (Number(fin.c)) await exec("UPDATE users SET email = CONCAT('deleted-', uuid, '@deleted.invalid'), username = CONCAT('deleted-', id), name = NULL, password_hash = NULL, firebase_uid = NULL, avatar_url = NULL, suspended = 1, totp_enabled = 0, totp_secret_enc = NULL WHERE id = ?", [req.user!.id]);
  else await exec('DELETE FROM users WHERE id = ?', [req.user!.id]);
  res.json({ ok: true });
});
