import { Router } from 'express';
import { encryptSecret, randomToken } from '@oghost/shared';
import { q, one, exec, json, parse } from '../../db';
import { body, patchBody, z, HttpError, idParam, paginate } from '../../lib/http';
import { requirePerm } from '../../lib/auth';
import { config } from '../../config';
import { audit } from '../../services/audit';
import { allSettings, setSetting, SECRET_KEYS } from '../../services/settings';
import { sendMail } from '../../services/mail';
import { notify } from '../../services/notify';
import { pushTrustedToNodes } from '../../services/security';
import { getServer, setSuspension, syncSpec } from '../../services/servers';
import { getNode, agent } from '../../services/nodes';
import { driveAdminStats } from '../../services/drive';
import { WEBHOOK_EVENTS, deliverWebhook } from '../../services/webhooks';

export const systemAdmin = Router();

// ---------------------------------------------------------------- settings
const SETTING_KEY = /^(app|security|uploads|store|payments|drive|plugins|smtp|firebase|google|razorpay|stripe|cashfree|upi|billing|network|branding|coins|linkvertise|discord)\.[A-Za-z0-9.]{1,80}$/;
systemAdmin.get('/settings', requirePerm('admin.settings'), async (_req, res) => res.json({ settings: await allSettings(), secretKeys: [...SECRET_KEYS] }));
systemAdmin.put('/settings', requirePerm('admin.settings'), async (req, res) => {
  const b = body(z.record(z.string(), z.unknown()), req); const changed: string[] = [];
  for (const [k, v] of Object.entries(b)) {
    if (!SETTING_KEY.test(k)) throw new HttpError(422, `Unknown setting ${k}`);
    if (SECRET_KEYS.has(k) && (v === '' || v == null || (typeof v === 'object'))) continue; // empty = keep existing secret
    if (k === 'firebase.serviceAccount' && typeof v === 'string') { try { const j = JSON.parse(v); if (!j.private_key || !j.client_email) throw new Error(); } catch { throw new HttpError(422, 'firebase.serviceAccount must be the service-account JSON from Firebase console'); } }
    await setSetting(k, v); changed.push(k);
  }
  await audit(req, 'admin.settings.update', { type: 'settings', id: 'global' }, { keys: changed }); res.json({ ok: true, changed });
});
systemAdmin.post('/settings/test-mail', requirePerm('admin.settings'), async (req, res) => { await sendMail(req.user!.email, 'OGHOST PANEL test email', 'SMTP is configured correctly.'); res.json({ ok: true, to: req.user!.email }); });

// ---------------------------------------------------------------- OGHOST Security Center
const PS = requirePerm('admin.security');
systemAdmin.get('/security/overview', PS, async (_req, res) => {
  const c = async (sql: string) => Number((await one<any>(sql))?.c ?? 0);
  res.json({
    openIncidents: await c("SELECT COUNT(*) AS c FROM security_incidents WHERE status = 'open'"), highOpen: await c("SELECT COUNT(*) AS c FROM security_incidents WHERE status = 'open' AND severity = 'high'"),
    pendingReviews: await c("SELECT COUNT(*) AS c FROM security_scans WHERE review_status = 'pending'"), openAppeals: await c("SELECT COUNT(*) AS c FROM security_appeals WHERE status = 'open'"),
    blockedServers: await c('SELECT COUNT(*) AS c FROM servers WHERE security_blocked = 1'), securitySuspended: await c("SELECT COUNT(*) AS c FROM servers WHERE suspended_at IS NOT NULL AND suspension_reason LIKE 'Security:%'"),
    scans24h: await c('SELECT COUNT(*) AS c FROM security_scans WHERE created_at > DATE_SUB(NOW(), INTERVAL 1 DAY)'), trusted: await c('SELECT COUNT(*) AS c FROM trusted_software'),
    byLevel: await q('SELECT level, COUNT(*) AS c FROM security_scans WHERE created_at > DATE_SUB(NOW(), INTERVAL 30 DAY) GROUP BY level'),
    byCategory: await q('SELECT category, severity, COUNT(*) AS c FROM security_incidents WHERE created_at > DATE_SUB(NOW(), INTERVAL 30 DAY) GROUP BY category, severity ORDER BY c DESC'),
    suspended: await q("SELECT s.id, s.name, s.node_id, s.node_server_id, s.owner_id, u.email, s.suspended_at, s.suspended_until, s.suspension_reason, s.security_level, s.security_blocked FROM servers s JOIN users u ON u.id = s.owner_id WHERE s.security_blocked = 1 OR s.suspension_reason LIKE 'Security:%' ORDER BY s.suspended_at DESC"),
  });
});
systemAdmin.get('/security/scans', PS, async (req, res) => {
  const p = paginate(req); const cond: string[] = []; const v: any[] = [];
  if (req.query.level) { cond.push('sc.level = ?'); v.push(req.query.level); } if (req.query.review) { cond.push('sc.review_status = ?'); v.push(req.query.review); } if (req.query.server) { cond.push('sc.server_id = ?'); v.push(Number(req.query.server)); }
  res.json({ scans: (await q<any>(`SELECT sc.*, s.name AS server_name, s.node_id, s.node_server_id FROM security_scans sc JOIN servers s ON s.id = sc.server_id ${cond.length ? 'WHERE ' + cond.join(' AND ') : ''} ORDER BY sc.id DESC LIMIT ? OFFSET ?`, [...v, p.limit, p.offset])).map(r => ({ ...r, findings: parse(r.findings, []), minecraft: parse(r.minecraft, null) })) });
});
systemAdmin.get('/security/incidents', PS, async (req, res) => {
  const p = paginate(req); const cond: string[] = []; const v: any[] = [];
  if (req.query.status) { cond.push('i.status = ?'); v.push(req.query.status); } if (req.query.severity) { cond.push('i.severity = ?'); v.push(req.query.severity); } if (req.query.server) { cond.push('i.server_id = ?'); v.push(Number(req.query.server)); }
  res.json({ incidents: (await q<any>(`SELECT i.*, s.name AS server_name, s.owner_id FROM security_incidents i LEFT JOIN servers s ON s.id = i.server_id ${cond.length ? 'WHERE ' + cond.join(' AND ') : ''} ORDER BY i.id DESC LIMIT ? OFFSET ?`, [...v, p.limit, p.offset])).map(r => ({ ...r, evidence: parse(r.evidence, null) })) });
});
systemAdmin.post('/security/scans/:id/approve', PS, async (req, res) => {
  const sc: any = await one('SELECT * FROM security_scans WHERE id = ?', [idParam(req)]); if (!sc) throw new HttpError(404, 'Scan not found');
  const b = body(z.object({ name: z.string().min(1).max(200).optional(), note: z.string().max(500).optional() }), req);
  await exec('INSERT INTO trusted_software (sha256, name, note, added_by) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE note = VALUES(note)', [sc.sha256, b.name || sc.file.split('/').pop(), b.note ?? null, req.user!.id]);
  await exec("UPDATE security_scans SET review_status = 'approved', reviewed_by = ? WHERE sha256 = ? AND review_status IN ('pending','rejected')", [req.user!.id, sc.sha256]);
  await pushTrustedToNodes();
  const unblocked: number[] = [];
  for (const s of await q<any>("SELECT DISTINCT s.id, s.owner_id, s.name, s.suspension_reason FROM servers s JOIN security_scans sc ON sc.server_id = s.id WHERE sc.sha256 = ? AND s.security_blocked = 1", [sc.sha256])) {
    const pending = await one<any>("SELECT COUNT(*) AS c FROM security_scans WHERE server_id = ? AND review_status = 'pending'", [s.id]);
    if (Number(pending.c) || s.suspension_reason?.startsWith('Security:')) continue; // high-risk suspensions are released explicitly
    await exec("UPDATE servers SET security_blocked = 0, security_level = 'safe' WHERE id = ?", [s.id]); await syncSpec(s.id).catch(() => {}); unblocked.push(s.id);
    await notify(s.owner_id, 'security', `"${s.name}" approved`, 'An administrator verified your software. You can start the server now.', { link: `/server/${s.id}` });
  }
  await audit(req, 'security.approve', { type: 'scan', id: sc.id }, { sha256: sc.sha256, file: sc.file, unblocked }); res.json({ ok: true, unblocked });
});
systemAdmin.post('/security/scans/:id/reject', PS, async (req, res) => {
  const sc: any = await one('SELECT sc.*, s.owner_id, s.name FROM security_scans sc JOIN servers s ON s.id = sc.server_id WHERE sc.id = ?', [idParam(req)]); if (!sc) throw new HttpError(404, 'Scan not found');
  const b = body(z.object({ reason: z.string().min(1).max(500) }), req);
  await exec("UPDATE security_scans SET review_status = 'rejected', reviewed_by = ? WHERE id = ?", [req.user!.id, sc.id]); await exec('UPDATE servers SET security_blocked = 1 WHERE id = ?', [sc.server_id]); await syncSpec(sc.server_id).catch(() => {});
  await notify(sc.owner_id, 'security', `Software rejected on "${sc.name}"`, `${sc.file}: ${b.reason}. Remove the file to start the server again (your files were not deleted).`, { link: `/server/${sc.server_id}`, email: true });
  await audit(req, 'security.reject', { type: 'scan', id: sc.id }, b); res.json({ ok: true });
});
systemAdmin.post('/security/incidents/:id/resolve', PS, async (req, res) => {
  const b = body(z.object({ status: z.enum(['resolved', 'dismissed']), note: z.string().max(2000).optional() }), req);
  const r = await exec('UPDATE security_incidents SET status = ?, review_note = ?, reviewed_by = ? WHERE id = ?', [b.status, b.note ?? null, req.user!.id, idParam(req)]); if (!r.affectedRows) throw new HttpError(404, 'Incident not found');
  await audit(req, 'security.incident.' + b.status, { type: 'incident', id: idParam(req) }, b); res.json({ ok: true });
});
systemAdmin.post('/security/servers/:id/extend', PS, async (req, res) => {
  const b = body(z.object({ hours: z.number().int().min(1).max(8760).nullable(), reason: z.string().max(300).optional() }), req); const s = await getServer(idParam(req));
  if (!s.suspended_at) throw new HttpError(409, 'Server is not suspended');
  const until = b.hours ? new Date(Math.max(Date.now(), s.suspended_until ? new Date(s.suspended_until).getTime() : Date.now()) + b.hours * 3600_000) : null;
  await exec('UPDATE servers SET suspended_until = ? WHERE id = ?', [until, s.id]);
  await notify(s.owner_id, 'security', `Suspension of "${s.name}" extended`, `${until ? `Until ${until.toUTCString()}` : 'Until an administrator releases it'}.${b.reason ? ` Reason: ${b.reason}` : ''}`, { link: `/server/${s.id}`, email: true });
  await audit(req, 'security.extend', { type: 'server', id: s.id }, { ...b, until }); res.json({ ok: true, until });
});
systemAdmin.post('/security/servers/:id/suspend', PS, async (req, res) => {
  const b = body(z.object({ hours: z.number().int().min(1).max(8760).nullable().default(48), reason: z.string().min(1).max(300) }), req); const s = await getServer(idParam(req));
  await exec('UPDATE servers SET security_blocked = 1 WHERE id = ?', [s.id]); await setSuspension(s.id, true, `Security: ${b.reason}`, b.hours);
  const node = await getNode(s.node_id); await agent(node, 'POST', `/api/servers/${s.node_server_id}/power`, { action: 'kill' }, { serverId: s.node_server_id }).catch(() => {});
  await exec("INSERT INTO security_incidents (server_id, node_id, severity, category, rule, action_taken, reviewed_by) VALUES (?, ?, 'high', 'manual', 'admin-action', ?, ?)", [s.id, s.node_id, `Suspended by admin ${b.hours ? `for ${b.hours}h` : 'indefinitely'}`, req.user!.id]);
  await notify(s.owner_id, 'security', `Server "${s.name}" suspended`, b.reason, { link: `/server/${s.id}`, email: true }); await audit(req, 'security.suspend', { type: 'server', id: s.id }, b); res.json({ ok: true });
});
systemAdmin.post('/security/servers/:id/release', PS, async (req, res) => {
  const s = await getServer(idParam(req)); const b = body(z.object({ note: z.string().max(500).optional() }), req);
  await exec("UPDATE servers SET security_blocked = 0, security_level = 'unscanned' WHERE id = ?", [s.id]); await setSuspension(s.id, false, null, null);
  await exec("UPDATE security_incidents SET status = 'resolved', reviewed_by = ?, review_note = COALESCE(?, review_note) WHERE server_id = ? AND status = 'open'", [req.user!.id, b.note ?? null, s.id]);
  await notify(s.owner_id, 'security', `"${s.name}" released`, 'An administrator lifted the security restriction. Files are scanned again before the next start.', { link: `/server/${s.id}` });
  await audit(req, 'security.release', { type: 'server', id: s.id }, b); res.json({ ok: true });
});
systemAdmin.post('/security/servers/:id/rescan', PS, async (req, res) => { const s = await getServer(idParam(req)); const node = await getNode(s.node_id); res.json(await agent(node, 'POST', `/api/servers/${s.node_server_id}/scan`, undefined, { serverId: s.node_server_id, timeoutMs: 600_000 })); });
systemAdmin.get('/security/appeals', PS, async (req, res) => res.json({ appeals: await q(`SELECT a.*, s.name AS server_name, u.email FROM security_appeals a JOIN servers s ON s.id = a.server_id JOIN users u ON u.id = a.user_id ${req.query.status ? 'WHERE a.status = ?' : ''} ORDER BY a.id DESC LIMIT 200`, req.query.status ? [req.query.status] : []) }));
systemAdmin.post('/security/appeals/:id/respond', PS, async (req, res) => {
  const b = body(z.object({ status: z.enum(['accepted', 'rejected']), response: z.string().min(1).max(2000), release: z.boolean().default(false) }), req);
  const a: any = await one('SELECT a.*, s.name FROM security_appeals a JOIN servers s ON s.id = a.server_id WHERE a.id = ?', [idParam(req)]); if (!a) throw new HttpError(404, 'Appeal not found');
  await exec('UPDATE security_appeals SET status = ?, response = ? WHERE id = ?', [b.status, b.response, a.id]);
  if (b.status === 'accepted' && b.release) { await exec("UPDATE servers SET security_blocked = 0, security_level = 'unscanned' WHERE id = ?", [a.server_id]); await setSuspension(a.server_id, false, null, null); }
  await notify(a.user_id, 'security', `Appeal ${b.status} for "${a.name}"`, b.response, { link: `/server/${a.server_id}`, email: true });
  await audit(req, 'security.appeal.' + b.status, { type: 'appeal', id: a.id }, b); res.json({ ok: true });
});
systemAdmin.get('/security/trusted', PS, async (_req, res) => res.json({ trusted: await q('SELECT t.*, u.email AS added_by_email FROM trusted_software t LEFT JOIN users u ON u.id = t.added_by ORDER BY t.id DESC') }));
systemAdmin.post('/security/trusted', PS, async (req, res) => { const b = body(z.object({ sha256: z.string().regex(/^[a-f0-9]{64}$/), name: z.string().min(1).max(200), note: z.string().max(500).optional() }), req); await exec('INSERT INTO trusted_software (sha256, name, note, added_by) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE name = VALUES(name), note = VALUES(note)', [b.sha256, b.name, b.note ?? null, req.user!.id]); await pushTrustedToNodes(); await audit(req, 'security.trust', { type: 'sha256', id: b.sha256 }, b); res.status(201).json({ ok: true }); });
systemAdmin.delete('/security/trusted/:id', PS, async (req, res) => { await exec('DELETE FROM trusted_software WHERE id = ?', [idParam(req)]); await pushTrustedToNodes(); await audit(req, 'security.untrust', { type: 'trusted', id: idParam(req) }); res.json({ ok: true }); });

// ---------------------------------------------------------------- Google Drive statistics (no access to customers' Drive files)
systemAdmin.get('/drive', requirePerm('admin.drive'), async (_req, res) => res.json(await driveAdminStats()));

// ---------------------------------------------------------------- audit logs
systemAdmin.get('/audit', requirePerm('admin.audit'), async (req, res) => {
  const p = paginate(req); const cond: string[] = []; const v: any[] = [];
  if (req.query.user) { cond.push('a.user_id = ?'); v.push(Number(req.query.user)); } if (req.query.action) { cond.push('a.action LIKE ?'); v.push(`${req.query.action}%`); }
  if (req.query.target_type) { cond.push('a.target_type = ?'); v.push(req.query.target_type); } if (req.query.target_id) { cond.push('a.target_id = ?'); v.push(String(req.query.target_id)); }
  res.json({ logs: (await q<any>(`SELECT a.*, u.email FROM audit_logs a LEFT JOIN users u ON u.id = a.user_id ${cond.length ? 'WHERE ' + cond.join(' AND ') : ''} ORDER BY a.id DESC LIMIT ? OFFSET ?`, [...v, p.limit, p.offset])).map(r => ({ ...r, metadata: parse(r.metadata, null) })) });
});

// ---------------------------------------------------------------- announcements
const annSchema = z.object({ title: z.string().min(1).max(200), body: z.string().min(1).max(10000), level: z.enum(['info', 'warning', 'maintenance', 'critical']).default('info'), startsAt: z.string().datetime().nullable().optional(), endsAt: z.string().datetime().nullable().optional(), email: z.boolean().default(false) });
systemAdmin.get('/announcements', requirePerm('admin.announcements'), async (_req, res) => res.json({ announcements: await q('SELECT * FROM announcements ORDER BY id DESC') }));
systemAdmin.post('/announcements', requirePerm('admin.announcements'), async (req, res) => {
  const b = body(annSchema, req);
  const r = await exec('INSERT INTO announcements (title, body, level, starts_at, ends_at, created_by) VALUES (?, ?, ?, ?, ?, ?)', [b.title, b.body, b.level, b.startsAt ? new Date(b.startsAt) : null, b.endsAt ? new Date(b.endsAt) : null, req.user!.id]);
  let emailed = 0;
  if (b.email) { for (const u of await q<any>('SELECT email FROM users WHERE suspended = 0 AND email_verified_at IS NOT NULL')) { await sendMail(u.email, `[${b.level.toUpperCase()}] ${b.title}`, b.body).then(() => emailed++).catch(() => {}); } await exec('UPDATE announcements SET email_sent = 1 WHERE id = ?', [r.insertId]); }
  await audit(req, 'admin.announcement.create', { type: 'announcement', id: r.insertId }, { title: b.title, emailed }); res.status(201).json({ id: r.insertId, emailed });
});
systemAdmin.patch('/announcements/:id', requirePerm('admin.announcements'), async (req, res) => { const b = patchBody(annSchema.partial(), req); await exec('UPDATE announcements SET title = COALESCE(?, title), body = COALESCE(?, body), level = COALESCE(?, level), starts_at = IF(? = 1, ?, starts_at), ends_at = IF(? = 1, ?, ends_at) WHERE id = ?', [b.title ?? null, b.body ?? null, b.level ?? null, b.startsAt !== undefined ? 1 : 0, b.startsAt ? new Date(b.startsAt) : null, b.endsAt !== undefined ? 1 : 0, b.endsAt ? new Date(b.endsAt) : null, idParam(req)]); res.json({ ok: true }); });
systemAdmin.delete('/announcements/:id', requirePerm('admin.announcements'), async (req, res) => { await exec('DELETE FROM announcements WHERE id = ?', [idParam(req)]); res.json({ ok: true }); });

// ---------------------------------------------------------------- outgoing webhooks
const hookSchema = z.object({ url: z.string().url().max(500).refine(u => u.startsWith('https://') || config.env !== 'production', 'Webhook URLs must use https'), events: z.array(z.string()).min(1).max(50), enabled: z.boolean().default(true) });
systemAdmin.get('/webhooks', requirePerm('admin.settings'), async (_req, res) => res.json({ webhooks: (await q<any>('SELECT id, url, events, enabled, last_status, last_delivery_at, created_at FROM outgoing_webhooks ORDER BY id')).map(h => ({ ...h, events: parse(h.events, []) })), events: WEBHOOK_EVENTS }));
systemAdmin.post('/webhooks', requirePerm('admin.settings'), async (req, res) => {
  const b = body(hookSchema, req); for (const e of b.events) if (e !== '*' && !WEBHOOK_EVENTS.includes(e)) throw new HttpError(422, `Unknown event ${e}`);
  const secret = `whsec_${randomToken(24)}`;
  const r = await exec('INSERT INTO outgoing_webhooks (url, secret_enc, events, enabled, created_by) VALUES (?, ?, ?, ?, ?)', [b.url, encryptSecret(secret, config.appKey), json(b.events), b.enabled ? 1 : 0, req.user!.id]);
  await audit(req, 'admin.webhook.create', { type: 'webhook', id: r.insertId }, { url: b.url, events: b.events }); res.status(201).json({ id: r.insertId, secret, note: 'Store this signing secret now; it is not shown again.' });
});
systemAdmin.patch('/webhooks/:id', requirePerm('admin.settings'), async (req, res) => { const b = patchBody(hookSchema.partial(), req); await exec('UPDATE outgoing_webhooks SET url = COALESCE(?, url), events = COALESCE(?, events), enabled = COALESCE(?, enabled) WHERE id = ?', [b.url ?? null, b.events ? json(b.events) : null, b.enabled === undefined ? null : b.enabled ? 1 : 0, idParam(req)]); res.json({ ok: true }); });
systemAdmin.post('/webhooks/:id/test', requirePerm('admin.settings'), async (req, res) => { const h = await one('SELECT * FROM outgoing_webhooks WHERE id = ?', [idParam(req)]); if (!h) throw new HttpError(404, 'Webhook not found'); res.json({ status: await deliverWebhook(h, 'ping', { test: true, by: req.user!.id }) }); });
systemAdmin.delete('/webhooks/:id', requirePerm('admin.settings'), async (req, res) => { await exec('DELETE FROM outgoing_webhooks WHERE id = ?', [idParam(req)]); res.json({ ok: true }); });

// ---------------------------------------------------------------- API keys (all users) & background jobs
systemAdmin.get('/api-keys', requirePerm('admin.apikeys'), async (_req, res) => res.json({ keys: (await q<any>('SELECT k.id, k.user_id, u.email, k.name, k.prefix, k.scopes, k.allowed_ips, k.last_used_at, k.expires_at, k.created_at FROM api_keys k JOIN users u ON u.id = k.user_id ORDER BY k.id DESC')).map(k => ({ ...k, scopes: parse(k.scopes, []), allowed_ips: parse(k.allowed_ips, null) })) }));
systemAdmin.delete('/api-keys/:id', requirePerm('admin.apikeys'), async (req, res) => { await exec('DELETE FROM api_keys WHERE id = ?', [idParam(req)]); await audit(req, 'admin.apikey.revoke', { type: 'api_key', id: idParam(req) }); res.json({ ok: true }); });
systemAdmin.get('/jobs', requirePerm('admin.overview'), async (req, res) => { const p = paginate(req); res.json({ jobs: (await q<any>(`SELECT id, type, payload, status, attempts, max_attempts, run_at, last_error, result, created_at, finished_at FROM jobs ${req.query.status ? 'WHERE status = ?' : ''} ORDER BY id DESC LIMIT ? OFFSET ?`, [...(req.query.status ? [req.query.status] : []), p.limit, p.offset])).map(j => ({ ...j, payload: parse(j.payload, null), result: parse(j.result, null) })) }); });
systemAdmin.post('/jobs/:id/retry', requirePerm('admin.servers'), async (req, res) => { const r = await exec("UPDATE jobs SET status = 'queued', attempts = 0, run_at = NOW(), locked_at = NULL, unique_key = NULL WHERE id = ? AND status = 'failed'", [idParam(req)]); if (!r.affectedRows) throw new HttpError(409, 'Only failed jobs can be retried'); res.json({ ok: true }); });
