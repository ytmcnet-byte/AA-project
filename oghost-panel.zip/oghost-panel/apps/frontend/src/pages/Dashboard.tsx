import { Link } from 'react-router-dom';
import { Server, Cpu, MemoryStick, HardDrive, Receipt, LifeBuoy, Plus } from 'lucide-react';
import { useApi } from '../lib/hooks';
import { useAuth } from '../lib/auth';
import { Badge, Card, Empty, ErrorBox, Loading, PageHeader, Stat } from '../components/ui';
import { mb, money } from '../lib/format';

export function ServerCard({ s }: { s: any }) {
  return (
    <Link to={`/server/${s.id}`} className="card card-pad group block transition hover:border-brand-700/70 hover:bg-ink-850">
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0"><div className="truncate font-bold text-white group-hover:text-brand-400">{s.name}</div><div className="mt-0.5 truncate text-xs text-ink-400">{s.egg?.name} · Node {s.node?.name} · ID {s.nodeId}/{s.nodeServerId}</div></div>
        <div className="flex shrink-0 flex-col items-end gap-1"><Badge value={s.suspended ? 'suspended' : s.state} />{s.securityBlocked && <Badge value="blocked" label="security review" />}</div>
      </div>
      <div className="mt-4 grid grid-cols-3 gap-2 text-xs text-ink-300">
        <div className="flex items-center gap-1.5"><MemoryStick className="h-3.5 w-3.5 text-ink-400" />{mb(s.limits.memoryMb)}</div>
        <div className="flex items-center gap-1.5"><Cpu className="h-3.5 w-3.5 text-ink-400" />{s.limits.cpuPercent ? `${s.limits.cpuPercent / 100} core${s.limits.cpuPercent > 100 ? 's' : ''}` : 'Unlimited'}</div>
        <div className="flex items-center gap-1.5"><HardDrive className="h-3.5 w-3.5 text-ink-400" />{mb(s.limits.diskMb)}</div>
      </div>
      <div className="mt-3 flex items-center justify-between border-t border-ink-800 pt-3 text-xs"><span className="font-mono text-ink-300">{s.address || 'no allocation'}</span>{s.node?.status !== 'online' && <span className="text-amber-400">node {s.node?.status}</span>}{s.relation === 'subuser' && <span className="text-sky-400">shared with you</span>}</div>
    </Link>
  );
}

export function ServerList() {
  const { data, error, loading, reload } = useApi<any>('/api/servers', [], 15000);
  const { config } = useAuth();
  return (
    <>
      <PageHeader title="My Servers" subtitle="Servers you own or have been invited to." actions={config?.storeEnabled && <Link to="/store" className="btn-primary"><Plus className="h-4 w-4" />New server</Link>} />
      {error && <ErrorBox error={error} onRetry={reload} />}
      {loading && !data ? <Loading /> : data?.servers?.length ? <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">{data.servers.map((s: any) => <ServerCard key={s.id} s={s} />)}</div> : <div className="card"><Empty title="No servers yet" icon={<Server className="h-8 w-8" />}>{config?.storeEnabled ? <>Order a plan from the <Link to="/store" className="link">store</Link> and your server will be created automatically after payment.</> : 'Ask an administrator to create a server for you.'}</Empty></div>}
    </>
  );
}

export function Dashboard() {
  const { user, config } = useAuth();
  const servers = useApi<any>('/api/servers', [], 15000);
  const invoices = useApi<any>(config?.storeEnabled ? '/api/store/invoices' : null);
  const tickets = useApi<any>('/api/tickets');
  const list = servers.data?.servers || [];
  const unpaid = (invoices.data?.invoices || []).filter((i: any) => i.status === 'unpaid');
  const open = (tickets.data?.tickets || []).filter((t: any) => t.status !== 'closed');
  return (
    <>
      <PageHeader title={`Welcome, ${user?.name || user?.username}`} subtitle="Powering the Next Generation of Game Hosting." />
      <div className="mb-6 grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="Servers" value={servers.data ? list.length : '…'} icon={<Server className="h-4 w-4" />} sub={servers.data ? `${list.filter((s: any) => s.state === 'running').length} running` : undefined} />
        <Stat label="Running" value={servers.data ? list.filter((s: any) => s.state === 'running').length : '…'} icon={<Cpu className="h-4 w-4" />} sub="as last reported by nodes" />
        <Stat label="Unpaid invoices" value={invoices.data ? unpaid.length : config?.storeEnabled ? '…' : '—'} icon={<Receipt className="h-4 w-4" />} sub={unpaid.length ? money(unpaid.reduce((a: number, i: any) => a + i.total_cents, 0), unpaid[0]?.currency) : undefined} />
        <Stat label="Open tickets" value={tickets.data ? open.length : '…'} icon={<LifeBuoy className="h-4 w-4" />} />
      </div>
      {unpaid.length > 0 && <div className="mb-6 rounded-lg border border-amber-900/60 bg-amber-950/30 p-3 text-sm text-amber-200">You have {unpaid.length} unpaid invoice{unpaid.length > 1 ? 's' : ''}. <Link className="link" to="/billing">Review billing</Link></div>}
      <Card title="Your servers" actions={<Link to="/servers" className="link text-sm">View all</Link>}>
        {servers.error && <ErrorBox error={servers.error} />}
        {servers.loading && !servers.data ? <Loading /> : list.length ? <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">{list.slice(0, 6).map((s: any) => <ServerCard key={s.id} s={s} />)}</div> : <Empty title="No servers yet" icon={<Server className="h-8 w-8" />}>{config?.storeEnabled ? <Link to="/store" className="link">Browse plans</Link> : 'Ask an administrator to create one for you.'}</Empty>}
      </Card>
    </>
  );
}
