export * from './crypto';
export * from './paths';
export * from './types';
export * from './eggs';
export * from './startup';
export * from './jarscan';
export const OGHOST_VERSION = '1.0.0';
export const BRAND = { name: 'OGHOST PANEL', tagline: 'Powering the Next Generation of Game Hosting.', credit: 'Powered by SHIVAMBROOG' };
