import { CronExpressionParser } from 'cron-parser';
import { q, one, exec, json } from '../db';
import { HttpError } from '../lib/http';
import { power, getServer } from './servers';
import { getNode, agent } from './nodes';
import { requestBackup, pruneBackups } from './backups';
import { notify } from './notify';
import { registerJob, enqueue } from './jobs';

export function nextRun(cron: string | null, runOnceAt: Date | null, tz: string, from = new Date()): Date | null {
  if (runOnceAt) return runOnceAt > from ? runOnceAt : null;
  if (!cron) return null;
  try { Intl.DateTimeFormat('en-US', { timeZone: tz }); } catch { throw new HttpError(422, `Unknown timezone ${tz}`); }
  try { return CronExpressionParser.parse(cron, { tz, currentDate: from }).next().toDate(); }
  catch (e: any) { throw new HttpError(422, `Invalid cron expression: ${e.message}`); }
}

const wait = (ms: number) => new Promise(r => setTimeout(r, ms));

export async function runSchedule(scheduleId: number, manual = false) {
  const s: any = await one('SELECT * FROM schedules WHERE id = ?', [scheduleId]); if (!s) return;
  const server = await getServer(s.server_id);
  const tasks = await q('SELECT * FROM schedule_tasks WHERE schedule_id = ? ORDER BY sequence, id', [scheduleId]);
  const run = await exec("INSERT INTO schedule_runs (schedule_id, status) VALUES (?, 'running')", [scheduleId]);
  await exec('UPDATE schedules SET is_processing = 1, last_run_at = NOW() WHERE id = ?', [scheduleId]);
  const out: any[] = []; let failed = false;
  try {
    if (s.only_when_online && !manual) {
      const node = await getNode(server.node_id); const st = await agent(node, 'GET', `/api/servers/${server.node_server_id}`, undefined, { serverId: server.node_server_id }).catch(() => null);
      if (st?.state !== 'running') { out.push({ skipped: 'Server is not running' }); return; }
    }
    if (server.suspended_at) { out.push({ skipped: 'Server is suspended' }); return; }
    for (const t of tasks) {
      if (t.delay_seconds) await wait(Math.min(t.delay_seconds, 900) * 1000);
      try {
        let r: unknown = null;
        if (['start', 'stop', 'restart', 'kill'].includes(t.action)) r = await power(server.id, t.action);
        else if (t.action === 'command') { const node = await getNode(server.node_id); r = await agent(node, 'POST', `/api/servers/${server.node_server_id}/command`, { command: t.payload || '' }, { serverId: server.node_server_id }); }
        else if (t.action === 'backup') { const b = await requestBackup(server.id, t.payload || `Scheduled: ${s.name}`, { wait: true }); if (b.status !== 'completed') throw new Error(b.error || 'Backup failed'); r = { backup: b.uuid }; }
        else if (t.action === 'delete_old_backups') r = { deleted: await pruneBackups(server.id, Math.max(0, Number(t.payload || 3))) };
        else if (t.action === 'notify') { await notify(server.owner_id, 'schedule', `Schedule "${s.name}"`, t.payload || 'Schedule ran', { link: `/server/${server.id}/schedules` }); r = { notified: true }; }
        out.push({ task: t.id, action: t.action, ok: true, result: r });
      } catch (e: any) {
        out.push({ task: t.id, action: t.action, ok: false, error: e.message });
        if (!t.continue_on_failure) { failed = true; break; }
      }
    }
  } finally {
    await exec('UPDATE schedule_runs SET status = ?, output = ?, finished_at = NOW() WHERE id = ?', [failed ? 'failed' : 'success', json(out), run.insertId]);
    const next = s.run_once_at ? null : nextRun(s.cron, null, s.timezone);
    await exec('UPDATE schedules SET is_processing = 0, next_run_at = ?, enabled = IF(run_once_at IS NOT NULL, 0, enabled) WHERE id = ?', [next, scheduleId]);
    // keep the last 100 runs per schedule
    await exec('DELETE FROM schedule_runs WHERE schedule_id = ? AND id < (SELECT m FROM (SELECT MIN(id) AS m FROM (SELECT id FROM schedule_runs WHERE schedule_id = ? ORDER BY id DESC LIMIT 100) x) y)', [scheduleId, scheduleId]);
    if (failed && s.notify_on_failure) await notify(server.owner_id, 'schedule', `Schedule "${s.name}" failed`, out.filter(o => !o.ok).map(o => `${o.action}: ${o.error}`).join('\n'), { link: `/server/${server.id}/schedules`, email: true });
  }
  return out;
}
registerJob('schedule.run', async (p) => runSchedule(p.scheduleId, !!p.manual));

/** Called every 15s: queues due schedules (unique key prevents overlapping runs of the same schedule). */
export async function tickSchedules() {
  const due = await q("SELECT id FROM schedules WHERE enabled = 1 AND is_processing = 0 AND next_run_at IS NOT NULL AND next_run_at <= NOW() LIMIT 100");
  for (const d of due) { await exec('UPDATE schedules SET next_run_at = NULL WHERE id = ?', [d.id]); await enqueue('schedule.run', { scheduleId: d.id }, { uniqueKey: `schedule:${d.id}`, maxAttempts: 1 }); }
  // safety: schedules stuck processing for > 6 hours (panel crash) are released
  await exec('UPDATE schedules SET is_processing = 0 WHERE is_processing = 1 AND last_run_at < DATE_SUB(NOW(), INTERVAL 6 HOUR)');
  const lost = await q('SELECT id, cron, timezone FROM schedules WHERE enabled = 1 AND is_processing = 0 AND next_run_at IS NULL AND cron IS NOT NULL AND run_once_at IS NULL');
  for (const l of lost) { const pending: any = await one("SELECT id FROM jobs WHERE unique_key = ?", [`schedule:${l.id}`]); if (!pending) await exec('UPDATE schedules SET next_run_at = ? WHERE id = ?', [nextRun(l.cron, null, l.timezone), l.id]).catch(() => {}); }
}
