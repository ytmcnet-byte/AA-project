import { useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { Copy, Plus, RefreshCw, Trash2 } from 'lucide-react';
import { useApi, useAction, toast } from '../../lib/hooks';
import { api } from '../../lib/api';
import { ago, bytes, date, dur, mb, pct } from '../../lib/format';
import { Badge, Bar, Card, Confirm, Empty, ErrorBox, Field, Loading, Modal, Notice, PageHeader, Spinner, Stat, Switch, Table, Tabs } from '../../components/ui';
import { FormFields, type FieldDef } from './Crud';

const nodeFields = (locs: any[]): FieldDef[] => [
  { key: 'name', label: 'Name' }, { key: 'locationId', label: 'Location', type: 'select', options: locs.map(l => ({ value: l.id, label: `${l.name} (${l.short})` })) },
  { key: 'fqdn', label: 'Agent hostname / IP (from the panel)', hint: 'Panel → agent connection address' }, { key: 'publicIp', label: 'Public IP for players', hint: 'Used for connection addresses and reachability checks' },
  { key: 'scheme', label: 'Scheme', type: 'select', options: [{ value: 'https', label: 'https (TLS, recommended)' }, { value: 'http', label: 'http (private network only)' }] }, { key: 'port', label: 'Agent port', type: 'number' },
  { key: 'memoryMb', label: 'Memory to allocate (MB)', type: 'number' }, { key: 'memoryOverallocate', label: 'Memory over-allocation %', type: 'number', hint: '0 = none, -1..-100 reserve' },
  { key: 'diskMb', label: 'Disk to allocate (MB)', type: 'number' }, { key: 'diskOverallocate', label: 'Disk over-allocation %', type: 'number' },
  { key: 'cpuPercent', label: 'CPU capacity % (0 = unlimited)', type: 'number' }, { key: 'maxServers', label: 'Max servers (0 = unlimited)', type: 'number' },
];

function EnvModal({ env, onClose, title = 'Agent configuration' }: { env: string | null; onClose: () => void; title?: string }) {
  return <Modal open={!!env} onClose={onClose} title={title} wide>
    <Notice kind="warn" className="mb-3">This contains the node secret. Save it as <span className="font-mono">~/oghost-agent/agent.env</span> on the node (chmod 600), then start the agent with <span className="font-mono">bash installer/install.sh --agent</span> or <span className="font-mono">node dist/agent.mjs</span>.</Notice>
    <pre className="max-h-[50vh] overflow-auto rounded-lg bg-ink-950 p-3 text-xs">{env}</pre>
    <div className="mt-3 flex justify-end"><button className="btn-secondary" onClick={() => { navigator.clipboard.writeText(env || ''); toast('Copied', 'success'); }}><Copy className="h-4 w-4" />Copy</button></div>
  </Modal>;
}

export function NodesAdmin() {
  const { data, error, loading, reload } = useApi<any>('/api/admin/nodes', [], 10000); const locs = useApi<any>('/api/admin/locations'); const { busy, run } = useAction(); const nav = useNavigate();
  const [create, setCreate] = useState<any>(null); const [env, setEnv] = useState<string | null>(null);
  return <><PageHeader title="Nodes" subtitle="Each node runs the OGHOST agent as a normal (non-root) user. The panel talks to it over TLS with short-lived signed tokens." actions={<button className="btn-primary" disabled={!locs.data?.locations?.length} title={locs.data?.locations?.length ? '' : 'Create a location first'} onClick={() => setCreate({ name: '', locationId: locs.data.locations[0].id, fqdn: '', publicIp: '', scheme: 'https', port: 8443, memoryMb: 8192, memoryOverallocate: 0, diskMb: 51200, diskOverallocate: 0, cpuPercent: 0, maxServers: 0 })}><Plus className="h-4 w-4" />New node</button>} />
    {locs.data && !locs.data.locations.length && <Notice className="mb-4">Create a <Link className="link" to="/admin/locations">location</Link> before adding nodes.</Notice>}
    {loading ? <Loading /> : error ? <ErrorBox error={error} onRetry={reload} /> : !data.nodes.length ? <Card><Empty title="No nodes yet" /></Card> :
      <div className="grid gap-4 lg:grid-cols-2">{data.nodes.map((n: any) => { const hb = n.heartbeat; return <button key={n.id} className="card card-pad text-left transition hover:border-brand-700" onClick={() => nav(`/admin/nodes/${n.id}`)}>
        <div className="flex items-start justify-between"><div><div className="text-lg font-bold">{n.name} <span className="text-sm font-normal text-ink-400">#{n.id}</span></div><div className="text-xs text-ink-400">{n.location_name} · {n.scheme}://{n.fqdn}:{n.port} · public {n.public_ip}</div></div>
          <Badge value={n.emergency ? 'high_risk' : n.maintenance ? 'suspicious' : n.status} label={n.emergency ? 'emergency' : n.maintenance ? 'maintenance' : n.status} /></div>
        <div className="mt-4 grid grid-cols-3 gap-4 text-xs">
          <div><div className="text-ink-400">Allocated RAM</div>{mb(n.capacity.memory)} / {mb(Math.round(n.capacity.memoryMax))}<Bar value={n.capacity.memory} max={n.capacity.memoryMax} /></div>
          <div><div className="text-ink-400">Allocated disk</div>{mb(n.capacity.disk)} / {mb(Math.round(n.capacity.diskMax))}<Bar value={n.capacity.disk} max={n.capacity.diskMax} /></div>
          <div><div className="text-ink-400">Servers / ports</div>{n.capacity.servers}{n.max_servers ? ` / ${n.max_servers}` : ''} · {n.allocations} ports</div>
        </div>
        <div className="mt-3 text-xs text-ink-400">{hb ? <>Host CPU {pct(hb.cpu.usagePercent)} of {hb.cpu.cores} cores · RAM {bytes(hb.memory.total - hb.memory.free)} / {bytes(hb.memory.total)} · {hb.arch} · agent v{hb.version} · heartbeat {ago(n.last_heartbeat_at)}</> : 'No heartbeat received yet'}</div>
      </button>; })}</div>}
    <Modal open={!!create} onClose={() => setCreate(null)} wide title="New node" footer={<><button className="btn-secondary" onClick={() => setCreate(null)}>Cancel</button><button className="btn-primary" disabled={!!busy} onClick={() => run('c', async () => { const r = await api('POST', '/api/admin/nodes', create); setCreate(null); setEnv(r.agentEnv); reload(); })}>{busy && <Spinner />}Create</button></>}>
      {create && <FormFields fields={nodeFields(locs.data?.locations || [])} value={create} onChange={setCreate} />}
    </Modal>
    <EnvModal env={env} onClose={() => setEnv(null)} title="Node created — agent configuration" />
  </>;
}

export function NodeDetailAdmin() {
  const { id } = useParams(); const nav = useNavigate();
  const { data, error, loading, reload } = useApi<any>(`/api/admin/nodes/${id}`, [], 10000); const locs = useApi<any>('/api/admin/locations');
  const [tab, setTab] = useState<'about' | 'settings' | 'allocations' | 'servers' | 'maintenance'>('about'); const { busy, run } = useAction();
  const [env, setEnv] = useState<string | null>(null); const [edit, setEdit] = useState<any>(null); const [del, setDel] = useState(false);
  if (loading) return <Loading />; if (error) return <ErrorBox error={error} onRetry={reload} />;
  const n = data.node; const hb = n.heartbeat;
  const e = edit || { name: n.name, locationId: n.location_id, fqdn: n.fqdn, publicIp: n.public_ip, scheme: n.scheme, port: n.port, memoryMb: n.memory_mb, memoryOverallocate: n.memory_overalloc, diskMb: n.disk_mb, diskOverallocate: n.disk_overalloc, cpuPercent: n.cpu_percent, maxServers: n.max_servers };
  return <><PageHeader title={<>{n.name} <Badge value={n.status} className="ml-2 align-middle" /></>} subtitle={<>Node #{n.id} · {n.location_name ? `${n.location_name} · ` : ""}{n.scheme}://{n.fqdn}:{n.port}</>}
      actions={<><button className="btn-secondary" onClick={() => run('cfg', async () => setEnv((await api('GET', `/api/admin/nodes/${n.id}/configuration`)).agentEnv))}>Show agent config</button><button className="btn-danger" onClick={() => setDel(true)}>Delete</button></>} />
    {n.scheme === 'http' && <Notice kind="warn" className="mb-4">This node uses plain http. Node traffic, including file contents, is not encrypted. Use https or a private network or tunnel.</Notice>}
    {hb?.runningAsRoot && <Notice kind="error" className="mb-4">The agent on this node is running as root. Run it as an unprivileged user.</Notice>}
    {n.emergency ? <Notice kind="error" className="mb-4">Emergency maintenance: servers are stopped and cannot start.</Notice> : n.maintenance ? <Notice kind="warn" className="mb-4">Maintenance mode: new servers are not placed on this node.</Notice> : null}
    <Tabs value={tab} onChange={setTab} tabs={[{ id: 'about', label: 'Status' }, { id: 'allocations', label: `Allocations (${n.allocations})` }, { id: 'servers', label: `Servers (${data.servers.length})` }, { id: 'maintenance', label: 'Maintenance' }, { id: 'settings', label: 'Settings' }]} />
    {tab === 'about' && <NodeStatus n={n} hb={hb} reservations={data.reservations} />}
    {tab === 'allocations' && <NodeAllocations nodeId={n.id} />}
    {tab === 'servers' && <Card>{!data.servers.length ? <Empty title="No servers on this node" /> : <Table><thead><tr><th>Folder ID</th><th>Name</th><th>State</th><th>RAM</th><th>Disk</th></tr></thead><tbody>{data.servers.map((s: any) => <tr key={s.id}><td className="font-mono">{s.node_server_id}</td><td><Link className="link" to={`/admin/servers/${s.id}`}>{s.name}</Link></td><td><Badge value={s.state} /></td><td>{mb(s.memory_mb)}</td><td>{mb(s.disk_mb)}</td></tr>)}</tbody></Table>}</Card>}
    {tab === 'maintenance' && <Maintenance n={n} reload={reload} />}
    {tab === 'settings' && <Card title="Node settings"><FormFields fields={nodeFields(locs.data?.locations || [])} value={e} onChange={setEdit} />
      <div className="mt-4 flex flex-wrap justify-between gap-2"><button className="btn-secondary" onClick={() => run('rot', async () => { const r = await api('POST', `/api/admin/nodes/${n.id}/rotate-secret`); setEnv(r.agentEnv); toast(r.note, 'info'); })}>Rotate node secret</button><button className="btn-primary" disabled={!edit || !!busy} onClick={() => run('s', () => api('PATCH', `/api/admin/nodes/${n.id}`, edit).then(() => { setEdit(null); reload(); }), 'Saved')}>Save</button></div></Card>}
    <EnvModal env={env} onClose={() => setEnv(null)} />
    <Confirm open={del} onClose={() => setDel(false)} danger title="Delete node" phrase={n.name} confirmLabel="Delete" busy={busy === 'd'} onConfirm={() => run('d', () => api('DELETE', `/api/admin/nodes/${n.id}`).then(() => nav('/admin/nodes')), 'Node deleted')}>Only nodes without servers or pending deletions can be deleted. Files on the node machine are not touched.</Confirm>
  </>;
}

function NodeStatus({ n, hb, reservations }: { n: any; hb: any; reservations: any[] }) {
  const java = useApi<any>(`/api/admin/nodes/${n.id}/java`); const [refreshing, setRefreshing] = useState(false);
  const stats = useApi<any>(`/api/admin/nodes/${n.id}/stats?hours=24`, [], 60000);
  const pts = stats.data?.stats || [];
  const spark = (vals: number[], max: number) => { if (vals.length < 2) return <div className="text-xs text-ink-500">Not enough samples yet</div>; const w = 300, h = 50; const d = vals.map((v, i) => `${(i / (vals.length - 1)) * w},${h - (Math.min(v, max) / (max || 1)) * h}`).join(' '); return <svg viewBox={`0 0 ${w} ${h}`} className="h-12 w-full" preserveAspectRatio="none"><polyline points={d} fill="none" strokeWidth="1.5" className="stroke-brand-500" /></svg>; };
  if (!hb) return <Card><Empty title="No heartbeat yet">Start the agent on the node with the configuration from “Show agent config”.</Empty></Card>;
  return <div className="grid gap-6">
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
      <Stat label="Host CPU" value={pct(hb.cpu.usagePercent)} sub={`${hb.cpu.cores} cores · load ${hb.cpu.load?.map((l: number) => l.toFixed(2)).join(' ')}`} />
      <Stat label="Host memory" value={bytes(hb.memory.total - hb.memory.free)} sub={`of ${bytes(hb.memory.total)}`} />
      <Stat label="Host disk" value={bytes(hb.disk.total - hb.disk.free)} sub={`of ${bytes(hb.disk.total)} · ${hb.disk.fsType || ''}`} />
      <Stat label="Agent" value={`v${hb.version}`} sub={`${hb.platform}/${hb.arch} · up ${dur(hb.uptime)} · heartbeat ${ago(n.last_heartbeat_at)}`} />
    </div>
    <div className="grid gap-6 lg:grid-cols-2">
      <Card title="CPU, last 24 h">{spark(pts.map((p: any) => Number(p.cpu)), 100)}</Card>
      <Card title="Memory, last 24 h">{spark(pts.map((p: any) => Number(p.mem_used)), Math.max(...pts.map((p: any) => Number(p.mem_total)), 1))}</Card>
    </div>
    <div className="grid gap-6 lg:grid-cols-2">
      <Card title="Java runtimes found" actions={<button className="btn-secondary btn-sm" disabled={refreshing} onClick={async () => { setRefreshing(true); try { java.setData(await api('GET', `/api/admin/nodes/${n.id}/java?refresh=1`)); } catch (e: any) { toast(e.message, 'error'); } setRefreshing(false); }}><RefreshCw className={`h-4 w-4 ${refreshing ? 'animate-spin' : ''}`} />Rescan</button>}>
        {java.loading ? <Loading /> : java.error ? <ErrorBox error={java.error} /> : !java.data.java.length ? <Notice kind="warn">No Java found. Install a JDK in the agent user's home (e.g. ~/java/jdk-21) and add it to JAVA_SEARCH_PATHS.</Notice> :
          <Table><tbody>{java.data.java.map((j: any) => <tr key={j.path}><td className="font-semibold">Java {j.major}</td><td className="text-xs">{j.version} · {j.vendor}</td><td className="font-mono text-xs">{j.path}</td></tr>)}</tbody></Table>}
      </Card>
      <Card title="Isolation on this host">
        <ul className="space-y-2 text-sm">
          <li><span className="font-semibold">CPU limit:</span> {hb.cpulimit ? <>cpulimit at <span className="font-mono">{hb.cpulimit}</span>. Best-effort throttling (SIGSTOP/SIGCONT), not hard kernel CPU isolation.</> : <span className="text-amber-300">cpulimit not found. CPU limits are not enforced on this node.</span>}</li>
          <li><span className="font-semibold">Disk limit:</span> enforced by the agent (writes are checked and the directory is measured periodically). Kernel quota support: <span className="font-mono">{hb.disk.quotaSupport || 'unknown'}</span>. Application-level checks are not a filesystem quota; processes can briefly exceed the limit between measurements.</li>
          <li><span className="font-semibold">Process isolation:</span> {hb.runningAsRoot ? 'agent runs as root' : 'all servers run as the agent user. Without root, servers on the same node are not isolated from each other at the OS level.'}</li>
        </ul>
      </Card>
    </div>
    {reservations.length > 0 && <Card title="Reserved IDs (incomplete deletions/transfers)"><Table><tbody>{reservations.map((r: any) => <tr key={r.node_server_id}><td className="font-mono">{r.node_server_id}</td><td>{r.reason}</td><td className="text-xs">{date(r.created_at)}</td></tr>)}</tbody></Table></Card>}
  </div>;
}

function NodeAllocations({ nodeId }: { nodeId: number }) {
  const { data, error, loading, reload } = useApi<any>(`/api/admin/nodes/${nodeId}/allocations`); const { busy, run } = useAction();
  const [add, setAdd] = useState<any>(null); const [results, setResults] = useState<any>(null); const [sel, setSel] = useState<number[]>([]);
  const check = (ids?: number[]) => run('chk', async () => { const r = await api('POST', `/api/admin/nodes/${nodeId}/allocations/check`, { ids }); setResults(r); reload(); });
  return <Card title="Allocations" actions={<div className="flex gap-2"><button className="btn-secondary btn-sm" disabled={!!busy} onClick={() => check(sel.length ? sel : undefined)}>{busy === 'chk' && <Spinner />}Check reachability{sel.length ? ` (${sel.length})` : ' (first 50)'}</button><button className="btn-primary btn-sm" onClick={() => setAdd({ ip: '0.0.0.0', ports: '25565-25575', alias: '', protocol: 'tcp+udp' })}><Plus className="h-4 w-4" />Add ports</button></div>}>
    <Notice className="mb-3">Reachability is tested by connecting from the panel to the node's public IP. Free ports get a temporary listener on the node. If the panel shares the host or LAN with the node, “reachable” does not prove that the port is open to the internet. UDP cannot be verified.</Notice>
    {loading ? <Loading /> : error ? <ErrorBox error={error} /> : !data.allocations.length ? <Empty title="No allocations" /> :
      <Table><thead><tr><th><input type="checkbox" checked={sel.length === data.allocations.length} onChange={e => setSel(e.target.checked ? data.allocations.map((a: any) => a.id) : [])} /></th><th>Address</th><th>Alias</th><th>Protocol</th><th>Server</th><th>Reachability</th><th /></tr></thead><tbody>{data.allocations.map((a: any) => <tr key={a.id}>
        <td><input type="checkbox" checked={sel.includes(a.id)} onChange={e => setSel(e.target.checked ? [...sel, a.id] : sel.filter(x => x !== a.id))} /></td><td className="font-mono">{a.ip}:{a.port}</td>
        <td><input className="input h-8 w-36 text-xs" defaultValue={a.alias || ''} onBlur={ev => ev.target.value !== (a.alias || '') && run('al', () => api('PATCH', `/api/admin/allocations/${a.id}`, { alias: ev.target.value || null }), 'Alias saved')} /></td><td>{a.protocol}</td>
        <td>{a.server_id ? <Link className="link" to={`/admin/servers/${a.server_id}`}>{a.server_name}</Link> : <span className="text-ink-500">free</span>}</td><td><Badge value={a.reachable} /> <span className="text-xs text-ink-500">{a.checked_at ? ago(a.checked_at) : ''}</span></td>
        <td>{!a.server_id && <button className="btn-ghost btn-sm px-1.5 text-red-400" onClick={() => run('rm', () => api('DELETE', `/api/admin/allocations/${a.id}`).then(reload), 'Removed')}><Trash2 className="h-4 w-4" /></button>}</td></tr>)}</tbody></Table>}
    <Modal open={!!add} onClose={() => setAdd(null)} title="Add allocations" footer={<><button className="btn-secondary" onClick={() => setAdd(null)}>Cancel</button><button className="btn-primary" disabled={!!busy} onClick={() => run('add', async () => { const r = await api('POST', `/api/admin/nodes/${nodeId}/allocations`, { ...add, alias: add.alias || undefined }); setAdd(null); reload(); toast(`${r.created} port(s) added`, 'success'); })}>Add</button></>}>
      {add && <div className="grid gap-4"><Field label="Bind IP" hint="0.0.0.0 binds all interfaces"><input className="input font-mono" value={add.ip} onChange={e => setAdd({ ...add, ip: e.target.value })} /></Field>
        <Field label="Ports" hint="Comma-separated ports or ranges, 1024–65535 (non-root agents cannot bind lower ports)"><input className="input font-mono" value={add.ports} onChange={e => setAdd({ ...add, ports: e.target.value })} /></Field>
        <Field label="Alias (optional hostname shown to customers)"><input className="input" value={add.alias} onChange={e => setAdd({ ...add, alias: e.target.value })} /></Field>
        <Field label="Protocol"><select className="input" value={add.protocol} onChange={e => setAdd({ ...add, protocol: e.target.value })}><option value="tcp+udp">TCP + UDP</option><option value="tcp">TCP</option><option value="udp">UDP</option></select></Field></div>}
    </Modal>
    <Modal open={!!results} onClose={() => setResults(null)} wide title={`Reachability from the panel to ${results?.target}`}>
      <Table><thead><tr><th>Port</th><th>Result</th><th>Notes</th></tr></thead><tbody>{results?.results?.map((r: any) => <tr key={r.id}><td className="font-mono">{r.port}</td><td><Badge value={r.reachable} /></td><td className="text-xs">{r.note}{r.udp ? ` ${r.udp}.` : ''}</td></tr>)}</tbody></Table>
    </Modal>
  </Card>;
}

function Maintenance({ n, reload }: { n: any; reload: () => void }) {
  const { busy, run } = useAction(); const [f, setF] = useState({ stopServers: false, notifyOwners: true, message: '' });
  const go = (maintenance: boolean, emergency: boolean) => run('m', async () => { const r = await api('POST', `/api/admin/nodes/${n.id}/maintenance`, { maintenance, emergency, ...f, message: f.message || undefined }); reload(); toast(`Updated${r.stopped ? `; ${r.stopped} server(s) stopped` : ''}${r.failures?.length ? `; ${r.failures.length} failed to stop` : ''}`, r.failures?.length ? 'error' : 'success'); });
  return <Card title="Maintenance mode"><div className="grid max-w-xl gap-4">
    <p className="text-sm text-ink-300">Maintenance stops new servers from being placed here. Emergency maintenance also force-stops every server on this node and blocks starts until it ends. Only servers on this node are affected.</p>
    <Switch checked={f.stopServers} onChange={v => setF({ ...f, stopServers: v })} label="Stop running servers gracefully" />
    <Switch checked={f.notifyOwners} onChange={v => setF({ ...f, notifyOwners: v })} label="Notify server owners" />
    <Field label="Message to owners"><textarea className="input" value={f.message} onChange={e => setF({ ...f, message: e.target.value })} /></Field>
    <div className="flex flex-wrap gap-2">{n.maintenance || n.emergency ? <button className="btn-primary" disabled={!!busy} onClick={() => go(false, false)}>End maintenance</button> : <><button className="btn-secondary" disabled={!!busy} onClick={() => go(true, false)}>Start maintenance</button><button className="btn-danger" disabled={!!busy} onClick={() => go(true, true)}>Emergency maintenance</button></>}</div>
  </div></Card>;
}
