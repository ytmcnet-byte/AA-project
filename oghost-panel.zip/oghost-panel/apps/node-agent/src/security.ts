import fs from 'node:fs';
import path from 'node:path';
import { scanJar, SCANNER_VERSION, type ScanResult } from '@oghost/shared';
import { provenanceFile } from './installer';
import { dirs, config } from './config';
import { report } from './reporter';
import { processTree, cmdline, cwdOf, exeOf, socketInodes, tcpConnections } from './procfs';
import type { ServerInstance } from './server';

export const trusted = new Set<string>();
const cacheFile = path.join(dirs.metadata, 'scan-cache.json');
type CacheEntry = { mtime: number; size: number; result: ScanResult; mode: string };
let cache: Record<string, CacheEntry> = {};
try { cache = JSON.parse(fs.readFileSync(cacheFile, 'utf8')); } catch { /* fresh */ }
const saveCache = () => fs.writeFileSync(cacheFile, JSON.stringify(cache), { mode: 0o600 });

/** Plugin/mod mode: only prohibited-software rules matter (plugins are not servers). */
function asPluginResult(r: ScanResult): ScanResult {
  if (r.level === 'suspicious' && !r.findings.some(f => f.severity === 'medium' || f.severity === 'high')) return { ...r, level: 'safe', reason: 'Plugin/mod: no prohibited signatures' };
  return r;
}

export async function scanFile(abs: string, mode: 'server' | 'plugin'): Promise<ScanResult> {
  const st = fs.statSync(abs); const key = `${mode}:${abs}`; const c = cache[key];
  if (c && c.mtime === st.mtimeMs && c.size === st.size && c.result.scannerVersion === SCANNER_VERSION) {
    if (trusted.has(c.result.sha256) && c.result.level !== 'safe') return { ...c.result, level: 'safe', trusted: true, reason: 'Approved by administrator' };
    return c.result;
  }
  let r = await scanJar(abs, trusted); if (mode === 'plugin') r = asPluginResult(r);
  cache[key] = { mtime: st.mtimeMs, size: st.size, result: r, mode }; saveCache();
  return r;
}

const rel = (inst: ServerInstance, abs: string) => '/' + path.relative(inst.dir, abs);
function jarsIn(dir: string, depth = 1): string[] {
  const out: string[] = [];
  try { for (const e of fs.readdirSync(dir, { withFileTypes: true })) { const p = path.join(dir, e.name); if (e.isFile() && /\.jar$/i.test(e.name)) out.push(p); else if (e.isDirectory() && depth > 1 && !e.name.startsWith('.')) out.push(...jarsIn(p, depth - 1)); } } catch { /* */ }
  return out;
}

/**
 * Scan everything that is about to execute BEFORE starting. Unknown software is never executed to test it.
 */
export async function preStartScan(inst: ServerInstance): Promise<{ blocked: boolean; message: string }> {
  if (inst.spec.egg.runtime !== 'java') return { blocked: false, message: '' };
  const serverJar = inst.spec.startup.includes('-jar') ? path.join(inst.dir, inst.spec.variables.SERVER_JAR || 'server.jar') : null;
  const results: Array<{ file: string; mode: string; result: ScanResult }> = [];
  if (serverJar && fs.existsSync(serverJar)) results.push({ file: rel(inst, serverJar), mode: 'server', result: withProvenance(inst, await scanFile(serverJar, 'server')) });
  else if (serverJar) return { blocked: true, message: `Server JAR ${inst.spec.variables.SERVER_JAR || 'server.jar'} not found. Reinstall or upload it.` };
  for (const j of jarsIn(inst.dir)) if (j !== serverJar) results.push({ file: rel(inst, j), mode: 'plugin', result: await scanFile(j, 'plugin') });
  for (const sub of ['plugins', 'mods']) for (const j of jarsIn(path.join(inst.dir, sub), 2)) results.push({ file: rel(inst, j), mode: 'plugin', result: await scanFile(j, 'plugin') });
  const bad = results.filter(r => r.result.level !== 'safe');
  report('scan', inst.id, { phase: 'pre-start', results: results.map(r => ({ file: r.file, mode: r.mode, ...summary(r.result) })) });
  if (!bad.length) return { blocked: false, message: '' };
  const high = bad.find(b => b.result.level === 'high_risk');
  inst.log(`\x1b[31m[OGHOST Security]\x1b[0m ${high ? 'HIGH RISK' : 'Suspicious'} software detected: ${bad.map(b => `${b.file} (${b.result.reason})`).join('; ')}`);
  inst.spec.securityBlocked = true;
  return { blocked: true, message: high ? `High-risk software detected in ${high.file}. The server has been stopped and reported to administrators.` : `Execution blocked pending administrator review: ${bad.map(b => b.file).join(', ')}` };
}
/** Official installer downloads (checksum-verified, recorded outside the customer directory) pass medium heuristic findings.
 * High-risk signatures are never overridden. */
function withProvenance(inst: ServerInstance, r: ScanResult): ScanResult {
  if (r.level !== 'suspicious') return r;
  try {
    const p = JSON.parse(fs.readFileSync(provenanceFile(inst.id), 'utf8'));
    if (p.sha256 === r.sha256) return { ...r, level: 'safe', reason: `Official ${p.installer} build installed by the OGHOST installer (checksum verified at download); heuristic notes: ${r.reason}` };
  } catch { /* no provenance */ }
  return r;
}
export const summary = (r: ScanResult) => ({ level: r.level, sha256: r.sha256, size: r.size, reason: r.reason, minecraft: r.minecraft, findings: r.findings.slice(0, 50), truncated: r.truncated, scannerVersion: r.scannerVersion });

/** Scan a JAR right after upload so administrators see it immediately (start is still gated). */
export async function scanUploaded(inst: ServerInstance, abs: string) {
  if (!/\.jar$/i.test(abs)) return;
  const mode = path.resolve(abs) === path.join(inst.dir, inst.spec.variables.SERVER_JAR || 'server.jar') ? 'server' : 'plugin';
  try { const r = await scanFile(abs, mode); report('scan', inst.id, { phase: 'upload', results: [{ file: rel(inst, abs), mode, ...summary(r) }] }); if (r.level === 'high_risk') { inst.spec.securityBlocked = true; if (inst.isActive()) inst.kill('security'); } } catch { /* */ }
}

// ---------------- Runtime monitoring ----------------
const MINER_RE = /(xmrig|minerd|cpuminer|ccminer|nbminer|lolminer|t-rex|srbminer|xmr-stak|ethminer|nanominer|stratum\+)/i;
const TUNNEL_RE = /\b(ngrok|frpc|cloudflared|chisel|gost|v2ray|xray|sing-box|ssserver|sslocal|playit|bore|tmate|ttyd|gotty|sshd|dropbear|proot|qemu)\b/i;
const POOL_PORTS = new Set([3333, 4444, 5555, 6666, 7777, 8888, 9999, 14444, 14433, 45700, 10128, 10343, 20535, 3357]);
const alerted = new Map<string, number>();
const once = (key: string, ms = 3600_000) => { const t = alerted.get(key) || 0; if (Date.now() - t < ms) return false; alerted.set(key, Date.now()); return true; };
const cpuHigh = new Map<number, number>();

export function monitor(inst: ServerInstance) {
  const pid = inst.pid; if (!pid) return;
  const tree = processTree(pid); const children = tree.filter(p => p.pid !== pid);
  for (const c of children) {
    const cmd = cmdline(c.pid); const exe = exeOf(c.pid); const cwd = cwdOf(c.pid);
    if (MINER_RE.test(cmd) || MINER_RE.test(exe)) {
      inst.log(`\x1b[31m[OGHOST Security]\x1b[0m Cryptocurrency miner process detected (PID ${c.pid}). Server stopped.`);
      report('runtime', inst.id, { severity: 'high', category: 'crypto-mining', rule: 'miner-process', detail: { pid: c.pid, cmd: cmd.slice(0, 500), exe, cwd } });
      inst.spec.securityBlocked = true; inst.kill('security'); return;
    }
    if (once(`child:${inst.id}:${exe}`)) report('runtime', inst.id, { severity: TUNNEL_RE.test(cmd) ? 'medium' : 'low', category: TUNNEL_RE.test(cmd) ? 'tunnel-proxy' : 'unexpected-child', rule: 'child-process', detail: { pid: c.pid, cmd: cmd.slice(0, 500), exe, cwd } });
    if (cwd && !cwd.startsWith(inst.dir) && once(`cwd:${inst.id}:${c.pid}`)) report('runtime', inst.id, { severity: 'medium', category: 'outside-directory', rule: 'cwd-outside', detail: { pid: c.pid, cwd, cmd: cmd.slice(0, 300) } });
  }
  // Network attribution via socket inodes (no root required)
  const inodes = new Set<string>(); for (const p of tree) for (const i of socketInodes(p.pid)) inodes.add(i);
  if (inodes.size) {
    const conns = tcpConnections().filter(c => inodes.has(c.inode) && c.state === '01');
    const pool = conns.filter(c => POOL_PORTS.has(c.remotePort));
    if (pool.length && once(`pool:${inst.id}`)) report('runtime', inst.id, { severity: 'medium', category: 'network', rule: 'mining-pool-port', detail: { connections: pool.slice(0, 20).map(c => `${c.remoteIp}:${c.remotePort}`) } });
    const outbound = conns.filter(c => c.remotePort !== inst.spec.primaryPort && !inst.spec.ports.includes(c.remotePort));
    if (outbound.length > 300 && once(`conn:${inst.id}`)) report('runtime', inst.id, { severity: 'medium', category: 'network', rule: 'connection-flood', detail: { established: conns.length } });
  }
  // Sustained CPU: >95% of the allocation (or of 2 cores when unlimited) for 10 minutes
  const cap = inst.spec.cpuPercent || 200;
  if (inst.stats.cpu > cap * 0.95) { const since = cpuHigh.get(inst.id) || Date.now(); cpuHigh.set(inst.id, since); if (Date.now() - since > 10 * 60_000 && once(`cpu:${inst.id}`)) report('runtime', inst.id, { severity: 'low', category: 'cpu-abuse', rule: 'sustained-cpu', detail: { cpu: inst.stats.cpu, allocation: inst.spec.cpuPercent } }); }
  else cpuHigh.delete(inst.id);
  void config;
}

/** Detect newly created native executables inside the server directory (external writes). */
export function scanExecutables(inst: ServerInstance) {
  const allowed = new Set(['bedrock_server']);
  const check = (dir: string, depth: number) => {
    let ents: fs.Dirent[] = []; try { ents = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
    for (const e of ents) {
      const p = path.join(dir, e.name);
      if (e.isDirectory() && depth > 0 && !['libraries', 'world', 'world_nether', 'world_the_end', 'cache', 'versions'].includes(e.name)) check(p, depth - 1);
      else if (e.isFile() && !allowed.has(e.name)) {
        try { const st = fs.statSync(p); if (!(st.mode & 0o111) || st.size < 1024) continue; const fd = fs.openSync(p, 'r'); const b = Buffer.alloc(4); fs.readSync(fd, b, 0, 4, 0); fs.closeSync(fd);
          if (b[0] === 0x7f && b[1] === 0x45 && b[2] === 0x4c && b[3] === 0x46 && once(`exe:${inst.id}:${p}:${st.mtimeMs}`, 86400_000)) report('runtime', inst.id, { severity: MINER_RE.test(e.name) ? 'high' : 'medium', category: 'executable-download', rule: 'elf-in-server-dir', detail: { file: rel(inst, p), size: st.size } });
        } catch { /* */ }
      }
    }
  };
  check(inst.dir, 2);
}
