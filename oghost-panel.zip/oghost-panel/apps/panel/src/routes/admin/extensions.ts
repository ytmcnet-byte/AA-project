import { Router } from 'express';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import crypto from 'node:crypto';
import { pipeline } from 'node:stream/promises';
import { q, parse } from '../../db';
import { body, z, HttpError, idParam } from '../../lib/http';
import { requirePerm } from '../../lib/auth';
import { audit } from '../../services/audit';
import { discoverExtensions, setEnabled, updateExtensionSettings, installFromZip, uninstall, extensionStatus } from '../../services/extensions';

export const extensionsAdmin = Router();
const P = requirePerm('admin.extensions');
extensionsAdmin.get('/extensions', P, async (_req, res) => {
  const discovered = await discoverExtensions();
  const rows = await q<any>('SELECT * FROM extensions ORDER BY name');
  res.json({ extensions: rows.map(r => { const m = parse<any>(r.manifest, {}); const st = parse<any>(r.settings, {}); return { id: r.id, identifier: r.identifier, name: r.name, version: r.version, enabled: !!r.enabled, description: m.description, author: m.author, permissions: m.permissions, granted: parse(r.granted_permissions, []), ui: m.ui || [], settingsSchema: m.settings || [], settings: Object.fromEntries(Object.entries(st).map(([k, v]: any) => [k, v && typeof v === 'object' && v.enc ? { secret: true, set: true } : v])), status: extensionStatus(r.identifier), installedAt: r.installed_at }; }), problems: discovered.filter(d => d.error),
    compatibility: 'OGHOST extensions use the OGHOST Extension SDK. Pterodactyl Blueprint packages are not directly compatible and must be ported.' });
});
extensionsAdmin.post('/extensions/:id/enable', P, async (req, res) => { const b = body(z.object({ grant: z.array(z.string()).max(20) }), req); const r = await setEnabled(idParam(req), true, b.grant); await audit(req, 'admin.extension.enable', { type: 'extension', id: idParam(req) }, b); res.json(r); });
extensionsAdmin.post('/extensions/:id/disable', P, async (req, res) => { const r = await setEnabled(idParam(req), false, []); await audit(req, 'admin.extension.disable', { type: 'extension', id: idParam(req) }); res.json(r); });
extensionsAdmin.put('/extensions/:id/settings', P, async (req, res) => { await updateExtensionSettings(idParam(req), body(z.record(z.string(), z.unknown()), req)); await audit(req, 'admin.extension.settings', { type: 'extension', id: idParam(req) }); res.json({ ok: true }); });
/** PUT raw .zip body. Installed extensions start disabled; the admin reviews and grants permissions before enabling. */
extensionsAdmin.put('/extensions/install', P, async (req, res) => {
  const size = Number(req.headers['content-length'] || 0); if (size > 50 * 1024 * 1024) throw new HttpError(413, 'Archive too large (50 MB max)');
  const tmp = path.join(os.tmpdir(), `oghost-ext-${crypto.randomUUID()}.zip`);
  try {
    let n = 0; await pipeline(req, async function* (src) { for await (const c of src) { n += c.length; if (n > 50 * 1024 * 1024) throw new HttpError(413, 'Archive too large'); yield c; } }, fs.createWriteStream(tmp));
    const m = await installFromZip(tmp, req.query.replace === '1'); await audit(req, 'admin.extension.install', { type: 'extension', id: m.identifier }, { version: m.version, permissions: m.permissions });
    res.status(201).json({ identifier: m.identifier, version: m.version, permissions: m.permissions, enabled: false });
  } finally { fs.rmSync(tmp, { force: true }); }
});
extensionsAdmin.delete('/extensions/:id', P, async (req, res) => { const keep = req.query.keepData === '1'; await uninstall(idParam(req), keep); await audit(req, 'admin.extension.uninstall', { type: 'extension', id: idParam(req) }, { keepData: keep }); res.json({ ok: true }); });
