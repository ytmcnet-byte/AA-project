import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import readline from 'node:readline/promises';
import express from 'express';
import helmet from 'helmet';
import cookieParser from 'cookie-parser';
import rateLimit from 'express-rate-limit';
import { config } from './config';
import { pool, q, exec, migrate } from './db';
import { authenticate, csrf, apiKeyGate } from './lib/auth';
import { errorHandler, HttpError } from './lib/http';
import { buildOpenApi, DOCS_HTML } from './lib/openapi';
import { attachRealtime } from './realtime';
import { seed, createAdmin, countUsers } from './seed';
import { authRouter } from './routes/auth';
import { accountRouter } from './routes/account';
import { serversRouter } from './routes/servers';
import { remoteRouter } from './routes/remote';
import { driveRouter } from './routes/drive';
import { storeRouter } from './routes/store';
import { coinsRouter } from './routes/coins';
import { ticketsRouter } from './routes/tickets';
import { paymentWebhooksRouter } from './routes/webhooks';
import { adminRouter } from './routes/admin';
import { extensionsMount, extensionsUi, loadEnabledExtensions } from './services/extensions';
import { startJobWorker, stopJobWorker } from './services/jobs';
import { releaseExpiredSuspensions } from './services/security';
import { tickSchedules } from './services/scheduler';
import { tickDrive } from './services/drive';
import { billingTick } from './services/billing';
import { retryReservations } from './services/lifecycle';
import { notifyAdmins } from './services/notify';
import { dispatchWebhook } from './services/webhooks';

const VERSION = '1.0.0';

export function buildApp() {
  const app = express();
  app.disable('x-powered-by');
  app.set('trust proxy', /^\d+$/.test(config.trustProxy) ? Number(config.trustProxy) : config.trustProxy === 'false' ? false : config.trustProxy);
  app.use(helmet({
    contentSecurityPolicy: {
      useDefaults: true,
      directives: {
        'script-src': ["'self'", 'https://apis.google.com', 'https://www.gstatic.com', 'https://checkout.razorpay.com', 'https://js.stripe.com', 'https://sdk.cashfree.com'],
        'connect-src': ["'self'", 'ws:', 'wss:', 'https://*.googleapis.com', 'https://*.firebaseio.com', 'https://*.firebaseapp.com', 'https://api.razorpay.com', 'https://lumberjack.razorpay.com'],
        'frame-src': ["'self'", 'https://*.firebaseapp.com', 'https://accounts.google.com', 'https://api.razorpay.com', 'https://checkout.razorpay.com', 'https://js.stripe.com', 'https://*.cashfree.com'],
        'img-src': ["'self'", 'data:', 'https:'],
        'style-src': ["'self'", "'unsafe-inline'"],
        'upgrade-insecure-requests': config.appUrl.startsWith('https://') ? [] : null,
      },
    },
    crossOriginOpenerPolicy: { policy: 'same-origin-allow-popups' },
    crossOriginEmbedderPolicy: false,
    strictTransportSecurity: config.appUrl.startsWith('https://'),
  }));
  app.use(cookieParser());
  app.get('/healthz', async (_req, res) => { await q('SELECT 1'); res.json({ ok: true, version: VERSION }); });

  // Raw-body routes first: signature verification needs the exact bytes.
  app.use('/api/webhooks', paymentWebhooksRouter);
  app.use('/api/remote', remoteRouter);
  app.use('/api/servers/:id/files/write', express.raw({ type: () => true, limit: '20mb' }));
  app.use('/api', express.json({ limit: '2mb' }));
  app.use(authenticate);
  app.use('/api', csrf, apiKeyGate);

  const general = rateLimit({ windowMs: 60_000, limit: 600, standardHeaders: 'draft-8', legacyHeaders: false, keyGenerator: (req) => (req.user ? `u:${req.user.id}` : `ip:${req.ip}`), validate: { keyGeneratorIpFallback: false } });
  const authLimit = rateLimit({ windowMs: 15 * 60_000, limit: 50, standardHeaders: 'draft-8', legacyHeaders: false, skip: (req) => req.method === 'GET' });
  app.use('/api', general);
  app.use('/api/auth', authLimit);

  const mounts: Array<[string, express.Router]> = [
    ['/api/auth', authRouter], ['/api/account', accountRouter], ['/api/servers', serversRouter], ['/api/drive', driveRouter],
    ['/api/store', storeRouter], ['/api/coins', coinsRouter], ['/api/tickets', ticketsRouter], ['/api/admin', adminRouter], ['/api/webhooks', paymentWebhooksRouter],
  ];
  for (const [p, r] of mounts) if (p !== '/api/webhooks') app.use(p, r);
  app.use('/api/extensions', extensionsMount);
  app.use('/extensions-ui', extensionsUi);

  let spec: any = null;
  app.get('/api/docs/openapi.json', (_req, res) => { spec ??= buildOpenApi(mounts, VERSION, `${config.appUrl}`); res.json(spec); });
  app.get('/api/docs', (_req, res) => { res.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'unsafe-inline' 'self'; style-src 'unsafe-inline'; connect-src 'self'"); res.type('html').send(DOCS_HTML); });
  app.use('/api', (_req, _res, next) => next(new HttpError(404, 'Endpoint not found')));

  app.use('/uploads', express.static(config.uploadsDir, { maxAge: '1d', index: false, dotfiles: 'deny', setHeaders: (res) => res.setHeader('X-Content-Type-Options', 'nosniff') }));
  if (fs.existsSync(path.join(config.frontendDir, 'index.html'))) {
    app.use(express.static(config.frontendDir, { index: false, maxAge: '1h', setHeaders: (res, f) => { if (/assets[\\/]/.test(f)) res.setHeader('Cache-Control', 'public, max-age=31536000, immutable'); } }));
    app.get('/{*any}', (_req, res) => { res.setHeader('Cache-Control', 'no-cache'); res.sendFile(path.join(config.frontendDir, 'index.html')); });
  } else {
    app.get('/', (_req, res) => res.type('text').send('OGHOST PANEL API is running, but the frontend is not built. Run: npm run build'));
  }
  app.use(errorHandler);
  return app;
}

const loops: NodeJS.Timeout[] = [];
function every(ms: number, name: string, fn: () => Promise<unknown>) {
  let running = false;
  const run = async () => { if (running) return; running = true; try { await fn(); } catch (e: any) { console.error(`[panel] ${name}:`, e?.message || e); } finally { running = false; } };
  loops.push(setInterval(run, ms)); setTimeout(run, 2000 + Math.random() * 3000);
}

/** Marks nodes offline when no heartbeat arrives within NODE_OFFLINE_SECONDS. Server states are left as last reported (not faked). */
async function detectOfflineNodes() {
  const stale = await q<any>("SELECT id, name, last_heartbeat_at FROM nodes WHERE status <> 'offline' AND (last_heartbeat_at IS NULL OR last_heartbeat_at < NOW() - INTERVAL ? SECOND) AND (status = 'online' OR created_at < NOW() - INTERVAL ? SECOND)", [config.nodeOfflineSeconds, config.nodeOfflineSeconds]);
  for (const n of stale) {
    const r = await exec("UPDATE nodes SET status = 'offline' WHERE id = ? AND status <> 'offline'", [n.id]); if (!r.affectedRows) continue;
    console.warn(`[panel] node ${n.id} (${n.name}) is offline`);
    await notifyAdmins('admin.nodes', 'node_offline', `Node ${n.name} is offline`, `No heartbeat for more than ${config.nodeOfflineSeconds}s (last: ${n.last_heartbeat_at ? new Date(n.last_heartbeat_at).toISOString() : 'never'}).`, { link: `/admin/nodes/${n.id}`, email: true }).catch(() => {});
    dispatchWebhook('node.offline', { nodeId: n.id, name: n.name }).catch(() => {});
  }
}
async function prune() {
  await exec('DELETE FROM server_stats WHERE at < NOW() - INTERVAL 7 DAY LIMIT 50000');
  await exec('DELETE FROM node_stats WHERE at < NOW() - INTERVAL 7 DAY LIMIT 50000');
  await exec('DELETE FROM notifications WHERE read_at IS NOT NULL AND created_at < NOW() - INTERVAL 90 DAY LIMIT 50000');
  await exec('DELETE FROM sessions WHERE expires_at < NOW()');
  await exec('DELETE FROM drive_oauth_states WHERE expires_at < NOW()');
  await exec("DELETE FROM jobs WHERE status IN ('done','failed') AND finished_at < NOW() - INTERVAL 30 DAY LIMIT 50000");
}

async function serve() {
  await migrate(); await seed();
  if (!(await countUsers())) console.warn('[panel] No users yet. Create the first administrator: node dist/panel.mjs create-admin');
  const app = buildApp(); const server = http.createServer(app);
  server.requestTimeout = 0; server.headersTimeout = 65_000; // uploads/backups can be long-running streams
  attachRealtime(server);
  startJobWorker();
  every(10_000, 'node-offline', detectOfflineNodes);
  every(60_000, 'suspensions', releaseExpiredSuspensions);
  every(15_000, 'schedules', tickSchedules);
  every(60_000, 'drive', tickDrive);
  every(600_000, 'billing', billingTick);
  every(60_000, 'reservations', retryReservations);
  every(3_600_000, 'prune', prune);
  await loadEnabledExtensions().catch(e => console.error('[panel] extensions:', e.message));
  server.listen(config.port, config.host, () => console.log(`[panel] OGHOST PANEL ${VERSION} listening on http://${config.host}:${config.port} (APP_URL ${config.appUrl})`));
  const stop = () => { console.log('[panel] shutting down'); stopJobWorker(); loops.forEach(clearInterval); server.close(() => pool.end().finally(() => process.exit(0))); setTimeout(() => process.exit(0), 8000).unref(); };
  process.on('SIGTERM', stop); process.on('SIGINT', stop);
}

async function prompt(label: string, hidden = false) {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout, terminal: true });
  if (hidden) { const w = (rl as any)._writeToOutput; (rl as any)._writeToOutput = (s: string) => { if (s.includes(label)) w.call(rl, s); else w.call(rl, '*'); }; }
  const a = await rl.question(label); rl.close(); if (hidden) process.stdout.write('\n'); return a.trim();
}
const arg = (n: string) => { const i = process.argv.indexOf(`--${n}`); return i > 0 ? process.argv[i + 1] : process.env[`ADMIN_${n.toUpperCase()}`]; };

async function main() {
  const cmd = process.argv[2] || 'serve';
  switch (cmd) {
    case 'keygen': console.log(crypto.randomBytes(32).toString('base64url')); return;
    case 'migrate': await migrate(); await pool.end(); return;
    case 'seed': await migrate(); await seed(); await pool.end(); return;
    case 'create-admin': {
      await migrate(); await seed();
      const email = arg('email') || await prompt('Admin email: '); const username = arg('username') || await prompt('Admin username: ');
      const password = arg('password') || await prompt('Admin password (min 10 chars, letters + digits): ', true);
      const id = await createAdmin(email, username, password); console.log(`[panel] Super Admin ready (user #${id}, ${email})`); await pool.end(); return;
    }
    case 'serve': await serve(); return;
    default: console.log('Usage: node dist/panel.mjs [serve|migrate|seed|create-admin --email E --username U --password P|keygen]'); process.exit(1);
  }
}
main().catch(e => { console.error('[panel] fatal:', e?.message || e); process.exit(1); });
