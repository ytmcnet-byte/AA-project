import { Router } from 'express';
import crypto from 'node:crypto';
import { validateHeap, validateVariables, recommendedHeap } from '@oghost/shared';
import { q, one, exec, json, parse, tx } from '../../db';
import { body, patchBody, z, HttpError, idParam, paginate, forbidden } from '../../lib/http';
import { requirePerm, hasPerm, hashPassword, passwordPolicy, ADMIN_PERMISSIONS, type AuthUser } from '../../lib/auth';
import { audit, serverActivity } from '../../services/audit';
import { createServer, getServer, getEgg, deleteServer, recoverServer, setSuspension, syncSpec, pushAndInstall, power, buildSpec } from '../../services/servers';
import { getNode, agent, agentStream } from '../../services/nodes';
import { startTransfer, importIntoServer } from '../../services/lifecycle';
import { enqueue } from '../../services/jobs';
import { notify } from '../../services/notify';
import { dispatchWebhook } from '../../services/webhooks';

export const coreAdmin = Router();

// ---------------------------------------------------------------- overview (all numbers come from the DB / heartbeats)
coreAdmin.get('/overview', requirePerm('admin.overview'), async (_req, res) => {
  const n = async (sql: string, p: any[] = []) => Number((await one<any>(sql, p))?.c ?? 0);
  const nodes = await q<any>('SELECT id, name, status, maintenance, emergency, memory_mb, disk_mb, last_heartbeat_at, heartbeat FROM nodes ORDER BY id');
  const nodeSummaries = nodes.map(nd => { const hb = parse<any>(nd.heartbeat, null); return { id: nd.id, name: nd.name, status: nd.status, maintenance: !!nd.maintenance, emergency: !!nd.emergency, lastHeartbeatAt: nd.last_heartbeat_at, cpu: hb?.cpu?.usagePercent ?? null, cores: hb?.cpu?.cores ?? null, memTotal: hb?.memory?.total ?? null, memUsed: hb ? hb.memory.total - hb.memory.free : null, diskTotal: hb?.disk?.total ?? null, diskUsed: hb ? hb.disk.total - hb.disk.free : null, arch: hb?.arch ?? null, version: hb?.version ?? null }; });
  const revenue = await q<any>("SELECT currency, SUM(total_cents) AS total FROM invoices WHERE status = 'paid' AND paid_at >= DATE_SUB(NOW(), INTERVAL 30 DAY) GROUP BY currency");
  const revenueAll = await q<any>("SELECT currency, SUM(total_cents) AS total FROM invoices WHERE status = 'paid' GROUP BY currency");
  const states = await q<any>('SELECT state, COUNT(*) AS c FROM servers GROUP BY state');
  res.json({
    users: await n('SELECT COUNT(*) AS c FROM users'), usersLast30d: await n('SELECT COUNT(*) AS c FROM users WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)'),
    servers: await n('SELECT COUNT(*) AS c FROM servers'), serversRunning: await n("SELECT COUNT(*) AS c FROM servers WHERE state = 'running'"), serversSuspended: await n('SELECT COUNT(*) AS c FROM servers WHERE suspended_at IS NOT NULL'), serverStates: states,
    nodes: nodeSummaries, nodesOnline: nodeSummaries.filter(x => x.status === 'online').length,
    activeServices: await n("SELECT COUNT(*) AS c FROM services WHERE status = 'active'"), pendingOrders: await n("SELECT COUNT(*) AS c FROM orders WHERE status = 'pending'"),
    unpaidInvoices: await n("SELECT COUNT(*) AS c FROM invoices WHERE status = 'unpaid'"), paymentsAwaitingApproval: await n("SELECT COUNT(*) AS c FROM payments WHERE status = 'awaiting_approval'"),
    revenue30d: revenue.map(r => ({ currency: r.currency, cents: Number(r.total) })), revenueAll: revenueAll.map(r => ({ currency: r.currency, cents: Number(r.total) })),
    openTickets: await n("SELECT COUNT(*) AS c FROM tickets WHERE status <> 'closed'"),
    securityOpen: await n("SELECT COUNT(*) AS c FROM security_incidents WHERE status = 'open'"), securityPendingReviews: await n("SELECT COUNT(*) AS c FROM security_scans WHERE review_status = 'pending'"),
    failedJobs24h: await n("SELECT COUNT(*) AS c FROM jobs WHERE status = 'failed' AND finished_at >= DATE_SUB(NOW(), INTERVAL 1 DAY)"),
    backups: await n("SELECT COUNT(*) AS c FROM backups WHERE status = 'completed'"),
    signups: await q("SELECT DATE(created_at) AS day, COUNT(*) AS c FROM users WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY) GROUP BY DATE(created_at) ORDER BY day"),
    revenueDaily: await q("SELECT DATE(paid_at) AS day, currency, SUM(total_cents) AS cents FROM invoices WHERE status = 'paid' AND paid_at >= DATE_SUB(NOW(), INTERVAL 30 DAY) GROUP BY DATE(paid_at), currency ORDER BY day"),
  });
});
coreAdmin.get('/nodes/:id/stats', requirePerm('admin.nodes'), async (req, res) => {
  const hours = Math.min(168, Number(req.query.hours) || 24);
  res.json({ stats: await q('SELECT cpu, mem_used, mem_total, disk_used, disk_total, rx, tx, at FROM node_stats WHERE node_id = ? AND at >= DATE_SUB(NOW(), INTERVAL ? HOUR) ORDER BY at', [idParam(req), hours]) });
});

// ---------------------------------------------------------------- users
const canManageUser = (actor: AuthUser, targetRolePerms: string[]) => actor.permissions.includes('*') || !targetRolePerms.includes('*');
coreAdmin.get('/users', requirePerm('admin.users.read'), async (req, res) => {
  const p = paginate(req); const s = String(req.query.search || '').trim(); const where = s ? 'WHERE u.email LIKE ? OR u.username LIKE ? OR u.name LIKE ? OR u.id = ?' : '';
  const params = s ? [`%${s}%`, `%${s}%`, `%${s}%`, Number(s) || 0] : [];
  const rows = await q(`SELECT u.id, u.uuid, u.email, u.username, u.name, u.avatar_url, u.role_id, r.slug AS role_slug, r.name AS role_name, u.email_verified_at, u.totp_enabled, u.firebase_uid IS NOT NULL AS google_linked, u.suspended, u.last_login_at, u.created_at,
    (SELECT COUNT(*) FROM servers s WHERE s.owner_id = u.id) AS servers FROM users u JOIN roles r ON r.id = u.role_id ${where} ORDER BY u.id DESC LIMIT ? OFFSET ?`, [...params, p.limit, p.offset]);
  const total = await one<any>(`SELECT COUNT(*) AS c FROM users u ${where}`, params);
  res.json({ users: rows, total: Number(total.c), page: p.page });
});
coreAdmin.get('/users/:id', requirePerm('admin.users.read'), async (req, res) => {
  const id = idParam(req);
  const u = await one('SELECT u.id, u.uuid, u.email, u.username, u.name, u.avatar_url, u.role_id, r.slug AS role_slug, u.email_verified_at, u.totp_enabled, u.firebase_uid IS NOT NULL AS google_linked, u.suspended, u.last_login_at, u.created_at FROM users u JOIN roles r ON r.id = u.role_id WHERE u.id = ?', [id]); if (!u) throw new HttpError(404, 'User not found');
  res.json({ user: u, servers: await q('SELECT id, name, node_id, node_server_id, state FROM servers WHERE owner_id = ?', [id]), services: await q('SELECT id, status, plan_id, next_due_at FROM services WHERE user_id = ?', [id]),
    sessions: await q('SELECT id, ip, user_agent, created_at, last_seen_at, expires_at FROM sessions WHERE user_id = ? AND expires_at > NOW() ORDER BY last_seen_at DESC', [id]) });
});
const userSchema = z.object({ email: z.string().email().max(191), username: z.string().regex(/^[a-zA-Z0-9_.-]{3,32}$/), name: z.string().max(100).nullable().optional(), roleId: z.number().int(), password: z.string().max(200).optional(), emailVerified: z.boolean().default(true) });
async function assertRoleAssignable(actor: AuthUser, roleId: number) {
  const r: any = await one('SELECT * FROM roles WHERE id = ?', [roleId]); if (!r) throw new HttpError(422, 'Role not found');
  const perms = parse<string[]>(r.permissions, []);
  if (!actor.permissions.includes('*') && perms.some(p => !actor.permissions.includes(p))) throw forbidden('You cannot assign a role with permissions you do not have');
  return r;
}
coreAdmin.post('/users', requirePerm('admin.users'), async (req, res) => {
  const b = body(userSchema, req); await assertRoleAssignable(req.user!, b.roleId);
  if (b.password) passwordPolicy(b.password);
  const r = await exec('INSERT INTO users (uuid, email, username, name, password_hash, role_id, email_verified_at) VALUES (?, ?, ?, ?, ?, ?, ?)', [crypto.randomUUID(), b.email.toLowerCase(), b.username, b.name ?? null, b.password ? await hashPassword(b.password) : null, b.roleId, b.emailVerified ? new Date() : null])
    .catch((e: any) => { if (e.code === 'ER_DUP_ENTRY') throw new HttpError(409, 'Email or username already in use'); throw e; });
  await audit(req, 'admin.user.create', { type: 'user', id: r.insertId }, { email: b.email, roleId: b.roleId }); res.status(201).json({ id: r.insertId });
});
coreAdmin.patch('/users/:id', requirePerm('admin.users'), async (req, res) => {
  const id = idParam(req); const b = patchBody(userSchema.partial().extend({ suspended: z.boolean().optional(), disable2fa: z.boolean().optional() }), req);
  const target: any = await one('SELECT u.*, r.permissions FROM users u JOIN roles r ON r.id = u.role_id WHERE u.id = ?', [id]); if (!target) throw new HttpError(404, 'User not found');
  if (!canManageUser(req.user!, parse(target.permissions, []))) throw forbidden('Only a Super Admin can modify a Super Admin');
  if (id === req.user!.id && (b.suspended || (b.roleId && b.roleId !== target.role_id))) throw new HttpError(409, 'You cannot suspend yourself or change your own role');
  if (b.roleId) await assertRoleAssignable(req.user!, b.roleId);
  const sets: string[] = []; const vals: any[] = [];
  const add = (c: string, v: unknown) => { sets.push(`${c} = ?`); vals.push(v); };
  if (b.email) add('email', b.email.toLowerCase()); if (b.username) add('username', b.username); if (b.name !== undefined) add('name', b.name);
  if (b.roleId) add('role_id', b.roleId); if (b.password) { passwordPolicy(b.password); add('password_hash', await hashPassword(b.password)); }
  if (b.emailVerified !== undefined) add('email_verified_at', b.emailVerified ? (target.email_verified_at || new Date()) : null);
  if (b.suspended !== undefined) add('suspended', b.suspended ? 1 : 0);
  if (b.disable2fa) { add('totp_enabled', 0); add('totp_secret_enc', null); add('recovery_codes', null); }
  if (sets.length) await exec(`UPDATE users SET ${sets.join(', ')} WHERE id = ?`, [...vals, id]).catch((e: any) => { if (e.code === 'ER_DUP_ENTRY') throw new HttpError(409, 'Email or username already in use'); throw e; });
  if (b.suspended || b.password || b.disable2fa) await exec('DELETE FROM sessions WHERE user_id = ?', [id]);
  await audit(req, 'admin.user.update', { type: 'user', id }, { ...b, password: b.password ? '[changed]' : undefined }); res.json({ ok: true });
});
coreAdmin.delete('/users/:id/sessions', requirePerm('admin.users'), async (req, res) => { await exec('DELETE FROM sessions WHERE user_id = ?', [idParam(req)]); await audit(req, 'admin.user.logout_all', { type: 'user', id: idParam(req) }); res.json({ ok: true }); });
coreAdmin.delete('/users/:id', requirePerm('admin.users'), async (req, res) => {
  const id = idParam(req); if (id === req.user!.id) throw new HttpError(409, 'You cannot delete your own account here');
  const target: any = await one('SELECT u.*, r.permissions FROM users u JOIN roles r ON r.id = u.role_id WHERE u.id = ?', [id]); if (!target) throw new HttpError(404, 'User not found');
  if (!canManageUser(req.user!, parse(target.permissions, []))) throw forbidden('Only a Super Admin can delete a Super Admin');
  const servers = await one<any>('SELECT COUNT(*) AS c FROM servers WHERE owner_id = ?', [id]); if (Number(servers.c)) throw new HttpError(409, 'Delete or transfer this user\'s servers first');
  const fin = await one<any>('SELECT (SELECT COUNT(*) FROM invoices WHERE user_id = ?) + (SELECT COUNT(*) FROM tickets WHERE user_id = ?) + (SELECT COUNT(*) FROM ticket_messages WHERE user_id = ?) AS c', [id, id, id]);
  if (Number(fin.c)) { // keep financial/support records, anonymise personal data
    await exec("UPDATE users SET email = CONCAT('deleted-', id, '@invalid'), username = CONCAT('deleted_', id), name = NULL, password_hash = NULL, avatar_url = NULL, firebase_uid = NULL, totp_enabled = 0, totp_secret_enc = NULL, recovery_codes = NULL, suspended = 1 WHERE id = ?", [id]);
    await exec('DELETE FROM sessions WHERE user_id = ?', [id]); await exec('DELETE FROM api_keys WHERE user_id = ?', [id]);
  } else await exec('DELETE FROM users WHERE id = ?', [id]);
  await audit(req, 'admin.user.delete', { type: 'user', id }, { anonymised: !!Number(fin.c) }); res.json({ ok: true, anonymised: !!Number(fin.c) });
});

// ---------------------------------------------------------------- roles
coreAdmin.get('/roles', requirePerm('admin.roles'), async (_req, res) => res.json({ roles: (await q<any>('SELECT r.*, (SELECT COUNT(*) FROM users u WHERE u.role_id = r.id) AS users FROM roles r ORDER BY r.id')).map(r => ({ ...r, permissions: parse(r.permissions, []) })), available: ADMIN_PERMISSIONS }));
const roleSchema = z.object({ slug: z.string().regex(/^[a-z0-9_-]{2,64}$/), name: z.string().min(1).max(100), permissions: z.array(z.string()).max(100) });
function checkPerms(actor: AuthUser, perms: string[]) {
  for (const p of perms) { if (p !== '*' && !ADMIN_PERMISSIONS.includes(p)) throw new HttpError(422, `Unknown permission ${p}`); if (!actor.permissions.includes('*') && !actor.permissions.includes(p)) throw forbidden(`You cannot grant ${p}`); }
}
coreAdmin.post('/roles', requirePerm('admin.roles'), async (req, res) => {
  const b = body(roleSchema, req); checkPerms(req.user!, b.permissions);
  const r = await exec('INSERT INTO roles (slug, name, permissions) VALUES (?, ?, ?)', [b.slug, b.name, json(b.permissions)]).catch((e: any) => { if (e.code === 'ER_DUP_ENTRY') throw new HttpError(409, 'Slug already in use'); throw e; });
  await audit(req, 'admin.role.create', { type: 'role', id: r.insertId }, b); res.status(201).json({ id: r.insertId });
});
coreAdmin.patch('/roles/:id', requirePerm('admin.roles'), async (req, res) => {
  const id = idParam(req); const b = patchBody(roleSchema.partial(), req); const r: any = await one('SELECT * FROM roles WHERE id = ?', [id]); if (!r) throw new HttpError(404, 'Role not found');
  if (r.slug === 'super_admin') throw new HttpError(409, 'The Super Admin role cannot be modified');
  if (b.permissions) checkPerms(req.user!, b.permissions);
  await exec('UPDATE roles SET name = COALESCE(?, name), permissions = COALESCE(?, permissions), slug = IF(is_system = 1, slug, COALESCE(?, slug)) WHERE id = ?', [b.name ?? null, b.permissions ? json(b.permissions) : null, b.slug ?? null, id]);
  await audit(req, 'admin.role.update', { type: 'role', id }, b); res.json({ ok: true });
});
coreAdmin.delete('/roles/:id', requirePerm('admin.roles'), async (req, res) => {
  const id = idParam(req); const r: any = await one('SELECT * FROM roles WHERE id = ?', [id]); if (!r) throw new HttpError(404, 'Role not found'); if (r.is_system) throw new HttpError(409, 'Built-in roles cannot be deleted');
  const u = await one<any>('SELECT COUNT(*) AS c FROM users WHERE role_id = ?', [id]); if (Number(u.c)) throw new HttpError(409, 'Reassign the users of this role first');
  await exec('DELETE FROM roles WHERE id = ?', [id]); await audit(req, 'admin.role.delete', { type: 'role', id }); res.json({ ok: true });
});

// ---------------------------------------------------------------- servers
coreAdmin.get('/servers', requirePerm('admin.servers'), async (req, res) => {
  const p = paginate(req); const cond: string[] = []; const vals: any[] = [];
  if (req.query.search) { cond.push('(s.name LIKE ? OR s.uuid LIKE ? OR u.email LIKE ? OR s.id = ?)'); const t = `%${req.query.search}%`; vals.push(t, t, t, Number(req.query.search) || 0); }
  if (req.query.node) { cond.push('s.node_id = ?'); vals.push(Number(req.query.node)); }
  if (req.query.owner) { cond.push('s.owner_id = ?'); vals.push(Number(req.query.owner)); }
  if (req.query.state) { cond.push('s.state = ?'); vals.push(String(req.query.state)); }
  if (req.query.suspended === '1') cond.push('s.suspended_at IS NOT NULL');
  const where = cond.length ? `WHERE ${cond.join(' AND ')}` : '';
  const rows = await q(`SELECT s.id, s.uuid, s.name, s.node_id, n.name AS node_name, s.node_server_id, s.owner_id, u.email AS owner_email, u.username AS owner_username, s.egg_id, e.name AS egg_name, s.state, s.status_detail, s.memory_mb, s.cpu_percent, s.disk_mb, s.suspended_at, s.suspended_until, s.suspension_reason, s.security_level, s.security_blocked, s.installed_version, s.created_at,
    (SELECT CONCAT(a.ip, ':', a.port) FROM allocations a WHERE a.server_id = s.id AND a.is_primary = 1 LIMIT 1) AS address
    FROM servers s JOIN nodes n ON n.id = s.node_id JOIN users u ON u.id = s.owner_id JOIN eggs e ON e.id = s.egg_id ${where} ORDER BY s.id DESC LIMIT ? OFFSET ?`, [...vals, p.limit, p.offset]);
  const total = await one<any>(`SELECT COUNT(*) AS c FROM servers s JOIN users u ON u.id = s.owner_id ${where}`, vals);
  res.json({ servers: rows, total: Number(total.c), page: p.page });
});
coreAdmin.get('/servers/:id', requirePerm('admin.servers'), async (req, res) => {
  const s = await getServer(idParam(req)); const node = await getNode(s.node_id);
  let live: any = null; if (node.status === 'online') live = await agent(node, 'GET', `/api/servers/${s.node_server_id}`, undefined, { serverId: s.node_server_id, timeoutMs: 5000 }).catch((e: any) => ({ error: e.message }));
  res.json({ server: { ...s, variables: parse(s.variables, {}) }, node: { id: node.id, name: node.name, status: node.status }, live,
    allocations: await q('SELECT * FROM allocations WHERE server_id = ?', [s.id]), owner: await one('SELECT id, email, username FROM users WHERE id = ?', [s.owner_id]),
    subusers: await q('SELECT su.id, su.user_id, u.email, su.permissions FROM server_subusers su JOIN users u ON u.id = su.user_id WHERE su.server_id = ?', [s.id]),
    incidents: await q('SELECT id, severity, category, rule, status, created_at FROM security_incidents WHERE server_id = ? ORDER BY id DESC LIMIT 20', [s.id]) });
});
const createSchema = z.object({ name: z.string().trim().min(1).max(100), description: z.string().max(2000).optional(), ownerId: z.number().int(), nodeId: z.number().int(), eggId: z.number().int(), memoryMb: z.number().int().min(128).max(1048576), cpuPercent: z.number().int().min(0).max(10000), diskMb: z.number().int().min(256).max(10485760), swapMb: z.number().int().min(0).max(65536).optional(), allocationId: z.number().int().optional(), additionalAllocations: z.number().int().min(0).max(20).optional(), databaseLimit: z.number().int().min(0).max(100).optional(), allocationLimit: z.number().int().min(1).max(50).optional(), backupLimit: z.number().int().min(0).max(100).optional(), backupStorageMb: z.number().int().min(0).optional(), variables: z.record(z.string(), z.string().max(1000)).optional(), javaPath: z.string().max(500).nullable().optional(), xmsMb: z.number().int().min(64).optional(), xmxMb: z.number().int().min(128).optional(), startup: z.string().max(1000).optional(), skipInstall: z.boolean().optional(), autoRestart: z.boolean().optional() });
coreAdmin.post('/servers', requirePerm('admin.servers'), async (req, res) => {
  const b = body(createSchema, req); const owner = await one('SELECT id FROM users WHERE id = ?', [b.ownerId]); if (!owner) throw new HttpError(422, 'Owner not found');
  const r = await createServer(b);
  if (b.skipInstall) { await syncSpec(r.id).catch(() => {}); await exec("UPDATE servers SET state = 'offline', status_detail = 'Created without installation: upload your files' WHERE id = ?", [r.id]); }
  await audit(req, 'admin.server.create', { type: 'server', id: r.id }, { nodeId: b.nodeId, nodeServerId: r.nodeServerId, name: b.name });
  void dispatchWebhook('server.created', { serverId: r.id, nodeId: b.nodeId, nodeServerId: r.nodeServerId, ownerId: b.ownerId }); res.status(201).json(r);
});
coreAdmin.patch('/servers/:id', requirePerm('admin.servers'), async (req, res) => {
  const id = idParam(req); const s = await getServer(id);
  const b = body(z.object({ name: z.string().trim().min(1).max(100).optional(), description: z.string().max(2000).nullable().optional(), ownerId: z.number().int().optional(), memoryMb: z.number().int().min(128).optional(), cpuPercent: z.number().int().min(0).max(10000).optional(), diskMb: z.number().int().min(256).optional(), swapMb: z.number().int().min(0).optional(), databaseLimit: z.number().int().min(0).optional(), allocationLimit: z.number().int().min(1).optional(), backupLimit: z.number().int().min(0).optional(), backupStorageMb: z.number().int().min(0).optional(), maxUploadMb: z.number().int().min(1).max(102400).optional(), xmsMb: z.number().int().min(64).optional(), xmxMb: z.number().int().min(128).optional(), startup: z.string().max(1000).optional(), eggId: z.number().int().optional(), variables: z.record(z.string(), z.string().max(1000)).optional(), javaPath: z.string().max(500).nullable().optional(), autoRestart: z.boolean().optional() }), req);
  if (b.ownerId) { const o = await one('SELECT id FROM users WHERE id = ?', [b.ownerId]); if (!o) throw new HttpError(422, 'Owner not found'); }
  const memory = b.memoryMb ?? s.memory_mb; let xms = b.xmsMb ?? s.xms_mb; let xmx = b.xmxMb ?? s.xmx_mb;
  if (b.memoryMb && !b.xmxMb && xmx > memory) { const h = recommendedHeap(memory); xmx = h.xmxMb; xms = Math.min(xms, xmx); }
  const egg = await getEgg(b.eggId ?? s.egg_id); if (egg.definition.runtime === 'java') validateHeap(memory, xms, xmx);
  if (b.memoryMb || b.diskMb) { const node = await getNode(s.node_id); const { nodeCapacity } = await import('../../services/servers'); const cap = await nodeCapacity(node); if (cap.memory - s.memory_mb + memory > cap.memoryMax) throw new HttpError(409, 'Node does not have enough RAM'); if (cap.disk - s.disk_mb + (b.diskMb ?? s.disk_mb) > cap.diskMax) throw new HttpError(409, 'Node does not have enough disk'); }
  const vars = b.variables ? validateVariables(egg.definition, { ...parse(s.variables, {}), ...b.variables }, true) : undefined;
  const cols: Record<string, unknown> = { name: b.name, description: b.description, owner_id: b.ownerId, memory_mb: b.memoryMb, cpu_percent: b.cpuPercent, disk_mb: b.diskMb, swap_mb: b.swapMb, database_limit: b.databaseLimit, allocation_limit: b.allocationLimit, backup_limit: b.backupLimit, backup_storage_mb: b.backupStorageMb, max_upload_mb: b.maxUploadMb, xms_mb: xms, xmx_mb: xmx, startup: b.startup, egg_id: b.eggId, variables: vars ? json(vars) : undefined, java_path: b.javaPath, auto_restart: b.autoRestart === undefined ? undefined : b.autoRestart ? 1 : 0 };
  const keys = Object.keys(cols).filter(k => cols[k] !== undefined);
  if (keys.length) await exec(`UPDATE servers SET ${keys.map(k => `${k} = ?`).join(', ')} WHERE id = ?`, [...keys.map(k => cols[k]), id]);
  if (b.ownerId && b.ownerId !== s.owner_id) { await exec('DELETE FROM server_subusers WHERE server_id = ? AND user_id = ?', [id, b.ownerId]); await notify(b.ownerId, 'system', `You now own server "${s.name}"`, 'An administrator transferred ownership of this server to you.', { link: `/server/${id}` }); }
  const sync = await syncSpec(id).then(() => null).catch((e: any) => e.message);
  await audit(req, 'admin.server.update', { type: 'server', id }, b); await serverActivity(req, id, 'server.admin_updated', b);
  res.json({ ok: true, syncWarning: sync, note: (b.memoryMb || b.cpuPercent || b.xmxMb) ? 'Resource changes apply on the next restart.' : undefined });
});
coreAdmin.post('/servers/:id/power', requirePerm('admin.servers'), async (req, res) => { const b = body(z.object({ action: z.enum(['start', 'stop', 'restart', 'kill']) }), req); const r = await power(idParam(req), b.action); await audit(req, `admin.server.${b.action}`, { type: 'server', id: idParam(req) }); res.json(r); });
coreAdmin.post('/servers/:id/reinstall', requirePerm('admin.servers'), async (req, res) => { await pushAndInstall(idParam(req), true); await audit(req, 'admin.server.reinstall', { type: 'server', id: idParam(req) }); res.json({ ok: true }); });
coreAdmin.post('/servers/:id/suspend', requirePerm('admin.servers'), async (req, res) => {
  const b = body(z.object({ reason: z.string().max(500).default('Suspended by an administrator'), hours: z.number().int().min(1).max(8760).nullable().default(null) }), req);
  const s = await getServer(idParam(req)); await setSuspension(s.id, true, b.reason, b.hours);
  const node = await getNode(s.node_id); await agent(node, 'POST', `/api/servers/${s.node_server_id}/power`, { action: 'stop' }, { serverId: s.node_server_id }).catch(() => {});
  await notify(s.owner_id, 'system', `Server "${s.name}" suspended`, b.reason, { link: `/server/${s.id}`, email: true });
  await audit(req, 'admin.server.suspend', { type: 'server', id: s.id }, b); void dispatchWebhook('server.suspended', { serverId: s.id, reason: b.reason }); res.json({ ok: true });
});
coreAdmin.post('/servers/:id/unsuspend', requirePerm('admin.servers'), async (req, res) => {
  const s = await getServer(idParam(req)); await setSuspension(s.id, false, null, null);
  await notify(s.owner_id, 'system', `Server "${s.name}" unsuspended`, 'You can start your server again.', { link: `/server/${s.id}` }); await audit(req, 'admin.server.unsuspend', { type: 'server', id: s.id }); res.json({ ok: true, securityBlocked: !!s.security_blocked });
});
/** Deletion requires typing the "<node>/<id>" identifier (names are not unique, IDs are). */
coreAdmin.delete('/servers/:id', requirePerm('admin.servers'), async (req, res) => {
  const s = await getServer(idParam(req)); const b = body(z.object({ confirm: z.string() }), req);
  if (b.confirm !== `${s.node_id}/${s.node_server_id}`) throw new HttpError(422, `Type ${s.node_id}/${s.node_server_id} to confirm deletion`);
  const r = await deleteServer(s.id); await audit(req, 'admin.server.delete', { type: 'server', id: s.id }, { nodeId: s.node_id, nodeServerId: s.node_server_id, name: s.name });
  void dispatchWebhook('server.deleted', { serverId: s.id, nodeId: s.node_id, nodeServerId: s.node_server_id }); res.json(r);
});
coreAdmin.post('/servers/:id/recover', requirePerm('admin.servers'), async (req, res) => { const r = await recoverServer(idParam(req)); await audit(req, 'admin.server.recover', { type: 'server', id: idParam(req) }); res.json(r); });
coreAdmin.post('/servers/:id/transfer', requirePerm('admin.servers'), async (req, res) => {
  const b = body(z.object({ nodeId: z.number().int(), allocationId: z.number().int().optional() }), req);
  await startTransfer(idParam(req), b.nodeId, b.allocationId);
  const job = await enqueue('server.transfer', { serverId: idParam(req), targetNodeId: b.nodeId, allocationId: b.allocationId }, { uniqueKey: `transfer:${idParam(req)}:${Date.now()}`, maxAttempts: 1 });
  await audit(req, 'admin.server.transfer', { type: 'server', id: idParam(req) }, b); res.status(202).json({ jobId: job });
});
coreAdmin.post('/servers/:id/clone', requirePerm('admin.servers'), async (req, res) => {
  const s = await getServer(idParam(req)); const b = body(z.object({ nodeId: z.number().int().optional(), name: z.string().trim().min(1).max(100).optional(), ownerId: z.number().int().optional() }), req);
  if (!['offline', 'stopped', 'install_failed', 'crashed'].includes(s.state)) throw new HttpError(409, 'Stop the server before cloning so files are consistent');
  const job = await enqueue('server.clone', { serverId: s.id, targetNodeId: b.nodeId ?? s.node_id, name: b.name || `${s.name} (copy)`, ownerId: b.ownerId ?? s.owner_id }, { maxAttempts: 1 });
  await audit(req, 'admin.server.clone', { type: 'server', id: s.id }, b); res.status(202).json({ jobId: job });
});
coreAdmin.get('/servers/:id/export', requirePerm('admin.servers'), async (req, res) => {
  const s = await getServer(idParam(req)); const node = await getNode(s.node_id);
  res.setHeader('Content-Disposition', `attachment; filename="server-${s.node_id}-${s.node_server_id}.zip"`);
  await audit(req, 'admin.server.export', { type: 'server', id: s.id });
  await agentStream(node, req, res, 'GET', `/api/servers/${s.node_server_id}/archive`, s.node_server_id);
});
coreAdmin.get('/servers/:id/export-config', requirePerm('admin.servers'), async (req, res) => {
  const s = await getServer(idParam(req)); const egg = await getEgg(s.egg_id); const spec = await buildSpec(s);
  res.setHeader('Content-Disposition', `attachment; filename="server-${s.node_id}-${s.node_server_id}.json"`);
  res.json({ oghost: 1, name: s.name, description: s.description, egg: egg.slug, memoryMb: s.memory_mb, cpuPercent: s.cpu_percent, diskMb: s.disk_mb, xmsMb: s.xms_mb, xmxMb: s.xmx_mb, startup: s.startup, variables: spec.variables, databaseLimit: s.database_limit, allocationLimit: s.allocation_limit, backupLimit: s.backup_limit });
});
/** Import: PUT a .zip (raw body) into an existing (stopped) server; replaces its files. */
coreAdmin.put('/servers/:id/import', requirePerm('admin.servers'), async (req, res) => {
  const s = await getServer(idParam(req)); if (s.state === 'running' || s.state === 'starting') throw new HttpError(409, 'Stop the server first');
  const size = Number(req.headers['content-length'] || req.headers['x-file-size'] || 0); if (!size) throw new HttpError(411, 'Content-Length required');
  if (size > s.disk_mb * 1024 * 1024) throw new HttpError(413, 'Archive is larger than the server disk limit');
  const r = await importIntoServer(s.id, req, size); await audit(req, 'admin.server.import', { type: 'server', id: s.id }, { size }); res.json(r);
});
coreAdmin.post('/servers/:id/allocations', requirePerm('admin.servers'), async (req, res) => {
  const s = await getServer(idParam(req)); const b = body(z.object({ allocationId: z.number().int(), primary: z.boolean().default(false) }), req);
  await tx(async (c) => {
    const a: any = await one('SELECT * FROM allocations WHERE id = ? AND node_id = ? FOR UPDATE', [b.allocationId, s.node_id], c); if (!a || (a.server_id && a.server_id !== s.id)) throw new HttpError(409, 'Allocation not available on this node');
    if (b.primary) await exec('UPDATE allocations SET is_primary = 0 WHERE server_id = ?', [s.id], c);
    await exec('UPDATE allocations SET server_id = ?, is_primary = ? WHERE id = ?', [s.id, b.primary ? 1 : a.is_primary, a.id], c);
  });
  await syncSpec(s.id).catch(() => {}); res.json({ ok: true });
});
coreAdmin.delete('/servers/:id/allocations/:aid', requirePerm('admin.servers'), async (req, res) => {
  const s = await getServer(idParam(req)); const a: any = await one('SELECT * FROM allocations WHERE id = ? AND server_id = ?', [idParam(req, 'aid'), s.id]); if (!a) throw new HttpError(404, 'Allocation not assigned');
  if (a.is_primary) throw new HttpError(409, 'Assign a different primary allocation first');
  await exec('UPDATE allocations SET server_id = NULL, is_primary = 0, notes = NULL WHERE id = ?', [a.id]); await syncSpec(s.id).catch(() => {}); res.json({ ok: true });
});
