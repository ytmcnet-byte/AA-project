// Numeric ID allocation, same-name servers, deletion confirmation and ID reuse.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { skip, admin, mkServer, rmServer, NODE } from './common.mjs';
const DATA = process.env.E2E_AGENT_DATA_ROOT; // e.g. /tmp/oge/data — enables on-disk folder checks

test('concurrent creation gets unique numeric IDs; same names work; deleted IDs are reused', { skip }, async () => {
  const c = await admin(); const made = [];
  try {
    const rs = await Promise.all(Array.from({ length: 6 }, () => mkServer(c, 'e2e same name')));
    made.push(...rs);
    const ids = rs.map(r => r.nodeServerId);
    assert.equal(new Set(ids).size, ids.length, `duplicate IDs allocated: ${ids}`);
    ids.forEach(i => assert.ok(Number.isInteger(i) && i > 0));
    if (DATA) for (const i of ids) {
      const d = path.join(DATA, 'nodes', String(NODE), 'servers', String(i));
      assert.ok(fs.statSync(d).isDirectory(), `folder ${d}`);
      assert.ok(!fs.readdirSync(path.dirname(d)).some(n => !/^\d+$/.test(n)), 'only numeric folder names');
    }
    const victim = rs[2];
    const bad = await c.call('DELETE', `/api/admin/servers/${victim.id}`, { confirm: 'wrong' }, { allowError: true });
    assert.ok(bad.status >= 400, 'delete without the right confirmation phrase is refused');
    await rmServer(c, victim); made.splice(made.indexOf(victim), 1);
    const again = await mkServer(c, 'e2e same name'); made.push(again);
    assert.equal(again.nodeServerId, victim.nodeServerId, 'lowest free ID is reused once deletion completed');
  } finally { for (const s of made) await rmServer(c, s); }
});
