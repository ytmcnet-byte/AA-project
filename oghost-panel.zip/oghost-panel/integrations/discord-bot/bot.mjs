// Example OGCoins Discord bot for OGHOST PANEL.
//   /balance [user]                       -> shows the OGCoins balance of a linked panel account
//   /givecoins user amount reference [reason] (staff role only) -> credits coins after a sale on Discord
// Customers must first link Discord on the panel's OGCoins page. "reference" must be unique per sale
// (e.g. your order or ticket number): the panel never credits the same reference twice.
// Load env vars yourself (e.g. `node --env-file=.env bot.mjs`).
import { Client, Events, GatewayIntentBits, REST, Routes, SlashCommandBuilder, MessageFlags } from 'discord.js';

const { DISCORD_BOT_TOKEN, DISCORD_APP_ID, DISCORD_GUILD_ID, STAFF_ROLE_ID, PANEL_URL, PANEL_API_KEY } = process.env;
for (const [k, v] of Object.entries({ DISCORD_BOT_TOKEN, DISCORD_APP_ID, PANEL_URL, PANEL_API_KEY })) if (!v) { console.error(`Missing ${k}`); process.exit(1); }

const commands = [
  new SlashCommandBuilder().setName('balance').setDescription('Show OGCoins balance').addUserOption(o => o.setName('user').setDescription('Member (default: you)')),
  new SlashCommandBuilder().setName('givecoins').setDescription('Staff: credit OGCoins to a member')
    .addUserOption(o => o.setName('user').setDescription('Member').setRequired(true))
    .addIntegerOption(o => o.setName('amount').setDescription('Coins').setRequired(true).setMinValue(1).setMaxValue(10_000_000))
    .addStringOption(o => o.setName('reference').setDescription('Unique order / payment ID').setRequired(true).setMaxLength(100))
    .addStringOption(o => o.setName('reason').setDescription('Shown to the customer').setMaxLength(200)),
].map(c => c.toJSON());

async function panel(method, path, body) {
  const r = await fetch(PANEL_URL.replace(/\/$/, '') + path, { method, headers: { authorization: `Bearer ${PANEL_API_KEY}`, 'content-type': 'application/json' }, body: body ? JSON.stringify(body) : undefined, signal: AbortSignal.timeout(15000) });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw Object.assign(new Error(data.error || `Panel returned ${r.status}`), { status: r.status, data });
  return data;
}

if (process.argv.includes('--register')) {
  const rest = new REST().setToken(DISCORD_BOT_TOKEN);
  await rest.put(DISCORD_GUILD_ID ? Routes.applicationGuildCommands(DISCORD_APP_ID, DISCORD_GUILD_ID) : Routes.applicationCommands(DISCORD_APP_ID), { body: commands });
  console.log('Slash commands registered'); process.exit(0);
}

const client = new Client({ intents: [GatewayIntentBits.Guilds] });
client.on('interactionCreate', async (i) => {
  if (!i.isChatInputCommand()) return;
  try {
    if (i.commandName === 'balance') {
      const u = i.options.getUser('user') || i.user;
      const r = await panel('GET', `/api/admin/coins/discord/${u.id}`);
      return i.reply({ content: r.linked ? `${u} has **${r.balance.toLocaleString()} ${r.name}** (panel user ${r.username}).` : `${u} has not linked Discord on the panel yet (OGCoins page → Link Discord).`, flags: MessageFlags.Ephemeral });
    }
    if (i.commandName === 'givecoins') {
      if (!STAFF_ROLE_ID || !i.inGuild() || !i.member.roles.cache?.has(STAFF_ROLE_ID)) return i.reply({ content: 'Staff only.', flags: MessageFlags.Ephemeral });
      const u = i.options.getUser('user', true); const amount = i.options.getInteger('amount', true); const reference = i.options.getString('reference', true);
      const r = await panel('POST', '/api/admin/coins/discord/grant', { discordId: u.id, amount, reference, reason: i.options.getString('reason') || `Purchased on Discord (${reference})` });
      return i.reply({ content: r.duplicate ? `Reference ${reference} was already credited earlier. Nothing changed. Balance: ${r.balance}.` : `Credited ${amount} to ${u}. New balance: ${r.balance}.`, flags: MessageFlags.Ephemeral });
    }
  } catch (e) {
    const msg = e.data?.code === 'NOT_LINKED' ? 'That member has not linked Discord on the panel yet.' : `Error: ${e.message}`;
    if (i.replied || i.deferred) await i.followUp({ content: msg, flags: MessageFlags.Ephemeral }).catch(() => {}); else await i.reply({ content: msg, flags: MessageFlags.Ephemeral }).catch(() => {});
  }
});
client.once(Events.ClientReady, () => console.log(`Logged in as ${client.user.tag}`));
client.login(DISCORD_BOT_TOKEN);
