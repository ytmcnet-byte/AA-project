import { initializeApp, cert, getApps, deleteApp, type App } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';
import { getSetting } from './settings';
import { HttpError } from '../lib/http';

let app: App | null = null; let key = '';
async function firebaseApp() {
  const projectId = await getSetting<string>('firebase.projectId'); const sa = await getSetting<string>('firebase.serviceAccount');
  if (!projectId) throw new HttpError(503, 'Google sign-in is not configured (Firebase project ID missing)');
  const k = `${projectId}:${sa ? 'sa' : 'nosa'}`;
  if (app && key === k) return { app, hasCredentials: !!sa };
  if (app) await deleteApp(app).catch(() => {});
  const name = `oghost-${Date.now()}`;
  app = sa ? initializeApp({ credential: cert(JSON.parse(sa)), projectId }, name) : initializeApp({ projectId }, name);
  key = k; void getApps; return { app, hasCredentials: !!sa };
}
/** Server-side verification of a Firebase ID token (signature, audience, issuer, expiry; revocation when credentials exist). */
export async function verifyFirebaseIdToken(idToken: string) {
  const { app: a, hasCredentials } = await firebaseApp();
  try {
    const t = await getAuth(a).verifyIdToken(idToken, hasCredentials);
    if (t.firebase?.sign_in_provider !== 'google.com') throw new HttpError(400, 'Only Google sign-in is accepted on this endpoint');
    return t;
  } catch (e: any) { if (e instanceof HttpError) throw e; throw new HttpError(401, `Google sign-in verification failed: ${e.code || e.message}`); }
}
export async function deleteFirebaseUser(uid: string) { try { const { app: a, hasCredentials } = await firebaseApp(); if (hasCredentials) await getAuth(a).deleteUser(uid); } catch { /* best effort */ } }
