'use strict';

/**
 * Plugin Bypass Module
 * Sonar, AuthMe, nLogin aur doosre anti-bot plugins ko handle karta hai
 */

// ── Sonar Anti-Bot keyword patterns ───────────────────────────────────────
const SONAR_PATTERNS = [
  /sonar/i,
  /please move/i,
  /move to verify/i,
  /verification/i,
  /verify yourself/i,
  /anti.?bot/i,
  /you are being checked/i,
  /jump to verify/i,
  /walk forward/i,
  /move forward/i,
  /sneak to/i,
  /captcha/i,
];

// ── AuthMe / nLogin keyword patterns ──────────────────────────────────────
const AUTHME_LOGIN_PATTERNS = [
  /please login/i,
  /\/login/i,
  /use \/login/i,
  /log in with/i,
  /you are not logged in/i,
  /please authenticate/i,
  /use \/l /i,
];

const AUTHME_REGISTER_PATTERNS = [
  /please register/i,
  /\/register/i,
  /use \/register/i,
  /you are not registered/i,
  /register with/i,
];

const AUTHME_SUCCESS_PATTERNS = [
  /successfully logged in/i,
  /you have been logged in/i,
  /login successful/i,
  /welcome back/i,
  /authenticated/i,
  /registered successfully/i,
  /you have been registered/i,
];

class PluginBypass {
  constructor(bot, config) {
    this.bot = bot;
    this.config = config.plugins || {};
    this.sonarHandled = false;
    this.authDone = false;
    this.sonarVerifyInterval = null;

    this._setupListeners();
    console.log('[Bypass] Plugin bypass module loaded');
    this._logStatus();
  }

  _logStatus() {
    const s = this.config.sonar?.enabled ? '✓ ON' : '✗ OFF';
    const a = this.config.authme?.enabled ? '✓ ON' : '✗ OFF';
    const r = this.config.register?.enabled ? '✓ ON' : '✗ OFF';
    console.log(`[Bypass] Sonar: ${s} | AuthMe/Login: ${a} | Register: ${r}`);
  }

  _setupListeners() {
    // Chat message listener — plugin messages yahan aate hain
    this.bot.on('message', (jsonMsg) => {
      const text = jsonMsg.toString();
      this._handleMessage(text);
    });

    // Tab message (action bar) bhi check karo
    this.bot.on('actionBar', (jsonMsg) => {
      const text = jsonMsg.toString();
      this._handleMessage(text);
    });

    // Spawn pe kuch plugins title screen dete hain
    this.bot.on('title', (text) => {
      if (text) this._handleMessage(text.toString());
    });

    // Spawn hone par register trigger karo agar enabled hai
    this.bot.once('spawn', () => {
      if (this.config.register?.enabled && !this.authDone) {
        setTimeout(() => this._tryRegister(), 2000);
      }
    });
  }

  _handleMessage(text) {
    if (!text) return;

    // ── Sonar bypass ──────────────────────────────────────────────────────
    if (this.config.sonar?.enabled && !this.sonarHandled) {
      const isSonar = SONAR_PATTERNS.some(p => p.test(text));
      if (isSonar) {
        console.log(`[Bypass] Sonar detected! Message: "${text}"`);
        this._handleSonar();
        return;
      }
    }

    // ── AuthMe / nLogin login ─────────────────────────────────────────────
    if (this.config.authme?.enabled && !this.authDone) {
      const needsLogin = AUTHME_LOGIN_PATTERNS.some(p => p.test(text));
      if (needsLogin) {
        console.log(`[Bypass] AuthMe login prompt mila: "${text}"`);
        setTimeout(() => this._tryLogin(), 1500);
        return;
      }

      const needsRegister = AUTHME_REGISTER_PATTERNS.some(p => p.test(text));
      if (needsRegister) {
        console.log(`[Bypass] AuthMe register prompt mila: "${text}"`);
        setTimeout(() => this._tryRegister(), 1500);
        return;
      }

      const success = AUTHME_SUCCESS_PATTERNS.some(p => p.test(text));
      if (success) {
        console.log('[Bypass] AuthMe login/register successful!');
        this.authDone = true;
        if (this.sonarVerifyInterval) {
          clearInterval(this.sonarVerifyInterval);
          this.sonarVerifyInterval = null;
        }
        return;
      }
    }
  }

  // ── Sonar: move around to pass verification ────────────────────────────
  _handleSonar() {
    this.sonarHandled = true;
    const bot = this.bot;

    console.log('[Bypass] Sonar bypass shuru — movement sequence chala raha hun...');

    // Sonar check: move, jump, sneak — sequence
    const sequence = async () => {
      try {
        // Forward chalna
        bot.setControlState('forward', true);
        await this._wait(600);
        bot.setControlState('forward', false);

        // Jump
        bot.setControlState('jump', true);
        await this._wait(300);
        bot.setControlState('jump', false);

        // Back
        bot.setControlState('back', true);
        await this._wait(600);
        bot.setControlState('back', false);

        // Sneak
        bot.setControlState('sneak', true);
        await this._wait(800);
        bot.setControlState('sneak', false);

        // Sprint forward
        bot.setControlState('sprint', true);
        bot.setControlState('forward', true);
        await this._wait(500);
        bot.setControlState('forward', false);
        bot.setControlState('sprint', false);

        // Look around
        const yaw = Math.random() * Math.PI * 2;
        bot.look(yaw, 0, false);
        await this._wait(300);

        console.log('[Bypass] Sonar movement sequence complete');
      } catch (err) {
        console.log(`[Bypass] Sonar sequence error: ${err.message}`);
      }
    };

    // Pehle sequence chalaao, phir har 3 second pe movement karte raho
    sequence();

    let attempts = 0;
    this.sonarVerifyInterval = setInterval(async () => {
      attempts++;
      if (attempts > 15) {
        clearInterval(this.sonarVerifyInterval);
        this.sonarVerifyInterval = null;
        console.log('[Bypass] Sonar bypass attempts timeout — manual check karo');
        return;
      }
      // Random movement
      const dir = ['forward', 'back', 'left', 'right'][Math.floor(Math.random() * 4)];
      bot.setControlState(dir, true);
      await this._wait(400 + Math.random() * 400);
      bot.setControlState(dir, false);
      if (attempts % 3 === 0) {
        bot.setControlState('jump', true);
        await this._wait(200);
        bot.setControlState('jump', false);
      }
    }, 3000);
  }

  // ── AuthMe: /login ─────────────────────────────────────────────────────
  _tryLogin() {
    const pass = this.config.authme?.password || this.config.register?.password;
    if (!pass) {
      console.log('[Bypass] AuthMe password config.json mein nahi dala!');
      return;
    }
    console.log('[Bypass] AuthMe /login bhej raha hun...');
    this.bot.chat(`/login ${pass}`);
  }

  // ── AuthMe / register plugin: /register ───────────────────────────────
  _tryRegister() {
    const pass = this.config.register?.password || this.config.authme?.password;
    if (!pass) {
      console.log('[Bypass] Register password config.json mein nahi dala!');
      return;
    }
    console.log('[Bypass] /register command bhej raha hun...');
    this.bot.chat(`/register ${pass} ${pass}`);

    // 2 second baad login bhi try karo
    setTimeout(() => {
      if (!this.authDone) this._tryLogin();
    }, 2000);
  }

  // ── Utility ────────────────────────────────────────────────────────────
  _wait(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  // Reset karo reconnect pe
  reset() {
    this.sonarHandled = false;
    this.authDone = false;
    if (this.sonarVerifyInterval) {
      clearInterval(this.sonarVerifyInterval);
      this.sonarVerifyInterval = null;
    }
    console.log('[Bypass] Reset ho gaya');
  }
}

module.exports = PluginBypass;
