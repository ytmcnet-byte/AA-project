#!/usr/bin/env bash
# =============================================================================
#  OGHOST PANEL installer — Powering the Next Generation of Game Hosting.
#  Powered by SHIVAMBROOG
#
#  bash installer/install.sh            install / update the panel
#  bash installer/install.sh --agent    install / update a node agent on this machine
#
#  Runs as a normal Linux user. It never calls sudo and never asks for the
#  system root password. Steps that genuinely need a host administrator
#  (kernel quotas, enable-linger, opening firewall ports) are printed as
#  instructions instead of being run.
#
#  Options:
#    --agent            install the node agent instead of the panel
#    --yes, -y          accept defaults for yes/no questions (non-interactive)
#    --no-service       do not install a systemd --user unit / start the service
#    --skip-build       reuse the existing build in dist/
#    --allow-root       permit running as root (NOT recommended; see docs)
#    --help
#
#  Non-interactive panel install: pre-set APP_URL, PORT, DB_HOST, DB_PORT,
#  DB_NAME, DB_USER, DB_PASSWORD, ADMIN_EMAIL, ADMIN_USERNAME, ADMIN_PASSWORD.
#  Non-interactive agent install: pre-set NODE_ID, NODE_SECRET, PANEL_URL,
#  AGENT_PORT (or place ~/oghost-agent/agent.env before running).
# =============================================================================
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
MODE=panel; YES=0; NO_SERVICE=0; SKIP_BUILD=0; ALLOW_ROOT=0
for a in "$@"; do
  case "$a" in
    --agent) MODE=agent ;; --yes|-y) YES=1 ;; --no-service) NO_SERVICE=1 ;;
    --skip-build) SKIP_BUILD=1 ;; --allow-root) ALLOW_ROOT=1 ;;
    --help|-h) sed -n '2,27p' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
    *) echo "Unknown option: $a (see --help)"; exit 1 ;;
  esac
done

R=$'\e[31m'; G=$'\e[32m'; Y=$'\e[33m'; B=$'\e[1m'; N=$'\e[0m'
[ -t 1 ] || { R=; G=; Y=; B=; N=; }
info() { echo "${B}==>${N} $*"; }
ok()   { echo "${G}  ✓${N} $*"; }
warn() { echo "${Y}  !${N} $*"; }
die()  { echo "${R}  ✗ $*${N}" >&2; exit 1; }
ask()  { # ask VAR "Prompt" default [secret]
  local __v="$1" __p="$2" __d="${3:-}" __s="${4:-}" __a
  if [ -n "${!__v:-}" ]; then return; fi
  if [ "$YES" = 1 ] || [ ! -t 0 ]; then
    [ -n "$__d" ] || [ -n "$__s" ] || die "$__v is required (set it in the environment for non-interactive installs)"
    printf -v "$__v" '%s' "$__d"; return; fi
  if [ -n "$__s" ]; then read -r -s -p "  $__p: " __a; echo; else read -r -p "  $__p${__d:+ [$__d]}: " __a; fi
  printf -v "$__v" '%s' "${__a:-$__d}"
}
yesno() { # yesno "Question" default(y/n)
  local d="${2:-n}" a
  if [ "$YES" = 1 ] || [ ! -t 0 ]; then [ "$d" = y ]; return; fi
  read -r -p "  $1 [$( [ "$d" = y ] && echo Y/n || echo y/N )]: " a; a="${a:-$d}"; [[ "$a" =~ ^[Yy] ]]
}
setenv() { # setenv FILE KEY VALUE  (replace or append, value written verbatim)
  local f="$1" k="$2" v="$3"
  if grep -q "^$k=" "$f" 2>/dev/null; then
    local tmp; tmp="$(mktemp)"; awk -v k="$k" -v v="$v" 'BEGIN{FS=OFS="="} $1==k{print k"="v; next} {print}' "$f" >"$tmp"; cat "$tmp" >"$f"; rm -f "$tmp"
  else echo "$k=$v" >>"$f"; fi
}

echo
echo "${R}${B}  OGHOST PANEL${N}  ${B}installer${N} — Powering the Next Generation of Game Hosting."
echo "  Powered by SHIVAMBROOG"
echo

# ---------------------------------------------------------------- preflight
info "Checking this machine"
[ "$(uname -s)" = Linux ] || warn "OGHOST is developed for Linux; $(uname -s) is untested."
ARCH="$(uname -m)"
case "$ARCH" in x86_64|amd64) ARCH=x64 ;; aarch64|arm64) ARCH=aarch64 ;; *) warn "Architecture $ARCH is untested (supported: amd64, arm64)." ;; esac
ok "architecture: $(uname -m)"
if [ "$(id -u)" = 0 ]; then
  if [ "$ALLOW_ROOT" != 1 ]; then
    die "You are running as root. OGHOST is designed to run as a normal user and game servers must never run as root.
    Create a user (e.g. 'adduser oghost'), log in as that user and re-run. If you really know what you are doing, pass --allow-root
    (the agent will still refuse to start game servers as root unless RUN_AS_UID_BASE is configured)."
  fi
  warn "Running as root because --allow-root was given."
else ok "running as $(id -un) (non-root)"; fi
command -v node >/dev/null || die "Node.js 20+ is required. Without root you can install it with nvm: https://github.com/nvm-sh/nvm  (nvm install 20)"
NODE_MAJOR="$(node -p 'process.versions.node.split(".")[0]')"
[ "$NODE_MAJOR" -ge 20 ] || die "Node.js $(node -v) found; version 20 or newer is required (nvm install 20)."
ok "node $(node -v)"
command -v npm >/dev/null || die "npm is required (it ships with Node.js)."
command -v tar >/dev/null || die "tar is required."

# ---------------------------------------------------------------- build
build() {
  if [ "$SKIP_BUILD" = 1 ] && [ -f "$ROOT/dist/panel.mjs" ]; then ok "using existing build"; return; fi
  info "Installing dependencies (npm ci) — this can take a few minutes"
  ( cd "$ROOT" && { npm ci --no-audit --no-fund || npm install --no-audit --no-fund; } ) || die "npm install failed"
  info "Building"
  if [ "$MODE" = panel ]; then ( cd "$ROOT" && npm run build ) || die "build failed"
  else ( cd "$ROOT" && npm run build:backend ) || die "build failed"; fi
  ok "build complete"
}

# ---------------------------------------------------------------- services
have_user_systemd() { command -v systemctl >/dev/null && systemctl --user show-environment >/dev/null 2>&1; }
install_service() { # install_service panel|agent
  local what="$1" unit="oghost-$1.service"
  [ "$NO_SERVICE" = 1 ] && { warn "--no-service: start manually with: bash $ROOT/scripts/oghost.sh start $what"; return; }
  if have_user_systemd; then
    mkdir -p "$HOME/.config/systemd/user"
    cat >"$HOME/.config/systemd/user/$unit" <<UNIT
[Unit]
Description=OGHOST ${what} (Powered by SHIVAMBROOG)
After=network-online.target

[Service]
Type=simple
ExecStart=/usr/bin/env bash $ROOT/scripts/run.sh $what
Environment=PATH=$(dirname "$(command -v node)"):/usr/local/bin:/usr/bin:/bin
Restart=on-failure
RestartSec=5
# The agent stops game servers gracefully on shutdown
TimeoutStopSec=120
KillMode=mixed
NoNewPrivileges=yes

[Install]
WantedBy=default.target
UNIT
    systemctl --user daemon-reload
    systemctl --user enable "$unit" >/dev/null
    systemctl --user restart "$unit"
    sleep 3
    if systemctl --user is-active --quiet "$unit"; then ok "systemd --user service $unit is running"
    else warn "$unit failed to start. Logs: journalctl --user -u $unit -n 50"; fi
    if command -v loginctl >/dev/null && [ "$(loginctl show-user "$(id -un)" -p Linger --value 2>/dev/null)" != yes ]; then
      warn "To keep $what running after you log out and start it at boot, a host administrator must run once:"
      echo "        loginctl enable-linger $(id -un)"
      echo "      (or, if your user may: 'loginctl enable-linger' without arguments)."
    fi
  else
    warn "systemd --user is not available; using the nohup helper."
    bash "$ROOT/scripts/oghost.sh" restart "$what" || true
    if command -v crontab >/dev/null && yesno "Add an @reboot crontab entry to start $what at boot?" y; then
      ( crontab -l 2>/dev/null | grep -v "scripts/oghost.sh start $what" ; echo "@reboot bash $ROOT/scripts/oghost.sh start $what" ) | crontab -
      ok "crontab @reboot entry added"
    else echo "      Start later with: bash $ROOT/scripts/oghost.sh start $what"; fi
  fi
}

# ================================================================ PANEL
install_panel() {
  build
  local ENVF="$ROOT/.env"
  info "Panel configuration ($ENVF)"
  if [ ! -f "$ENVF" ]; then
    ask APP_URL "Public URL of the panel (https://panel.example.com)" "http://$(hostname -I 2>/dev/null | awk '{print $1}' || echo 127.0.0.1):8080"
    ask PORT "Port for the panel to listen on (>1024, no root needed)" "8080"
    ask DB_HOST "MySQL/MariaDB host" "127.0.0.1"
    ask DB_PORT "MySQL/MariaDB port" "3306"
    ask DB_NAME "Database name" "oghost"
    ask DB_USER "Database user" "oghost"
    ask DB_PASSWORD "Database password (leave empty to generate one)" "" secret
    [ -n "$DB_PASSWORD" ] || DB_PASSWORD="$(node -e 'console.log(require("crypto").randomBytes(18).toString("base64url"))')"
    umask 077
    cat >"$ENVF" <<ENV
# OGHOST PANEL configuration. Keep private (chmod 600). See .env.example for all options.
NODE_ENV=production
APP_URL=$APP_URL
HOST=0.0.0.0
PORT=$PORT
APP_KEY=$(node "$ROOT/dist/panel.mjs" keygen)
DB_HOST=$DB_HOST
DB_PORT=$DB_PORT
DB_NAME=$DB_NAME
DB_USER=$DB_USER
DB_PASSWORD=$DB_PASSWORD
DATA_ROOT=$ROOT/.server
# Behind a reverse proxy (nginx/caddy) on the same host keep TRUST_PROXY=loopback
TRUST_PROXY=loopback
ENV
    chmod 600 "$ENVF"; ok "wrote $ENVF (APP_KEY generated — back it up: it encrypts stored secrets)"
  else
    ok "$ENVF exists — keeping it"
    grep -q '^APP_KEY=.\{32,\}' "$ENVF" || { setenv "$ENVF" APP_KEY "$(node "$ROOT/dist/panel.mjs" keygen)"; ok "generated missing APP_KEY"; }
    set -a; # shellcheck disable=SC1090
    . <(grep -E '^(DB_HOST|DB_PORT|DB_NAME|DB_USER|DB_PASSWORD)=' "$ENVF"); set +a
  fi

  info "Database"
  echo "  OGHOST needs a MySQL 8 / MariaDB 10.6+ database. If your host administrator manages MySQL, ask them to run:"
  cat <<SQL
      CREATE DATABASE \`$DB_NAME\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
      CREATE USER '$DB_USER'@'localhost' IDENTIFIED BY '<password from .env>';
      CREATE USER '$DB_USER'@'127.0.0.1' IDENTIFIED BY '<password from .env>';
      GRANT ALL PRIVILEGES ON \`$DB_NAME\`.* TO '$DB_USER'@'localhost', '$DB_USER'@'127.0.0.1';
SQL
  local MYSQL; MYSQL="$(command -v mariadb || command -v mysql || true)"
  if ! node "$ROOT/dist/panel.mjs" migrate >/tmp/oghost-migrate.$$ 2>&1; then
    warn "Could not connect/migrate with the credentials in .env: $(tail -n1 /tmp/oghost-migrate.$$)"
    if [ -n "$MYSQL" ] && yesno "Create the database and user now with a MySQL administrator account (used once, never stored)?" n; then
      local DBA_USER DBA_PASS; ask DBA_USER "MySQL administrator user" "root"; ask DBA_PASS "MySQL administrator password" "" secret
      MYSQL_PWD="$DBA_PASS" "$MYSQL" -h "$DB_HOST" -P "$DB_PORT" -u "$DBA_USER" <<SQL || die "creating the database failed"
CREATE DATABASE IF NOT EXISTS \`$DB_NAME\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS '$DB_USER'@'localhost' IDENTIFIED BY '$DB_PASSWORD';
CREATE USER IF NOT EXISTS '$DB_USER'@'127.0.0.1' IDENTIFIED BY '$DB_PASSWORD';
CREATE USER IF NOT EXISTS '$DB_USER'@'%' IDENTIFIED BY '$DB_PASSWORD';
GRANT ALL PRIVILEGES ON \`$DB_NAME\`.* TO '$DB_USER'@'localhost', '$DB_USER'@'127.0.0.1', '$DB_USER'@'%';
FLUSH PRIVILEGES;
SQL
      ok "database and user created"; unset DBA_PASS
      node "$ROOT/dist/panel.mjs" migrate || die "migration failed"
    else rm -f /tmp/oghost-migrate.$$; die "Create the database (SQL above), then re-run this installer."; fi
  fi
  rm -f /tmp/oghost-migrate.$$; ok "database migrated"
  node "$ROOT/dist/panel.mjs" seed >/dev/null && ok "default roles, eggs and settings seeded"

  info "Super Admin account"
  if [ -n "${ADMIN_EMAIL:-}" ] || yesno "Create (or reset) a Super Admin account now?" y; then
    ask ADMIN_EMAIL "Admin email" ""; ask ADMIN_USERNAME "Admin username" "admin"
    ask ADMIN_PASSWORD "Admin password (min 10 chars, letters + digits)" "" secret
    ADMIN_EMAIL="$ADMIN_EMAIL" ADMIN_USERNAME="$ADMIN_USERNAME" ADMIN_PASSWORD="$ADMIN_PASSWORD" node "$ROOT/dist/panel.mjs" create-admin
  fi
  mkdir -p "$ROOT/logs"
  install_service panel
  local URL; URL="$(sed -n 's/^APP_URL=//p' "$ENVF")"
  echo
  ok "${B}Panel installed.${N} Open $URL"
  echo "      Next: Admin → Nodes → Create node, then run 'bash installer/install.sh --agent' on each node machine."
  echo "      For HTTPS put nginx/Caddy in front (see documentation/DEPLOYMENT.md). Ports < 1024 need an administrator."
}

# ================================================================ AGENT
install_java() { # install_java MAJOR  -> ~/java/jdk-MAJOR (Eclipse Temurin, no root)
  local m="$1" dest="$HOME/java" url tmp
  mkdir -p "$dest"; url="https://api.adoptium.net/v3/binary/latest/$m/ga/linux/$ARCH/jre/hotspot/normal/eclipse"
  tmp="$(mktemp -d)"; info "Downloading Temurin Java $m for $ARCH"
  if command -v curl >/dev/null; then curl -fL --retry 3 -o "$tmp/j.tgz" "$url"; else wget -O "$tmp/j.tgz" "$url"; fi || { warn "download of Java $m failed"; rm -rf "$tmp"; return 1; }
  rm -rf "$dest/jdk-$m"; mkdir -p "$dest/jdk-$m"; tar -xzf "$tmp/j.tgz" -C "$dest/jdk-$m" --strip-components=1; rm -rf "$tmp"
  "$dest/jdk-$m/bin/java" -version >/dev/null 2>&1 && ok "Java $m installed at $dest/jdk-$m" || warn "Java $m extracted but does not run on this machine"
}
install_cpulimit() { # builds cpulimit from source into ~/bin (no root)
  command -v gcc >/dev/null && command -v make >/dev/null || { warn "gcc/make not available — cannot build cpulimit. CPU limits will be reported as inactive."; return 1; }
  local tmp; tmp="$(mktemp -d)"; info "Building cpulimit into ~/bin"
  ( cd "$tmp" && curl -fsSL https://github.com/opsengine/cpulimit/archive/refs/heads/master.tar.gz | tar -xz && cd cpulimit-master && sed -i 's/#include <sys\/sysctl.h>//' src/cpulimit.c && make -s >/dev/null 2>&1 ) \
    && mkdir -p "$HOME/bin" && cp "$tmp/cpulimit-master/src/cpulimit" "$HOME/bin/cpulimit" && chmod 755 "$HOME/bin/cpulimit" && ok "cpulimit installed at ~/bin/cpulimit" \
    || warn "cpulimit build failed — CPU limits will be reported as inactive."
  rm -rf "$tmp"
}

install_agent() {
  build
  local AD="$HOME/oghost-agent" ENVF="$HOME/oghost-agent/agent.env"
  mkdir -p "$AD/logs" "$AD/tls"; chmod 700 "$AD"
  info "Agent configuration ($ENVF)"
  if [ ! -f "$ENVF" ]; then
    if [ -z "${NODE_ID:-}" ] && [ -t 0 ] && [ "$YES" != 1 ] && yesno "Paste the agent config shown in Admin → Nodes → (node) → Show agent config?" y; then
      echo "  Paste it now, then press Ctrl-D on an empty line:"; umask 077; cat >"$ENVF"
    else
      ask NODE_ID "Node ID (from the panel)" ""; ask NODE_SECRET "Node secret (from the panel)" "" secret
      ask PANEL_URL "Panel URL" "http://127.0.0.1:8080"; ask AGENT_PORT "Agent port" "8443"
      umask 077; cat >"$ENVF" <<ENV
# OGHOST node agent configuration. Keep this file private (chmod 600).
NODE_ID=$NODE_ID
NODE_SECRET=$NODE_SECRET
PANEL_URL=$PANEL_URL
AGENT_HOST=0.0.0.0
AGENT_PORT=$AGENT_PORT
DATA_ROOT=~/oghost-agent/.server
CPULIMIT_PATH=~/bin/cpulimit
JAVA_SEARCH_PATHS=~/java
DISK_EXCEEDED_ACTION=warn
ENV
    fi
    chmod 600 "$ENVF"; ok "wrote $ENVF"
  else ok "$ENVF exists — keeping it"; fi
  grep -q '^NODE_ID=[0-9]' "$ENVF" && grep -q '^NODE_SECRET=.' "$ENVF" && grep -q '^PANEL_URL=.' "$ENVF" || die "$ENVF must contain NODE_ID, NODE_SECRET and PANEL_URL"

  # TLS for the agent API
  if grep -q '^AGENT_TLS_CERT=' "$ENVF"; then
    local CERT KEY; CERT="$(sed -n 's/^AGENT_TLS_CERT=//p' "$ENVF" | sed "s|^~|$HOME|")"; KEY="$(sed -n 's/^AGENT_TLS_KEY=//p' "$ENVF" | sed "s|^~|$HOME|")"
    if [ ! -f "$CERT" ] && command -v openssl >/dev/null && yesno "No TLS certificate at $CERT. Generate a self-signed one (the panel must then trust it via NODE_CA_FILE)?" y; then
      local FQDN; FQDN="$(hostname -f 2>/dev/null || hostname)"; ask TLS_NAME "Hostname or IP the panel uses to reach this node" "$FQDN"
      local SAN="DNS:$TLS_NAME"; [[ "$TLS_NAME" =~ ^[0-9.]+$ ]] && SAN="IP:$TLS_NAME"
      mkdir -p "$(dirname "$CERT")"
      openssl req -x509 -newkey rsa:2048 -nodes -days 825 -subj "/CN=$TLS_NAME" -addext "subjectAltName=$SAN" -keyout "$KEY" -out "$CERT" >/dev/null 2>&1
      chmod 600 "$KEY"; ok "self-signed certificate created: $CERT"
      echo "      Copy $CERT to the panel server and set NODE_CA_FILE=/path/to/that.pem in the panel .env, then restart the panel."
    fi
  else warn "This node uses plain http. Use it only on a private network/tunnel, or switch the node to https in the panel."; fi

  info "Java runtimes"
  local found; found="$( (ls -d /usr/lib/jvm/*/bin/java "$HOME"/java/*/bin/java 2>/dev/null; command -v java) | sort -u | tr '\n' ' ')"
  [ -n "$found" ] && ok "found: $found" || warn "no Java found"
  echo "      Minecraft needs Java 8 (≤1.16), 17 (1.17–1.20.4), 21 (1.20.5–1.21.x) or 25 (26.x). Java can be installed per user in ~/java."
  for m in 17 21 25; do
    [ -x "$HOME/java/jdk-$m/bin/java" ] && continue
    ls -d /usr/lib/jvm/*-"$m"-*/bin/java /usr/lib/jvm/*"$m"*/bin/java >/dev/null 2>&1 && continue
    yesno "Download Eclipse Temurin Java $m into ~/java (no root needed)?" "$( [ $m = 21 ] && echo y || echo n)" && install_java "$m" || true
  done
  grep -q '^JAVA_SEARCH_PATHS=' "$ENVF" || setenv "$ENVF" JAVA_SEARCH_PATHS "~/java"

  info "CPU limiting (cpulimit)"
  if [ -x "$HOME/bin/cpulimit" ] || command -v cpulimit >/dev/null; then ok "cpulimit available (best-effort throttling, not hard kernel isolation)"
  elif yesno "cpulimit not found. Build it from source into ~/bin (needs gcc + make, no root)?" y; then install_cpulimit || true
  else warn "without cpulimit the panel shows CPU limits as not enforced"; fi

  info "Storage and isolation (please read)"
  echo "      • Disk limits are enforced by the agent at application level (checked on every write and by periodic scans)."
  echo "        This is NOT a kernel filesystem quota. For hard quotas a host administrator can provide QUOTA_HOOK (see documentation/SECURITY.md)."
  echo "      • In non-root mode every game server runs as your Unix user ($(id -un)). Servers are separated by the panel's"
  echo "        path checks, not by the kernel. For hard isolation use one node per customer or a host with per-server users."
  local PORT; PORT="$(sed -n 's/^AGENT_PORT=//p' "$ENVF")"
  echo "      • Open TCP $PORT (agent API, panel → node only) and your game ports in the firewall. That requires an administrator."
  install_service agent
  echo; ok "${B}Agent installed.${N} The node turns ONLINE in the panel within ~15 s."
}

if [ "$MODE" = panel ]; then install_panel; else install_agent; fi
