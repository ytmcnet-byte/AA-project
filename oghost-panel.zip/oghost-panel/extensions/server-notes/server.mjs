// Example OGHOST extension (plain ESM, no build step). See documentation/EXTENSIONS.md.
export default {
  async register(ctx) {
    const canAccess = async (req, serverId) => {
      const list = await ctx.servers.listForUser(req.user.id);
      return list.some(s => s.id === serverId);
    };
    ctx.router.get('/notes/:serverId', async (req, res) => {
      const id = Number(req.params.serverId);
      if (!(await canAccess(req, id))) return res.status(404).json({ error: 'Server not found' });
      res.json({ note: (await ctx.storage.get(`note:${id}`)) || { text: '', updatedAt: null } });
    });
    ctx.router.put('/notes/:serverId', async (req, res) => {
      const id = Number(req.params.serverId);
      if (!(await canAccess(req, id))) return res.status(404).json({ error: 'Server not found' });
      const max = Number(await ctx.settings.get('maxLength')) || 5000;
      const text = String(req.body?.text ?? '');
      if (text.length > max) return res.status(422).json({ error: `Note is longer than ${max} characters` });
      const note = { text, updatedAt: new Date().toISOString(), by: req.user.username };
      await ctx.storage.set(`note:${id}`, note);
      res.json({ note });
    });
    ctx.adminRouter.get('/stats', async (_req, res) => res.json({ notes: (await ctx.storage.list('note:')).length }));
    ctx.events.on('server.deleted', async (d) => { await ctx.storage.delete(`note:${d.serverId}`); ctx.log('removed note of deleted server', d.serverId); });
    ctx.log('registered');
  },
};
