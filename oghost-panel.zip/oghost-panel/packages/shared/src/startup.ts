import type { EggDefinition } from './types';

export class StartupError extends Error { status = 422; }

/** Validate heap settings against the server memory allocation. Returns warnings (non-fatal). */
export function validateHeap(memoryMb: number, xmsMb: number, xmxMb: number): string[] {
  if (!Number.isInteger(xmsMb) || !Number.isInteger(xmxMb) || xmsMb < 64 || xmxMb < 128) throw new StartupError('Xms must be >= 64 MB and Xmx >= 128 MB');
  if (xmsMb > xmxMb) throw new StartupError('Xms cannot be larger than Xmx');
  if (xmxMb > memoryMb) throw new StartupError(`Xmx (${xmxMb} MB) exceeds the server RAM allocation (${memoryMb} MB)`);
  const w: string[] = [];
  if (xmxMb > memoryMb * 0.9 && memoryMb > 1024) w.push('Xmx is above 90% of allocated RAM; the JVM needs off-heap memory (metaspace, threads, native buffers). Recommended: leave 10-15% headroom.');
  if (xmxMb < 1024) w.push('Less than 1 GB heap is usually too small for modern Minecraft servers.');
  return w;
}

export function recommendedHeap(memoryMb: number) {
  const xmx = Math.max(128, Math.floor(memoryMb * (memoryMb > 2048 ? 0.88 : 0.85)));
  return { xmsMb: Math.min(xmx, Math.max(128, Math.floor(xmx / 4))), xmxMb: xmx };
}

/** Validate user-supplied variable values against egg rules. */
export function validateVariables(egg: EggDefinition, values: Record<string, string>, allowLocked = false) {
  const out: Record<string, string> = {};
  for (const v of egg.variables) {
    let val = values[v.key] ?? v.default;
    if (!v.userEditable && !allowLocked) val = values[v.key] ?? v.default;
    if (v.rules && !new RegExp(v.rules).test(val)) throw new StartupError(`Variable ${v.key} has an invalid value`);
    out[v.key] = val;
  }
  return out;
}

/**
 * Render a startup template into an argv array. NO shell is ever involved, so customers
 * cannot inject `;`, `&&`, `$(...)` etc. Shell metacharacters in the template are rejected.
 */
export function renderStartup(template: string, ctx: Record<string, string | number>): string[] {
  if (/[;&|`$<>\\]|\$\(/.test(template)) throw new StartupError('Startup command may not contain shell operators');
  const filled = template.replace(/\{\{([A-Z0-9_]+)\}\}/g, (_, k) => {
    if (!(k in ctx)) throw new StartupError(`Unknown startup token {{${k}}}`);
    return String(ctx[k]);
  });
  const argv = filled.split(/\s+/).filter(Boolean);
  if (!argv.length) throw new StartupError('Empty startup command');
  for (const a of argv) if (/[;&|`$<>]/.test(a)) throw new StartupError('Startup variables may not contain shell operators');
  return argv;
}

export function javaCompatibility(egg: EggDefinition, javaMajor: number | null, mcVersion?: string): string[] {
  const w: string[] = [];
  if (egg.runtime !== 'java') return w;
  if (javaMajor == null) { w.push('No Java executable selected or detected on this node.'); return w; }
  if (egg.javaMin && javaMajor < egg.javaMin) w.push(`${egg.name} requires Java ${egg.javaMin}+ (selected Java ${javaMajor}).`);
  const req = requiredJavaFor(mcVersion);
  if (req && javaMajor < req) w.push(`Minecraft ${mcVersion} requires Java ${req}+ (selected Java ${javaMajor}).`);
  if (mcVersion && /^1\.(\d+)/.test(mcVersion) && Number(mcVersion.split('.')[1]) <= 16 && javaMajor > 11) w.push(`Minecraft ${mcVersion} is often unstable on Java ${javaMajor}; Java 8 or 11 is recommended.`);
  return w;
}

/** Best-effort Java requirement by Minecraft version. Year-based versions (26.x+) need Java 25. */
export function requiredJavaFor(mc?: string): number | null {
  if (!mc || mc === 'latest') return null;
  const m = mc.match(/^(\d+)\.(\d+)(?:\.(\d+))?/); if (!m) return null;
  const major = +m[1], minor = +m[2], patch = +(m[3] || 0);
  if (major >= 26) return 25;
  if (major !== 1) return null;
  if (minor >= 21 || (minor === 20 && patch >= 5)) return 21;
  if (minor >= 18) return 17;
  if (minor === 17) return 16;
  return 8;
}

/**
 * Pick the most suitable Java for a server from the installs detected on a node.
 * Prefers the lowest installed major that satisfies both the egg and the Minecraft version
 * (e.g. 1.8 -> Java 8, 1.18 -> 17, 1.21 -> 21, 26.x -> 25). Old versions (<= 1.16) cap at Java 11 when possible.
 */
export function pickJava<T extends { major: number }>(installs: T[], opts: { eggMin?: number; mcVersion?: string | null }): T | null {
  const req = Math.max(opts.eggMin || 8, requiredJavaFor(opts.mcVersion || undefined) || 0);
  const ok = installs.filter(j => j.major >= req).sort((a, b) => a.major - b.major);
  if (!ok.length) return null;
  const legacy = opts.mcVersion && /^1\.(\d+)/.test(opts.mcVersion) && Number(opts.mcVersion.split('.')[1]) <= 16;
  if (legacy) return ok.find(j => j.major <= 11) || ok[0];
  // Unknown/"latest" version: newest Java is the safest default for current releases.
  if (!requiredJavaFor(opts.mcVersion || undefined)) return ok[ok.length - 1];
  return ok[0];
}
