import {
  createServerContainer,
  startContainer,
  stopContainer,
  restartContainer,
  deleteContainer,
  getContainerStatus,
  getContainerStats,
  getContainerLogs,
  attachContainerSocket,
  sendContainerCommand
} from "./docker.js";

import { isRemoteUserSpaceNode, userSpaceRequest } from "./userSpaceNodes.js";

import {
  createLocalServer,
  startLocalServer,
  stopLocalServer,
  restartLocalServer,
  deleteLocalServer,
  getLocalServerStatus,
  getLocalServerStats,
  getLocalServerLogs,
  attachLocalServerSocket,
  sendLocalServerCommand
} from "./local.js";

export const createServerRuntime = async (serverData: any, nodeId?: string) => {
  if (serverData.runtimeType === "local") {
    const targetNode = nodeId || serverData.nodeId || "local";
    if (targetNode !== "local") {
      await userSpaceRequest(targetNode, "POST", "/api/servers", serverData);
      return `user-space-${serverData.id}`;
    }
    return await createLocalServer(serverData);
  }
  return await createServerContainer(serverData, nodeId);
};

export const startServerRuntime = async (server: any) => {
  if (server.runtimeType === "local") {
    if (isRemoteUserSpaceNode(server)) return userSpaceRequest(server.nodeId, "POST", `/api/servers/${server.id}/power`, { action: "start" });
    return await startLocalServer(server.id, server);
  }
  return await startContainer(server.containerId, server.nodeId);
};

export const stopServerRuntime = async (server: any) => {
  if (server.runtimeType === "local") {
    if (isRemoteUserSpaceNode(server)) return userSpaceRequest(server.nodeId, "POST", `/api/servers/${server.id}/power`, { action: "stop" });
    return await stopLocalServer(server.id);
  }
  return await stopContainer(server.containerId, server.nodeId);
};

export const restartServerRuntime = async (server: any) => {
  if (server.runtimeType === "local") {
    if (isRemoteUserSpaceNode(server)) return userSpaceRequest(server.nodeId, "POST", `/api/servers/${server.id}/power`, { action: "restart" });
    return await restartLocalServer(server.id, server);
  }
  return await restartContainer(server.containerId, server.nodeId);
};

export const deleteServerRuntime = async (server: any) => {
  if (server.runtimeType === "local") {
    if (isRemoteUserSpaceNode(server)) return userSpaceRequest(server.nodeId, "DELETE", `/api/servers/${server.id}`);
    return await deleteLocalServer(server.id);
  }
  return await deleteContainer(server.containerId, server.nodeId);
};

export const getServerRuntimeStatus = async (server: any) => {
  if (server.runtimeType === "local") {
    if (isRemoteUserSpaceNode(server)) {
      const data = await userSpaceRequest(server.nodeId, "GET", `/api/servers/${server.id}`);
      return { State: { Running: !!data.running, Status: data.running ? "running" : "exited", StartedAt: null }, ...data };
    }
    return await getLocalServerStatus(server.id);
  }
  return await getContainerStatus(server.containerId, server.nodeId);
};

export const getServerRuntimeStats = async (server: any) => {
  if (server.runtimeType === "local") {
    if (isRemoteUserSpaceNode(server)) return { cpu_stats: { cpu_usage: { total_usage: 0 }, system_cpu_usage: 100 }, memory_stats: { usage: 0, limit: Number(server.ram || 1) * 1024 * 1024 * 1024 }, userSpace: true };
    return await getLocalServerStats(server.id);
  }
  return await getContainerStats(server.containerId, server.nodeId);
};

export const getServerRuntimeLogs = async (server: any) => {
  if (server.runtimeType === "local") {
    if (isRemoteUserSpaceNode(server)) { const d = await userSpaceRequest(server.nodeId, "GET", `/api/servers/${server.id}/logs`); return d.logs || ""; }
    return await getLocalServerLogs(server.id);
  }
  return await getContainerLogs(server.containerId, server.nodeId);
};

export const attachServerRuntimeSocket = async (server: any, serverId: string) => {
  if (server.runtimeType === "local") {
    if (isRemoteUserSpaceNode(server)) return;
    return attachLocalServerSocket(server.id, serverId);
  }
  return await attachContainerSocket(server.containerId, serverId, server.nodeId);
};

export const sendServerRuntimeCommand = async (server: any, command: string) => {
  if (server.runtimeType === "local") {
    if (isRemoteUserSpaceNode(server)) return userSpaceRequest(server.nodeId, "POST", `/api/servers/${server.id}/command`, { command });
    return await sendLocalServerCommand(server.id, command);
  }
  return await sendContainerCommand(server.containerId, command, server.nodeId);
};
