import fs from 'node:fs';
import path from 'node:path';
import yauzl from 'yauzl';

export interface InstalledPlugin { file: string; name: string; version: string; kind: 'bukkit' | 'paper' | 'velocity' | 'bungee' | 'fabric' | 'quilt' | 'forge' | 'unknown'; depends: string[]; softDepends: string[]; size: number; modified: string; }

function readEntries(file: string, names: string[]): Promise<Record<string, string>> {
  return new Promise((res) => yauzl.open(file, { lazyEntries: true, autoClose: true }, (err, z) => {
    const out: Record<string, string> = {}; if (err || !z) return res(out);
    z.on('entry', (e: yauzl.Entry) => {
      if (!names.includes(e.fileName) || e.uncompressedSize > 1024 * 1024) return z.readEntry();
      z.openReadStream(e, (er, s) => { if (er || !s) return z.readEntry(); const c: Buffer[] = []; s.on('data', d => c.push(d)); s.on('end', () => { out[e.fileName] = Buffer.concat(c).toString('utf8'); z.readEntry(); }); });
    });
    z.on('end', () => res(out)); z.on('error', () => res(out)); z.readEntry();
  }));
}
const yamlField = (y: string, k: string) => y.match(new RegExp(`^${k}:\\s*['"]?([^'"\\n#]+)`, 'm'))?.[1]?.trim() || '';
const yamlList = (y: string, k: string): string[] => {
  const inline = y.match(new RegExp(`^${k}:\\s*\\[([^\\]]*)\\]`, 'm')); if (inline) return inline[1].split(',').map(s => s.trim().replace(/['"]/g, '')).filter(Boolean);
  const block = y.match(new RegExp(`^${k}:\\s*\\n((?:\\s+-\\s*.+\\n?)+)`, 'm')); return block ? block[1].split('\n').map(l => l.replace(/^\s+-\s*/, '').trim().replace(/['"]/g, '')).filter(Boolean) : [];
};

export async function inspectPlugin(file: string): Promise<InstalledPlugin> {
  const st = fs.statSync(file);
  const e = await readEntries(file, ['plugin.yml', 'paper-plugin.yml', 'bungee.yml', 'velocity-plugin.json', 'fabric.mod.json', 'quilt.mod.json', 'META-INF/mods.toml', 'META-INF/neoforge.mods.toml']);
  const base = { file: path.basename(file), size: st.size, modified: st.mtime.toISOString() };
  if (e['paper-plugin.yml'] || e['plugin.yml']) { const y = e['paper-plugin.yml'] || e['plugin.yml']; return { ...base, kind: e['paper-plugin.yml'] ? 'paper' : 'bukkit', name: yamlField(y, 'name'), version: yamlField(y, 'version'), depends: yamlList(y, 'depend'), softDepends: yamlList(y, 'softdepend') }; }
  if (e['bungee.yml']) { const y = e['bungee.yml']; return { ...base, kind: 'bungee', name: yamlField(y, 'name'), version: yamlField(y, 'version'), depends: yamlList(y, 'depends'), softDepends: yamlList(y, 'softDepends') }; }
  if (e['velocity-plugin.json']) { const j = JSON.parse(e['velocity-plugin.json']); return { ...base, kind: 'velocity', name: j.name || j.id, version: j.version || '', depends: (j.dependencies || []).filter((d: any) => !d.optional).map((d: any) => d.id), softDepends: (j.dependencies || []).filter((d: any) => d.optional).map((d: any) => d.id) }; }
  if (e['fabric.mod.json'] || e['quilt.mod.json']) { try { const j = JSON.parse(e['fabric.mod.json'] || e['quilt.mod.json']); const q = j.quilt_loader; return { ...base, kind: q ? 'quilt' : 'fabric', name: q?.metadata?.name || j.name || j.id || q?.id, version: q?.version || j.version || '', depends: Object.keys(j.depends || {}).filter(d => !['minecraft', 'java', 'fabricloader'].includes(d)), softDepends: Object.keys(j.recommends || j.suggests || {}) }; } catch { /* */ } }
  const toml = e['META-INF/mods.toml'] || e['META-INF/neoforge.mods.toml']; if (toml) return { ...base, kind: 'forge', name: toml.match(/displayName\s*=\s*"([^"]+)"/)?.[1] || toml.match(/modId\s*=\s*"([^"]+)"/)?.[1] || base.file, version: toml.match(/^version\s*=\s*"([^"]+)"/m)?.[1] || '', depends: [], softDepends: [] };
  return { ...base, kind: 'unknown', name: base.file.replace(/\.jar$/, ''), version: '', depends: [], softDepends: [] };
}

export async function listPlugins(dir: string) {
  const out: InstalledPlugin[] = [];
  for (const sub of ['plugins', 'mods']) { const d = path.join(dir, sub); if (!fs.existsSync(d)) continue; for (const f of fs.readdirSync(d)) if (/\.jar$/i.test(f)) out.push({ ...(await inspectPlugin(path.join(d, f))), file: `${sub}/${f}` }); }
  const names = new Set(out.map(p => p.name.toLowerCase()));
  return out.map(p => ({ ...p, missingDependencies: p.depends.filter(d => !names.has(d.toLowerCase())) }));
}
