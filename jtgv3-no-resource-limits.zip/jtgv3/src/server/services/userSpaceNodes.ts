import axios from "axios";
import { readJSON } from "./db.js";

async function getNode(nodeId: string) {
  const nodes = await readJSON("nodes.json") || [];
  const node = nodes.find((n: any) => n.id === nodeId);
  if (!node) throw new Error(`User-space node ${nodeId} not found. Add it in Nodes first.`);
  return node;
}

export async function userSpaceRequest(nodeId: string, method: string, route: string, data?: any) {
  const node = await getNode(nodeId);
  const baseURL = String(node.apiUrl || `${node.ssl ? "https" : "http"}://${node.hostname || node.ip}:${node.apiPort || 8787}`).replace(/\/$/, "");
  if (!node.token) throw new Error(`Node ${node.name || nodeId} has no agent token configured.`);
  const response = await axios.request({
    method, url: `${baseURL}${route}`, data, timeout: 20000,
    headers: { Authorization: `Bearer ${node.token}`, "Content-Type": "application/json" }
  });
  return response.data;
}

export const isRemoteUserSpaceNode = (server: any) => !!server?.nodeId && server.nodeId !== "local" && server.runtimeType === "local";
