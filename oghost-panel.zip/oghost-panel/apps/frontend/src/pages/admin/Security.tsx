import { useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { Plus, ShieldCheck, Trash2 } from 'lucide-react';
import { useApi, useAction, toast } from '../../lib/hooks';
import { api } from '../../lib/api';
import { bytes, date } from '../../lib/format';
import { Badge, Card, Confirm, Empty, ErrorBox, Field, Loading, Modal, Notice, PageHeader, Pager, Spinner, Stat, Switch, Table, Tabs } from '../../components/ui';

type Tab = 'overview' | 'reviews' | 'scans' | 'incidents' | 'appeals' | 'trusted';
const sev = (s: string) => (s === 'high' ? 'high_risk' : s === 'medium' ? 'suspicious' : 'info');

export function SecurityCenter() {
  const [sp, setSp] = useSearchParams(); const tab = (sp.get('tab') as Tab) || 'overview'; const server = sp.get('server') || '';
  const { data, error, loading, reload } = useApi<any>('/api/admin/security/overview', [], 15000);
  const setTab = (t: Tab) => { const n = new URLSearchParams(sp); n.set('tab', t); setSp(n, { replace: true }); };
  return <><PageHeader title="OGHOST Security Center" subtitle="Static JAR analysis (files are never executed), process watchdog incidents, suspensions and appeals. Only the affected server is ever suspended; customer files are never deleted automatically." />
    {server && <Notice className="mb-4">Filtered to server #{server}. <button className="underline" onClick={() => { const n = new URLSearchParams(sp); n.delete('server'); setSp(n); }}>Clear filter</button></Notice>}
    <Tabs value={tab} onChange={setTab} tabs={[{ id: 'overview', label: 'Overview' }, { id: 'reviews', label: `Pending reviews${data?.pendingReviews ? ` (${data.pendingReviews})` : ''}` }, { id: 'scans', label: 'Scans' }, { id: 'incidents', label: `Incidents${data?.openIncidents ? ` (${data.openIncidents})` : ''}` }, { id: 'appeals', label: `Appeals${data?.openAppeals ? ` (${data.openAppeals})` : ''}` }, { id: 'trusted', label: 'Trusted software' }]} />
    {tab === 'overview' && (loading ? <Loading /> : error ? <ErrorBox error={error} onRetry={reload} /> : <Overview d={data} reload={reload} />)}
    {tab === 'reviews' && <Scans review server={server} onChange={reload} />}
    {tab === 'scans' && <Scans server={server} onChange={reload} />}
    {tab === 'incidents' && <Incidents server={server} onChange={reload} />}
    {tab === 'appeals' && <Appeals onChange={reload} />}
    {tab === 'trusted' && <Trusted />}
  </>;
}

function Overview({ d, reload }: { d: any; reload: () => void }) {
  const { busy, run } = useAction(); const [ext, setExt] = useState<any>(null); const [hours, setHours] = useState('48');
  const lv = (l: string) => d.byLevel.find((x: any) => x.level === l)?.c || 0;
  return <div className="grid gap-6">
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
      <Stat label="Open incidents" value={d.openIncidents} sub={`${d.highOpen} high severity`} />
      <Stat label="Pending reviews" value={d.pendingReviews} sub="Suspicious files awaiting a decision" />
      <Stat label="Blocked / suspended" value={`${d.blockedServers} / ${d.securitySuspended}`} sub="servers" />
      <Stat label="Scans (24 h)" value={d.scans24h} sub={`30 days: ${lv('safe')} safe · ${lv('suspicious')} suspicious · ${lv('high_risk')} high risk · ${d.trusted} trusted hashes`} />
    </div>
    <Card title="Restricted servers">{!d.suspended.length ? <Empty title="No restricted servers" icon={<ShieldCheck className="h-8 w-8" />} /> :
      <Table><thead><tr><th>Server</th><th>Owner</th><th>Level</th><th>Reason</th><th>Until</th><th /></tr></thead><tbody>{d.suspended.map((s: any) => <tr key={s.id}>
        <td><Link className="link" to={`/admin/servers/${s.id}`}>{s.name}</Link><div className="font-mono text-xs text-ink-400">{s.node_id}/{s.node_server_id}</div></td><td className="text-xs">{s.email}</td><td><Badge value={s.security_level} /></td>
        <td className="max-w-xs text-xs">{s.suspension_reason || (s.security_blocked ? 'Start blocked pending review' : '')}</td><td className="text-xs">{s.suspended_at ? (s.suspended_until ? date(s.suspended_until) : 'until released') : '—'}</td>
        <td className="whitespace-nowrap text-right">{s.suspended_at && <button className="btn-ghost btn-sm" onClick={() => setExt(s)}>Extend</button>}<button className="btn-ghost btn-sm" onClick={() => run('rs' + s.id, async () => { const r = await api('POST', `/api/admin/security/servers/${s.id}/rescan`); toast(`Rescanned ${r.results?.length ?? 0} file(s)`, 'info'); reload(); })}>{busy === 'rs' + s.id && <Spinner />}Rescan</button><button className="btn-primary btn-sm" onClick={() => run('rl', () => api('POST', `/api/admin/security/servers/${s.id}/release`, {}).then(reload), 'Released')}>Release</button></td></tr>)}</tbody></Table>}</Card>
    <Card title="Incidents by category (30 days)">{!d.byCategory.length ? <Empty title="No incidents" /> : <div className="flex flex-wrap gap-2">{d.byCategory.map((c: any) => <Badge key={c.category + c.severity} value={sev(c.severity)} label={`${c.category} (${c.severity}): ${c.c}`} />)}</div>}</Card>
    <Modal open={!!ext} onClose={() => setExt(null)} title="Extend suspension" footer={<><button className="btn-secondary" onClick={() => setExt(null)}>Cancel</button><button className="btn-primary" onClick={() => run('ex', () => api('POST', `/api/admin/security/servers/${ext.id}/extend`, { hours: hours ? Number(hours) : null }).then(() => { setExt(null); reload(); }), 'Extended')}>Extend</button></>}>
      <Field label="Additional hours" hint="Empty = indefinitely, until released"><input className="input" type="number" value={hours} onChange={e => setHours(e.target.value)} /></Field></Modal>
  </div>;
}

function Findings({ f }: { f: any[] }) {
  if (!f?.length) return <span className="text-xs text-ink-500">No findings</span>;
  return <ul className="space-y-1 text-xs">{f.slice(0, 30).map((x, i) => <li key={i}><Badge value={sev(x.severity)} label={x.severity} /> <span className="font-mono">{x.rule}</span> in <span className="font-mono">{x.entry}</span>{x.detail ? ` — ${x.detail}` : ''}</li>)}{f.length > 30 && <li className="text-ink-400">…and {f.length - 30} more</li>}</ul>;
}

function Scans({ review, server, onChange }: { review?: boolean; server: string; onChange: () => void }) {
  const [page, setPage] = useState(1); const [level, setLevel] = useState('');
  const qs = new URLSearchParams({ page: String(page), per_page: '25', ...(review ? { review: 'pending' } : {}), ...(level ? { level } : {}), ...(server ? { server } : {}) }).toString();
  const { data, error, loading, reload } = useApi<any>(`/api/admin/security/scans?${qs}`); const { busy, run } = useAction();
  const [open, setOpen] = useState<any>(null); const [rej, setRej] = useState<any>(null); const [reason, setReason] = useState(''); const [appr, setAppr] = useState<any>(null); const [note, setNote] = useState('');
  const done = () => { reload(); onChange(); };
  return <Card title={review ? 'Files awaiting review' : 'Scan history'} actions={!review && <select className="input w-40" value={level} onChange={e => { setLevel(e.target.value); setPage(1); }}><option value="">All levels</option><option value="safe">Safe</option><option value="suspicious">Suspicious</option><option value="high_risk">High risk</option></select>}>
    {review && <Notice className="mb-3">Approving adds the file's SHA-256 to trusted software on every node. Rejecting keeps the server blocked until the owner removes the file; files are never deleted for them.</Notice>}
    {loading ? <Loading /> : error ? <ErrorBox error={error} onRetry={reload} /> : !data.scans.length ? <Empty title={review ? 'Nothing to review' : 'No scans'} /> :
      <Table><thead><tr><th>When</th><th>Server</th><th>File</th><th>Level</th><th>Detected software</th><th>Reason</th><th /></tr></thead><tbody>{data.scans.map((s: any) => <tr key={s.id}>
        <td className="whitespace-nowrap text-xs">{date(s.created_at)}<div className="text-ink-500">{s.phase} · {s.mode}</div></td><td><Link className="link" to={`/admin/servers/${s.server_id}`}>{s.server_name}</Link><div className="font-mono text-xs text-ink-500">{s.node_id}/{s.node_server_id}</div></td>
        <td className="font-mono text-xs">{s.file}<div className="text-ink-500">{bytes(s.size_bytes)} · {s.sha256.slice(0, 12)}…</div></td><td><Badge value={s.level} />{s.review_status !== 'none' && <div className="mt-1 text-xs text-ink-400">{s.review_status}</div>}</td>
        <td className="text-xs">{s.minecraft?.detected ? s.minecraft.software.join(', ') || 'Minecraft' : 'not recognised'}</td><td className="max-w-xs text-xs">{s.reason}</td>
        <td className="whitespace-nowrap text-right"><button className="btn-ghost btn-sm" onClick={() => setOpen(s)}>Findings</button>{s.review_status === 'pending' && <><button className="btn-primary btn-sm" onClick={() => { setAppr(s); setNote(''); }}>Approve</button><button className="btn-danger btn-sm ml-1" onClick={() => { setRej(s); setReason(''); }}>Reject</button></>}</td></tr>)}</tbody></Table>}
    <Pager page={page} setPage={setPage} hasMore={(data?.scans?.length || 0) >= 25} />
    <Modal open={!!open} onClose={() => setOpen(null)} wide title={open?.file}><div className="mb-3 font-mono text-xs text-ink-400">SHA-256 {open?.sha256}</div><Findings f={open?.findings} /></Modal>
    <Modal open={!!appr} onClose={() => setAppr(null)} title="Approve and trust file" footer={<><button className="btn-secondary" onClick={() => setAppr(null)}>Cancel</button><button className="btn-primary" disabled={!!busy} onClick={() => run('a', async () => { const r = await api('POST', `/api/admin/security/scans/${appr.id}/approve`, { note: note || undefined }); setAppr(null); done(); toast(r.unblocked?.length ? `Approved; ${r.unblocked.length} server(s) unblocked` : 'Approved', 'success'); })}>Approve</button></>}>
      <p className="mb-3 text-sm">Trust <span className="font-mono">{appr?.file}</span> (hash {appr?.sha256?.slice(0, 16)}…) on all nodes?</p><Field label="Note"><input className="input" value={note} onChange={e => setNote(e.target.value)} /></Field></Modal>
    <Modal open={!!rej} onClose={() => setRej(null)} title="Reject file" footer={<><button className="btn-secondary" onClick={() => setRej(null)}>Cancel</button><button className="btn-danger" disabled={!reason || !!busy} onClick={() => run('r', () => api('POST', `/api/admin/security/scans/${rej.id}/reject`, { reason }).then(() => { setRej(null); done(); }), 'Rejected')}>Reject</button></>}>
      <Field label="Reason (sent to the owner)"><textarea className="input" value={reason} onChange={e => setReason(e.target.value)} /></Field></Modal>
  </Card>;
}

function Incidents({ server, onChange }: { server: string; onChange: () => void }) {
  const [page, setPage] = useState(1); const [status, setStatus] = useState('open');
  const qs = new URLSearchParams({ page: String(page), per_page: '25', ...(status ? { status } : {}), ...(server ? { server } : {}) }).toString();
  const { data, error, loading, reload } = useApi<any>(`/api/admin/security/incidents?${qs}`); const { run } = useAction();
  const [open, setOpen] = useState<any>(null); const [note, setNote] = useState('');
  const resolve = (st: string) => run('r', () => api('POST', `/api/admin/security/incidents/${open.id}/resolve`, { status: st, note: note || undefined }).then(() => { setOpen(null); reload(); onChange(); }), `Incident ${st}`);
  return <Card title="Incidents" actions={<select className="input w-36" value={status} onChange={e => { setStatus(e.target.value); setPage(1); }}><option value="">All</option><option value="open">Open</option><option value="resolved">Resolved</option><option value="dismissed">Dismissed</option></select>}>
    {loading ? <Loading /> : error ? <ErrorBox error={error} onRetry={reload} /> : !data.incidents.length ? <Empty title="No incidents" /> :
      <Table><thead><tr><th>When</th><th>Server</th><th>Severity</th><th>Category / rule</th><th>Action taken</th><th>Status</th><th /></tr></thead><tbody>{data.incidents.map((i: any) => <tr key={i.id}>
        <td className="whitespace-nowrap text-xs">{date(i.created_at)}</td><td>{i.server_id ? <Link className="link" to={`/admin/servers/${i.server_id}`}>{i.server_name || `#${i.server_id}`}</Link> : `node ${i.node_id}`}</td><td><Badge value={sev(i.severity)} label={i.severity} /></td>
        <td className="text-xs">{i.category}<div className="font-mono text-ink-400">{i.rule}</div></td><td className="max-w-xs text-xs">{i.action_taken}</td><td>{i.status}</td><td><button className="btn-ghost btn-sm" onClick={() => { setOpen(i); setNote(i.review_note || ''); }}>Review</button></td></tr>)}</tbody></Table>}
    <Pager page={page} setPage={setPage} hasMore={(data?.incidents?.length || 0) >= 25} />
    <Modal open={!!open} onClose={() => setOpen(null)} wide title={`Incident #${open?.id} — ${open?.rule}`} footer={open?.status === 'open' && <><button className="btn-secondary" onClick={() => resolve('dismissed')}>Dismiss (false positive)</button><button className="btn-primary" onClick={() => resolve('resolved')}>Mark resolved</button></>}>
      <div className="mb-2 text-sm">Action taken: {open?.action_taken || 'none'}</div>
      <h4 className="mb-1 text-sm font-semibold">Evidence (preserved)</h4><pre className="max-h-80 overflow-auto whitespace-pre-wrap rounded-lg bg-ink-950 p-3 text-xs">{JSON.stringify(open?.evidence, null, 2)}</pre>
      {open?.status === 'open' && <Field label="Review note" className="mt-3"><textarea className="input" value={note} onChange={e => setNote(e.target.value)} /></Field>}
      {open?.status !== 'open' && open?.review_note && <p className="mt-3 text-sm text-ink-300">Note: {open.review_note}</p>}
    </Modal>
  </Card>;
}

function Appeals({ onChange }: { onChange: () => void }) {
  const [status, setStatus] = useState('open'); const { data, error, loading, reload } = useApi<any>(`/api/admin/security/appeals${status ? `?status=${status}` : ''}`); const { busy, run } = useAction();
  const [open, setOpen] = useState<any>(null); const [resp, setResp] = useState(''); const [release, setRelease] = useState(true);
  const respond = (st: string) => run('r', () => api('POST', `/api/admin/security/appeals/${open.id}/respond`, { status: st, response: resp, release: st === 'accepted' && release }).then(() => { setOpen(null); reload(); onChange(); }), `Appeal ${st}`);
  return <Card title="Appeals" actions={<select className="input w-36" value={status} onChange={e => setStatus(e.target.value)}><option value="">All</option><option value="open">Open</option><option value="accepted">Accepted</option><option value="rejected">Rejected</option></select>}>
    {loading ? <Loading /> : error ? <ErrorBox error={error} onRetry={reload} /> : !data.appeals.length ? <Empty title="No appeals" /> :
      <Table><thead><tr><th>When</th><th>Server</th><th>Owner</th><th>Message</th><th>Status</th><th /></tr></thead><tbody>{data.appeals.map((a: any) => <tr key={a.id}><td className="text-xs">{date(a.created_at)}</td><td><Link className="link" to={`/admin/servers/${a.server_id}`}>{a.server_name}</Link></td><td className="text-xs">{a.email}</td><td className="max-w-md text-xs">{a.message}</td><td>{a.status}</td><td>{a.status === 'open' && <button className="btn-ghost btn-sm" onClick={() => { setOpen(a); setResp(''); }}>Respond</button>}</td></tr>)}</tbody></Table>}
    <Modal open={!!open} onClose={() => setOpen(null)} title="Respond to appeal" footer={<><button className="btn-danger" disabled={!resp || !!busy} onClick={() => respond('rejected')}>Reject</button><button className="btn-primary" disabled={!resp || !!busy} onClick={() => respond('accepted')}>Accept</button></>}>
      <p className="mb-3 whitespace-pre-wrap rounded-lg bg-ink-950 p-3 text-sm">{open?.message}</p><Field label="Response to the customer"><textarea className="input" value={resp} onChange={e => setResp(e.target.value)} /></Field><div className="mt-3"><Switch checked={release} onChange={setRelease} label="When accepting, release the server" /></div></Modal>
  </Card>;
}

function Trusted() {
  const { data, error, loading, reload } = useApi<any>('/api/admin/security/trusted'); const { busy, run } = useAction();
  const [add, setAdd] = useState<any>(null); const [rm, setRm] = useState<any>(null);
  return <Card title="Trusted software (SHA-256 allow-list)" actions={<button className="btn-primary btn-sm" onClick={() => setAdd({ sha256: '', name: '', note: '' })}><Plus className="h-4 w-4" />Add hash</button>}>
    {loading ? <Loading /> : error ? <ErrorBox error={error} /> : !data.trusted.length ? <Empty title="No trusted hashes" /> :
      <Table><thead><tr><th>Name</th><th>SHA-256</th><th>Note</th><th>Added</th><th /></tr></thead><tbody>{data.trusted.map((t: any) => <tr key={t.id}><td>{t.name}</td><td className="font-mono text-xs">{t.sha256}</td><td className="text-xs">{t.note}</td><td className="text-xs">{date(t.created_at)}<div className="text-ink-500">{t.added_by_email}</div></td><td><button className="btn-ghost btn-sm px-1.5 text-red-400" onClick={() => setRm(t)}><Trash2 className="h-4 w-4" /></button></td></tr>)}</tbody></Table>}
    <Modal open={!!add} onClose={() => setAdd(null)} title="Trust a file hash" footer={<><button className="btn-secondary" onClick={() => setAdd(null)}>Cancel</button><button className="btn-primary" disabled={!!busy} onClick={() => run('a', () => api('POST', '/api/admin/security/trusted', { ...add, sha256: add.sha256.trim().toLowerCase(), note: add.note || undefined }).then(() => { setAdd(null); reload(); }), 'Added')}>Add</button></>}>
      {add && <div className="grid gap-4"><Field label="SHA-256"><input className="input font-mono text-xs" value={add.sha256} onChange={e => setAdd({ ...add, sha256: e.target.value })} /></Field><Field label="Name"><input className="input" value={add.name} onChange={e => setAdd({ ...add, name: e.target.value })} /></Field><Field label="Note"><input className="input" value={add.note} onChange={e => setAdd({ ...add, note: e.target.value })} /></Field></div>}</Modal>
    <Confirm open={!!rm} onClose={() => setRm(null)} danger title="Remove trusted hash" confirmLabel="Remove" busy={busy === 'rm'} onConfirm={() => run('rm', () => api('DELETE', `/api/admin/security/trusted/${rm.id}`).then(() => { setRm(null); reload(); }), 'Removed')}>Files with this hash will be scanned normally again.</Confirm>
  </Card>;
}
