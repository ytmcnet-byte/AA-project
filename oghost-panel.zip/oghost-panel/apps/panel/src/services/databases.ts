import mysql from 'mysql2/promise';
import { encryptSecret, decryptSecret, randomToken } from '@oghost/shared';
import { q, one, exec } from '../db';
import { config } from '../config';
import { HttpError } from '../lib/http';

/** Admin credentials for database hosts are stored encrypted and only ever used server-side. */
async function hostConn(h: any) {
  return mysql.createConnection({ host: h.host, port: h.port, user: h.username, password: decryptSecret(h.password_enc, config.appKey), multipleStatements: false, connectTimeout: 8000 });
}
export async function testHost(h: { host: string; port: number; username: string; password: string }) {
  const c = await mysql.createConnection({ host: h.host, port: h.port, user: h.username, password: h.password, connectTimeout: 8000 });
  try { const [r]: any = await c.query('SELECT VERSION() AS v'); const [g]: any = await c.query('SHOW GRANTS'); return { version: r[0].v, canGrant: g.some((x: any) => /WITH GRANT OPTION/i.test(Object.values(x)[0] as string)) }; } finally { await c.end(); }
}
const ident = (s: string) => { if (!/^[A-Za-z0-9_]{1,64}$/.test(s)) throw new HttpError(400, 'Invalid identifier'); return '`' + s + '`'; };

export async function createServerDatabase(server: { id: number; node_id: number; database_limit: number }, name: string, remote: string) {
  if (!/^[A-Za-z0-9_]{1,40}$/.test(name)) throw new HttpError(422, 'Database name may only contain letters, numbers and underscores (max 40)');
  if (!/^[0-9A-Za-z.%:_-]{1,64}$/.test(remote)) throw new HttpError(422, 'Invalid remote host pattern');
  const count: any = await one('SELECT COUNT(*) AS c FROM server_databases WHERE server_id = ?', [server.id]);
  if (Number(count.c) >= server.database_limit) throw new HttpError(409, `Database limit reached (${server.database_limit})`);
  const host: any = await one(`SELECT h.*, (SELECT COUNT(*) FROM server_databases d WHERE d.host_id = h.id) AS used FROM database_hosts h WHERE (h.node_id = ? OR h.node_id IS NULL) HAVING (h.max_databases = 0 OR used < h.max_databases) ORDER BY h.node_id IS NULL, used LIMIT 1`, [server.node_id]);
  if (!host) throw new HttpError(409, 'No database host is available for this node. Ask an administrator to add one.');
  const dbName = `s${server.id}_${name}`.slice(0, 64); const user = `u${server.id}_${randomToken(4)}`.slice(0, 32); const password = randomToken(18);
  const c = await hostConn(host);
  try {
    await c.query(`CREATE DATABASE ${ident(dbName)} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`);
    try {
      await c.query('CREATE USER ?@? IDENTIFIED BY ?', [user, remote, password]);
      await c.query(`GRANT ALL PRIVILEGES ON ${ident(dbName)}.* TO ?@?`, [user, remote]);
    } catch (e) { await c.query(`DROP DATABASE IF EXISTS ${ident(dbName)}`); throw e; }
  } catch (e: any) { throw new HttpError(502, `Database host error: ${e.sqlMessage || e.message}`); } finally { await c.end(); }
  const r = await exec('INSERT INTO server_databases (server_id, host_id, database_name, username, password_enc, remote) VALUES (?, ?, ?, ?, ?, ?)', [server.id, host.id, dbName, user, encryptSecret(password, config.appKey), remote]);
  return { id: r.insertId, database: dbName, username: user, password };
}
export async function deleteServerDatabase(id: number) {
  const d: any = await one('SELECT d.*, h.host, h.port, h.username AS admin_user, h.password_enc AS admin_pw FROM server_databases d JOIN database_hosts h ON h.id = d.host_id WHERE d.id = ?', [id]); if (!d) throw new HttpError(404, 'Database not found');
  const c = await hostConn({ host: d.host, port: d.port, username: d.admin_user, password_enc: d.admin_pw });
  try { await c.query(`DROP DATABASE IF EXISTS ${ident(d.database_name)}`); await c.query('DROP USER IF EXISTS ?@?', [d.username, d.remote]); } finally { await c.end(); }
  await exec('DELETE FROM server_databases WHERE id = ?', [id]);
}
export async function rotateDatabasePassword(id: number) {
  const d: any = await one('SELECT d.*, h.host, h.port, h.username AS admin_user, h.password_enc AS admin_pw FROM server_databases d JOIN database_hosts h ON h.id = d.host_id WHERE d.id = ?', [id]); if (!d) throw new HttpError(404, 'Database not found');
  const pw = randomToken(18); const c = await hostConn({ host: d.host, port: d.port, username: d.admin_user, password_enc: d.admin_pw });
  try { await c.query('ALTER USER ?@? IDENTIFIED BY ?', [d.username, d.remote, pw]); } finally { await c.end(); }
  await exec('UPDATE server_databases SET password_enc = ? WHERE id = ?', [encryptSecret(pw, config.appKey), id]); return pw;
}
export async function listServerDatabases(serverId: number) {
  return (await q('SELECT d.id, d.database_name, d.username, d.password_enc, d.remote, d.created_at, COALESCE(h.public_host, h.host) AS host, h.port FROM server_databases d JOIN database_hosts h ON h.id = d.host_id WHERE d.server_id = ?', [serverId]))
    .map((d: any) => { const { password_enc, ...rest } = d; return { ...rest, password: decryptSecret(password_enc, config.appKey) }; });
}
