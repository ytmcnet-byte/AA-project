import { dispatchWebhook } from '../services/webhooks';
import { Router } from 'express';
import crypto from 'node:crypto';
import rateLimit from 'express-rate-limit';
import { randomToken, sha256, verifyTotp, decryptSecret } from '@oghost/shared';
import { one, exec, q, json, parse } from '../db';
import { body, z, HttpError, bad } from '../lib/http';
import { createSession, destroySession, hashPassword, verifyPassword, passwordPolicy, loadUserById } from '../lib/auth';
import { getSetting } from '../services/settings';
import { sendMail } from '../services/mail';
import { audit } from '../services/audit';
import { verifyFirebaseIdToken } from '../services/firebase';
import { config } from '../config';

export const authRouter = Router();
const limiter = rateLimit({ windowMs: 15 * 60_000, limit: 30, standardHeaders: 'draft-7', legacyHeaders: false, message: { error: 'Too many attempts, try again later' } });
const mailLimiter = rateLimit({ windowMs: 60 * 60_000, limit: 6, standardHeaders: 'draft-7', legacyHeaders: false, message: { error: 'Too many email requests, try again later' } });

export async function issueEmailToken(userId: number, type: 'verify' | 'reset') {
  const token = randomToken(32);
  await exec('UPDATE email_tokens SET used_at = NOW() WHERE user_id = ? AND type = ? AND used_at IS NULL', [userId, type]);
  await exec('INSERT INTO email_tokens (user_id, type, token_hash, expires_at) VALUES (?, ?, ?, ?)', [userId, type, sha256(token), new Date(Date.now() + (type === 'verify' ? 48 : 1) * 3600_000)]);
  return token;
}
export async function sendVerification(user: { id: number; email: string }) {
  const t = await issueEmailToken(user.id, 'verify');
  await sendMail(user.email, 'Verify your OGHOST account', `Welcome to OGHOST.\n\nVerify your email address: ${config.appUrl}/verify-email?token=${t}\n\nThis link expires in 48 hours.`);
}
async function consumeToken(token: string, type: 'verify' | 'reset') {
  const row: any = await one('SELECT * FROM email_tokens WHERE token_hash = ? AND type = ? AND used_at IS NULL AND expires_at > NOW()', [sha256(String(token)), type]);
  if (!row) throw new HttpError(400, 'This link is invalid or has expired');
  await exec('UPDATE email_tokens SET used_at = NOW() WHERE id = ?', [row.id]); return row.user_id as number;
}
const customerRole = async () => (await one<{ id: number }>("SELECT id FROM roles WHERE slug = 'customer'"))!.id;

authRouter.get('/me', async (req, res) => {
  const pub = { name: await getSetting('app.name'), registration: await getSetting('app.registration'), requireEmailVerification: await getSetting('app.requireEmailVerification'), storeEnabled: await getSetting('store.enabled'), currency: await getSetting('app.currency'), coins: { enabled: !!(await getSetting('coins.enabled')), name: String(await getSetting('coins.name') || 'OGCoins') },
    firebase: (await getSetting('firebase.apiKey')) ? { apiKey: await getSetting('firebase.apiKey'), authDomain: await getSetting('firebase.authDomain'), projectId: await getSetting('firebase.projectId'), appId: await getSetting('firebase.appId') } : null,
    announcements: await q("SELECT id, title, body, level, starts_at, ends_at FROM announcements WHERE (starts_at IS NULL OR starts_at <= NOW()) AND (ends_at IS NULL OR ends_at >= NOW()) ORDER BY id DESC LIMIT 5") };
  res.json({ user: req.user ?? null, twoFactorPending: !!req.twoFactorPending, csrf: req.csrf ?? null, config: pub, brand: { name: 'OGHOST PANEL', tagline: 'Powering the Next Generation of Game Hosting.', credit: 'Powered by SHIVAMBROOG' } });
});

authRouter.post('/register', limiter, async (req, res) => {
  if (!(await getSetting('app.registration'))) throw new HttpError(403, 'Registration is disabled');
  const b = body(z.object({ email: z.string().email().max(191), username: z.string().regex(/^[a-zA-Z0-9_.-]{3,32}$/), password: z.string().max(200), name: z.string().max(100).optional() }), req);
  passwordPolicy(b.password);
  const r = await exec('INSERT INTO users (uuid, email, username, name, password_hash, role_id) VALUES (?, ?, ?, ?, ?, ?)', [crypto.randomUUID(), b.email.toLowerCase(), b.username, b.name ?? null, await hashPassword(b.password), await customerRole()]);
  await sendVerification({ id: r.insertId, email: b.email.toLowerCase() });
  await createSession(req, res, r.insertId); await audit({ ...req, user: { id: r.insertId } } as any, 'auth.register', { type: 'user', id: r.insertId }); void dispatchWebhook('user.registered', { userId: r.insertId });
  res.status(201).json({ ok: true, user: await loadUserById(r.insertId) });
});

authRouter.post('/login', limiter, async (req, res) => {
  const b = body(z.object({ login: z.string().max(191), password: z.string().max(200) }), req);
  const u: any = await one('SELECT id, password_hash, totp_enabled, suspended FROM users WHERE email = ? OR username = ?', [b.login.toLowerCase(), b.login]);
  const ok = await verifyPassword(b.password, u?.password_hash ?? '$2a$12$invalidinvalidinvalidinvalidinvalidinvalidinvalidinv');
  if (!u || !ok) { await audit(req, 'auth.login_failed', undefined, { login: b.login.slice(0, 50) }, 'anonymous'); throw new HttpError(401, 'Invalid credentials'); }
  if (u.suspended) throw new HttpError(403, 'Account suspended');
  if (u.totp_enabled) { await createSession(req, res, u.id, true); return res.json({ twoFactorRequired: true }); }
  await createSession(req, res, u.id); await exec('UPDATE users SET last_login_at = NOW() WHERE id = ?', [u.id]);
  await audit({ ...req, user: { id: u.id } } as any, 'auth.login', { type: 'user', id: u.id });
  res.json({ ok: true, user: await loadUserById(u.id) });
});

authRouter.post('/login/2fa', limiter, async (req, res) => {
  const pending = (req as any).pendingUser; if (!pending || !req.twoFactorPending) throw new HttpError(401, 'No pending two-factor login');
  const b = body(z.object({ code: z.string().max(20) }), req);
  const row: any = await one('SELECT totp_secret_enc, recovery_codes FROM users WHERE id = ?', [pending.id]);
  let ok = verifyTotp(decryptSecret(row.totp_secret_enc, config.appKey), b.code);
  if (!ok) { const codes: string[] = parse(row.recovery_codes, []); const h = sha256(b.code.trim().toLowerCase()); if (codes.includes(h)) { ok = true; await exec('UPDATE users SET recovery_codes = ? WHERE id = ?', [json(codes.filter(c => c !== h)), pending.id]); } }
  if (!ok) throw new HttpError(401, 'Invalid two-factor code');
  await destroySession(req, res); await createSession(req, res, pending.id); await exec('UPDATE users SET last_login_at = NOW() WHERE id = ?', [pending.id]);
  await audit({ ...req, user: pending } as any, 'auth.login', { type: 'user', id: pending.id }, { twoFactor: true });
  res.json({ ok: true, user: await loadUserById(pending.id) });
});

/** Google sign-in via Firebase Authentication. The ID token is verified server-side; browser claims are never trusted. */
authRouter.post('/firebase', limiter, async (req, res) => {
  const b = body(z.object({ idToken: z.string().min(20).max(5000), link: z.boolean().optional() }), req);
  const t = await verifyFirebaseIdToken(b.idToken);
  const email = String(t.email || '').toLowerCase(); if (!email || !t.email_verified) throw new HttpError(400, 'Your Google account email is not verified');
  if (b.link) {
    if (!req.user) throw new HttpError(401, 'Sign in first to link Google');
    const other: any = await one('SELECT id FROM users WHERE firebase_uid = ? AND id <> ?', [t.uid, req.user.id]); if (other) throw new HttpError(409, 'This Google account is already linked to another user');
    await exec('UPDATE users SET firebase_uid = ? WHERE id = ?', [t.uid, req.user.id]); await audit(req, 'auth.google_linked', { type: 'user', id: req.user.id });
    return res.json({ ok: true, user: await loadUserById(req.user.id) });
  }
  let u: any = await one('SELECT id, suspended, totp_enabled FROM users WHERE firebase_uid = ?', [t.uid]);
  if (!u) {
    const byEmail: any = await one('SELECT id, suspended, totp_enabled, firebase_uid FROM users WHERE email = ?', [email]);
    if (byEmail) {
      if (byEmail.firebase_uid) throw new HttpError(409, 'This email is linked to a different Google account');
      // Google has verified ownership of this email address -> link automatically.
      await exec('UPDATE users SET firebase_uid = ?, email_verified_at = COALESCE(email_verified_at, NOW()) WHERE id = ?', [t.uid, byEmail.id]); u = byEmail;
    } else {
      if (!(await getSetting('app.registration'))) throw new HttpError(403, 'Registration is disabled');
      let username = (email.split('@')[0].replace(/[^a-zA-Z0-9_.-]/g, '') || 'user').slice(0, 24); if (username.length < 3) username = `user${username}`;
      if (await one('SELECT id FROM users WHERE username = ?', [username])) username = `${username.slice(0, 24)}${crypto.randomInt(1000, 9999)}`;
      const r = await exec('INSERT INTO users (uuid, email, username, name, avatar_url, role_id, firebase_uid, email_verified_at) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())', [crypto.randomUUID(), email, username, t.name ?? null, t.picture ?? null, await customerRole(), t.uid]);
      u = { id: r.insertId, suspended: 0, totp_enabled: 0 };
    }
  }
  if (u.suspended) throw new HttpError(403, 'Account suspended');
  if (u.totp_enabled) { await createSession(req, res, u.id, true); return res.json({ twoFactorRequired: true }); }
  await createSession(req, res, u.id); await exec('UPDATE users SET last_login_at = NOW() WHERE id = ?', [u.id]);
  await audit({ ...req, user: { id: u.id } } as any, 'auth.login', { type: 'user', id: u.id }, { provider: 'google' });
  res.json({ ok: true, user: await loadUserById(u.id) });
});

authRouter.post('/logout', async (req, res) => { await destroySession(req, res); res.json({ ok: true }); });
authRouter.post('/verify-email', limiter, async (req, res) => { const id = await consumeToken(String(req.body?.token || ''), 'verify'); await exec('UPDATE users SET email_verified_at = NOW() WHERE id = ?', [id]); res.json({ ok: true }); });
authRouter.post('/resend-verification', mailLimiter, async (req, res) => { if (!req.user) throw new HttpError(401, 'Sign in first'); if (req.user.email_verified) throw bad('Already verified'); await sendVerification(req.user); res.json({ ok: true }); });
authRouter.post('/forgot-password', mailLimiter, async (req, res) => {
  const email = String(req.body?.email || '').toLowerCase(); const u: any = await one('SELECT id, email FROM users WHERE email = ?', [email]);
  if (u) { const t = await issueEmailToken(u.id, 'reset'); await sendMail(u.email, 'Reset your OGHOST password', `Reset your password: ${config.appUrl}/reset-password?token=${t}\n\nThis link expires in 1 hour. If you did not request it, ignore this email.`); }
  res.json({ ok: true, message: 'If that email exists, a reset link has been sent.' });
});
authRouter.post('/reset-password', limiter, async (req, res) => {
  const b = body(z.object({ token: z.string(), password: z.string().max(200) }), req); passwordPolicy(b.password);
  const id = await consumeToken(b.token, 'reset');
  await exec('UPDATE users SET password_hash = ? WHERE id = ?', [await hashPassword(b.password), id]);
  await exec('DELETE FROM sessions WHERE user_id = ?', [id]); await audit({ ...req, user: { id } } as any, 'auth.password_reset', { type: 'user', id });
  res.json({ ok: true });
});
