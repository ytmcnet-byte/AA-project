import { Router } from 'express';
import rateLimit from 'express-rate-limit';
import { q, one, exec } from '../db';
import { body, z, HttpError, paginate, ip } from '../lib/http';
import { requireAuth, requireVerified } from '../lib/auth';
import { audit } from '../services/audit';
import { coinName, coinsEnabled, redeemCode, linkvertiseStatus, startLinkvertise, completeLinkvertise, discordConfig, discordConnectUrl, discordCallback } from '../services/coins';

export const coinsRouter = Router();

// ---- Browser redirects (GET, come back from Linkvertise / Discord). The session cookie is SameSite=Lax, so it is sent on these top-level navigations.
const returnLimiter = rateLimit({ windowMs: 60_000, limit: 30, standardHeaders: 'draft-8', legacyHeaders: false });
coinsRouter.get(['/linkvertise/return', '/linkvertise/return/:token'], returnLimiter, async (req, res) => {
  const to = await completeLinkvertise({ token: req.params.token ? String(req.params.token).slice(0, 128) : undefined, hash: typeof req.query.hash === 'string' ? req.query.hash : undefined, sessionUserId: req.user?.id, ip: ip(req) });
  res.redirect(303, to);
});
coinsRouter.get('/discord/callback', returnLimiter, async (req, res) => {
  const to = await discordCallback(req.user?.id, typeof req.query.code === 'string' ? req.query.code : '', typeof req.query.state === 'string' ? req.query.state : '');
  res.redirect(303, to);
});

coinsRouter.use(requireAuth);

coinsRouter.get('/balance', async (req, res) => { const u: any = await one('SELECT coin_balance FROM users WHERE id = ?', [req.user!.id]); res.json({ balance: Number(u.coin_balance), name: await coinName() }); });
coinsRouter.get('/wallet', async (req, res) => {
  const u: any = await one('SELECT coin_balance, discord_id, discord_username FROM users WHERE id = ?', [req.user!.id]);
  const d = await discordConfig();
  res.json({
    enabled: await coinsEnabled(), name: await coinName(), balance: Number(u.coin_balance),
    linkvertise: await linkvertiseStatus(req.user!.id),
    discord: { enabled: d.enabled, linked: !!u.discord_id, username: u.discord_username, discordId: u.discord_id, inviteUrl: d.inviteUrl || null, shopText: d.shopText },
    transactions: await q('SELECT id, amount, balance_after, type, description, invoice_id, created_at FROM coin_transactions WHERE user_id = ? ORDER BY id DESC LIMIT 20', [req.user!.id]),
  });
});
coinsRouter.get('/transactions', async (req, res) => {
  const p = paginate(req);
  const rows = await q('SELECT id, amount, balance_after, type, description, invoice_id, created_at FROM coin_transactions WHERE user_id = ? ORDER BY id DESC LIMIT ? OFFSET ?', [req.user!.id, p.limit, p.offset]);
  const t: any = await one('SELECT COUNT(*) AS n FROM coin_transactions WHERE user_id = ?', [req.user!.id]);
  res.json({ transactions: rows, total: Number(t.n), page: p.page, per_page: p.per });
});

const redeemLimiter = rateLimit({ windowMs: 15 * 60_000, limit: 15, standardHeaders: 'draft-8', legacyHeaders: false, keyGenerator: (req) => `u:${req.user!.id}`, validate: { keyGeneratorIpFallback: false } });
coinsRouter.post('/redeem', redeemLimiter, async (req, res) => {
  const b = body(z.object({ code: z.string().min(4).max(60) }), req);
  const r = await redeemCode(req.user!.id, b.code); await audit(req, 'coins.redeem', { type: 'user', id: req.user!.id }, { coins: r.coins }); res.json(r);
});

coinsRouter.post('/linkvertise/start', requireVerified, async (req, res) => res.json(await startLinkvertise(req.user!.id, ip(req))));

coinsRouter.get('/discord/connect', async (req, res) => res.json({ url: await discordConnectUrl(req.user!.id) }));
coinsRouter.post('/discord/unlink', async (req, res) => {
  const u: any = await one('SELECT discord_id FROM users WHERE id = ?', [req.user!.id]); if (!u?.discord_id) throw new HttpError(409, 'No Discord account is linked');
  await exec('UPDATE users SET discord_id = NULL, discord_username = NULL, discord_linked_at = NULL WHERE id = ?', [req.user!.id]);
  await audit(req, 'coins.discord_unlinked', { type: 'user', id: req.user!.id }, { discordId: u.discord_id }); res.json({ ok: true });
});
