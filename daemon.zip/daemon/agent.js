require('dotenv').config();
const express=require('express'); const cors=require('cors'); const fs=require('fs'); const path=require('path');
const {spawn}=require('child_process'); const pidusage=require('pidusage');
const app=express(); app.use(cors()); app.use(express.json({limit:'2mb'}));
const ROOT=path.resolve(process.env.DATA_DIR||path.join(__dirname,'data','servers')); fs.mkdirSync(ROOT,{recursive:true});
const processes=new Map(); const meta=new Map();
function auth(req,res,next){ if(req.path==='/health') return next(); const key=req.get('authorization'); if(!process.env.NODE_KEY||key!==`Bearer ${process.env.NODE_KEY}`) return res.status(401).json({error:'Unauthorized'}); next(); }
app.use(auth);
function dir(id){return path.join(ROOT,id)}
function cpuset(s){ const n=Math.max(1,Number(s.cpuCores||s.cpu||1)); if(Array.isArray(s.cpuSet)&&s.cpuSet.length)return s.cpuSet.join(','); if(typeof s.cpuSet==='string'&&s.cpuSet)return s.cpuSet; return Array.from({length:n},(_,i)=>i).join(','); }
function cmd(s){ const t=String(s.type||'paper').toLowerCase(); const d=dir(s.id); const args=[]; let bin;
 if(t==='node'||t==='nodejs'){bin='node'; args.push(s.entry||'index.js')} else if(t==='python'||t==='python3'){bin='python3';args.push('-u',s.entry||'main.py')} else {bin=s.javaBin||'java';args.push(`-Xms${Number(s.ram||1)}G`,`-Xmx${Number(s.ram||1)}G`,'-jar',s.jar||'server.jar','nogui','--nojline')}
 return {bin,args,d,t}; }
app.get('/health',(req,res)=>res.json({ok:true,service:'jtg-local-daemon',docker:false,root:ROOT}));
app.post('/servers/:id/create',(req,res)=>{const s={...req.body,id:req.params.id};fs.mkdirSync(dir(s.id),{recursive:true});fs.writeFileSync(path.join(dir(s.id),'server.json'),JSON.stringify(s,null,2));res.json({ok:true});});
app.post('/servers/:id/start',(req,res)=>{const id=req.params.id;if(processes.has(id))return res.status(409).json({error:'Already running'});let s=req.body; const f=path.join(dir(id),'server.json');if(!s||!Object.keys(s).length){if(!fs.existsSync(f))return res.status(404).json({error:'Missing server config'});s=JSON.parse(fs.readFileSync(f,'utf8'))} s.id=id;fs.mkdirSync(dir(id),{recursive:true});const c=cmd(s);const set=cpuset(s);const child=spawn('taskset',['-c',set,c.bin,...c.args],{cwd:c.d,env:{...process.env,PORT:String(s.port||25565),SERVER_PORT:String(s.port||25565)},stdio:['pipe','pipe','pipe']});processes.set(id,child);meta.set(id,{startedAt:new Date().toISOString(),cpuSet:set});child.on('exit',()=>{processes.delete(id);meta.delete(id)});res.json({ok:true,pid:child.pid,cpuSet:set});});
app.post('/servers/:id/stop',(req,res)=>{const c=processes.get(req.params.id);if(c){try{c.stdin.write('stop\n')}catch{};setTimeout(()=>{try{c.kill('SIGTERM')}catch{}},1000)}res.json({ok:true});});
app.get('/servers/:id/status',(req,res)=>{const c=processes.get(req.params.id),m=meta.get(req.params.id);res.json({State:{Running:!!c,Status:c?'running':'exited',StartedAt:m?.startedAt||null},pid:c?.pid||null,cpuSet:m?.cpuSet||null});});
app.get('/servers/:id/stats',async(req,res)=>{const c=processes.get(req.params.id);if(!c)return res.json({cpu:0,ram:0,disk:0,isRunning:false});try{const x=await pidusage(c.pid);res.json({cpu:x.cpu,ram:x.memory,disk:0,isRunning:true})}catch(e){res.status(500).json({error:String(e.message||e)})}});
app.post('/servers/:id/command',(req,res)=>{const c=processes.get(req.params.id);if(!c||!c.stdin)return res.status(409).json({error:'Not running'});c.stdin.write(String(req.body.command||'')+'\n');res.json({ok:true})});
app.delete('/servers/:id',(req,res)=>{const id=req.params.id,c=processes.get(id);if(c)try{c.kill('SIGTERM')}catch{};processes.delete(id);meta.delete(id);fs.rmSync(dir(id),{recursive:true,force:true});res.json({ok:true})});
const PORT=Number(process.env.PORT||6768);app.listen(PORT,'0.0.0.0',()=>console.log(`JTG Local Daemon listening on ${PORT}`));
