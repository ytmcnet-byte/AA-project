# OGHOST extensions

OGHOST has its own extension system. It is inspired by Blueprint for Pterodactyl, but **Pterodactyl Blueprint packages are not compatible.** Blueprint extensions are PHP/Laravel plus Pterodactyl's React code and cannot be installed as-is. They have to be ported to this SDK.

## Trust model

Extension server code runs **inside the panel process with the panel's privileges**. The manifest's permission list controls which SDK capabilities the extension's context receives, and it is shown to the administrator before enabling. It is **not a sandbox** against malicious code. Only install extensions you trust.

The panel grants permissions all-or-nothing: you can only enable an extension after approving every permission it requests. Extension UI pages run in a sandboxed iframe (`allow-scripts allow-forms`, opaque origin) and can only make requests to the extension's own API routes, through a relay.

## Layout

```
extensions/<identifier>/
  extension.json      manifest
  server.mjs          optional server entry (ESM, default export { register(ctx), unregister?() })
  ui/                 optional static pages, served at /extensions-ui/<identifier>/...
```

Install by copying a folder into `EXTENSIONS_DIR` (default `extensions/`) or by uploading a `.zip` in **Admin → Extensions**. New extensions are installed disabled, and no code runs during installation. Enable, disable, reload, configure settings and uninstall from the same page.

## Manifest

```json
{
  "identifier": "server-notes",
  "name": "Server Notes",
  "version": "1.0.0",
  "description": "Private notes per server",
  "author": "OGHOST",
  "sdk": 1,
  "permissions": ["routes", "storage", "settings", "events", "ui", "servers:read"],
  "server": "server.mjs",
  "ui": [{ "id": "notes", "title": "Notes", "file": "notes.html", "area": "server" }],
  "settings": [{ "key": "maxLength", "label": "Maximum note length", "type": "number", "default": 5000 }]
}
```

- `identifier`: `^[a-z][a-z0-9-]{1,63}$`
- `sdk`: must be `1`
- `ui[].area`: `admin` (Admin → Extensions → page), `client` (customer area) or `server` (a tab on each server)
- `settings[].type`: `string`, `number`, `boolean`, `secret` (stored encrypted, never shown again)

## Permissions

| Permission | Grants |
| --- | --- |
| `routes` | `ctx.router` (mounted at `/api/extensions/<id>/...`, authenticated users) and `ctx.adminRouter` (`/api/extensions/<id>/admin/...`, needs `admin.extensions`) |
| `storage` | `ctx.storage.get/set/delete/list`: key-value storage scoped to the extension |
| `settings` | `ctx.settings.get(key)`: values set by the administrator |
| `events` | `ctx.events.on(event, handler)`: `server.created`, `server.deleted`, `server.suspended`, `invoice.paid`, `order.created`, `security.incident`, `node.offline`, ... |
| `notifications` | `ctx.notifications.notifyUser(userId, title, body, link?)` |
| `ui` | Serve pages listed in `ui` |
| `servers:read` | `ctx.servers.get(id)`, `ctx.servers.listForUser(userId)` |
| `users:read` | `ctx.users.get(id)` (id, email, username only) |

Routes always require an authenticated user. Extensions must still check that the user may access the resource (see the example's `canAccess`).

## Server code

```js
export default {
  async register(ctx) {
    ctx.router.get('/hello', async (req, res) => res.json({ hello: req.user.username }));
    ctx.events.on('server.deleted', async ({ serverId }) => ctx.storage.delete(`note:${serverId}`));
  },
  async unregister() { /* optional cleanup */ },
};
```

TypeScript types and `validateManifest()` are in `packages/extension-sdk`.

## UI pages

Include the bridge and talk to your routes:

```html
<script src="/extensions-ui/_sdk/bridge.js"></script>
<script>
OGHOST.context.then(async (ctx) => {           // { serverId, user, ... } depending on area
  const r = await OGHOST.request('GET', '/notes/' + ctx.serverId);   // -> /api/extensions/<id>/notes/<sid>
});
</script>
```

The relay only accepts paths under the extension's own prefix and the methods GET/POST/PUT/PATCH/DELETE.

See `extensions/server-notes/` for a complete working example.
