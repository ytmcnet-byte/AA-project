import { Router } from 'express';
import { q, one, exec, json, parse, tx } from '../../db';
import { body, patchBody, z, HttpError, idParam, paginate } from '../../lib/http';
import { requirePerm } from '../../lib/auth';
import { audit } from '../../services/audit';
import { markInvoicePaid, cancelService, createInvoice, addMonths } from '../../services/billing';
import { refund } from '../../services/gateways';
import { notify } from '../../services/notify';
import { setSuspension } from '../../services/servers';

export const commerceAdmin = Router();
const P = requirePerm('admin.store');
const upd = async (table: string, id: number, map: Record<string, unknown>) => { const k = Object.keys(map).filter(x => map[x] !== undefined); if (k.length) await exec(`UPDATE ${table} SET ${k.map(x => `\`${x}\` = ?`).join(', ')} WHERE id = ?`, [...k.map(x => map[x]), id]); };
const dup = (e: any) => { if (e.code === 'ER_DUP_ENTRY') throw new HttpError(409, 'Slug/code already in use'); throw e; };
const bool = (v: boolean | undefined) => (v === undefined ? undefined : v ? 1 : 0);

// categories
const catSchema = z.object({ name: z.string().min(1).max(100), slug: z.string().regex(/^[a-z0-9-]{2,100}$/), description: z.string().max(2000).nullable().optional(), sort: z.number().int().default(0), visible: z.boolean().default(true) });
commerceAdmin.get('/store/categories', P, async (_req, res) => res.json({ categories: await q('SELECT * FROM product_categories ORDER BY sort, id') }));
commerceAdmin.post('/store/categories', P, async (req, res) => { const b = body(catSchema, req); const r = await exec('INSERT INTO product_categories (name, slug, description, sort, visible) VALUES (?, ?, ?, ?, ?)', [b.name, b.slug, b.description ?? null, b.sort, b.visible ? 1 : 0]).catch(dup); await audit(req, 'admin.store.category.create', { type: 'category', id: r.insertId }, b); res.status(201).json({ id: r.insertId }); });
commerceAdmin.patch('/store/categories/:id', P, async (req, res) => { const b = patchBody(catSchema.partial(), req); await upd('product_categories', idParam(req), { name: b.name, slug: b.slug, description: b.description, sort: b.sort, visible: bool(b.visible) }).catch(dup); res.json({ ok: true }); });
commerceAdmin.delete('/store/categories/:id', P, async (req, res) => { const c = await one<any>('SELECT COUNT(*) AS c FROM products WHERE category_id = ?', [idParam(req)]); if (Number(c.c)) throw new HttpError(409, 'Category has products'); await exec('DELETE FROM product_categories WHERE id = ?', [idParam(req)]); res.json({ ok: true }); });

// products
const prodSchema = z.object({ categoryId: z.number().int(), name: z.string().min(1).max(100), slug: z.string().regex(/^[a-z0-9-]{2,100}$/), type: z.enum(['minecraft', 'vps', 'game', 'custom', 'addon_storage', 'addon_ram', 'addon_cpu']), description: z.string().max(5000).nullable().optional(), visible: z.boolean().default(true), sort: z.number().int().default(0) });
commerceAdmin.get('/store/products', P, async (_req, res) => res.json({ products: await q('SELECT p.*, (SELECT COUNT(*) FROM plans pl WHERE pl.product_id = p.id) AS plans FROM products p ORDER BY p.sort, p.id') }));
commerceAdmin.post('/store/products', P, async (req, res) => { const b = body(prodSchema, req); const r = await exec('INSERT INTO products (category_id, name, slug, type, description, visible, sort) VALUES (?, ?, ?, ?, ?, ?, ?)', [b.categoryId, b.name, b.slug, b.type, b.description ?? null, b.visible ? 1 : 0, b.sort]).catch(dup); await audit(req, 'admin.store.product.create', { type: 'product', id: r.insertId }, b); res.status(201).json({ id: r.insertId }); });
commerceAdmin.patch('/store/products/:id', P, async (req, res) => { const b = patchBody(prodSchema.partial(), req); await upd('products', idParam(req), { category_id: b.categoryId, name: b.name, slug: b.slug, type: b.type, description: b.description, visible: bool(b.visible), sort: b.sort }).catch(dup); res.json({ ok: true }); });
commerceAdmin.delete('/store/products/:id', P, async (req, res) => { const c = await one<any>('SELECT COUNT(*) AS c FROM plans WHERE product_id = ?', [idParam(req)]); if (Number(c.c)) throw new HttpError(409, 'Delete or move the product\'s plans first'); await exec('DELETE FROM products WHERE id = ?', [idParam(req)]); res.json({ ok: true }); });

// plans
const planSchema = z.object({ productId: z.number().int(), name: z.string().min(1).max(100), description: z.string().max(5000).nullable().optional(), priceCents: z.number().int().min(0), currency: z.string().regex(/^[A-Z]{3}$/).default('INR'), billingCycle: z.enum(['monthly', 'quarterly', 'semiannual', 'annual', 'one_time']).default('monthly'), setupFeeCents: z.number().int().min(0).default(0), memoryMb: z.number().int().min(0), cpuPercent: z.number().int().min(0), diskMb: z.number().int().min(0), databases: z.number().int().min(0).default(0), backups: z.number().int().min(0).default(1), allocations: z.number().int().min(1).default(1), eggId: z.number().int().nullable().optional(), nodeId: z.number().int().nullable().optional(), locationId: z.number().int().nullable().optional(), stock: z.number().int().min(0).nullable().optional(), visible: z.boolean().default(true), sort: z.number().int().default(0), coinPrice: z.number().int().min(0).max(100_000_000).nullable().optional(), maxPerUser: z.number().int().min(1).max(1000).nullable().optional() });
commerceAdmin.get('/store/plans', P, async (_req, res) => res.json({ plans: await q('SELECT pl.*, pr.name AS product_name, (SELECT COUNT(*) FROM services s WHERE s.plan_id = pl.id AND s.status IN (\'active\',\'suspended\')) AS active_services FROM plans pl JOIN products pr ON pr.id = pl.product_id ORDER BY pl.product_id, pl.sort, pl.price_cents') }));
commerceAdmin.post('/store/plans', P, async (req, res) => {
  const b = body(planSchema, req);
  const r = await exec('INSERT INTO plans (product_id, name, description, price_cents, currency, billing_cycle, setup_fee_cents, memory_mb, cpu_percent, disk_mb, `databases`, backups, allocations, egg_id, node_id, location_id, stock, visible, sort, coin_price, max_per_user) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', [b.productId, b.name, b.description ?? null, b.priceCents, b.currency, b.billingCycle, b.setupFeeCents, b.memoryMb, b.cpuPercent, b.diskMb, b.databases, b.backups, b.allocations, b.eggId ?? null, b.nodeId ?? null, b.locationId ?? null, b.stock ?? null, b.visible ? 1 : 0, b.sort, b.coinPrice ?? null, b.maxPerUser ?? null]);
  await audit(req, 'admin.store.plan.create', { type: 'plan', id: r.insertId }, b); res.status(201).json({ id: r.insertId });
});
commerceAdmin.patch('/store/plans/:id', P, async (req, res) => {
  const b = patchBody(planSchema.partial(), req);
  await upd('plans', idParam(req), { product_id: b.productId, name: b.name, description: b.description, price_cents: b.priceCents, currency: b.currency, billing_cycle: b.billingCycle, setup_fee_cents: b.setupFeeCents, memory_mb: b.memoryMb, cpu_percent: b.cpuPercent, disk_mb: b.diskMb, databases: b.databases, backups: b.backups, allocations: b.allocations, egg_id: b.eggId, node_id: b.nodeId, location_id: b.locationId, stock: b.stock, visible: bool(b.visible), sort: b.sort, coin_price: b.coinPrice, max_per_user: b.maxPerUser });
  await audit(req, 'admin.store.plan.update', { type: 'plan', id: idParam(req) }, b); res.json({ ok: true, note: 'Existing services keep their price until they change plan; resource changes apply to new orders only.' });
});
commerceAdmin.delete('/store/plans/:id', P, async (req, res) => { const c = await one<any>('SELECT (SELECT COUNT(*) FROM services WHERE plan_id = ?) + (SELECT COUNT(*) FROM orders WHERE plan_id = ?) AS c', [idParam(req), idParam(req)]); if (Number(c.c)) throw new HttpError(409, 'Plan has orders/services. Hide it instead (visible = false).'); await exec('DELETE FROM plans WHERE id = ?', [idParam(req)]); res.json({ ok: true }); });

// coupons
const couponSchema = z.object({ code: z.string().regex(/^[A-Za-z0-9_-]{3,50}$/).transform(s => s.toUpperCase()), type: z.enum(['percent', 'fixed']), value: z.number().int().min(1), maxUses: z.number().int().min(1).nullable().optional(), expiresAt: z.string().datetime().nullable().optional(), planIds: z.array(z.number().int()).nullable().optional(), recurring: z.boolean().default(false), active: z.boolean().default(true) });
commerceAdmin.get('/store/coupons', P, async (_req, res) => res.json({ coupons: (await q<any>('SELECT * FROM coupons ORDER BY id DESC')).map(c => ({ ...c, plan_ids: parse(c.plan_ids, null) })) }));
commerceAdmin.post('/store/coupons', P, async (req, res) => { const b = body(couponSchema, req); if (b.type === 'percent' && b.value > 100) throw new HttpError(422, 'Percent coupons are 1-100'); const r = await exec('INSERT INTO coupons (code, type, value, max_uses, expires_at, plan_ids, recurring, active) VALUES (?, ?, ?, ?, ?, ?, ?, ?)', [b.code, b.type, b.value, b.maxUses ?? null, b.expiresAt ? new Date(b.expiresAt) : null, b.planIds?.length ? json(b.planIds) : null, b.recurring ? 1 : 0, b.active ? 1 : 0]).catch(dup); await audit(req, 'admin.store.coupon.create', { type: 'coupon', id: r.insertId }, b); res.status(201).json({ id: r.insertId }); });
commerceAdmin.patch('/store/coupons/:id', P, async (req, res) => { const b = patchBody(couponSchema.partial(), req); await upd('coupons', idParam(req), { code: b.code, type: b.type, value: b.value, max_uses: b.maxUses, expires_at: b.expiresAt === undefined ? undefined : b.expiresAt ? new Date(b.expiresAt) : null, plan_ids: b.planIds === undefined ? undefined : b.planIds?.length ? json(b.planIds) : null, recurring: bool(b.recurring), active: bool(b.active) }).catch(dup); res.json({ ok: true }); });
commerceAdmin.delete('/store/coupons/:id', P, async (req, res) => { await exec('UPDATE coupons SET active = 0 WHERE id = ?', [idParam(req)]); res.json({ ok: true, note: 'Coupons are deactivated (not deleted) to keep order history intact.' }); });

// orders / invoices / services
const PO = requirePerm('admin.orders');
commerceAdmin.get('/orders', PO, async (req, res) => { const p = paginate(req); const st = req.query.status ? 'WHERE o.status = ?' : ''; res.json({ orders: await q(`SELECT o.*, u.email, pl.name AS plan_name FROM orders o JOIN users u ON u.id = o.user_id JOIN plans pl ON pl.id = o.plan_id ${st} ORDER BY o.id DESC LIMIT ? OFFSET ?`, [...(st ? [req.query.status] : []), p.limit, p.offset]) }); });
commerceAdmin.get('/invoices', PO, async (req, res) => { const p = paginate(req); const st = req.query.status ? 'WHERE i.status = ?' : ''; res.json({ invoices: await q(`SELECT i.id, i.number, i.user_id, u.email, i.status, i.total_cents, i.currency, i.due_at, i.paid_at, i.created_at, i.service_id, i.order_id FROM invoices i JOIN users u ON u.id = i.user_id ${st} ORDER BY i.id DESC LIMIT ? OFFSET ?`, [...(st ? [req.query.status] : []), p.limit, p.offset]) }); });
commerceAdmin.get('/invoices/:id', PO, async (req, res) => { const inv: any = await one('SELECT i.*, u.email FROM invoices i JOIN users u ON u.id = i.user_id WHERE i.id = ?', [idParam(req)]); if (!inv) throw new HttpError(404, 'Invoice not found'); res.json({ invoice: { ...inv, items: parse(inv.items, []) }, payments: await q('SELECT * FROM payments WHERE invoice_id = ? ORDER BY id DESC', [inv.id]) }); });
commerceAdmin.post('/invoices/:id/cancel', PO, async (req, res) => { const r = await exec("UPDATE invoices SET status = 'cancelled' WHERE id = ? AND status = 'unpaid'", [idParam(req)]); if (!r.affectedRows) throw new HttpError(409, 'Only unpaid invoices can be cancelled'); await audit(req, 'admin.invoice.cancel', { type: 'invoice', id: idParam(req) }); res.json({ ok: true }); });
commerceAdmin.post('/invoices', PO, async (req, res) => {
  const b = body(z.object({ userId: z.number().int(), serviceId: z.number().int().nullable().optional(), items: z.array(z.object({ description: z.string().min(1).max(300), amount_cents: z.number().int().min(0) })).min(1).max(50), currency: z.string().regex(/^[A-Z]{3}$/).default('INR'), dueDays: z.number().int().min(0).max(365).default(7) }), req);
  const inv = await tx(c => createInvoice(c, { userId: b.userId, serviceId: b.serviceId ?? null, items: b.items, discount: 0, currency: b.currency, dueAt: new Date(Date.now() + b.dueDays * 86400_000) }));
  await notify(b.userId, 'payment', 'New invoice', 'An administrator created an invoice for you.', { link: `/billing/invoices/${inv.id}`, email: true }); await audit(req, 'admin.invoice.create', { type: 'invoice', id: inv.id }, b); res.status(201).json(inv);
});
commerceAdmin.get('/services', PO, async (req, res) => { const p = paginate(req); res.json({ services: await q('SELECT sv.*, u.email, pl.name AS plan_name, s.name AS server_name FROM services sv JOIN users u ON u.id = sv.user_id JOIN plans pl ON pl.id = sv.plan_id LEFT JOIN servers s ON s.id = sv.server_id ORDER BY sv.id DESC LIMIT ? OFFSET ?', [p.limit, p.offset]) }); });
commerceAdmin.patch('/services/:id', PO, async (req, res) => {
  const b = body(z.object({ nextDueAt: z.string().datetime().optional(), extendMonths: z.number().int().min(1).max(36).optional(), priceCents: z.number().int().min(0).optional(), status: z.enum(['active', 'suspended']).optional() }), req);
  const svc: any = await one('SELECT * FROM services WHERE id = ?', [idParam(req)]); if (!svc) throw new HttpError(404, 'Service not found');
  const due = b.nextDueAt ? new Date(b.nextDueAt) : b.extendMonths ? addMonths(svc.next_due_at ? new Date(svc.next_due_at) : new Date(), b.extendMonths) : undefined;
  await upd('services', svc.id, { next_due_at: due, price_cents: b.priceCents, status: b.status });
  if (b.status && svc.server_id) await setSuspension(svc.server_id, b.status === 'suspended', b.status === 'suspended' ? 'Billing: suspended by an administrator' : null, null).catch(() => {});
  await audit(req, 'admin.service.update', { type: 'service', id: svc.id }, b); res.json({ ok: true });
});
commerceAdmin.post('/services/:id/cancel', PO, async (req, res) => { const b = body(z.object({ immediate: z.boolean().default(false) }), req); await cancelService(null, idParam(req), b.immediate); await audit(req, 'admin.service.cancel', { type: 'service', id: idParam(req) }, b); res.json({ ok: true }); });

// payments
const PP = requirePerm('admin.payments');
commerceAdmin.get('/payments', PP, async (req, res) => { const p = paginate(req); const st = req.query.status ? 'WHERE p.status = ?' : ''; res.json({ payments: await q(`SELECT p.id, p.invoice_id, i.number AS invoice_number, p.user_id, u.email, p.gateway, p.gateway_order_id, p.gateway_payment_id, p.amount_cents, p.refunded_cents, p.currency, p.status, p.reference, p.failure_reason, p.approved_by, p.created_at, p.updated_at FROM payments p JOIN invoices i ON i.id = p.invoice_id JOIN users u ON u.id = p.user_id ${st} ORDER BY p.id DESC LIMIT ? OFFSET ?`, [...(st ? [req.query.status] : []), p.limit, p.offset]) }); });
/** Manual/UPI approval: the administrator confirms the money arrived (bank statement / UPI app). */
commerceAdmin.post('/payments/:id/approve', PP, async (req, res) => {
  const p: any = await one("SELECT * FROM payments WHERE id = ? AND gateway IN ('upi','manual')", [idParam(req)]); if (!p) throw new HttpError(404, 'Manual/UPI payment not found');
  if (p.status !== 'awaiting_approval' && p.status !== 'pending') throw new HttpError(409, `Payment is ${p.status}`);
  const b = body(z.object({ note: z.string().max(300).optional() }), req);
  const r = await markInvoicePaid(p.invoice_id, { gateway: p.gateway, paymentId: p.id, reference: p.reference || b.note, approvedBy: req.user!.id });
  await audit(req, 'admin.payment.approve', { type: 'payment', id: p.id }, { invoice: p.invoice_id, reference: p.reference, note: b.note }); res.json(r);
});
commerceAdmin.post('/payments/:id/reject', PP, async (req, res) => {
  const b = body(z.object({ reason: z.string().min(1).max(300) }), req); const p: any = await one('SELECT * FROM payments WHERE id = ?', [idParam(req)]); if (!p) throw new HttpError(404, 'Payment not found');
  if (p.status === 'succeeded') throw new HttpError(409, 'Use a refund for succeeded payments');
  await exec("UPDATE payments SET status = 'failed', failure_reason = ?, approved_by = ? WHERE id = ?", [b.reason, req.user!.id, p.id]);
  await notify(p.user_id, 'payment', 'Payment could not be verified', `Reason: ${b.reason}. Your invoice is still unpaid.`, { link: `/billing/invoices/${p.invoice_id}`, email: true });
  await audit(req, 'admin.payment.reject', { type: 'payment', id: p.id }, b); res.json({ ok: true });
});
commerceAdmin.post('/payments/:id/refund', PP, async (req, res) => {
  const b = body(z.object({ amountCents: z.number().int().min(1).nullable().default(null), reason: z.string().max(300).optional() }), req);
  const r = await refund(idParam(req), b.amountCents, req.user!.id); await audit(req, 'admin.payment.refund', { type: 'payment', id: idParam(req) }, { ...b, ...r }); res.json(r);
});
