import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import https from 'node:https';
import crypto from 'node:crypto';
import express, { type Request, type Response, type NextFunction } from 'express';
import { Server as IOServer } from 'socket.io';
import { verifyToken, OGHOST_VERSION, PathSecurityError, type AgentServerSpec, type NodeHeartbeat } from '@oghost/shared';
import { config, dirs, serverDir, backupDir } from './config';
import { ServerInstance } from './server';
import { quotaHook } from './quota';
import { fileRoutes } from './files';
import { javaList, detectCpulimit, inspectJava } from './java';
import { cpuUsage, memInfo, netTotals, diskInfo, quotaSupport, systemBasics } from './system';
import { panelFetch, report } from './reporter';
import { monitor, scanExecutables, trusted, scanFile, summary } from './security';
import { createLocalBackup, restoreArchive, backupFile, tempFile } from './backups';
import { driveResumableUpload, driveDownload } from './drive';
import { listPlugins } from './plugins';
import { downloadTo } from './download';
import { createZip } from './archive';
import { fmt } from './disk';

const servers = new Map<number, ServerInstance>();
for (const f of fs.readdirSync(dirs.metadata)) {
  const m = f.match(/^server-(\d+)\.json$/); if (!m) continue;
  try { const spec = JSON.parse(fs.readFileSync(path.join(dirs.metadata, f), 'utf8')) as AgentServerSpec; servers.set(spec.id, new ServerInstance(spec)); } catch (e) { console.error('[agent] bad metadata', f, e); }
}

const app = express();
app.disable('x-powered-by');

// --- Auth: every request must carry a short-lived token signed by the panel with this node's secret.
function auth(req: Request, _res: Response, next: NextFunction) {
  try {
    const tok = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    const p = verifyToken<{ aud: string; nodeId: number; serverId?: number }>(tok, config.secret);
    if (p.aud !== 'node' || p.nodeId !== config.nodeId) throw new Error('Token not issued for this node');
    const m = req.path.match(/^\/servers\/(\d+)/); if (p.serverId != null && (!m || Number(m[1]) !== p.serverId)) throw new Error('Token scoped to another server');
    (req as any).token = p; next();
  } catch (e: any) { next(Object.assign(new Error(`Unauthorized: ${e.message}`), { status: 401 })); }
}
const getInst = (req: Request) => { const s = servers.get(Number(req.params.id)); if (!s) throw Object.assign(new Error('Server not found on node'), { status: 404 }); return s; };
const J = express.json({ limit: '2mb' });

app.get('/health', (_req, res) => res.json({ ok: true, version: OGHOST_VERSION, nodeId: config.nodeId }));
app.use('/api', auth);

app.get('/api/system', async (_req, res) => res.json(await heartbeatPayload()));
app.get('/api/java', async (req, res) => res.json({ java: await javaList(req.query.refresh === '1'), cpulimit: detectCpulimit() }));
app.post('/api/java/inspect', J, async (req, res) => { const j = await inspectJava(String(req.body.path || '')); if (!j) throw Object.assign(new Error('Not a working Java executable'), { status: 422 }); res.json(j); });
// Reachability probe: temporarily listen on a FREE port so the panel can test whether it is reachable from outside.
// Ports in use by a running server are reported as such (the panel then probes the live server instead).
app.post('/api/system/probe-listen', J, async (req, res) => {
  const port = Number(req.body.port); const ip = String(req.body.ip || '0.0.0.0'); const seconds = Math.min(30, Math.max(3, Number(req.body.seconds) || 10));
  if (!Number.isInteger(port) || port < 1024 || port > 65535) throw Object.assign(new Error('Port must be 1024-65535'), { status: 400 });
  const net = await import('node:net'); const srv = net.createServer(sock => { sock.end('OGHOST-PROBE\n'); });
  srv.once('error', (e: any) => res.json({ listening: false, inUse: e.code === 'EADDRINUSE', error: e.code }));
  srv.listen(port, ip, () => { setTimeout(() => srv.close(), seconds * 1000).unref(); res.json({ listening: true, seconds }); });
});
app.put('/api/security/trusted', J, (req, res) => { trusted.clear(); for (const h of req.body.hashes || []) trusted.add(String(h)); res.json({ ok: true, count: trusted.size }); });

app.put('/api/servers/:id', J, (req, res) => {
  const spec = req.body as AgentServerSpec; if (spec.id !== Number(req.params.id)) throw Object.assign(new Error('id mismatch'), { status: 400 });
  let inst = servers.get(spec.id);
  if (!inst) { inst = new ServerInstance(spec); servers.set(spec.id, inst); attach(inst); }
  inst.updateSpec(spec); res.json(statusOf(inst));
});
app.get('/api/servers/:id', (req, res) => res.json(statusOf(getInst(req))));
app.get('/api/servers/:id/logs', (req, res) => res.json({ lines: getInst(req).console.slice(-Number(req.query.lines || 500)) }));
app.post('/api/servers/:id/install', J, async (req, res) => { const inst = getInst(req); const p = inst.install(!!req.body?.reinstall); if (req.body?.wait) res.json(await p); else { p.catch(() => {}); res.status(202).json({ ok: true }); } });
app.delete('/api/servers/:id', async (req, res) => {
  const inst = servers.get(Number(req.params.id));
  if (inst) { inst.kill('delete'); await new Promise(r => setTimeout(r, 300)); inst.removeAllListeners(); }
  await quotaHook('clear', Number(req.params.id), serverDir(Number(req.params.id)));
  await fs.promises.rm(serverDir(Number(req.params.id)), { recursive: true, force: true });
  await fs.promises.rm(backupDir(Number(req.params.id)), { recursive: true, force: true });
  await fs.promises.rm(path.join(dirs.metadata, `server-${req.params.id}.json`), { force: true });
  servers.delete(Number(req.params.id)); res.json({ ok: true, deleted: !fs.existsSync(serverDir(Number(req.params.id))) });
});
app.post('/api/servers/:id/power', J, async (req, res) => {
  const inst = getInst(req); const a = String(req.body.action);
  if (a === 'start') await inst.start(); else if (a === 'stop') inst.stop(); else if (a === 'kill') inst.kill('manual');
  else if (a === 'restart') { inst.restart().catch(e => inst.log(`[OGHOST] Restart failed: ${e.message}`)); }
  else throw Object.assign(new Error('Unknown power action'), { status: 400 });
  res.json(statusOf(inst));
});
app.post('/api/servers/:id/command', J, (req, res) => { getInst(req).command(String(req.body.command || '')); res.json({ ok: true }); });
app.post('/api/servers/:id/scan', async (req, res) => {
  const inst = getInst(req); const out: any[] = []; const walk = (d: string, depth: number) => { for (const e of fs.readdirSync(d, { withFileTypes: true })) { const p = path.join(d, e.name); if (e.isFile() && /\.jar$/i.test(e.name)) out.push(p); else if (e.isDirectory() && depth > 0 && !['libraries', 'world', 'cache', 'versions'].includes(e.name)) walk(p, depth - 1); } };
  walk(inst.dir, 2); const serverJar = path.join(inst.dir, inst.spec.variables.SERVER_JAR || 'server.jar');
  const results = []; for (const f of out) { const mode = f === serverJar ? 'server' : 'plugin'; results.push({ file: '/' + path.relative(inst.dir, f), mode, ...summary(await scanFile(f, mode)) }); }
  report('scan', inst.id, { phase: 'manual', results }); res.json({ results });
});
app.use('/api/servers/:id/files', (req, _res, next) => { if (req.method === 'POST' && req.path === '/write') return express.raw({ type: () => true, limit: '8mb' })(req, _res, next); if (req.method === 'PUT') return next(); return J(req, _res, next); }, fileRoutes(getInst));

// ---- Local backups
app.post('/api/servers/:id/backups', J, async (req, res) => {
  const inst = getInst(req); const uuid = String(req.body.uuid);
  const r = await createLocalBackup(inst, uuid, Number(req.body.maxBytes || 0)); const sha = await sha256(r.file);
  res.json({ uuid, size: r.size, md5: r.md5, sha256: sha });
});
app.get('/api/servers/:id/backups/:uuid/download', (req, res) => { const f = backupFile(Number(req.params.id), String(req.params.uuid)); const st = fs.statSync(f); res.setHeader('Content-Length', st.size); res.type('application/zip'); fs.createReadStream(f).pipe(res); });
app.put('/api/servers/:id/backups/:uuid/upload', async (req, res) => {
  const f = backupFile(Number(req.params.id), String(req.params.uuid)); const max = Number(req.query.maxBytes || 0); await fs.promises.mkdir(path.dirname(f), { recursive: true });
  let n = 0; await new Promise<void>((ok, fail) => { const w = fs.createWriteStream(f); req.on('data', (c: Buffer) => { n += c.length; if (max && n > max) { req.destroy(); w.destroy(); fail(Object.assign(new Error('Backup exceeds backup storage limit'), { status: 507 })); } }); req.pipe(w); w.on('finish', () => ok()); w.on('error', fail); }).catch(e => { fs.rmSync(f, { force: true }); throw e; });
  res.json({ uuid: req.params.uuid, size: n, sha256: await sha256(f) });
});
app.delete('/api/servers/:id/backups/:uuid', async (req, res) => { await fs.promises.rm(backupFile(Number(req.params.id), String(req.params.uuid)), { force: true }); res.json({ ok: true }); });
app.post('/api/servers/:id/backups/:uuid/restore', J, async (req, res) => {
  const inst = getInst(req); if (inst.busy) throw Object.assign(new Error(`Busy: ${inst.busy}`), { status: 409 }); inst.busy = 'restore';
  try { const r = await restoreArchive(inst, backupFile(inst.id, String(req.params.uuid)), !!req.body.truncate); inst.log(`[OGHOST] Backup ${req.params.uuid} restored (${fmt(r.bytes)})`); res.json(r); } finally { inst.busy = null; }
});

// ---- Google Drive (panel passes a short-lived access token only)
app.post('/api/servers/:id/drive/upload', J, async (req, res) => {
  const inst = getInst(req); if (inst.busy) throw Object.assign(new Error(`Busy: ${inst.busy}`), { status: 409 });
  inst.busy = 'drive-backup'; const tmp = tempFile(`drive-${inst.id}.zip`); const { accessToken, parentId, name, apiBase } = req.body;
  try {
    const free = diskInfo().free; if (inst.disk.used > free * 0.9) throw Object.assign(new Error('Not enough temporary space on the node to stage the backup'), { status: 507 });
    const z = await createZip(inst.dir, ['/'], tmp);
    const up = await driveResumableUpload({ apiBase: apiBase || 'https://www.googleapis.com', accessToken, parentId, name, file: tmp, onProgress: (d, t) => inst.emit('backup-progress', { phase: 'upload', done: d, total: t }) });
    res.json({ ...up, localMd5: z.md5 });
  } finally { await fs.promises.rm(tmp, { force: true }); inst.busy = null; }
});
app.post('/api/servers/:id/drive/restore', J, async (req, res) => {
  const inst = getInst(req); if (inst.isActive()) throw Object.assign(new Error('Stop the server before restoring'), { status: 409 });
  if (inst.busy) throw Object.assign(new Error(`Busy: ${inst.busy}`), { status: 409 }); inst.busy = 'drive-restore';
  const tmp = tempFile(`restore-${inst.id}.zip`); let safety: any = null;
  try {
    await driveDownload({ apiBase: req.body.apiBase || 'https://www.googleapis.com', accessToken: req.body.accessToken, fileId: req.body.fileId, file: tmp, maxBytes: diskInfo().free * 0.8 });
    if (req.body.safetyBackupUuid) { try { inst.busy = null; const s = await createLocalBackup(inst, String(req.body.safetyBackupUuid), 0); safety = { uuid: req.body.safetyBackupUuid, size: s.size, sha256: await sha256(s.file) }; } catch (e: any) { safety = { error: e.message }; } finally { inst.busy = 'drive-restore'; }
      if (safety?.error) throw Object.assign(new Error(`Safety backup failed, restore aborted and no files were changed: ${safety.error}`), { status: 507 }); }
    const r = await restoreArchive(inst, tmp, req.body.truncate !== false); inst.log(`[OGHOST] Restored Google Drive backup (${fmt(r.bytes)})`);
    res.json({ ...r, safety });
  } finally { await fs.promises.rm(tmp, { force: true }); inst.busy = null; }
});

// ---- Plugins
app.get('/api/servers/:id/plugins', async (req, res) => res.json({ plugins: await listPlugins(getInst(req).dir) }));
app.post('/api/servers/:id/plugins/install', J, async (req, res) => {
  const inst = getInst(req); const { url, filename, folder, hash, allowHosts, replace } = req.body;
  if (!/^[A-Za-z0-9 ._+()\-]{1,128}\.jar$/.test(filename)) throw Object.assign(new Error('Invalid plugin filename'), { status: 400 });
  if (!['plugins', 'mods'].includes(folder)) throw Object.assign(new Error('Invalid folder'), { status: 400 });
  const dir = path.join(inst.dir, folder); await fs.promises.mkdir(dir, { recursive: true });
  const target = path.join(dir, filename); let backedUp: string[] = [];
  const toReplace: string[] = (replace || []).filter((f: string) => /^[^/]+\.jar$/.test(f));
  if (fs.existsSync(target)) toReplace.push(filename);
  if (toReplace.length) { const bdir = path.join(inst.dir, '.oghost', 'plugin-backups', String(Date.now())); await fs.promises.mkdir(bdir, { recursive: true }); for (const f of new Set(toReplace)) { const src = path.join(dir, f); if (fs.existsSync(src)) { await fs.promises.rename(src, path.join(bdir, f)); backedUp.push(`/.oghost/plugin-backups/${path.basename(bdir)}/${f}`); } } }
  try { await downloadTo(url, target, { disk: inst.disk, hash, allowHosts }); }
  catch (e) { for (const b of backedUp) await fs.promises.rename(path.join(inst.dir, b), path.join(dir, path.basename(b))).catch(() => {}); throw e; }
  const scan = await scanFile(target, 'plugin');
  if (scan.level === 'high_risk') { await fs.promises.rename(target, target + '.quarantined'); report('scan', inst.id, { phase: 'plugin-install', results: [{ file: `/${folder}/${filename}`, mode: 'plugin', ...summary(scan) }] }); throw Object.assign(new Error('Plugin failed the security scan and was quarantined'), { status: 422 }); }
  res.json({ ok: true, file: `${folder}/${filename}`, backedUp, scan: summary(scan) });
});
app.post('/api/servers/:id/plugins/delete', J, async (req, res) => {
  const inst = getInst(req); const f = String(req.body.file); if (!/^(plugins|mods)\/[^/]+\.jar$/.test(f)) throw Object.assign(new Error('Invalid plugin path'), { status: 400 });
  await fs.promises.rm(path.join(inst.dir, f), { force: true }); res.json({ ok: true });
});

// ---- Version changer: back up current server JAR/libraries, apply new spec, reinstall. Rollback supported.
app.post('/api/servers/:id/version', J, async (req, res) => {
  const inst = getInst(req); if (inst.isActive()) throw Object.assign(new Error('Stop the server before changing version'), { status: 409 });
  const id = `v${Date.now()}`; const bdir = path.join(inst.dir, '.oghost', 'version-backups', id); await fs.promises.mkdir(bdir, { recursive: true });
  const items = fs.readdirSync(inst.dir).filter(f => /\.jar$/i.test(f) || ['libraries', 'versions', 'user_jvm_args.txt', 'run.sh', 'bedrock_server', 'PocketMine-MP.phar'].includes(f));
  for (const f of items) await fs.promises.cp(path.join(inst.dir, f), path.join(bdir, f), { recursive: true });
  fs.writeFileSync(path.join(bdir, 'oghost-spec.json'), JSON.stringify({ variables: inst.spec.variables, egg: inst.spec.egg.slug, startup: inst.spec.startup }));
  inst.updateSpec(req.body.spec as AgentServerSpec);
  try { for (const f of items.filter(f => /\.jar$/i.test(f))) await fs.promises.rm(path.join(inst.dir, f), { force: true }); const r = await inst.install(true); res.json({ ok: true, rollbackId: id, ...r }); }
  catch (e: any) { for (const f of items) await fs.promises.cp(path.join(bdir, f), path.join(inst.dir, f), { recursive: true, force: true }); inst.setState('offline'); throw Object.assign(new Error(`Version change failed and was rolled back: ${e.message}`), { status: 502, rollbackId: id }); }
});
app.post('/api/servers/:id/version/rollback', J, async (req, res) => {
  const inst = getInst(req); if (inst.isActive()) throw Object.assign(new Error('Stop the server first'), { status: 409 });
  const id = String(req.body.rollbackId); if (!/^v\d+$/.test(id)) throw Object.assign(new Error('Invalid rollback id'), { status: 400 });
  const bdir = path.join(inst.dir, '.oghost', 'version-backups', id); if (!fs.existsSync(bdir)) throw Object.assign(new Error('Rollback point not found'), { status: 404 });
  for (const f of fs.readdirSync(inst.dir)) if (/\.jar$/i.test(f) || f === 'libraries') await fs.promises.rm(path.join(inst.dir, f), { recursive: true, force: true });
  for (const f of fs.readdirSync(bdir)) if (f !== 'oghost-spec.json') await fs.promises.cp(path.join(bdir, f), path.join(inst.dir, f), { recursive: true, force: true });
  res.json({ ok: true, previous: JSON.parse(fs.readFileSync(path.join(bdir, 'oghost-spec.json'), 'utf8')) });
});
app.get('/api/servers/:id/version/rollbacks', (req, res) => { const d = path.join(getInst(req).dir, '.oghost', 'version-backups'); res.json({ points: fs.existsSync(d) ? fs.readdirSync(d).filter(f => /^v\d+$/.test(f)).map(f => { let meta = {}; try { meta = JSON.parse(fs.readFileSync(path.join(d, f, 'oghost-spec.json'), 'utf8')); } catch { /* */ } return { id: f, at: new Date(Number(f.slice(1))).toISOString(), ...meta }; }) : [] }); });

// ---- Transfer / clone / export / import (streamed archives)
app.get('/api/servers/:id/archive', async (req, res) => {
  const inst = getInst(req); const tmp = tempFile(`export-${inst.id}.zip`);
  try { const z = await createZip(inst.dir, ['/'], tmp); res.setHeader('Content-Length', z.size); res.setHeader('X-MD5', z.md5); res.type('application/zip'); await new Promise((r, j) => fs.createReadStream(tmp).pipe(res).on('finish', r).on('error', j)); }
  finally { await fs.promises.rm(tmp, { force: true }); }
});
app.put('/api/servers/:id/import', async (req, res) => {
  const inst = getInst(req); const tmp = tempFile(`import-${inst.id}.zip`); const declared = Number(req.headers['x-file-size'] || req.headers['content-length'] || 0);
  if (inst.disk.limitBytes && declared > inst.disk.limitBytes * 1.2) throw Object.assign(new Error('Archive too large for the disk allocation'), { status: 507 });
  try {
    let n = 0; await new Promise<void>((ok, fail) => { const w = fs.createWriteStream(tmp); req.on('data', (c: Buffer) => { n += c.length; if (inst.disk.limitBytes && n > inst.disk.limitBytes * 1.2) { req.destroy(); fail(Object.assign(new Error('Archive too large'), { status: 507 })); } }); req.pipe(w); w.on('finish', () => ok()); w.on('error', fail); });
    const r = await restoreArchive(inst, tmp, req.query.truncate !== '0'); res.json({ ok: true, ...r });
  } finally { await fs.promises.rm(tmp, { force: true }); }
});

app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
  const status = err instanceof PathSecurityError ? 400 : err.code === 'ENOENT' ? 404 : err.code === 'EEXIST' ? 409 : err.status || 500;
  if (status >= 500) console.error('[agent]', err);
  res.status(status).json({ error: err.message || 'Internal error', ...(err.driveKind ? { driveKind: err.driveKind } : {}), ...(err.rollbackId ? { rollbackId: err.rollbackId } : {}) });
});

function statusOf(inst: ServerInstance) {
  return { id: inst.id, state: inst.state, pid: inst.pid, busy: inst.busy, stats: inst.stats, disk: { used: inst.disk.used, reserved: inst.disk.reserved, limit: inst.disk.limitBytes, exceeded: inst.disk.exceeded(), lastScan: inst.disk.lastScan, kernelQuota: inst.quota }, lastExit: inst.lastExit, cpulimitActive: !!inst.cpulimitProc, securityBlocked: inst.spec.securityBlocked };
}
const sha256 = (f: string) => new Promise<string>((res, rej) => { const h = crypto.createHash('sha256'); fs.createReadStream(f).on('data', d => h.update(d)).on('end', () => res(h.digest('hex'))).on('error', rej); });

// ---- Socket.IO console (panel connects per server with a scoped token)
const server = config.tlsCert && config.tlsKey ? https.createServer({ cert: fs.readFileSync(config.tlsCert), key: fs.readFileSync(config.tlsKey) }, app) : http.createServer(app);
const io = new IOServer(server, { path: '/ws', cors: { origin: false }, maxHttpBufferSize: 1e5 });
io.use((socket, next) => {
  try { const p = verifyToken<{ aud: string; nodeId: number; serverId: number; perms: string[] }>(String(socket.handshake.auth?.token), config.secret); if (p.aud !== 'node-ws' || p.nodeId !== config.nodeId || !servers.has(p.serverId)) throw new Error('bad scope'); (socket.data as any).p = p; next(); }
  catch (e: any) { next(new Error(`Unauthorized: ${e.message}`)); }
});
io.on('connection', (socket) => {
  const p = (socket.data as any).p as { serverId: number; perms: string[] }; const inst = servers.get(p.serverId)!;
  socket.join(`s${inst.id}`);
  socket.emit('status', statusOf(inst)); socket.emit('backlog', inst.console.slice(-500));
  socket.on('command', (cmd: string, ack?: (r: any) => void) => { try { if (!p.perms.includes('control.console')) throw new Error('No console permission'); inst.command(cmd); ack?.({ ok: true }); } catch (e: any) { ack?.({ error: e.message }); } });
  socket.on('power', async (action: string, ack?: (r: any) => void) => { try { const need = action === 'start' ? 'control.start' : action === 'restart' ? 'control.restart' : 'control.stop'; if (!p.perms.includes(need)) throw new Error('No permission'); if (action === 'start') await inst.start(); else if (action === 'stop') inst.stop(); else if (action === 'kill') inst.kill(); else if (action === 'restart') inst.restart().catch(e => inst.log(`[OGHOST] ${e.message}`)); ack?.({ ok: true }); } catch (e: any) { ack?.({ error: e.message }); } });
});
function attach(inst: ServerInstance) {
  inst.on('console', (l: string) => io.to(`s${inst.id}`).emit('console', l));
  inst.on('state', () => io.to(`s${inst.id}`).emit('status', statusOf(inst)));
  inst.on('backup-progress', (p) => io.to(`s${inst.id}`).emit('backup-progress', p));
}
for (const i of servers.values()) attach(i);

// ---- Periodic tasks: stats, monitoring, disk accounting, heartbeat
setInterval(() => { for (const i of servers.values()) if (i.pid) { i.sampleStats(); io.to(`s${i.id}`).emit('stats', { ...i.stats, disk: i.disk.used, diskLimit: i.disk.limitBytes, state: i.state }); try { monitor(i); } catch (e) { console.error('[monitor]', e); } } }, 2000);
setInterval(async () => {
  for (const i of servers.values()) {
    const before = i.disk.exceeded(); await i.disk.rescan(); i.stats.diskBytes = i.disk.used; scanExecutables(i);
    if (i.disk.exceeded() && !before) {
      report('disk_exceeded', i.id, { used: i.disk.used, limit: i.disk.limitBytes });
      i.log(`\x1b[31m[OGHOST]\x1b[0m Disk allocation exceeded: ${fmt(i.disk.used)} / ${fmt(i.disk.limitBytes)}. Uploads are blocked.`);
      if (config.diskExceededAction === 'stop' && i.isActive()) { i.log('[OGHOST] Stopping server (DISK_EXCEEDED_ACTION=stop).'); i.stop(); }
    } else if (!i.disk.unlimited && i.disk.used > i.disk.limitBytes * 0.9) report('disk_warning', i.id, { used: i.disk.used, limit: i.disk.limitBytes });
  }
}, config.diskScanSeconds * 1000);

let lastQuota = { fsType: 'unknown', quotaSupport: 'unknown' };
async function heartbeatPayload(): Promise<NodeHeartbeat> {
  const b = systemBasics(); const m = memInfo(); const d = diskInfo();
  return {
    nodeId: config.nodeId, version: OGHOST_VERSION, arch: b.arch, platform: b.platform, uptime: b.uptime,
    cpu: { cores: b.cores, load: b.load, usagePercent: cpuUsage() }, memory: m, disk: { ...d, ...lastQuota }, network: netTotals(),
    java: await javaList(), cpulimit: detectCpulimit(), runningAsRoot: process.getuid?.() === 0,
    servers: [...servers.values()].map(i => ({ id: i.id, state: i.state, pid: i.pid, cpu: i.stats.cpu, memory: i.stats.memory, diskBytes: i.disk.used })),
  };
}
async function heartbeat() {
  try { const r: any = await panelFetch('/api/remote/heartbeat', await heartbeatPayload()); if (Array.isArray(r.trusted)) { trusted.clear(); r.trusted.forEach((h: string) => trusted.add(h)); } }
  catch (e: any) { console.error(`[agent] heartbeat failed: ${e.message}`); }
}
quotaSupport().then(q => { lastQuota = q; });
setInterval(heartbeat, config.heartbeatSeconds * 1000); setTimeout(heartbeat, 1000);

if (process.getuid?.() === 0) console.warn('[agent] WARNING: running as root. Customer processes will be started with per-server UIDs (RUN_AS_UID_BASE) or refused.');
server.listen(config.port, config.host, () => console.log(`[agent] OGHOST node ${config.nodeId} listening on ${config.tlsCert ? 'https' : 'http'}://${config.host}:${config.port} data=${config.dataRoot}`));
const shutdown = () => { console.log('[agent] shutting down: stopping servers gracefully'); for (const i of servers.values()) if (i.isActive()) i.stop(); setTimeout(() => process.exit(0), 15000).unref(); if (![...servers.values()].some(i => i.isActive())) process.exit(0); };
process.on('SIGTERM', shutdown); process.on('SIGINT', shutdown);
