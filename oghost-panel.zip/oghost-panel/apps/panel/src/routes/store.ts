import { Router } from 'express';
import { q, one, parse } from '../db';
import { body, z, HttpError, idParam, paginate } from '../lib/http';
import { requireAuth, requireVerified } from '../lib/auth';
import { getSetting } from '../services/settings';
import { checkout, validateCoupon, getPlan, changePlan, cancelService, renewalInvoice, payInvoiceWithCoins } from '../services/billing';
import { coinName, coinsEnabled } from '../services/coins';
import { enabledGateways, startPayment, submitReference, verifyRazorpayCheckout, refreshPayment, type Gateway } from '../services/gateways';
import { audit } from '../services/audit';
import { dispatchWebhook } from '../services/webhooks';

export const storeRouter = Router();
const planCols = 'p.id, p.product_id, p.name, p.description, p.price_cents, p.currency, p.billing_cycle, p.setup_fee_cents, p.memory_mb, p.cpu_percent, p.disk_mb, p.databases, p.backups, p.allocations, p.egg_id, p.location_id, p.stock, p.sort, p.coin_price, p.max_per_user';

// Public catalogue (no auth needed so the landing page can show plans)
storeRouter.get('/catalog', async (_req, res) => {
  const enabled = !!(await getSetting('store.enabled'));
  const categories = await q('SELECT id, name, slug, description FROM product_categories WHERE visible = 1 ORDER BY sort, id');
  const products = await q('SELECT pr.id, pr.category_id, pr.name, pr.slug, pr.type, pr.description FROM products pr JOIN product_categories pc ON pc.id = pr.category_id WHERE pr.visible = 1 AND pc.visible = 1 ORDER BY pr.sort, pr.id');
  const plans = await q(`SELECT ${planCols} FROM plans p JOIN products pr ON pr.id = p.product_id JOIN product_categories pc ON pc.id = pr.category_id WHERE p.visible = 1 AND pr.visible = 1 AND pc.visible = 1 ORDER BY p.sort, p.price_cents`);
  const eggs = await q("SELECT id, slug, name, category FROM eggs ORDER BY category, name");
  const locations = await q('SELECT l.id, l.short, l.name, (SELECT COUNT(*) FROM nodes n WHERE n.location_id = l.id AND n.status = \'online\' AND n.maintenance = 0) AS online_nodes FROM locations l ORDER BY l.name');
  res.json({ enabled, categories, products, plans, eggs, locations, currency: await getSetting('app.currency'), coins: { enabled: await coinsEnabled(), name: await coinName() } });
});

storeRouter.use(requireAuth);
storeRouter.get('/gateways', async (_req, res) => res.json({ gateways: await enabledGateways() }));
storeRouter.post('/coupon', async (req, res) => {
  const b = body(z.object({ code: z.string().min(1).max(50), planId: z.number().int() }), req);
  const plan = await getPlan(b.planId); const subtotal = plan.price_cents + plan.setup_fee_cents;
  const { coupon, discount } = await validateCoupon(b.code, plan.id, subtotal);
  res.json({ code: coupon.code, type: coupon.type, value: coupon.value, recurring: !!coupon.recurring, discount, total: subtotal - discount });
});
storeRouter.post('/checkout', requireVerified, async (req, res) => {
  const b = body(z.object({ planId: z.number().int(), serverName: z.string().trim().min(1).max(100), eggId: z.number().int().optional(), locationId: z.number().int().optional(), variables: z.record(z.string(), z.string().max(500)).optional(), coupon: z.string().max(50).optional(), payWith: z.enum(['money', 'ogcoins']).default('money') }), req);
  const r = await checkout(req.user!.id, b.planId, { serverName: b.serverName, eggId: b.eggId, locationId: b.locationId, variables: b.variables }, b.coupon, b.payWith);
  await audit(req, 'store.checkout', { type: 'order', id: r.orderId }, { planId: b.planId, coupon: b.coupon, payWith: b.payWith });
  void dispatchWebhook('order.created', { orderId: r.orderId, userId: req.user!.id, planId: b.planId, total: r.total });
  res.status(201).json(r);
});

storeRouter.get('/services', async (req, res) => {
  res.json({ services: await q(`SELECT sv.id, sv.plan_id, sv.status, sv.price_cents, sv.currency, sv.billing_cycle, sv.next_due_at, sv.cancel_at_period_end, sv.coin_price, sv.auto_renew_coins, p.coin_price AS plan_coin_price, sv.created_at, sv.cancelled_at, sv.server_id, s.name AS server_name, s.node_server_id, p.name AS plan_name, p.product_id, pr.name AS product_name, p.memory_mb, p.cpu_percent, p.disk_mb
    FROM services sv JOIN plans p ON p.id = sv.plan_id JOIN products pr ON pr.id = p.product_id LEFT JOIN servers s ON s.id = sv.server_id WHERE sv.user_id = ? ORDER BY sv.id DESC`, [req.user!.id]) });
});
storeRouter.get('/services/:id/plans', async (req, res) => {
  const svc: any = await one('SELECT sv.*, p.product_id FROM services sv JOIN plans p ON p.id = sv.plan_id WHERE sv.id = ? AND sv.user_id = ?', [idParam(req), req.user!.id]); if (!svc) throw new HttpError(404, 'Service not found');
  res.json({ current: svc.plan_id, plans: await q(`SELECT ${planCols} FROM plans p WHERE p.product_id = ? AND p.visible = 1 AND p.billing_cycle = ? ORDER BY p.price_cents`, [svc.product_id, svc.billing_cycle]) });
});
const ownService = async (req: any) => { const svc: any = await one("SELECT * FROM services WHERE id = ? AND user_id = ? AND status IN ('active','suspended')", [idParam(req), req.user!.id]); if (!svc) throw new HttpError(404, 'Service not found'); return svc; };
storeRouter.post('/services/:id/renew', async (req, res) => {
  const r = await renewalInvoice(await ownService(req), { prepayCheck: true });
  res.status(r.existing ? 200 : 201).json(r);
});
/** Renew (or prepay the next period) straight from the OGCoins wallet. */
storeRouter.post('/services/:id/renew-coins', async (req, res) => {
  const svc = await ownService(req);
  const inv = await renewalInvoice(svc, { prepayCheck: true });
  if ((inv as any).free) return res.json({ ...inv, paid: true });
  const p = await payInvoiceWithCoins(inv.invoiceId, req.user!.id);
  await audit(req, 'store.renew_coins', { type: 'service', id: svc.id }, { invoiceId: inv.invoiceId, coins: p.coins });
  res.json({ invoiceId: inv.invoiceId, ...p });
});
storeRouter.put('/services/:id/auto-renew', async (req, res) => {
  const b = body(z.object({ enabled: z.boolean() }), req); const svc = await ownService(req);
  if (b.enabled && (svc.coin_price ?? (await getPlan(svc.plan_id)).coin_price) == null) throw new HttpError(422, `This plan cannot be renewed with ${await coinName()}`);
  await q('UPDATE services SET auto_renew_coins = ?, auto_renew_notified_at = NULL WHERE id = ?', [b.enabled ? 1 : 0, svc.id]); res.json({ ok: true, autoRenew: b.enabled });
});
storeRouter.post('/services/:id/change-plan', requireVerified, async (req, res) => {
  const b = body(z.object({ planId: z.number().int() }), req);
  const r = await changePlan(req.user!.id, idParam(req), b.planId); await audit(req, 'store.change_plan', { type: 'service', id: idParam(req) }, b); res.json(r);
});
storeRouter.post('/services/:id/cancel', async (req, res) => {
  const b = body(z.object({ immediate: z.boolean().default(false), reason: z.string().max(500).optional() }), req);
  await cancelService(req.user!.id, idParam(req), b.immediate); await audit(req, 'store.cancel', { type: 'service', id: idParam(req) }, b); res.json({ ok: true });
});
storeRouter.post('/services/:id/uncancel', async (req, res) => {
  const svc: any = await one("SELECT * FROM services WHERE id = ? AND user_id = ? AND status = 'active'", [idParam(req), req.user!.id]); if (!svc) throw new HttpError(404, 'Service not found');
  await q('UPDATE services SET cancel_at_period_end = 0 WHERE id = ?', [svc.id]); res.json({ ok: true });
});

storeRouter.get('/orders', async (req, res) => {
  const p = paginate(req);
  res.json({ orders: await q('SELECT o.id, o.uuid, o.kind, o.status, o.amount_cents, o.currency, o.created_at, o.service_id, pl.name AS plan_name FROM orders o JOIN plans pl ON pl.id = o.plan_id WHERE o.user_id = ? ORDER BY o.id DESC LIMIT ? OFFSET ?', [req.user!.id, p.limit, p.offset]) });
});
storeRouter.get('/invoices', async (req, res) => {
  const p = paginate(req);
  res.json({ invoices: await q('SELECT id, number, status, subtotal_cents, discount_cents, total_cents, coin_total, currency, due_at, paid_at, created_at, service_id, order_id FROM invoices WHERE user_id = ? ORDER BY id DESC LIMIT ? OFFSET ?', [req.user!.id, p.limit, p.offset]) });
});
storeRouter.get('/invoices/:id', async (req, res) => {
  const inv: any = await one('SELECT * FROM invoices WHERE id = ? AND user_id = ?', [idParam(req), req.user!.id]); if (!inv) throw new HttpError(404, 'Invoice not found');
  const payments = await q('SELECT id, gateway, status, amount_cents, refunded_cents, currency, reference, failure_reason, created_at FROM payments WHERE invoice_id = ? ORDER BY id DESC', [inv.id]);
  res.json({ invoice: { ...inv, items: parse(inv.items, []) }, payments, company: { name: await getSetting('app.name'), address: await getSetting('billing.companyAddress'), taxId: await getSetting('billing.taxId') } });
});
storeRouter.post('/invoices/:id/pay-coins', async (req, res) => {
  const r = await payInvoiceWithCoins(idParam(req), req.user!.id); await audit(req, 'store.pay_coins', { type: 'invoice', id: idParam(req) }, { coins: r.coins }); res.json(r);
});
storeRouter.post('/invoices/:id/pay', async (req, res) => {
  const b = body(z.object({ gateway: z.enum(['razorpay', 'stripe', 'cashfree', 'upi', 'manual']), phone: z.string().max(20).optional() }), req);
  res.json(await startPayment(idParam(req), req.user!, b.gateway as Gateway, { phone: b.phone }));
});
storeRouter.post('/payments/:id/reference', async (req, res) => {
  const b = body(z.object({ reference: z.string().trim().min(6).max(64) }), req);
  await submitReference(idParam(req), req.user!.id, b.reference); res.json({ ok: true, status: 'awaiting_approval' });
});
storeRouter.post('/payments/razorpay/verify', async (req, res) => {
  const b = body(z.object({ razorpay_order_id: z.string().max(100), razorpay_payment_id: z.string().max(100), razorpay_signature: z.string().max(200) }), req);
  res.json(await verifyRazorpayCheckout(req.user!.id, b));
});
storeRouter.post('/payments/:id/refresh', async (req, res) => res.json(await refreshPayment(idParam(req), req.user!.id)));
