import { useCallback, useEffect, useRef, useState } from 'react';
import { api } from './api';

/** Loads JSON from the API; reload() refetches; optional polling interval (ms). */
export function useApi<T = any>(path: string | null, deps: unknown[] = [], pollMs?: number) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(!!path);
  const alive = useRef(true);
  const load = useCallback(async (quiet = false) => {
    if (!path) return; if (!quiet) setLoading(true);
    try { const d = await api<T>('GET', path); if (alive.current) { setData(d); setError(null); } }
    catch (e: any) { if (alive.current) setError(e.message); }
    finally { if (alive.current) setLoading(false); }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [path, ...deps]);
  useEffect(() => { alive.current = true; load(); let t: any; if (pollMs) t = setInterval(() => load(true), pollMs); return () => { alive.current = false; if (t) clearInterval(t); }; }, [load, pollMs]);
  return { data, error, loading, reload: () => load(true), setData };
}

/** Wraps an async action with busy state + toast-friendly error handling. */
export function useAction() {
  const [busy, setBusy] = useState<string | null>(null);
  const run = useCallback(async <T,>(key: string, fn: () => Promise<T>, okMsg?: string): Promise<T | undefined> => {
    setBusy(key);
    try { const r = await fn(); if (okMsg) toast(okMsg, 'success'); return r; }
    catch (e: any) { toast(e.message || 'Something went wrong', 'error'); return undefined; }
    finally { setBusy(null); }
  }, []);
  return { busy, run };
}

type ToastKind = 'success' | 'error' | 'info';
export function toast(message: string, kind: ToastKind = 'info') { window.dispatchEvent(new CustomEvent('oghost:toast', { detail: { message, kind } })); }
