import { useMemo, useRef, useState } from 'react';
import { Folder, File as FileIcon, FileCode, Upload, FolderPlus, FilePlus, Trash2, Archive, Search, ArrowUp, Download, Pencil, Copy, Lock, Link2, RefreshCw } from 'lucide-react';
import { useApi, useAction, toast } from '../../lib/hooks';
import { api, post, upload } from '../../lib/api';
import { bytes, date, cls } from '../../lib/format';
import { Card, Confirm, Empty, ErrorBox, Field, Loading, Modal, Notice, Spinner } from '../../components/ui';
import { useServer } from './ServerLayout';

const join = (dir: string, name: string) => `${dir.replace(/\/$/, '')}/${name}`.replace(/^\/+/, '/');
const parent = (p: string) => p.replace(/\/[^/]*\/?$/, '') || '/';
type Ent = { name: string; path: string; directory: boolean; symlink: boolean; size: number; mode: string; modified: string; editable: boolean };

export function FilesTab() {
  const { id, can, server } = useServer(); const base = `/api/servers/${id}/files`;
  const [dir, setDir] = useState('/'); const { data, error, loading, reload } = useApi<any>(`${base}/list?path=${encodeURIComponent(dir)}`, [dir]);
  const [sel, setSel] = useState<Set<string>>(new Set()); const { busy, run } = useAction();
  const [edit, setEdit] = useState<{ path: string; content: string; original: string } | null>(null);
  const [prompt, setPrompt] = useState<null | { kind: 'mkdir' | 'newfile' | 'rename' | 'chmod' | 'compress' | 'copy'; ent?: Ent; value: string }>(null);
  const [del, setDel] = useState<string[] | null>(null); const [uploads, setUploads] = useState<Record<string, number>>({});
  const [q, setQ] = useState(''); const [results, setResults] = useState<any[] | null>(null);
  const fileInput = useRef<HTMLInputElement>(null); const w = can('file.write');
  const entries: Ent[] = data?.entries || [];
  const go = (p: string) => { setDir(p); setSel(new Set()); setResults(null); };
  const crumbs = useMemo(() => { const parts = dir.split('/').filter(Boolean); return [{ name: 'home', path: '/' }, ...parts.map((p, i) => ({ name: p, path: '/' + parts.slice(0, i + 1).join('/') }))]; }, [dir]);
  const open = (e: Ent) => { if (e.directory) return go(e.path); if (!e.editable) return void (window.location.href = `${base}/download?path=${encodeURIComponent(e.path)}`); run('open', async () => { const c = await api<string>('GET', `${base}/contents?path=${encodeURIComponent(e.path)}`, undefined, { raw: true }); setEdit({ path: e.path, content: c, original: c }); }); };
  const save = () => run('save', async () => { await api('POST', `${base}/write?path=${encodeURIComponent(edit!.path)}`, new Blob([edit!.content]), {}); setEdit({ ...edit!, original: edit!.content }); reload(); }, 'Saved');
  const doUpload = async (files: FileList | null) => {
    if (!files) return; const max = (server.limits.maxUploadMb || 0) * 1048576;
    for (const f of Array.from(files)) {
      if (max && f.size > max) { toast(`${f.name} exceeds the ${server.limits.maxUploadMb} MB upload limit`, 'error'); continue; }
      setUploads(u => ({ ...u, [f.name]: 0 }));
      try { await upload(`${base}/upload?directory=${encodeURIComponent(dir)}&name=${encodeURIComponent(f.name)}`, f, p => setUploads(u => ({ ...u, [f.name]: p }))); toast(`Uploaded ${f.name}`, 'success'); }
      catch (e: any) { toast(`${f.name}: ${e.message}`, 'error'); }
      setUploads(u => { const n = { ...u }; delete n[f.name]; return n; });
    }
    reload();
  };
  const submitPrompt = () => run('prompt', async () => {
    const p = prompt!; const v = p.value.trim(); if (!v) return;
    if (p.kind === 'mkdir') await post(`${base}/mkdir`, { path: join(dir, v) });
    else if (p.kind === 'newfile') { await api('POST', `${base}/write?path=${encodeURIComponent(join(dir, v))}`, new Blob(['']), {}); }
    else if (p.kind === 'rename') await post(`${base}/rename`, { from: p.ent!.path, to: v.startsWith('/') ? v : join(dir, v) });
    else if (p.kind === 'copy') await post(`${base}/copy`, { items: [{ from: p.ent!.path, to: v.startsWith('/') ? v : join(dir, v) }] });
    else if (p.kind === 'chmod') { if (!/^[0-7]{3}$/.test(v)) throw new Error('Use three octal digits, e.g. 644'); await post(`${base}/chmod`, { path: p.ent!.path, mode: v }); }
    else if (p.kind === 'compress') await post(`${base}/compress`, { root: dir, paths: [...sel].map(n => join(dir, n)), name: v.endsWith('.zip') ? v : `${v}.zip` });
    setPrompt(null); setSel(new Set()); reload();
  });
  const extract = (e: Ent) => run('extract', () => post(`${base}/extract`, { file: e.path, destination: dir }).then(reload), 'Archive extracted');
  const doSearch = () => run('search', async () => { const r = await api('GET', `${base}/search?q=${encodeURIComponent(q)}&path=${encodeURIComponent(dir)}`); setResults(r.results); });
  const toggle = (n: string) => setSel(s => { const x = new Set(s); x.has(n) ? x.delete(n) : x.add(n); return x; });

  if (edit) return <Editor edit={edit} setEdit={setEdit} save={save} busy={busy === 'save'} writable={w} />;
  return (
    <Card pad={false}>
      <div className="flex flex-wrap items-center gap-2 border-b border-ink-800 p-3">
        <div className="flex min-w-0 flex-1 flex-wrap items-center gap-1 font-mono text-sm">{crumbs.map((c, i) => <span key={c.path} className="flex items-center gap-1">{i > 0 && <span className="text-ink-600">/</span>}<button className="rounded px-1 hover:bg-ink-800 hover:text-white" onClick={() => go(c.path)}>{c.name}</button></span>)}</div>
        <div className="flex items-center gap-1"><input className="input h-8 w-36 py-1 text-xs" placeholder="Search files" value={q} onChange={e => setQ(e.target.value)} onKeyDown={e => e.key === 'Enter' && q.length >= 2 && doSearch()} /><button className="btn-ghost btn-sm" disabled={q.length < 2} onClick={doSearch}>{busy === 'search' ? <Spinner /> : <Search className="h-4 w-4" />}</button></div>
        <button className="btn-ghost btn-sm" onClick={reload} title="Refresh"><RefreshCw className="h-4 w-4" /></button>
        {w && <><button className="btn-secondary btn-sm" onClick={() => setPrompt({ kind: 'newfile', value: '' })}><FilePlus className="h-4 w-4" />File</button><button className="btn-secondary btn-sm" onClick={() => setPrompt({ kind: 'mkdir', value: '' })}><FolderPlus className="h-4 w-4" />Folder</button><button className="btn-primary btn-sm" onClick={() => fileInput.current?.click()}><Upload className="h-4 w-4" />Upload</button><input ref={fileInput} type="file" multiple className="hidden" onChange={e => { doUpload(e.target.files); e.target.value = ''; }} /></>}
      </div>
      {Object.keys(uploads).length > 0 && <div className="space-y-1 border-b border-ink-800 p-3 text-xs">{Object.entries(uploads).map(([n, p]) => <div key={n} className="flex items-center gap-2"><span className="w-48 truncate">{n}</span><div className="h-1.5 flex-1 rounded bg-ink-800"><div className="h-full rounded bg-brand-600" style={{ width: `${p}%` }} /></div><span>{p}%</span></div>)}</div>}
      {sel.size > 0 && <div className="flex flex-wrap items-center gap-2 border-b border-ink-800 bg-ink-850 p-2 text-sm"><span className="px-2">{sel.size} selected</span>{can('file.archive') && <button className="btn-secondary btn-sm" onClick={() => setPrompt({ kind: 'compress', value: `archive-${Date.now()}.zip` })}><Archive className="h-4 w-4" />Compress</button>}{can('file.delete') && <button className="btn-danger btn-sm" onClick={() => setDel([...sel].map(n => join(dir, n)))}><Trash2 className="h-4 w-4" />Delete</button>}<button className="btn-ghost btn-sm" onClick={() => setSel(new Set())}>Clear</button></div>}
      {results ? <div className="p-3"><div className="mb-2 flex items-center justify-between text-sm"><span>{results.length} result{results.length === 1 ? '' : 's'} for “{q}”</span><button className="btn-ghost btn-sm" onClick={() => setResults(null)}>Back to folder</button></div>{results.map(r => <button key={r.path} className="flex w-full items-center gap-2 rounded px-2 py-1.5 text-left font-mono text-sm hover:bg-ink-850" onClick={() => r.directory ? go(r.path) : go(parent(r.path))}>{r.directory ? <Folder className="h-4 w-4 text-brand-500" /> : <FileIcon className="h-4 w-4 text-ink-400" />}{r.path}<span className="ml-auto text-xs text-ink-500">{r.directory ? '' : bytes(r.size)}</span></button>)}</div>
        : loading && !data ? <Loading /> : error ? <div className="p-4"><ErrorBox error={error} onRetry={reload} /></div> : (
        <div className="divide-y divide-ink-850">
          {dir !== '/' && <button className="flex w-full items-center gap-3 px-4 py-2 text-sm text-ink-400 hover:bg-ink-850" onClick={() => go(parent(dir))}><ArrowUp className="h-4 w-4" />..</button>}
          {!entries.length && <Empty title="This folder is empty" />}
          {entries.map(e => (
            <div key={e.name} className={cls('group flex items-center gap-3 px-4 py-2 text-sm hover:bg-ink-850', sel.has(e.name) && 'bg-brand-950/30')}>
              <input type="checkbox" checked={sel.has(e.name)} onChange={() => toggle(e.name)} className="shrink-0" />
              <button className="flex min-w-0 flex-1 items-center gap-2 text-left" onClick={() => open(e)}>{e.directory ? <Folder className="h-4 w-4 shrink-0 text-brand-500" /> : e.symlink ? <Link2 className="h-4 w-4 shrink-0 text-amber-400" /> : e.editable ? <FileCode className="h-4 w-4 shrink-0 text-ink-300" /> : <FileIcon className="h-4 w-4 shrink-0 text-ink-400" />}<span className="truncate">{e.name}</span>{e.symlink && <span className="text-xs text-amber-400">(symlink — not followed)</span>}</button>
              <span className="hidden w-20 text-right text-xs text-ink-400 sm:block">{e.directory ? '' : bytes(e.size)}</span>
              <span className="hidden w-40 text-right text-xs text-ink-500 md:block">{date(e.modified)}</span>
              <span className="hidden w-10 font-mono text-xs text-ink-500 lg:block">{e.mode}</span>
              <div className="flex shrink-0 gap-0.5 opacity-100 sm:opacity-0 sm:group-hover:opacity-100">
                {!e.directory && <a className="btn-ghost btn-sm px-1.5" title="Download" href={`${base}/download?path=${encodeURIComponent(e.path)}`}><Download className="h-4 w-4" /></a>}
                {w && <button className="btn-ghost btn-sm px-1.5" title="Rename / move" onClick={() => setPrompt({ kind: 'rename', ent: e, value: e.name })}><Pencil className="h-4 w-4" /></button>}
                {w && <button className="btn-ghost btn-sm px-1.5" title="Copy" onClick={() => setPrompt({ kind: 'copy', ent: e, value: `${e.name}.copy` })}><Copy className="h-4 w-4" /></button>}
                {w && <button className="btn-ghost btn-sm px-1.5" title="Permissions" onClick={() => setPrompt({ kind: 'chmod', ent: e, value: e.mode })}><Lock className="h-4 w-4" /></button>}
                {can('file.archive') && /\.zip$/i.test(e.name) && <button className="btn-ghost btn-sm px-1.5" title="Extract here" onClick={() => extract(e)}><Archive className="h-4 w-4" /></button>}
                {can('file.delete') && <button className="btn-ghost btn-sm px-1.5 text-red-400" title="Delete" onClick={() => setDel([e.path])}><Trash2 className="h-4 w-4" /></button>}
              </div>
            </div>))}
        </div>)}
      <div className="border-t border-ink-800 px-4 py-2 text-xs text-ink-500">Every write is checked by the node against the server's disk limit before data is stored. This is application-level enforcement, not a kernel filesystem quota.</div>
      <Modal open={!!prompt} onClose={() => setPrompt(null)} title={{ mkdir: 'New folder', newfile: 'New file', rename: 'Rename or move', chmod: 'Change permissions', compress: 'Compress selection', copy: 'Copy to' }[prompt?.kind || 'mkdir']} footer={<><button className="btn-secondary" onClick={() => setPrompt(null)}>Cancel</button><button className="btn-primary" disabled={!!busy} onClick={submitPrompt}>{busy === 'prompt' && <Spinner />}OK</button></>}>
        <Field label={prompt?.kind === 'chmod' ? 'Mode (octal)' : prompt?.kind === 'rename' || prompt?.kind === 'copy' ? 'New name or absolute path' : 'Name'} hint={prompt?.kind === 'chmod' ? 'Setuid/setgid bits are not allowed.' : undefined}><input autoFocus className="input font-mono" value={prompt?.value || ''} onChange={e => setPrompt(p => p && { ...p, value: e.target.value })} onKeyDown={e => e.key === 'Enter' && submitPrompt()} /></Field>
      </Modal>
      <Confirm open={!!del} onClose={() => setDel(null)} danger title="Delete files" confirmLabel="Delete" busy={busy === 'del'} onConfirm={() => run('del', () => post(`${base}/delete`, { paths: del }).then(() => { setDel(null); setSel(new Set()); reload(); }), 'Deleted')}>
        <p>Permanently delete {del?.length} item{del?.length === 1 ? '' : 's'}? This cannot be undone.</p><ul className="max-h-40 overflow-auto font-mono text-xs text-ink-400">{del?.map(p => <li key={p}>{p}</li>)}</ul>
      </Confirm>
    </Card>
  );
}

function Editor({ edit, setEdit, save, busy, writable }: { edit: { path: string; content: string; original: string }; setEdit: (e: any) => void; save: () => void; busy: boolean; writable: boolean }) {
  const dirty = edit.content !== edit.original;
  return (
    <Card pad={false}>
      <div className="flex flex-wrap items-center gap-2 border-b border-ink-800 p-3"><span className="min-w-0 flex-1 truncate font-mono text-sm">{edit.path}{dirty && <span className="ml-2 text-amber-400">• unsaved</span>}</span>
        <button className="btn-secondary btn-sm" onClick={() => { if (!dirty || confirm('Discard unsaved changes?')) setEdit(null); }}>Close</button>
        {writable && <button className="btn-primary btn-sm" disabled={!dirty || busy} onClick={save}>{busy && <Spinner />}Save</button>}</div>
      {!writable && <Notice className="m-3">You have read-only access to files.</Notice>}
      <textarea spellCheck={false} readOnly={!writable} className="block h-[65vh] w-full resize-none bg-[#09090b] p-4 font-mono text-[13px] leading-5 text-zinc-100 outline-none" value={edit.content}
        onChange={e => setEdit({ ...edit, content: e.target.value })}
        onKeyDown={e => { if ((e.ctrlKey || e.metaKey) && e.key === 's') { e.preventDefault(); if (writable && dirty) save(); } if (e.key === 'Tab') { e.preventDefault(); const t = e.currentTarget; const s = t.selectionStart; const v = t.value.slice(0, s) + '  ' + t.value.slice(t.selectionEnd); setEdit({ ...edit, content: v }); requestAnimationFrame(() => { t.selectionStart = t.selectionEnd = s + 2; }); } }} />
    </Card>
  );
}
