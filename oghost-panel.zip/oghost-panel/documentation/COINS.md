# OGCoins (panel currency)

OGCoins is the panel's own currency. Customers get coins by completing Linkvertise links, by buying them on your Discord (credited by staff/bot or as a redeem code), or from admins. They spend coins to buy servers and to renew plans, either by hand or with auto-renew.

The currency name is configurable (Settings → OGCoins → Currency name). Coins are whole numbers.

## How balances are kept safe

- Every change is a row in `coin_transactions` (amount, balance after, type, reference, actor). `users.coin_balance` is the cached total and has a `CHECK (coin_balance >= 0)` constraint.
- Spending locks the user row (`SELECT … FOR UPDATE`) inside the same DB transaction that marks the invoice paid, so two parallel purchases cannot overspend. Tested with concurrent requests (`tests/e2e/coins.test.mjs`).
- `(type, reference)` is unique. Retrying the same Discord grant, Linkvertise hash, invoice payment or code redemption never credits or charges twice.
- Coin payments create a `payments` row with gateway `ogcoins` and amount `0`. Money revenue reports therefore do not count coin sales.
- There are no automatic coin refunds. If you cancel or refund something, adjust the wallet by hand (Admin → OGCoins → Wallets → Adjust). Every adjustment is audited.

## Selling plans for coins

Admin → Store → plan → "OGCoins price per cycle".

| Price | Coin price | Result |
|---|---|---|
| > 0 | empty | Money only (as before) |
| > 0 | set | Customer chooses money or OGCoins at checkout; renewal invoices can be paid either way |
| 0 (and no setup fee) | set | Coins-only plan |
| 0 | empty | Free plan (renewals are auto-paid) |

- "Max per customer" limits how many active or pending services of that plan one account can have. It is useful for free and coin plans.
- Coupons only apply to money payments.
- Upgrades and downgrades on coin-priced services charge the prorated coin difference.
- Stock is reserved at checkout. If the coin payment fails (for example, the balance is too low), the order is cancelled and the stock is returned.

## Renewals

- Customer → Billing → Services → "Renew with OGCoins" extends the service by one cycle immediately.
- Prepaying is capped by Settings → Store → "Max periods a customer can prepay" (default 6).
- Auto-renew: a toggle per service. The billing job (every 10 minutes) charges coins once the due date is within 24 hours. If the balance is too low, the customer gets one notification. The normal grace/suspension rules then apply, and auto-renew retries every run until it succeeds or the service is suspended.
- Admins can run the billing job immediately: `POST /api/admin/billing/run` (permission `admin.orders`).

## Earning with Linkvertise

Coins are credited only after the panel itself asks Linkvertise's Anti-Bypassing API whether the visit was real. A browser redirect alone never credits coins.

### Setup
1. In the Linkvertise publisher dashboard, open the Anti-Bypassing settings, enable it, and copy the API token.
   - The Anti-Bypassing toggle applies to all of your Linkvertise links: each one then redirects with `?hash=…`.
2. Panel → Settings → Linkvertise:
   - Paste the token (stored encrypted). You can use `LINKVERTISE_TOKEN` in `.env` instead.
   - Choose the mode:
     - **dynamic** (default): enter your publisher user ID (the number in your Linkvertise links / full-script snippet). For each claim the panel builds a link `https://link-to.net/<userId>/<random>/dynamic?r=<base64 target>`, and the target carries a one-time secret token: `<APP_URL>/api/coins/linkvertise/return/<token>`.
     - **static**: create one normal Linkvertise link whose target is `<APP_URL>/api/coins/linkvertise/return` and paste it as "Static link URL". The return request is matched to the signed-in user's latest pending claim, so the customer must use the same browser session.
   - Set coins per link, the daily limit per user, the IP limit, the cooldown, the minimum seconds, and the session lifetime.
3. Enable it.

### What happens
1. The customer clicks "Earn" on `/coins`. A pending claim is created, subject to the daily limit, IP limit, cooldown and verified email.
2. The customer completes Linkvertise, which redirects to the return URL with `hash`.
3. The panel checks the claim (pending, not expired, not done faster than the minimum seconds, right account). It then calls `POST https://publisher.linkvertise.com/api/v1/anti_bypassing?token=…&hash=…`. Only the response `TRUE` credits coins. The hash is stored as unique, so it can never be reused.

### Limitations (honest)
- This was tested against a local mock of the Anti-Bypassing API (`tests/mocks/coins-mock.mjs`), not against a real Linkvertise account.
- Linkvertise documents the hash as valid for about 10 seconds and single-use. If the panel cannot reach Linkvertise in time, the claim fails with `verify_error` and no coins are given.
- It is not verified that Anti-Bypassing hashes are appended to dynamic links. If coins never arrive in dynamic mode (the claims show `not_verified`), switch to static mode.
- Anti-bypass stops "skip the ads" tools. It does not stop a real person completing many links from many accounts. The per-IP limit and the email-verification requirement help, but are not perfect.

## Buying coins on Discord

Three options, which can be combined:

1. **Redeem codes**: Admin → OGCoins → Redeem codes → Create. You can make up to 500 at a time, set uses per code and an expiry, or use a custom code like `DIWALI2026`. Sell or give the code on Discord, and the customer redeems it on `/coins`. Each account can redeem a code once. Codes that have been used can only be deactivated, not deleted.
2. **Linked account + bot/staff grant**: the customer links Discord on `/coins` (OAuth2, scope `identify` only; the access token is revoked right after reading the user ID and is not stored). Staff or your bot then credit coins:
   ```http
   POST /api/admin/coins/discord/grant
   Authorization: Bearer ogh_<prefix>_<secret>
   Content-Type: application/json

   {"discordId": "123456789012345678", "amount": 500, "reference": "order-1042", "reason": "Discord shop"}
   ```
   - The response is `{ userId, balance, duplicate }`.
   - `reference` must be unique per sale. Sending the same reference again returns `duplicate: true` and does not credit again.
   - If the member has not linked Discord, the response is 404 with `code: "NOT_LINKED"`.
   - `GET /api/admin/coins/discord/<discordId>` returns `{ linked, userId, username, balance }`.
   - The API key must belong to an admin whose role has `admin.coins`, and it needs the `admin.*` scope.
3. **Manual adjust**: Admin → OGCoins → Wallets → Adjust.

### Discord application setup
1. Go to https://discord.com/developers/applications → New Application → OAuth2.
2. Add the redirect `<APP_URL>/api/coins/discord/callback`.
3. Copy the Client ID and Client Secret into Panel → Settings → Discord (or `DISCORD_CLIENT_ID` / `DISCORD_CLIENT_SECRET` in `.env`), and enable it.
4. Optional: set the server invite URL and the shop text shown on the wallet page.

An example bot with `/balance` and `/givecoins` is in `integrations/discord-bot/`. It is example code that has been syntax-checked only and was not run against a real bot account. Discord OAuth was tested against a local mock, not real Discord.

## Customer API

All of these require login or an API key with the `coins.read` / `coins.write` scopes.

| Method | Path | |
|---|---|---|
| GET | `/api/coins/balance` | `{ balance, name }` |
| GET | `/api/coins/wallet` | Balance, Linkvertise status, Discord link state, recent transactions |
| GET | `/api/coins/transactions?page=` | History |
| POST | `/api/coins/redeem` `{code}` | Rate-limited to 15 per 15 minutes per user |
| POST | `/api/coins/linkvertise/start` | Returns `{ url }` |
| GET | `/api/coins/discord/connect` | Returns `{ url }` for the OAuth page |
| POST | `/api/coins/discord/unlink` | |
| POST | `/api/store/checkout` `{…, payWith: "ogcoins"}` | 402 `INSUFFICIENT_COINS` with `balance` and `required` |
| POST | `/api/store/invoices/:id/pay-coins` | |
| POST | `/api/store/services/:id/renew-coins` | |
| PUT | `/api/store/services/:id/auto-renew` `{enabled}` | |

## Admin API (permission `admin.coins`)

`GET /api/admin/coins/stats`, `GET /api/admin/coins/wallets?search=`, `GET /api/admin/coins/transactions?userId=&type=`, `POST /api/admin/coins/users/:id/adjust {amount, reason}`, `GET|POST /api/admin/coins/codes`, `PATCH|DELETE /api/admin/coins/codes/:id`, `GET /api/admin/coins/linkvertise`, plus the Discord endpoints above.
