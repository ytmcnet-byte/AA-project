#!/bin/sh
# Non-root user bhi apni "open files" soft limit hard limit tak badha sakta hai.
# Zyada ports (hazaaron) kholne ke liye ye zaroori hai.
cd "$(dirname "$0")" || exit 1
ulimit -n "$(ulimit -Hn)" 2>/dev/null
echo "open files limit: $(ulimit -n)"
exec node server.js "$@"
