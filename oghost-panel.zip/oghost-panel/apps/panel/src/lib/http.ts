import type { Request, Response, NextFunction } from 'express';
import { z, type ZodType } from 'zod';

export class HttpError extends Error { constructor(public status: number, message: string, public extra: Record<string, unknown> = {}) { super(message); } }
export const bad = (m: string) => new HttpError(400, m);
export const forbidden = (m = 'You do not have permission to do that') => new HttpError(403, m);
export const notFound = (m = 'Not found') => new HttpError(404, m);
export const conflict = (m: string) => new HttpError(409, m);

/** For PATCH with schema.partial(): zod applies .default() values even to omitted keys, which would silently reset
 *  untouched columns. Keep only the keys the client actually sent. */
export function patchBody<T extends ZodType>(schema: T, req: Request): z.infer<T> {
  const b: any = body(schema, req); const sent = req.body && typeof req.body === 'object' ? req.body : {};
  if (b && typeof b === 'object') for (const k of Object.keys(b)) if (!(k in sent)) delete b[k];
  return b;
}
export function body<T extends ZodType>(schema: T, req: Request): z.infer<T> {
  const r = schema.safeParse(req.body ?? {});
  if (!r.success) throw new HttpError(422, 'Validation failed', { issues: r.error.issues.map(i => ({ path: i.path.join('.'), message: i.message })) });
  return r.data;
}
export function qnum(v: unknown, d: number, max = 1000) { const n = Number(v); return Number.isFinite(n) && n > 0 ? Math.min(Math.floor(n), max) : d; }
export const idParam = (req: Request, key = 'id') => { const n = Number(req.params[key]); if (!Number.isInteger(n) || n < 1) throw bad('Invalid id'); return n; };
export const ip = (req: Request) => req.ip || req.socket.remoteAddress || '';
export function paginate(req: Request) { const per = qnum(req.query.per_page, 25, 200); const page = qnum(req.query.page, 1, 100000); return { limit: per, offset: (page - 1) * per, page, per }; }
export function errorHandler(err: any, _req: Request, res: Response, _next: NextFunction) {
  const status = err instanceof HttpError ? err.status : err.status || (err.code === 'ER_DUP_ENTRY' ? 409 : 500);
  if (status >= 500) console.error('[panel]', err);
  const message = status >= 500 && !(err instanceof HttpError) && !err.expose ? (err.message?.startsWith('Node ') || err.fromNode ? err.message : 'Internal server error') : err.code === 'ER_DUP_ENTRY' ? 'Duplicate entry: that value is already in use' : err.message;
  res.status(status).json({ error: message, ...(err.extra || {}) });
}
export { z };
