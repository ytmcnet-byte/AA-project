#!/usr/bin/env bash
set -e
DIR=${1:-$HOME/jtg-local-daemon}
mkdir -p "$DIR"
cp -a . "$DIR/"
cd "$DIR"
[ -f .env ] || cp .env.example .env
npm install --omit=dev
node agent.js
