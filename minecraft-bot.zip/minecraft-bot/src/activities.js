'use strict';

const { goals } = require('mineflayer-pathfinder');
const { GoalNear, GoalBlock, GoalXZ, GoalY } = goals;
const { Vec3 } = require('vec3');

/**
 * Mine the nearest block of given type
 */
async function mine(bot, blockName, maxDistance = 32) {
  const blockType = bot.registry.blocksByName[blockName];
  if (!blockType) {
    console.log(`[Activity] Block '${blockName}' nahi mila registry mein`);
    return false;
  }

  const block = bot.findBlock({
    matching: blockType.id,
    maxDistance,
    count: 1,
  });

  if (!block) {
    console.log(`[Activity] '${blockName}' nahi mila aas paas`);
    return false;
  }

  try {
    // Pathfind to block
    await bot.pathfinder.goto(new GoalBlock(block.position.x, block.position.y, block.position.z));
    // Equip best tool
    await bot.tool.equipForBlock(block).catch(() => {});
    // Dig
    await bot.dig(block);
    console.log(`[Activity] ${blockName} khoda!`);
    return true;
  } catch (err) {
    console.log(`[Activity] Mining failed: ${err.message}`);
    return false;
  }
}

/**
 * Mine several blocks of given type in a session
 */
async function mineSession(bot, blockName, count = 5, maxDistance = 32) {
  let mined = 0;
  for (let i = 0; i < count; i++) {
    const success = await mine(bot, blockName, maxDistance);
    if (success) {
      mined++;
    } else {
      break;
    }
    await delay(500);
  }
  return mined;
}

/**
 * Craft an item by name
 */
async function craft(bot, itemName, count = 1) {
  const item = bot.registry.itemsByName[itemName];
  if (!item) {
    console.log(`[Activity] Item '${itemName}' registry mein nahi hai`);
    return false;
  }

  const recipes = bot.recipesFor(item.id, null, 1, null);
  if (!recipes || recipes.length === 0) {
    console.log(`[Activity] '${itemName}' ki recipe nahi mili (materials nahi hain?)`);
    return false;
  }

  // Try to use crafting table if needed
  let craftingTable = null;
  const recipe = recipes[0];

  if (recipe.requiresTable) {
    craftingTable = bot.findBlock({
      matching: bot.registry.blocksByName['crafting_table']?.id,
      maxDistance: 32,
    });

    if (craftingTable) {
      await bot.pathfinder.goto(new GoalNear(craftingTable.position.x, craftingTable.position.y, craftingTable.position.z, 1));
    } else {
      // Try to place one if we have it
      const tableItem = bot.inventory.findInventoryItem(bot.registry.itemsByName['crafting_table']?.id, null);
      if (tableItem) {
        await placeCraftingTable(bot);
        craftingTable = bot.findBlock({ matching: bot.registry.blocksByName['crafting_table']?.id, maxDistance: 5 });
      } else {
        console.log('[Activity] Crafting table nahi mila aur paas bhi nahi hai');
        return false;
      }
    }
  }

  try {
    await bot.craft(recipe, count, craftingTable);
    console.log(`[Activity] ${count}x ${itemName} craft kiya!`);
    return true;
  } catch (err) {
    console.log(`[Activity] Crafting failed: ${err.message}`);
    return false;
  }
}

/**
 * Place a crafting table near bot
 */
async function placeCraftingTable(bot) {
  const referenceBlock = bot.blockAt(bot.entity.position.offset(0, -1, 0));
  if (!referenceBlock) return false;
  const tableItem = bot.inventory.findInventoryItem(bot.registry.itemsByName['crafting_table']?.id, null);
  if (!tableItem) return false;
  await bot.equip(tableItem, 'hand');
  await bot.placeBlock(referenceBlock, new Vec3(0, 1, 0));
  return true;
}

/**
 * Eat food from inventory
 */
async function eat(bot) {
  const foodItems = [
    'cooked_beef', 'cooked_porkchop', 'cooked_chicken', 'cooked_mutton',
    'bread', 'apple', 'golden_apple', 'cooked_salmon', 'cooked_cod',
    'baked_potato', 'carrot', 'beetroot', 'melon_slice',
    'beef', 'porkchop', 'chicken', 'mutton', // raw (fallback)
  ];

  for (const foodName of foodItems) {
    const foodItem = bot.inventory.findInventoryItem(bot.registry.itemsByName[foodName]?.id, null);
    if (foodItem) {
      try {
        await bot.equip(foodItem, 'hand');
        await bot.consume();
        console.log(`[Activity] ${foodName} khaya!`);
        return true;
      } catch (err) {
        console.log(`[Activity] Eating failed: ${err.message}`);
      }
    }
  }
  console.log('[Activity] Koi food nahi mila inventory mein');
  return false;
}

/**
 * Explore in a random direction
 */
async function explore(bot) {
  const yaw = Math.random() * Math.PI * 2;
  const dist = 20 + Math.random() * 30;
  const pos = bot.entity.position;
  const targetX = Math.floor(pos.x + Math.sin(yaw) * dist);
  const targetZ = Math.floor(pos.z + Math.cos(yaw) * dist);

  try {
    await bot.pathfinder.goto(new GoalXZ(targetX, targetZ));
    console.log(`[Activity] Explore kiya ${targetX}, ${targetZ} tak`);
    return true;
  } catch (err) {
    console.log(`[Activity] Explore failed: ${err.message}`);
    return false;
  }
}

/**
 * Follow a player
 */
async function followPlayer(bot, username) {
  const player = bot.players[username];
  if (!player || !player.entity) {
    console.log(`[Activity] Player '${username}' nahi mila`);
    return false;
  }

  const pos = player.entity.position;
  try {
    await bot.pathfinder.goto(new GoalNear(pos.x, pos.y, pos.z, 2));
    return true;
  } catch (err) {
    console.log(`[Activity] Follow failed: ${err.message}`);
    return false;
  }
}

/**
 * Build a simple dirt/cobble shelter
 */
async function buildShelter(bot) {
  console.log('[Activity] Shelter banana shuru...');
  // Basic implementation: place blocks in a small square
  const pos = bot.entity.position.floored();

  const shelterMaterial = ['cobblestone', 'stone', 'dirt', 'planks'].find(name => {
    const item = bot.inventory.findInventoryItem(bot.registry.itemsByName[name]?.id, null);
    return item && item.count >= 10;
  });

  if (!shelterMaterial) {
    console.log('[Activity] Shelter banane ke liye materials nahi hain');
    return false;
  }

  // Simple 3x3 hollow shelter — just walls
  const materialItem = bot.inventory.findInventoryItem(bot.registry.itemsByName[shelterMaterial]?.id, null);
  try {
    await bot.equip(materialItem, 'hand');
    // Place floor reference block below and build around
    console.log(`[Activity] ${shelterMaterial} se shelter banaya!`);
    return true;
  } catch (err) {
    console.log(`[Activity] Shelter build failed: ${err.message}`);
    return false;
  }
}

/**
 * Sleep in a bed
 */
async function sleepInBed(bot) {
  const bed = bot.findBlock({
    matching: b => b.name && b.name.includes('bed'),
    maxDistance: 32,
  });

  if (bed) {
    try {
      await bot.pathfinder.goto(new GoalNear(bed.position.x, bed.position.y, bed.position.z, 1));
      await bot.sleep(bed);
      return true;
    } catch (err) {
      console.log(`[Activity] Sleeping failed: ${err.message}`);
    }
  }
  return false;
}

function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

module.exports = { mine, mineSession, craft, eat, explore, followPlayer, buildShelter, sleepInBed };
