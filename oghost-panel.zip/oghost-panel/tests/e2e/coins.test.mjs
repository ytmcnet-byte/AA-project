// OGCoins end to end: redeem codes, double-spend protection, buying and renewing plans with coins, auto-renew,
// Linkvertise anti-bypass verification (mock API) and Discord linking + bot grants (mock OAuth2).
// Requires the panel to run with LINKVERTISE_API_BASE and DISCORD_API_BASE pointing at the mock (E2E_COINS_MOCK_PORT, default 9556).
import { test } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { admin, client, db, skip, PANEL, NODE, customJarEgg, waitFor, sleep, rmServer } from './common.mjs';
import { startCoinsMock } from '../mocks/coins-mock.mjs';

const MOCK_PORT = Number(process.env.E2E_COINS_MOCK_PORT || 9556);
const rnd = crypto.randomBytes(3).toString('hex');
const PASS = 'E2eCoinsPass123';
const DID = '7' + String(Date.now()).slice(-12) + String(Math.floor(Math.random() * 1e4)).padStart(4, '0');
const lvHash = () => crypto.randomBytes(32).toString('hex');

async function rawGet(c, path) { const r = await fetch(PANEL + path, { headers: c ? { cookie: c.cookie } : {}, redirect: 'manual' }); return { status: r.status, location: r.headers.get('location') || '' }; }
const balance = async (c) => (await c.get('/api/coins/balance')).balance;

test('OGCoins: codes, purchases, renewals, Linkvertise, Discord', { skip, timeout: 240000 }, async (t) => {
  const mock = await startCoinsMock(MOCK_PORT).catch(e => { throw new Error(`coins mock could not listen on ${MOCK_PORT}: ${e.message}`); });
  const a = await admin(); const conn = await db();
  const prev = (await a.get('/api/admin/settings')).settings;
  const cleanup = { services: [], plans: [], product: null, category: null };
  try {
    await a.put('/api/admin/settings', {
      'coins.enabled': true, 'coins.name': 'OGCoins', 'store.enabled': true, 'store.maxPrepayCycles': 6,
      'linkvertise.enabled': true, 'linkvertise.token': 'lv-e2e-token', 'linkvertise.mode': 'dynamic', 'linkvertise.userId': '424242',
      'linkvertise.coinsPerLink': 10, 'linkvertise.dailyLimit': 5, 'linkvertise.cooldownSeconds': 0, 'linkvertise.minSeconds': 2, 'linkvertise.claimTtlMinutes': 30,
      'discord.enabled': true, 'discord.clientId': 'dc-e2e-client', 'discord.clientSecret': 'dc-e2e-secret',
    });
    const [[role]] = await conn.query("SELECT id FROM roles WHERE slug = 'customer'");
    const users = [];
    for (const i of [1, 2, 3]) {
      const u = await a.post('/api/admin/users', { email: `e2e-coins-${rnd}-${i}@example.test`, username: `e2ecoins${rnd}${i}`, roleId: role.id, password: PASS, emailVerified: true });
      const c = client(PANEL); await c.login(`e2ecoins${rnd}${i}`, PASS); users.push({ id: u.id ?? u.user?.id, c });
    }
    const [u1, u2, u3] = users;
    for (const u of users) if (!u.id) u.id = (await u.c.get('/api/auth/me')).user.id;

    await t.test('wallet starts at 0 and config exposes the currency', async () => {
      const w = await u1.c.get('/api/coins/wallet'); assert.equal(w.balance, 0); assert.equal(w.name, 'OGCoins'); assert.equal(w.linkvertise.enabled, true); assert.equal(w.discord.enabled, true);
      const { config: cfg } = await u1.c.get('/api/auth/me'); assert.deepEqual(cfg.coins, { enabled: true, name: 'OGCoins' });
    });

    await t.test('redeem codes: once per account and max uses enforced', async () => {
      const { codes: [multi] } = await a.post('/api/admin/coins/codes', { coins: 100, maxUses: 2, note: 'e2e' });
      const { codes: [single] } = await a.post('/api/admin/coins/codes', { coins: 25, maxUses: 1, prefix: 'E2E' });
      assert.equal((await u1.c.post('/api/coins/redeem', { code: multi.toLowerCase() })).coins, 100);
      assert.equal((await u1.c.post('/api/coins/redeem', { code: multi }, { allowError: true })).status, 409);
      assert.equal((await u2.c.post('/api/coins/redeem', { code: multi })).balance, 100);
      assert.equal((await u3.c.post('/api/coins/redeem', { code: multi }, { allowError: true })).status, 422, 'third use of a 2-use code');
      assert.equal((await u1.c.post('/api/coins/redeem', { code: 'OG-NOPE-NOPE-NOPE' }, { allowError: true })).status, 422);
      // two accounts racing for a single-use code: exactly one wins
      const race = await Promise.all([u1.c.post('/api/coins/redeem', { code: single }, { allowError: true }), u2.c.post('/api/coins/redeem', { code: single }, { allowError: true })]);
      assert.equal(race.filter(r => r.status === 200).length, 1, JSON.stringify(race));
      const [[cr]] = await conn.query('SELECT uses FROM coin_codes WHERE code = ?', [single]); assert.equal(cr.uses, 1);
      // reset u1 / u2 to known balances
      for (const u of [u1, u2]) { const b = await balance(u.c); if (b !== 100) await a.post(`/api/admin/coins/users/${u.id}/adjust`, { amount: 100 - b, reason: 'e2e reset' }); }
      assert.equal(await balance(u1.c), 100); assert.equal(await balance(u2.c), 100);
    });

    await t.test('concurrent deductions cannot overspend; balance never negative', async () => {
      const rs = await Promise.all([1, 2, 3, 4].map(() => a.post(`/api/admin/coins/users/${u2.id}/adjust`, { amount: -60, reason: 'e2e race' }, { allowError: true })));
      assert.equal(rs.filter(r => r.status === 200).length, 1, JSON.stringify(rs.map(r => r.status)));
      assert.ok(rs.filter(r => r.status === 402).every(r => r.data.code === 'INSUFFICIENT_COINS'));
      assert.equal(await balance(u2.c), 40);
      const [[sum]] = await conn.query('SELECT SUM(amount) AS s FROM coin_transactions WHERE user_id = ?', [u2.id]); assert.equal(Number(sum.s), 40, 'ledger sum equals balance');
    });

    // Store objects
    const cat = await a.post('/api/admin/store/categories', { name: `E2E coins ${rnd}`, slug: `e2e-coins-${rnd}`, visible: false }); cleanup.category = cat.id;
    const prod = await a.post('/api/admin/store/products', { categoryId: cat.id, name: `E2E coin product ${rnd}`, slug: `e2e-coinprod-${rnd}`, type: 'minecraft', visible: true }); cleanup.product = prod.id;
    const egg = await customJarEgg(a);
    const coinPlan = await a.post('/api/admin/store/plans', { productId: prod.id, name: 'E2E coin plan', priceCents: 0, coinPrice: 50, maxPerUser: 1, stock: 5, memoryMb: 256, cpuPercent: 50, diskMb: 256, eggId: egg, nodeId: NODE, billingCycle: 'monthly' }); cleanup.plans.push(coinPlan.id);
    const freePlan = await a.post('/api/admin/store/plans', { productId: prod.id, name: 'E2E free plan', priceCents: 0, memoryMb: 256, cpuPercent: 50, diskMb: 256, eggId: egg, nodeId: NODE, billingCycle: 'monthly', visible: false }); cleanup.plans.push(freePlan.id);
    let svcId;

    await t.test('Discord: link via OAuth (mock), conflicts, bot grant idempotency', async () => {
      const { url } = await u3.c.get('/api/coins/discord/connect');
      const state = new URL(url).searchParams.get('state'); assert.ok(state); assert.match(url, /scope=identify/);
      assert.equal((await rawGet(u3.c, `/api/coins/discord/callback?code=x&state=bogus`)).location, '/coins?discord=state');
      await fetch(`http://127.0.0.1:${MOCK_PORT}/__mock/discord/code`, { method: 'POST', body: JSON.stringify({ code: 'c-u3', user: { id: DID, username: 'e2e_u3' } }) });
      assert.equal((await rawGet(u3.c, `/api/coins/discord/callback?code=c-u3&state=${state}`)).location, '/coins?discord=linked');
      assert.equal((await rawGet(u3.c, `/api/coins/discord/callback?code=c-u3&state=${state}`)).location, '/coins?discord=state', 'state is single use');
      assert.equal(mock.state.revoked.length >= 1, true, 'Discord access token revoked after reading identity');
      const w = await u3.c.get('/api/coins/wallet'); assert.equal(w.discord.linked, true); assert.equal(w.discord.username, 'e2e_u3');
      // same Discord account on a second panel account -> taken
      const s2 = new URL((await u1.c.get('/api/coins/discord/connect')).url).searchParams.get('state');
      await fetch(`http://127.0.0.1:${MOCK_PORT}/__mock/discord/code`, { method: 'POST', body: JSON.stringify({ code: 'c-u1', user: { id: DID, username: 'e2e_u3' } }) });
      assert.equal((await rawGet(u1.c, `/api/coins/discord/callback?code=c-u1&state=${s2}`)).location, '/coins?discord=taken');
      // bot API with an admin API key
      const { key } = await a.post('/api/account/api-keys', { name: `e2e coins bot ${rnd}`, scopes: ['admin.*'] });
      const bot = (m, p, b) => fetch(PANEL + p, { method: m, headers: { authorization: `Bearer ${key}`, 'content-type': 'application/json' }, body: b ? JSON.stringify(b) : undefined }).then(async r => ({ status: r.status, data: await r.json() }));
      assert.equal((await bot('GET', '/api/admin/coins/discord/' + DID)).data.balance, 0);
      const g1 = await bot('POST', '/api/admin/coins/discord/grant', { discordId: DID, amount: 30, reference: `e2e-order-${rnd}`, reason: 'Discord shop e2e' });
      assert.equal(g1.status, 200, JSON.stringify(g1.data)); assert.equal(g1.data.duplicate, false); assert.equal(g1.data.balance, 30);
      const g2 = await bot('POST', '/api/admin/coins/discord/grant', { discordId: DID, amount: 30, reference: `e2e-order-${rnd}` });
      assert.equal(g2.data.duplicate, true); assert.equal(await balance(u3.c), 30, 'retry with same reference does not double-credit');
      assert.equal((await bot('POST', '/api/admin/coins/discord/grant', { discordId: '799999999999999999', amount: 5, reference: 'x' })).data.code, 'NOT_LINKED');
      // customer key without admin scope cannot grant
      const ck = (await u1.c.post('/api/account/api-keys', { name: 'e2e', scopes: ['coins.read'] })).key;
      const r = await fetch(PANEL + '/api/admin/coins/discord/grant', { method: 'POST', headers: { authorization: `Bearer ${ck}`, 'content-type': 'application/json' }, body: JSON.stringify({ discordId: DID, amount: 5, reference: 'evil' }) });
      assert.equal(r.status, 403);
      const rk = await fetch(PANEL + '/api/coins/balance', { headers: { authorization: `Bearer ${ck}` } }); assert.equal(rk.status, 200, 'coins.read scope can read own balance');
    });

    await t.test('buy with OGCoins: insufficient -> 402 and stock restored; enough -> paid and provisioned', async () => {
      const [[p0]] = await conn.query('SELECT stock FROM plans WHERE id = ?', [coinPlan.id]);
      const bad = await u3.c.post('/api/store/checkout', { planId: coinPlan.id, serverName: `e2e-coin-${rnd}`, payWith: 'ogcoins' }, { allowError: true });
      assert.equal(bad.status, 402, JSON.stringify(bad.data)); assert.equal(bad.data.code, 'INSUFFICIENT_COINS'); assert.equal(bad.data.balance, 30); assert.equal(bad.data.required, 50);
      const [[p1]] = await conn.query('SELECT stock FROM plans WHERE id = ?', [coinPlan.id]); assert.equal(p1.stock, p0.stock, 'stock restored');
      const [[o]] = await conn.query('SELECT status FROM orders WHERE user_id = ? ORDER BY id DESC LIMIT 1', [u3.id]); assert.equal(o.status, 'cancelled');
      const money = await u3.c.post('/api/store/checkout', { planId: coinPlan.id, serverName: 'x', payWith: 'money' }, { allowError: true });
      assert.equal(money.status, 422, 'coin-only plan cannot be bought with money');
      await a.post(`/api/admin/coins/users/${u3.id}/adjust`, { amount: 90, reason: 'e2e top up' }); // 120
      const ok = await u3.c.post('/api/store/checkout', { planId: coinPlan.id, serverName: `e2e-coin-${rnd}`, payWith: 'ogcoins' });
      assert.equal(ok.paidWithCoins, true); assert.equal(ok.balance, 70);
      const [[inv]] = await conn.query('SELECT status, total_cents, coin_total FROM invoices WHERE id = ?', [ok.invoiceId]); assert.equal(inv.status, 'paid'); assert.equal(inv.coin_total, 50); assert.equal(inv.total_cents, 0);
      const [[pay]] = await conn.query('SELECT gateway, amount_cents FROM payments WHERE invoice_id = ?', [ok.invoiceId]); assert.equal(pay.gateway, 'ogcoins'); assert.equal(Number(pay.amount_cents), 0);
      const svc = await waitFor(async () => (await u3.c.get('/api/store/services')).services.find(s => s.plan_id === coinPlan.id && s.status === 'active' && s.server_id), { timeout: 90000, label: 'coin service provisioned' });
      svcId = svc.id; cleanup.services.push({ c: u3.c, id: svc.id });
      assert.equal(svc.coin_price, 50);
      const again = await u3.c.post('/api/store/checkout', { planId: coinPlan.id, serverName: 'e2e-2', payWith: 'ogcoins' }, { allowError: true });
      assert.equal(again.status, 409, 'max per user'); assert.equal(await balance(u3.c), 70, 'rejected order did not charge');
    });

    await t.test('renew with OGCoins extends the due date; prepay cap enforced', async () => {
      assert.ok(svcId, 'needs the purchased service');
      const [[before]] = await conn.query('SELECT next_due_at FROM services WHERE id = ?', [svcId]);
      const r = await u3.c.post(`/api/store/services/${svcId}/renew-coins`); assert.equal(r.balance, 20);
      const after = await waitFor(async () => { const [[x]] = await conn.query('SELECT next_due_at FROM services WHERE id = ?', [svcId]); return +new Date(x.next_due_at) !== +new Date(before.next_due_at) && x; }, { timeout: 30000, label: 'renewal applied' });
      const days = (new Date(after.next_due_at) - new Date(before.next_due_at)) / 86400000; assert.ok(days >= 27 && days <= 32, `extended ${days} days`);
      await a.put('/api/admin/settings', { 'store.maxPrepayCycles': 1 });
      await a.post(`/api/admin/coins/users/${u3.id}/adjust`, { amount: 100, reason: 'e2e' }); // 120
      const cap = await u3.c.post(`/api/store/services/${svcId}/renew-coins`, {}, { allowError: true });
      assert.equal(cap.status, 422, JSON.stringify(cap.data)); assert.equal(await balance(u3.c), 120, 'not charged when capped');
      await a.put('/api/admin/settings', { 'store.maxPrepayCycles': 6 });
    });

    await t.test('auto-renew charges coins before the due date, and waits when the balance is short', async () => {
      await u3.c.put(`/api/store/services/${svcId}/auto-renew`, { enabled: true });
      await a.post(`/api/admin/coins/users/${u3.id}/adjust`, { amount: -100, reason: 'e2e' }); // 20 (< 50)
      await conn.query('UPDATE services SET next_due_at = NOW() + INTERVAL 12 HOUR WHERE id = ?', [svcId]);
      await a.post('/api/admin/billing/run');
      const [[s1]] = await conn.query('SELECT next_due_at, auto_renew_notified_at FROM services WHERE id = ?', [svcId]);
      assert.ok((new Date(s1.next_due_at) - Date.now()) < 86400000, 'not renewed without enough coins'); assert.ok(s1.auto_renew_notified_at, 'customer notified once');
      assert.equal(await balance(u3.c), 20);
      await a.post(`/api/admin/coins/users/${u3.id}/adjust`, { amount: 40, reason: 'e2e' }); // 60
      await a.post('/api/admin/billing/run');
      await waitFor(async () => { const [[x]] = await conn.query('SELECT next_due_at FROM services WHERE id = ?', [svcId]); return new Date(x.next_due_at) - Date.now() > 25 * 86400000; }, { timeout: 30000, label: 'auto-renewal applied' }); assert.equal(await balance(u3.c), 10);
      const [[tx]] = await conn.query("SELECT COUNT(*) AS n FROM coin_transactions WHERE user_id = ? AND type = 'renewal'", [u3.id]); assert.equal(Number(tx.n), 2);
      await a.post('/api/admin/billing/run'); assert.equal(await balance(u3.c), 10, 'not charged twice');
    });

    await t.test('free plan renewal is paid automatically', async () => {
      const [ins] = await conn.query("INSERT INTO services (user_id, plan_id, status, price_cents, currency, billing_cycle, next_due_at) VALUES (?, ?, 'active', 0, 'INR', 'monthly', NOW() + INTERVAL 2 DAY)", [u1.id, freePlan.id]);
      try {
        const r = await u1.c.post(`/api/store/services/${ins.insertId}/renew`); assert.equal(r.free, true);
        await waitFor(async () => { const [[x]] = await conn.query('SELECT next_due_at FROM services WHERE id = ?', [ins.insertId]); return new Date(x.next_due_at) - Date.now() > 25 * 86400000; }, { timeout: 30000, label: 'free renewal applied' });
      } finally { await conn.query("UPDATE services SET status = 'cancelled' WHERE id = ?", [ins.insertId]); }
    });

    await t.test('Linkvertise: verified once, replay, too fast, bypass, wrong account, daily limit', async () => {
      const start = async (c) => { const r = await c.post('/api/coins/linkvertise/start'); const u = new URL(r.url); assert.match(u.pathname, /^\/424242\/[\d.]+\/dynamic$/); const target = decodeURIComponent(Buffer.from(u.searchParams.get('r'), 'base64').toString()); assert.match(target, /\/api\/coins\/linkvertise\/return\/[A-Za-z0-9_-]+$/); return new URL(target).pathname; };
      const b0 = await balance(u1.c);
      let p = await start(u1.c); const h1 = lvHash(); await fetch(`http://127.0.0.1:${MOCK_PORT}/__mock/lv/issue`, { method: 'POST', body: JSON.stringify({ hash: h1 }) });
      assert.match((await rawGet(u1.c, `${p}?hash=${h1}`)).location, /lv=too_fast/);
      p = await start(u1.c); await sleep(2200);
      assert.match((await rawGet(u1.c, `${p}?hash=${lvHash()}`)).location, /lv=not_verified/, 'hash Linkvertise does not know = bypass');
      p = await start(u1.c); await sleep(2200);
      assert.match((await rawGet(u1.c, `${p}?hash=${h1}`)).location, /lv=ok/);
      assert.equal(await balance(u1.c), b0 + 10);
      assert.match((await rawGet(u1.c, `${p}?hash=${h1}`)).location, /lv=used/, 'replaying the same return URL');
      const p2 = await start(u1.c); await sleep(2200);
      assert.match((await rawGet(u1.c, `${p2}?hash=${h1}`)).location, /lv=(used|not_verified)/, 'same hash on a new claim');
      const p3 = await start(u1.c); await sleep(2200); const h3 = lvHash(); await fetch(`http://127.0.0.1:${MOCK_PORT}/__mock/lv/issue`, { method: 'POST', body: JSON.stringify({ hash: h3 }) });
      assert.match((await rawGet(u2.c, `${p3}?hash=${h3}`)).location, /lv=wrong_account/);
      assert.equal(await balance(u1.c), b0 + 10, 'wrong account got nothing');
      // the claim stays pending for its owner; the secret token alone identifies it (e.g. the session cookie was lost)
      assert.match((await rawGet(null, `${p3}?hash=${h3}`)).location, /lv=ok/);
      assert.equal(await balance(u1.c), b0 + 20);
      const [[n]] = await conn.query("SELECT COUNT(*) AS n FROM coin_transactions WHERE user_id = ? AND type = 'linkvertise'", [u1.id]); assert.equal(Number(n.n), 2);
      assert.match((await rawGet(null, `/api/coins/linkvertise/return?hash=${lvHash()}`)).location, /lv=login/, 'static mode without a session');
      await a.put('/api/admin/settings', { 'linkvertise.dailyLimit': 1 });
      const lim = await u1.c.post('/api/coins/linkvertise/start', {}, { allowError: true }); assert.equal(lim.status, 429); assert.equal(lim.data.code, 'DAILY_LIMIT');
      const claims = await a.get('/api/admin/coins/linkvertise'); assert.ok(claims.claims.some(c => c.user_id === u1.id && c.status === 'completed'));
    });

    await t.test('admin views: stats, wallets, ledger', async () => {
      const s = await a.get('/api/admin/coins/stats'); assert.ok(s.inCirculation >= 0); assert.ok(s.linkvertise24h.completed >= 1);
      const w = await a.get(`/api/admin/coins/wallets?search=e2ecoins${rnd}`); assert.equal(w.wallets.length, 3);
      const l = await a.get(`/api/admin/coins/transactions?userId=${u3.id}`); assert.ok(l.transactions.some(x => x.type === 'discord')); assert.ok(l.transactions.some(x => x.type === 'purchase'));
      const sum = l.transactions.reduce((x, y) => x + Number(y.amount), 0); assert.equal(sum, await balance(u3.c), 'ledger matches balance');
    });
  } finally {
    for (const s of cleanup.services) await s.c.post(`/api/store/services/${s.id}/cancel`, { immediate: true }, { allowError: true });
    // cancelling only suspends (files are kept for the admin); delete the e2e servers for real
    const [left] = await conn.query("SELECT s.id, s.node_id AS nodeId, s.node_server_id AS nodeServerId FROM servers s JOIN services sv ON sv.server_id = s.id WHERE sv.plan_id IN (?)", [cleanup.plans.length ? cleanup.plans : [0]]);
    for (const s of left) await rmServer(a, s);
    for (const id of cleanup.plans) await a.patch(`/api/admin/store/plans/${id}`, { visible: false }, { allowError: true });
    const restore = {}; for (const k of ['linkvertise.enabled', 'linkvertise.dailyLimit', 'linkvertise.minSeconds', 'linkvertise.cooldownSeconds', 'linkvertise.userId', 'discord.enabled', 'discord.clientId', 'store.maxPrepayCycles']) restore[k] = prev?.[k] ?? null;
    await a.put('/api/admin/settings', Object.fromEntries(Object.entries(restore).filter(([, v]) => v !== null))).catch(() => {});
    await conn.end(); await mock.close();
  }
});
