import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Coins, Copy } from 'lucide-react';
import { useApi, useAction, toast } from '../../lib/hooks';
import { api, post, patch, del } from '../../lib/api';
import { useAuth } from '../../lib/auth';
import { date } from '../../lib/format';
import { Badge, Card, Empty, ErrorBox, Field, Loading, Modal, Notice, PageHeader, Pager, Spinner, Stat, Switch, Table, Tabs } from '../../components/ui';

type Tab = 'wallets' | 'codes' | 'ledger' | 'linkvertise' | 'bot';
export function CoinsAdmin() {
  const { config } = useAuth(); const n = config?.coins?.name || 'OGCoins';
  const [tab, setTab] = useState<Tab>('wallets');
  const stats = useApi<any>('/api/admin/coins/stats', [tab]);
  return <>
    <PageHeader title={n} subtitle={`Panel currency: wallets, redeem codes, Linkvertise earnings and the Discord bot API. Settings live under Settings → ${n} / Linkvertise / Discord.`} />
    {!config?.coins?.enabled && <Notice kind="warn" className="mb-4">{n} are disabled in Settings. Customers cannot see or spend them.</Notice>}
    {stats.data && <div className="mb-5 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
      <Stat label="Coins in circulation" value={stats.data.inCirculation.toLocaleString()} sub={`${stats.data.holders} wallets with a balance`} icon={<Coins className="h-5 w-5" />} />
      <Stat label="Issued (24 h)" value={stats.data.last24h.reduce((a: number, x: any) => a + x.earned, 0).toLocaleString()} sub={stats.data.last24h.filter((x: any) => x.earned).map((x: any) => `${x.type}: ${x.earned.toLocaleString()}`).join(' · ') || 'none'} />
      <Stat label="Spent (24 h)" value={stats.data.last24h.reduce((a: number, x: any) => a + x.spent, 0).toLocaleString()} sub={stats.data.last24h.filter((x: any) => x.spent).map((x: any) => `${x.type}: ${x.spent.toLocaleString()}`).join(' · ') || 'none'} />
      <Stat label="Linkvertise (24 h)" value={stats.data.linkvertise24h.completed} sub={`${stats.data.linkvertise24h.failed} failed · ${stats.data.linkvertise24h.pending} pending`} />
    </div>}
    <Tabs value={tab} onChange={setTab} tabs={[{ id: 'wallets', label: 'Wallets' }, { id: 'codes', label: 'Redeem codes' }, { id: 'ledger', label: 'Ledger' }, { id: 'linkvertise', label: 'Linkvertise' }, { id: 'bot', label: 'Discord bot API' }]} />
    {tab === 'wallets' ? <Wallets n={n} onChange={stats.reload} /> : tab === 'codes' ? <Codes n={n} /> : tab === 'ledger' ? <Ledger /> : tab === 'linkvertise' ? <Claims /> : <BotHelp n={n} />}
  </>;
}

function Wallets({ n, onChange }: { n: string; onChange: () => void }) {
  const [search, setSearch] = useState(''); const [qv, setQv] = useState(''); const [page, setPage] = useState(1); const [adj, setAdj] = useState<any>(null);
  const { data, error, loading, reload } = useApi<any>(`/api/admin/coins/wallets?search=${encodeURIComponent(qv)}&page=${page}&per_page=25`, [qv, page]);
  return <Card actions={<form className="flex gap-2" onSubmit={e => { e.preventDefault(); setPage(1); setQv(search.trim()); }}><input className="input h-9" placeholder="Email, username or Discord ID" value={search} onChange={e => setSearch(e.target.value)} /><button className="btn-secondary btn-sm">Search</button></form>}>
    {loading ? <Loading /> : error ? <ErrorBox error={error} /> : !data.wallets.length ? <Empty title="No users found" /> : <>
      <Table><thead><tr><th>User</th><th>Discord</th><th className="text-right">Balance</th><th>Last activity</th><th /></tr></thead><tbody>
        {data.wallets.map((w: any) => <tr key={w.id}><td><Link className="link font-semibold" to={`/admin/users/${w.id}`}>{w.username}</Link><div className="text-xs text-ink-400">{w.email}</div></td><td className="text-xs">{w.discord_username ? <>{w.discord_username}<div className="font-mono text-ink-400">{w.discord_id}</div></> : '—'}</td><td className="text-right font-bold text-amber-200">{Number(w.coin_balance).toLocaleString()}</td><td className="text-xs">{w.last_activity ? date(w.last_activity) : '—'}</td><td className="text-right"><button className="btn-secondary btn-sm" onClick={() => setAdj(w)}>Adjust</button></td></tr>)}
      </tbody></Table><Pager page={page} setPage={setPage} hasMore={data.wallets.length === 25} /></>}
    {adj && <Adjust n={n} user={adj} onClose={(ch) => { setAdj(null); if (ch) { reload(); onChange(); } }} />}
  </Card>;
}
function Adjust({ n, user, onClose }: { n: string; user: any; onClose: (changed: boolean) => void }) {
  const [amount, setAmount] = useState(''); const [reason, setReason] = useState(''); const { busy, run } = useAction();
  const hist = useApi<any>(`/api/admin/coins/transactions?userId=${user.id}&per_page=10`);
  const a = Math.trunc(Number(amount));
  const save = () => run('adj', async () => { const r = await post(`/api/admin/coins/users/${user.id}/adjust`, { amount: a, reason: reason.trim() }); toast(`New balance: ${r.balance.toLocaleString()} ${n}`, 'success'); onClose(true); });
  return <Modal open onClose={() => onClose(false)} title={`Adjust ${user.username}'s ${n}`} footer={<><button className="btn-secondary" onClick={() => onClose(false)}>Cancel</button><button className="btn-primary" disabled={!a || reason.trim().length < 3 || !!busy} onClick={save}>{busy && <Spinner />}{a < 0 ? 'Deduct' : 'Add'} {Math.abs(a || 0).toLocaleString()} {n}</button></>}>
    <div className="space-y-4">
      <div className="text-sm">Current balance: <b className="text-amber-200">{Number(user.coin_balance).toLocaleString()} {n}</b></div>
      <Field label="Amount" hint="Positive adds, negative deducts. A deduction larger than the balance is refused."><input className="input" type="number" step={1} value={amount} onChange={e => setAmount(e.target.value)} placeholder="e.g. 100 or -50" /></Field>
      <Field label="Reason (shown to the customer and stored in the audit log)"><input className="input" value={reason} onChange={e => setReason(e.target.value)} maxLength={200} placeholder="Discord purchase #123 / refund / giveaway" /></Field>
      {hist.data?.transactions?.length > 0 && <div><div className="mb-1 text-xs font-bold uppercase text-ink-400">Recent</div>{hist.data.transactions.map((t: any) => <div key={t.id} className="flex justify-between border-b border-ink-800 py-1 text-xs"><span>{date(t.created_at)} · {t.type} · {t.description}</span><span className={t.amount > 0 ? 'text-emerald-400' : 'text-red-400'}>{t.amount > 0 ? '+' : ''}{t.amount}</span></div>)}</div>}
    </div>
  </Modal>;
}

function Codes({ n }: { n: string }) {
  const [page, setPage] = useState(1); const { data, error, loading, reload } = useApi<any>(`/api/admin/coins/codes?page=${page}&per_page=25`, [page]);
  const { busy, run } = useAction(); const [open, setOpen] = useState(false); const [made, setMade] = useState<string[] | null>(null);
  const [f, setF] = useState({ coins: 100, count: 1, maxUses: 1, expiresAt: '', note: '', prefix: 'OG', code: '' });
  const create = () => run('mk', async () => { const r = await post('/api/admin/coins/codes', { coins: Number(f.coins), count: Number(f.count), maxUses: Number(f.maxUses), expiresAt: f.expiresAt ? new Date(f.expiresAt).toISOString() : null, note: f.note || undefined, prefix: f.prefix || undefined, code: f.code.trim() || undefined }); setMade(r.codes); setOpen(false); reload(); });
  const copy = (t: string) => navigator.clipboard?.writeText(t).then(() => toast('Copied', 'success')).catch(() => toast('Copy failed', 'error'));
  return <Card actions={<button className="btn-primary btn-sm" onClick={() => setOpen(true)}>Create codes</button>}>
    {loading ? <Loading /> : error ? <ErrorBox error={error} /> : !data.codes.length ? <Empty title="No codes yet">Create codes to sell or give away on Discord.</Empty> : <>
      <Table><thead><tr><th>Code</th><th className="text-right">{n}</th><th>Uses</th><th>Expires</th><th>Note</th><th>Active</th><th /></tr></thead><tbody>
        {data.codes.map((c: any) => <tr key={c.id}><td className="font-mono text-xs"><button className="inline-flex items-center gap-1 hover:text-white" onClick={() => copy(c.code)}>{c.code}<Copy className="h-3 w-3" /></button></td><td className="text-right font-semibold">{Number(c.coins).toLocaleString()}</td><td>{c.uses} / {c.max_uses}</td><td className="text-xs">{c.expires_at ? date(c.expires_at) : 'never'}</td><td className="text-xs">{c.note || '—'}<div className="text-ink-400">{c.created_by_name}</div></td>
          <td><Switch checked={!!c.active} onChange={v => run(`a${c.id}`, () => patch(`/api/admin/coins/codes/${c.id}`, { active: v }).then(reload))} /></td>
          <td className="text-right"><button className="btn-ghost btn-sm text-red-400" disabled={!!busy} onClick={() => run(`d${c.id}`, async () => { const r = await del(`/api/admin/coins/codes/${c.id}`); toast(r.deactivated ? 'Code was used, so it was deactivated instead of deleted' : 'Code deleted', 'success'); reload(); })}>Delete</button></td></tr>)}
      </tbody></Table><Pager page={page} setPage={setPage} hasMore={data.codes.length === 25} /></>}
    <Modal open={open} onClose={() => setOpen(false)} title="Create redeem codes" footer={<><button className="btn-secondary" onClick={() => setOpen(false)}>Cancel</button><button className="btn-primary" disabled={!!busy || Number(f.coins) < 1} onClick={create}>{busy === 'mk' && <Spinner />}Create</button></>}>
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label={`${n} per code`}><input className="input" type="number" min={1} value={f.coins} onChange={e => setF({ ...f, coins: Number(e.target.value) })} /></Field>
        <Field label="How many codes"><input className="input" type="number" min={1} max={500} value={f.count} onChange={e => setF({ ...f, count: Number(e.target.value) })} disabled={!!f.code} /></Field>
        <Field label="Uses per code" hint="1 = single-use. Each account can redeem a code once."><input className="input" type="number" min={1} value={f.maxUses} onChange={e => setF({ ...f, maxUses: Number(e.target.value) })} /></Field>
        <Field label="Expires (optional)"><input className="input" type="datetime-local" value={f.expiresAt} onChange={e => setF({ ...f, expiresAt: e.target.value })} /></Field>
        <Field label="Prefix"><input className="input font-mono uppercase" maxLength={8} value={f.prefix} onChange={e => setF({ ...f, prefix: e.target.value })} /></Field>
        <Field label="Custom code (optional, single)"><input className="input font-mono uppercase" maxLength={40} value={f.code} onChange={e => setF({ ...f, code: e.target.value, count: e.target.value ? 1 : f.count })} placeholder="DIWALI2026" /></Field>
        <Field label="Note" className="sm:col-span-2"><input className="input" maxLength={191} value={f.note} onChange={e => setF({ ...f, note: e.target.value })} placeholder="Discord order #123" /></Field>
      </div>
    </Modal>
    <Modal open={!!made} onClose={() => setMade(null)} title={`${made?.length} code(s) created`} footer={<><button className="btn-secondary" onClick={() => copy(made!.join('\n'))}><Copy className="h-4 w-4" />Copy all</button><button className="btn-primary" onClick={() => setMade(null)}>Done</button></>}>
      <textarea className="input h-60 font-mono text-xs" readOnly value={made?.join('\n') || ''} />
    </Modal>
  </Card>;
}

function Ledger() {
  const [type, setType] = useState(''); const [page, setPage] = useState(1);
  const { data, error, loading } = useApi<any>(`/api/admin/coins/transactions?type=${type}&page=${page}&per_page=50`, [type, page]);
  return <Card actions={<select className="input h-9 w-auto" value={type} onChange={e => { setType(e.target.value); setPage(1); }}><option value="">All types</option>{['linkvertise', 'redeem', 'discord', 'admin', 'purchase', 'renewal', 'upgrade', 'refund'].map(t => <option key={t}>{t}</option>)}</select>}>
    {loading ? <Loading /> : error ? <ErrorBox error={error} /> : !data.transactions.length ? <Empty title="No transactions" /> : <>
      <Table><thead><tr><th>Date</th><th>User</th><th>Type</th><th>Description</th><th>Reference</th><th className="text-right">Amount</th><th className="text-right">Balance</th></tr></thead><tbody>
        {data.transactions.map((t: any) => <tr key={t.id}><td className="whitespace-nowrap text-xs">{date(t.created_at)}</td><td><Link className="link" to={`/admin/users/${t.user_id}`}>{t.username}</Link></td><td><Badge value={t.type} /></td><td className="text-sm">{t.description}{t.actor && <div className="text-xs text-ink-400">by {t.actor}</div>}</td><td className="max-w-[180px] truncate font-mono text-[11px] text-ink-400" title={t.reference}>{t.reference}</td><td className={`text-right font-semibold ${t.amount > 0 ? 'text-emerald-400' : 'text-red-400'}`}>{t.amount > 0 ? '+' : ''}{Number(t.amount).toLocaleString()}</td><td className="text-right">{Number(t.balance_after).toLocaleString()}</td></tr>)}
      </tbody></Table><Pager page={page} setPage={setPage} hasMore={data.transactions.length === 50} /></>}
  </Card>;
}

function Claims() {
  const [page, setPage] = useState(1); const { data, error, loading } = useApi<any>(`/api/admin/coins/linkvertise?page=${page}&per_page=50`, [page]);
  return <Card>
    {loading ? <Loading /> : error ? <ErrorBox error={error} /> : !data.claims.length ? <Empty title="No Linkvertise claims yet" /> : <>
      <Table><thead><tr><th>Started</th><th>User</th><th>Status</th><th>Coins</th><th>IP</th><th>Completed</th></tr></thead><tbody>
        {data.claims.map((c: any) => <tr key={c.id}><td className="text-xs">{date(c.created_at)}</td><td><Link className="link" to={`/admin/users/${c.user_id}`}>{c.username}</Link></td><td><Badge value={c.status} />{c.failure && <div className="text-xs text-red-400">{c.failure}</div>}</td><td>{c.coins}</td><td className="font-mono text-xs">{c.ip}</td><td className="text-xs">{c.completed_at ? date(c.completed_at) : '—'}</td></tr>)}
      </tbody></Table><Pager page={page} setPage={setPage} hasMore={data.claims.length === 50} /></>}
  </Card>;
}

function BotHelp({ n }: { n: string }) {
  const [id, setId] = useState(''); const [res, setRes] = useState<any>(null); const { busy, run } = useAction();
  const origin = window.location.origin;
  return <div className="grid gap-5 lg:grid-cols-2">
    <Card title="Look up a Discord user">
      <div className="flex gap-2"><input className="input font-mono" value={id} onChange={e => setId(e.target.value.trim())} placeholder="Discord user ID" /><button className="btn-secondary" disabled={!/^\d{5,25}$/.test(id) || !!busy} onClick={() => run('l', async () => setRes(await api('GET', `/api/admin/coins/discord/${id}`)))}>Look up</button></div>
      {res && <div className="mt-3 text-sm">{res.linked ? <>Linked to <Link className="link" to={`/admin/users/${res.userId}`}>{res.username}</Link> · balance <b className="text-amber-200">{res.balance.toLocaleString()} {n}</b></> : 'No panel account is linked to this Discord ID.'}</div>}
    </Card>
    <Card title="Bot / automation API">
      <div className="space-y-2 text-sm text-ink-300">
        <p>Create an API key under <Link className="link" to="/admin/webhooks">Webhooks & API</Link> with the <code>admin.*</code> scope, owned by an admin whose role has the <code>admin.coins</code> permission. Keep this key only on the bot host.</p>
        <pre className="overflow-x-auto rounded-lg bg-ink-950 p-3 text-[11px] leading-relaxed">{`GET  ${origin}/api/admin/coins/discord/<discordId>
POST ${origin}/api/admin/coins/discord/grant
Authorization: Bearer <api key>
{ "discordId": "123...", "amount": 500,
  "reference": "order-123", "reason": "Discord shop" }`}</pre>
        <p className="hint">The reference must be unique per purchase. Repeating a request with the same reference never credits twice (the response says duplicate: true). An example discord.js bot is in integrations/discord-bot.</p>
      </div>
    </Card>
  </div>;
}
