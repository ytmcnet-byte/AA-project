import { encryptSecret, decryptSecret } from '@oghost/shared';
import { q, exec, json, parse } from '../db';
import { config } from '../config';

/** Keys whose values are encrypted at rest and never returned to the browser. */
export const SECRET_KEYS = new Set(['linkvertise.token', 'discord.clientSecret', 'smtp.password', 'firebase.serviceAccount', 'google.clientSecret', 'razorpay.keySecret', 'razorpay.webhookSecret', 'stripe.secretKey', 'stripe.webhookSecret', 'cashfree.secretKey', 'cashfree.webhookSecret']);
const ENV_FALLBACK: Record<string, string> = {
  'smtp.host': 'SMTP_HOST', 'smtp.port': 'SMTP_PORT', 'smtp.user': 'SMTP_USER', 'smtp.password': 'SMTP_PASSWORD', 'smtp.from': 'SMTP_FROM', 'smtp.secure': 'SMTP_SECURE',
  'firebase.apiKey': 'FIREBASE_API_KEY', 'firebase.authDomain': 'FIREBASE_AUTH_DOMAIN', 'firebase.projectId': 'FIREBASE_PROJECT_ID', 'firebase.appId': 'FIREBASE_APP_ID', 'firebase.serviceAccount': 'FIREBASE_SERVICE_ACCOUNT_JSON',
  'google.clientId': 'GOOGLE_CLIENT_ID', 'google.clientSecret': 'GOOGLE_CLIENT_SECRET',
  'razorpay.keyId': 'RAZORPAY_KEY_ID', 'razorpay.keySecret': 'RAZORPAY_KEY_SECRET', 'razorpay.webhookSecret': 'RAZORPAY_WEBHOOK_SECRET',
  'stripe.secretKey': 'STRIPE_SECRET_KEY', 'stripe.webhookSecret': 'STRIPE_WEBHOOK_SECRET', 'stripe.publishableKey': 'STRIPE_PUBLISHABLE_KEY',
  'cashfree.appId': 'CASHFREE_APP_ID', 'cashfree.secretKey': 'CASHFREE_SECRET_KEY', 'cashfree.webhookSecret': 'CASHFREE_WEBHOOK_SECRET', 'cashfree.env': 'CASHFREE_ENV',
  'upi.vpa': 'UPI_VPA', 'upi.payee': 'UPI_PAYEE_NAME',
  'linkvertise.token': 'LINKVERTISE_TOKEN', 'discord.clientId': 'DISCORD_CLIENT_ID', 'discord.clientSecret': 'DISCORD_CLIENT_SECRET',
};
export const DEFAULTS: Record<string, unknown> = {
  'app.name': 'OGHOST PANEL', 'app.registration': true, 'app.requireEmailVerification': true, 'app.currency': 'INR', 'app.timezone': 'Asia/Kolkata',
  'security.autoSuspendHours': 48, 'security.blockSuspicious': true, 'security.scanUploads': true,
  'uploads.maxMb': 1024, 'store.enabled': true, 'store.invoicePrefix': 'OGH', 'store.graceDays': 3, 'store.reminderDays': 3,
  'payments.manual.enabled': true, 'payments.upi.enabled': false, 'payments.razorpay.enabled': false, 'payments.stripe.enabled': false, 'payments.cashfree.enabled': false,
  'drive.enabled': true, 'drive.defaultIntervalMinutes': 60, 'drive.maxRetention': 7,
  'plugins.sources': ['modrinth', 'hangar', 'spiget', 'github'],
  'store.maxPrepayCycles': 6,
  'coins.enabled': true, 'coins.name': 'OGCoins',
  'linkvertise.enabled': false, 'linkvertise.mode': 'dynamic', 'linkvertise.userId': '', 'linkvertise.staticUrl': '', 'linkvertise.coinsPerLink': 10,
  'linkvertise.dailyLimit': 10, 'linkvertise.cooldownSeconds': 60, 'linkvertise.minSeconds': 10, 'linkvertise.claimTtlMinutes': 30, 'linkvertise.ipDailyLimit': 0,
  'discord.enabled': false, 'discord.clientId': '', 'discord.inviteUrl': '', 'discord.shopText': 'Buy OGCoins in our Discord server. Link your Discord account here so staff can credit your wallet, or redeem a code you received.',
};
let cache: Map<string, unknown> | null = null; let cacheAt = 0; let gen = 0;
async function load() {
  if (cache && Date.now() - cacheAt < 5000) return cache;
  const g = gen; const rows = await q<{ key: string; value: any }>('SELECT `key`, value FROM settings');
  const m = new Map(rows.map(r => [r.key, parse(r.value, null)]));
  // a write that happened while this query was in flight invalidates the result for caching purposes
  if (g === gen) { cache = m; cacheAt = Date.now(); }
  return m;
}
export async function getSetting<T = any>(key: string): Promise<T> {
  const m = await load();
  if (m.has(key)) { const v: any = m.get(key); if (SECRET_KEYS.has(key) && v && typeof v === 'object' && v.enc) { try { return decryptSecret(v.enc, config.appKey) as any; } catch { return '' as any; } } return v as T; }
  const envKey = ENV_FALLBACK[key]; if (envKey && process.env[envKey] !== undefined) { const raw = process.env[envKey]!; return (raw === 'true' ? true : raw === 'false' ? false : raw) as any; }
  return DEFAULTS[key] as T;
}
export async function setSetting(key: string, value: unknown) {
  const stored = SECRET_KEYS.has(key) && typeof value === 'string' && value ? { enc: encryptSecret(value, config.appKey) } : value;
  await exec('INSERT INTO settings (`key`, value) VALUES (?, ?) ON DUPLICATE KEY UPDATE value = VALUES(value)', [key, json(stored)]); gen++; cache = null;
}
/** Public-safe dump: secrets replaced by a boolean "set" marker. */
export async function allSettings() {
  const keys = new Set([...Object.keys(DEFAULTS), ...Object.keys(ENV_FALLBACK), ...(await load()).keys()]);
  const out: Record<string, unknown> = {};
  for (const k of [...keys].sort()) out[k] = SECRET_KEYS.has(k) ? { secret: true, set: !!(await getSetting(k)) } : await getSetting(k);
  return out;
}
