// ================================================
// MCPanel Daemon (Node Agent)
// ================================================
// Runs on every machine that should host Minecraft servers. The panel talks
// to this over HTTP (REST) and WebSocket (console), authenticated with a
// shared secret set in .env and configured in the panel under Admin > Nodes.
//
// Responsibilities:
//   - Report system stats (CPU cores, RAM, disk) and installed Java versions
//   - Create/delete server workspaces on local disk
//   - Start/stop/restart servers, REALLY enforcing CPU core pinning
//     (taskset -c), CPU % quota + hard RAM cap (systemd-run cgroup scope),
//     and a portable disk-quota watcher
//   - Stream live console output over WebSocket and accept stdin commands
//   - Report live CPU/RAM usage per server (pidusage)

require('dotenv').config();
const express = require('express');
const http = require('http');
const { WebSocketServer } = require('ws');
const { spawn, exec } = require('child_process');
const util = require('util');
const execAsync = util.promisify(exec);
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const sanitize = require('sanitize-filename');
const pidusage = require('pidusage');

const javaManager = require('./lib/javaManager');
const resourceLimits = require('./lib/resourceLimits');

const PORT = process.env.DAEMON_PORT || 8443;
const SECRET = process.env.DAEMON_SECRET;
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'servers');

if (!SECRET) {
    console.error('❌ DAEMON_SECRET is not set. Create a .env file (see .env.example) with a strong random secret, then paste the same value into the panel when registering this node.');
    process.exit(1);
}

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

const app = express();
app.use(express.json({ limit: '5mb' }));

const server = http.createServer(app);
const wss = new WebSocketServer({ server, path: '/ws/console' });

// In-memory registry of running processes: { [serverId]: { proc, startedAt, diskWatcher } }
const running = {};

// ------------------------------------------------
// Auth: every REST call and the WS handshake must present the shared secret
// ------------------------------------------------
function checkAuth(token) {
    if (!token) return false;
    // Constant-time compare
    const a = Buffer.from(token);
    const b = Buffer.from(SECRET);
    if (a.length !== b.length) return false;
    return crypto.timingSafeEqual(a, b);
}

app.use((req, res, next) => {
    const header = req.headers['authorization'] || '';
    const token = header.startsWith('Bearer ') ? header.slice(7) : null;
    if (!checkAuth(token)) return res.status(401).json({ error: 'Unauthorized: invalid or missing daemon token' });
    next();
});

// ------------------------------------------------
// System info
// ------------------------------------------------
app.get('/api/system', async (req, res) => {
    const javaVersions = await javaManager.detectJavaVersions();
    let diskFreeMb = null, diskTotalMb = null;
    try {
        const { stdout } = await execAsync(`df -m "${DATA_DIR}" | tail -1`);
        const parts = stdout.trim().split(/\s+/);
        // Filesystem  1M-blocks  Used  Available  Use%  Mounted
        diskTotalMb = parseInt(parts[1], 10);
        diskFreeMb = parseInt(parts[3], 10);
    } catch (e) { /* not on linux / df missing */ }

    res.json({
        hostname: os.hostname(),
        platform: process.platform,
        cpuCores: os.cpus().length,
        totalMemMb: Math.round(os.totalmem() / 1024 / 1024),
        freeMemMb: Math.round(os.freemem() / 1024 / 1024),
        diskTotalMb,
        diskFreeMb,
        javaVersions: Object.fromEntries(Object.entries(javaVersions).map(([k, v]) => [k, { major: v.major, vendor: v.vendor, full: v.full }])),
        hasTaskset: await resourceLimits.hasTaskset(),
        hasSystemdRun: await resourceLimits.hasSystemdRun(),
        runningServers: Object.keys(running).length
    });
});

// ------------------------------------------------
// Java version management
// ------------------------------------------------
app.get('/api/java-versions', async (req, res) => {
    const versions = await javaManager.detectJavaVersions(true);
    res.json(versions);
});

app.post('/api/java-versions/install', async (req, res) => {
    const { major } = req.body;
    if (!javaManager.APT_PACKAGES[major]) {
        return res.status(400).json({ error: `No known package for Java ${major}. Supported: ${Object.keys(javaManager.APT_PACKAGES).join(', ')}` });
    }
    try {
        const log = await javaManager.installJavaVersion(major);
        res.json({ success: true, log });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

// ------------------------------------------------
// Server workspace management
// ------------------------------------------------
function serverDir(id) {
    const safeId = sanitize(String(id));
    return path.join(DATA_DIR, safeId);
}

app.get('/api/servers', (req, res) => {
    const ids = fs.existsSync(DATA_DIR) ? fs.readdirSync(DATA_DIR).filter(f => fs.statSync(path.join(DATA_DIR, f)).isDirectory()) : [];
    res.json(ids.map(id => ({
        id,
        running: !!running[id],
        pid: running[id] ? running[id].proc.pid : null
    })));
});

app.post('/api/servers', (req, res) => {
    const { id } = req.body;
    if (!id) return res.status(400).json({ error: 'id required' });
    const dir = serverDir(id);
    if (fs.existsSync(dir)) return res.status(409).json({ error: 'Server workspace already exists on this node' });
    fs.mkdirSync(dir, { recursive: true });
    res.json({ success: true, path: dir });
});

app.delete('/api/servers/:id', (req, res) => {
    const dir = serverDir(req.params.id);
    if (running[req.params.id]) return res.status(409).json({ error: 'Stop the server before deleting its workspace' });
    if (fs.existsSync(dir)) fs.rmSync(dir, { recursive: true, force: true });
    res.json({ success: true });
});

// ------------------------------------------------
// File sync: panel uploads a tar.gz of the server directory here (initial
// deploy / jar+world sync), and can pull one back down (e.g. for backups).
// Raw binary body, NOT multipart, to keep this dependency-free.
// ------------------------------------------------
app.post('/api/servers/:id/upload', express.raw({ type: '*/*', limit: '2048mb' }), (req, res) => {
    const id = req.params.id;
    const dir = serverDir(id);
    if (running[id]) return res.status(409).json({ error: 'Stop the server before uploading new files' });
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

    const tmpTar = path.join(os.tmpdir(), `upload-${sanitize(String(id))}-${Date.now()}.tar.gz`);
    fs.writeFileSync(tmpTar, req.body);

    exec(`tar -xzf "${tmpTar}" -C "${dir}"`, { maxBuffer: 1024 * 1024 * 50 }, (err, stdout, stderr) => {
        fs.unlink(tmpTar, () => {});
        if (err) return res.status(500).json({ error: `Extraction failed: ${stderr || err.message}` });
        res.json({ success: true });
    });
});

app.get('/api/servers/:id/download', (req, res) => {
    const id = req.params.id;
    const dir = serverDir(id);
    if (!fs.existsSync(dir)) return res.status(404).json({ error: 'Server workspace not found' });

    res.setHeader('Content-Type', 'application/gzip');
    const tar = spawn('tar', ['-czf', '-', '-C', dir, '.']);
    tar.stdout.pipe(res);
    tar.stderr.on('data', d => console.error('tar download error:', d.toString()));
    tar.on('error', (e) => { if (!res.headersSent) res.status(500).json({ error: e.message }); });
});

// ------------------------------------------------
// Power control: start / stop / restart / kill
// ------------------------------------------------
app.get('/api/servers/:id/status', async (req, res) => {
    const id = req.params.id;
    const entry = running[id];
    if (!entry) return res.json({ status: 'stopped' });
    try {
        const stats = await pidusage(entry.proc.pid);
        res.json({ status: 'running', pid: entry.proc.pid, cpu: stats.cpu, memoryMb: Math.round(stats.memory / 1024 / 1024), uptimeMs: Date.now() - entry.startedAt });
    } catch (e) {
        res.json({ status: 'running', pid: entry.proc.pid });
    }
});

app.post('/api/servers/:id/power', async (req, res) => {
    const id = req.params.id;
    const { action, launch } = req.body; // action: start|stop|restart|kill ; launch: {javaVersion, ramMb, cpuCores, cpuLimitPercent, diskLimitMb, startupArgs, mcVersion}
    const dir = serverDir(id);

    try {
        if (action === 'start') {
            if (running[id]) return res.status(409).json({ error: 'Already running' });
            if (!fs.existsSync(dir)) return res.status(404).json({ error: 'Server workspace not found on this node' });
            if (!launch || !launch.startupArgs) return res.status(400).json({ error: 'launch.startupArgs required' });

            const resolved = await javaManager.resolveJavaBinary(launch.javaVersion, launch.mcVersion);
            const javaPath = resolved.path;
            const args = launch.startupArgs;

            const sanitizedCores = resourceLimits.sanitizeCoreList(launch.cpuCores);
            const cpuMode = launch.cpuMode === 'private' ? 'private' : 'shared';
            const limited = await resourceLimits.buildLimitedCommand(javaPath, args, {
                cpuMode,
                cpuCores: sanitizedCores
            });

            const proc = spawn(limited.command, limited.args, { cwd: dir, detached: true, stdio: ['pipe', 'pipe', 'pipe'] });
            proc.unref();

            const consoleBuffer = [];
            const pushLine = (line) => {
                consoleBuffer.push(line);
                if (consoleBuffer.length > 1000) consoleBuffer.shift();
                broadcastConsole(id, line);
            };
            proc.stdout.on('data', d => pushLine(d.toString()));
            proc.stderr.on('data', d => pushLine(d.toString()));
            proc.on('exit', (code, signal) => {
                pushLine(`\n[Daemon] Process exited (code=${code}, signal=${signal})\n`);
                if (running[id] && running[id].diskWatcher) running[id].diskWatcher.stop();
                delete running[id];
                broadcastStatus(id, 'stopped');
            });

            let diskWatcher = { stop() {} };
            if (launch.diskLimitMb) {
                diskWatcher = resourceLimits.watchDiskUsage(dir, launch.diskLimitMb, (mb) => {
                    pushLine(`\n[Daemon] Disk limit exceeded (${mb}MB > ${launch.diskLimitMb}MB). Server KILLED.\n`);
                    try { process.kill(proc.pid, 'SIGKILL'); } catch (e) { /* already dead */ }
                });
            }

            running[id] = { proc, startedAt: Date.now(), consoleBuffer, diskWatcher, limitMode: limited.mode };
            broadcastStatus(id, 'running');
            return res.json({ success: true, pid: proc.pid, limitMode: limited.mode, javaUsed: resolved.major });
        }

        if (action === 'stop' || action === 'kill') {
            const entry = running[id];
            if (!entry) return res.json({ success: true, note: 'already stopped' });
            if (action === 'kill') {
                process.kill(entry.proc.pid, 'SIGKILL');
            } else {
                // Try graceful stop via stdin "stop" command first (Minecraft convention)
                try { entry.proc.stdin.write('stop\n'); } catch (e) { /* ignore */ }
                setTimeout(() => {
                    if (running[id]) {
                        try { process.kill(entry.proc.pid, 'SIGTERM'); } catch (e) { /* already dead */ }
                    }
                }, 15000);
            }
            return res.json({ success: true });
        }

        if (action === 'restart') {
            return res.status(400).json({ error: 'Send stop, wait for stopped status, then start with launch config again.' });
        }

        return res.status(400).json({ error: 'Unknown action' });
    } catch (e) {
        console.error(e);
        return res.status(500).json({ error: e.message });
    }
});

app.post('/api/servers/:id/command', (req, res) => {
    const entry = running[req.params.id];
    if (!entry) return res.status(409).json({ error: 'Server is not running' });
    const { command } = req.body;
    try {
        entry.proc.stdin.write(command.endsWith('\n') ? command : command + '\n');
        res.json({ success: true });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

// ------------------------------------------------
// WebSocket console streaming (auth via ?token=)
// ------------------------------------------------
const wsClients = {}; // serverId -> Set of sockets

function broadcastConsole(id, line) {
    const set = wsClients[id];
    if (!set) return;
    for (const ws of set) {
        if (ws.readyState === ws.OPEN) ws.send(JSON.stringify({ type: 'console', data: line }));
    }
}
function broadcastStatus(id, status) {
    const set = wsClients[id];
    if (!set) return;
    for (const ws of set) {
        if (ws.readyState === ws.OPEN) ws.send(JSON.stringify({ type: 'status', status }));
    }
}

wss.on('connection', (ws, req) => {
    const url = new URL(req.url, 'http://localhost');
    const token = url.searchParams.get('token');
    const id = url.searchParams.get('serverId');

    if (!checkAuth(token)) {
        ws.close(4401, 'Unauthorized');
        return;
    }
    if (!id) {
        ws.close(4400, 'serverId query param required');
        return;
    }

    if (!wsClients[id]) wsClients[id] = new Set();
    wsClients[id].add(ws);

    // Replay recent console buffer so the panel isn't blank on connect
    if (running[id]) {
        for (const line of running[id].consoleBuffer) {
            ws.send(JSON.stringify({ type: 'console', data: line }));
        }
    }

    ws.on('message', (msg) => {
        try {
            const parsed = JSON.parse(msg.toString());
            if (parsed.type === 'command' && running[id]) {
                running[id].proc.stdin.write(parsed.data.endsWith('\n') ? parsed.data : parsed.data + '\n');
            }
        } catch (e) { /* ignore malformed frames */ }
    });

    ws.on('close', () => {
        wsClients[id].delete(ws);
    });
});

server.listen(PORT, () => {
    console.log(`✅ MCPanel Daemon listening on port ${PORT}`);
    console.log(`   Data directory: ${DATA_DIR}`);
    console.log(`   Register this node in the panel with this machine's IP/hostname, port ${PORT}, and the DAEMON_SECRET from .env`);
});
