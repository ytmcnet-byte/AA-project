import type { PublicConfig } from './auth';
/** Google sign-in through Firebase Authentication. Only the ID token is sent to the panel, which verifies it server-side. */
export async function googleIdToken(cfg: NonNullable<PublicConfig['firebase']>): Promise<string> {
  const [{ initializeApp, getApps }, { getAuth, GoogleAuthProvider, signInWithPopup, signOut }] = await Promise.all([import('firebase/app'), import('firebase/auth')]);
  const app = getApps().find(a => a.name === 'oghost') || initializeApp(cfg, 'oghost');
  const auth = getAuth(app); const provider = new GoogleAuthProvider(); provider.setCustomParameters({ prompt: 'select_account' });
  const cred = await signInWithPopup(auth, provider);
  const token = await cred.user.getIdToken(true);
  await signOut(auth).catch(() => {}); // the panel keeps its own session; no Firebase session needed in the browser
  return token;
}
