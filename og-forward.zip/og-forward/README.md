# OG Forward

Non-root VPS ke liye pure Node.js reverse port-forwarding (ngrok/frp jaisa). Zero dependencies, Node 16+.

```
Visitor ──► VPS_PUBLIC_IP:PORT ──► [server.js] ◄══ tunnel ══ [agent.js] ──► localhost:PORT
                                    (public VPS)             (aapki machine, NAT ke peeche bhi)
```

- **server.js** public VPS par chalta hai (non-root, 1024+ ports). Control port (default 7000) par agents ka wait karta hai.
- **agent.js** us machine par chalta hai jahan service hai. VPS ke public IP se connect hota hai.
- **Koi fixed port set nahi:** user VPS ka koi bhi free port le sakta hai, ya server khud de, ya poori range ek saath.

## Setup

### 1. VPS par (server)

```bash
cp server.config.example.json server.config.json
npm run token            # har user ke liye ek token banao
nano server.config.json
./start-server.sh        # ye open-files limit badha ke server chalata hai
```

`server.config.json`:

| key | matlab |
|---|---|
| `controlPort` | agents is port par connect karenge (default 7000) |
| `publicHost` | public ports kis IP par bind hon (`0.0.0.0` = sab) |
| `users.<naam>.token` | us user ka secret (min 16 chars) |
| `users.<naam>.ports` | **`"any"`** = VPS ka koi bhi port (1024-65535), ya `[from, to]` se limit karo |
| `maxTunnelsPerUser` | ek user max kitne ports khol sakta hai (default 5000) |
| `maxConnsPerTunnel` / `maxConnsPerUser` | simultaneous visitors ki limit |
| `autoPortRange` | `"auto"` port is range se milega (default 10000-60000) |
| `denyPorts` | ye ports kabhi nahi khulenge |

**Firewall:** VPS provider ke panel (security group) me control port aur jo ports expose karne hain wo kholne honge. Agar saare ports chahiye to panel me "all TCP" allow karo. Non-root user ufw/iptables nahi badal sakta.

### 2. Client machine par (agent)

```bash
cp agent.config.example.json agent.config.json
nano agent.config.json
node agent.js
```

## Tunnel ke 4 tarike (`agent.config.json` -> `tunnels`)

```json
"tunnels": [
  { "name": "web",   "localPort": 3000, "remotePort": 20001 },
  { "name": "auto",  "localPort": 8080, "remotePort": "auto" },
  { "name": "range", "portRange": [30000, 30999] },
  { "name": "everything", "portRange": "all" }
]
```

| tarika | kya hota hai |
|---|---|
| `"remotePort": 20001` | VPS ka port 20001 -> local `localPort` |
| `"remotePort": "auto"` | server koi free port chunta hai, agent ke log me dikhta hai (`LIVE ...:52467 (auto)`) |
| `"portRange": [from, to]` | VPS port **N -> local port N**, poori range ek saath |
| `"portRange": "all"` | VPS ke **saare free ports** (1024-65535) -> same number local port par |

- Range me `localPortStart` de sakte ho: `{"portRange": [20000, 20099], "localPortStart": 3000}` = VPS 20000->local 3000, 20001->3001, ...
- Jo ports VPS par pehle se kisi aur service ke paas hain (EADDRINUSE), server unhe **skip** kar deta hai, chheenta nahi. Log me dikhta hai kitne open hue, kitne skip.
- Fixed/auto tunnels pehle process hote hain, ranges baad me, to `"all"` baaki tunnels ka hissa nahi khayega.

### "Saare ports" chalane se pehle samjho

1. **File descriptor limit:** har open port = 1 fd. Zyada tar VPS par soft limit 1024 hoti hai, par hard limit bahut badi hoti hai. `./start-server.sh` soft limit ko hard limit tak badha deta hai (non-root ke liye allowed). Server khud kuch fds visitors ke liye reserve rakhta hai, aur startup par batata hai ki max kitne ports khul sakte hain. Poore ~64,500 ports ke liye hard limit kam se kam ~100,000 honi chahiye (`ulimit -Hn` se dekho). Kam ho to jitne budget me aaye utne khulenge, baaki skip hone ka reason log me aayega.
2. **Memory:** har listening port thoda RAM leta hai (15,000 ports ~ 100 MB tak).
3. **Security:** `"all"` ka matlab hai ki client machine ke `localhost:N` par jo bhi chal raha hai (database, admin panel, SSH...) wo VPS ke public port N par poori duniya ko dikhega. Sirf wahi cheezein expose karo jo public hone layak hain, ya `portRange` ko chhota rakho.
4. Port scanners saare ports par aate rehte hain. Agent ke log me "local connect fail" ke message har 30 sec me ek hi baar aate hain, spam nahi hota.

## Background me chalana (non-root)

```bash
nohup ./start-server.sh >> server.log 2>&1 &
# VPS reboot par auto-start (crontab -e):
@reboot cd /home/USER/og-forward && nohup ./start-server.sh >> server.log 2>&1 &
```

Ya `tmux` / `screen`.

## Features

- Multi-user: har user ka alag token, aur chaho to alag port range
- Token network par kabhi plain nahi jaata (HMAC-SHA256 challenge-response)
- Agent auto-reconnect (1s se 30s backoff), heartbeat se dead connection detect
- Same user ka naya agent aaye to purana band ho jaata hai (flapping nahi hoti)
- Brute-force protection: 5 galat auth par us IP ko 5 min ke liye block
- Local service down ho to visitor ka connection turant close
- Kisi bhi TCP service ke liye (HTTP, SSH, game server, DB, etc.)

## Limits / dhyan rakhne wali baatein

1. **Tunnel encrypted nahi hai.** Login safe hai, par data plain TCP me jaata hai. Sensitive service ho to uska apna TLS/SSH use karo.
2. Sirf TCP, UDP nahi.
3. Non-root ko 1-1023 ports nahi milte, to 80/443 par seedha nahi chalega.
4. Ek user ke liye ek hi agent ek time par chalega.
