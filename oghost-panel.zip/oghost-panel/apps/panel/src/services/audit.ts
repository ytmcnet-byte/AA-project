import type { Request } from 'express';
import { exec, json } from '../db';

export async function audit(req: Request | null, action: string, target?: { type: string; id: string | number }, metadata?: Record<string, unknown>, actor = 'user') {
  const user = (req as any)?.user;
  await exec('INSERT INTO audit_logs (user_id, actor, action, target_type, target_id, ip, metadata) VALUES (?, ?, ?, ?, ?, ?, ?)',
    [user?.id ?? null, (req as any)?.apiKey ? 'api' : actor, action, target?.type ?? null, target ? String(target.id) : null, req?.ip ?? null, json(metadata ?? {})]).catch(e => console.error('[audit]', e.message));
}
export async function serverActivity(req: Request | null, serverId: number, event: string, metadata?: Record<string, unknown>) {
  await exec('INSERT INTO server_activity (server_id, user_id, event, metadata, ip) VALUES (?, ?, ?, ?, ?)', [serverId, (req as any)?.user?.id ?? null, event, json(metadata ?? {}), req?.ip ?? null]).catch(() => {});
}
