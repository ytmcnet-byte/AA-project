import { Router } from 'express';
import crypto from 'node:crypto';
import { q, one, exec, txRetry } from '../../db';
import { body, z, HttpError, idParam, paginate } from '../../lib/http';
import { requirePerm } from '../../lib/auth';
import { audit } from '../../services/audit';
import { notify } from '../../services/notify';
import { changeCoins, coinName, coinStats, makeCode, normCode } from '../../services/coins';
import { billingTick } from '../../services/billing';

export const coinsAdmin = Router();
const P = requirePerm('admin.coins');

coinsAdmin.get('/coins/stats', P, async (_req, res) => res.json(await coinStats()));

coinsAdmin.get('/coins/wallets', P, async (req, res) => {
  const p = paginate(req); const s = String(req.query.search || '').trim();
  const where = s ? 'WHERE u.email LIKE ? OR u.username LIKE ? OR u.discord_id = ? OR u.discord_username LIKE ?' : '';
  const args = s ? [`%${s}%`, `%${s}%`, s, `%${s}%`] : [];
  res.json({ wallets: await q(`SELECT u.id, u.username, u.email, u.coin_balance, u.discord_id, u.discord_username, (SELECT MAX(created_at) FROM coin_transactions t WHERE t.user_id = u.id) AS last_activity FROM users u ${where} ORDER BY u.coin_balance DESC, u.id LIMIT ? OFFSET ?`, [...args, p.limit, p.offset]) });
});

coinsAdmin.get('/coins/transactions', P, async (req, res) => {
  const p = paginate(req); const conds: string[] = []; const args: any[] = [];
  if (req.query.userId) { conds.push('t.user_id = ?'); args.push(Number(req.query.userId)); }
  if (req.query.type) { conds.push('t.type = ?'); args.push(String(req.query.type)); }
  res.json({ transactions: await q(`SELECT t.*, u.username, u.email, a.username AS actor FROM coin_transactions t JOIN users u ON u.id = t.user_id LEFT JOIN users a ON a.id = t.actor_id ${conds.length ? 'WHERE ' + conds.join(' AND ') : ''} ORDER BY t.id DESC LIMIT ? OFFSET ?`, [...args, p.limit, p.offset]) });
});

/** Manual grant (+) or deduction (-). Each call gets a unique reference unless the caller supplies one (then it is idempotent). */
coinsAdmin.post('/coins/users/:id/adjust', P, async (req, res) => {
  const b = body(z.object({ amount: z.number().int().refine(n => n !== 0 && Math.abs(n) <= 100_000_000, 'Amount must be non-zero'), reason: z.string().trim().min(3).max(200), reference: z.string().trim().max(100).optional() }), req);
  const userId = idParam(req); const name = await coinName();
  const r = await changeCoins({ userId, amount: b.amount, type: 'admin', reference: `adm:${b.reference || crypto.randomUUID()}`, description: b.reason, actorId: req.user!.id });
  if (!r.duplicate) { await audit(req, 'admin.coins.adjust', { type: 'user', id: userId }, b); await notify(userId, 'system', b.amount > 0 ? `+${b.amount} ${name}` : `${b.amount} ${name}`, `${b.reason}. New balance: ${r.balance} ${name}.`, { link: '/coins' }); }
  res.json(r);
});

// ---- Redeem codes (e.g. sold or given away on Discord)
coinsAdmin.get('/coins/codes', P, async (req, res) => {
  const p = paginate(req);
  res.json({ codes: await q('SELECT c.*, u.username AS created_by_name FROM coin_codes c LEFT JOIN users u ON u.id = c.created_by ORDER BY c.id DESC LIMIT ? OFFSET ?', [p.limit, p.offset]) });
});
coinsAdmin.post('/coins/codes', P, async (req, res) => {
  const b = body(z.object({ coins: z.number().int().min(1).max(10_000_000), count: z.number().int().min(1).max(500).default(1), maxUses: z.number().int().min(1).max(100_000).default(1), expiresAt: z.string().datetime().nullable().optional(), note: z.string().max(191).optional(), prefix: z.string().max(8).optional(), code: z.string().min(4).max(40).regex(/^[A-Za-z0-9-]+$/).optional() }), req);
  if (b.code && b.count > 1) throw new HttpError(422, 'A custom code can only be created once (count = 1)');
  const codes: string[] = [];
  await txRetry(async (c) => {
    codes.length = 0;
    for (let i = 0; i < b.count; i++) {
      const code = b.code ? normCode(b.code) : makeCode(b.prefix || 'OG');
      await exec('INSERT INTO coin_codes (code, coins, max_uses, expires_at, note, created_by) VALUES (?, ?, ?, ?, ?, ?)', [code, b.coins, b.maxUses, b.expiresAt ? new Date(b.expiresAt) : null, b.note ?? null, req.user!.id], c);
      codes.push(code);
    }
  }).catch(e => { if (e?.code === 'ER_DUP_ENTRY') throw new HttpError(409, 'That code already exists'); throw e; });
  await audit(req, 'admin.coins.codes_created', undefined, { count: codes.length, coins: b.coins, maxUses: b.maxUses, note: b.note });
  res.status(201).json({ codes });
});
coinsAdmin.patch('/coins/codes/:id', P, async (req, res) => {
  const b = body(z.object({ active: z.boolean() }), req);
  await exec('UPDATE coin_codes SET active = ? WHERE id = ?', [b.active ? 1 : 0, idParam(req)]); await audit(req, 'admin.coins.code_update', { type: 'coin_code', id: idParam(req) }, b); res.json({ ok: true });
});
coinsAdmin.delete('/coins/codes/:id', P, async (req, res) => {
  const c: any = await one('SELECT uses FROM coin_codes WHERE id = ?', [idParam(req)]); if (!c) throw new HttpError(404, 'Code not found');
  if (c.uses > 0) { await exec('UPDATE coin_codes SET active = 0 WHERE id = ?', [idParam(req)]); return res.json({ ok: true, deactivated: true, note: 'Used codes are kept for the record and only deactivated.' }); }
  await exec('DELETE FROM coin_codes WHERE id = ?', [idParam(req)]); await audit(req, 'admin.coins.code_delete', { type: 'coin_code', id: idParam(req) }); res.json({ ok: true });
});

coinsAdmin.get('/coins/linkvertise', P, async (req, res) => {
  const p = paginate(req);
  res.json({ claims: await q('SELECT l.id, l.user_id, u.username, l.coins, l.status, l.ip, l.failure, l.created_at, l.completed_at FROM linkvertise_claims l JOIN users u ON u.id = l.user_id ORDER BY l.id DESC LIMIT ? OFFSET ?', [p.limit, p.offset]) });
});

// ---- Discord bot API (use an admin API key: Authorization: Bearer ogh_...; the key owner needs admin.coins).
coinsAdmin.get('/coins/discord/:discordId', P, async (req, res) => {
  const id = String(req.params.discordId); if (!/^\d{5,25}$/.test(id)) throw new HttpError(422, 'Invalid Discord ID');
  const u: any = await one('SELECT id, username, coin_balance, discord_username FROM users WHERE discord_id = ?', [id]);
  res.json(u ? { linked: true, userId: u.id, username: u.username, discordUsername: u.discord_username, balance: Number(u.coin_balance), name: await coinName() } : { linked: false });
});
/** Credit coins bought on Discord. "reference" must be unique per purchase (order/message ID): retries never double-credit. */
coinsAdmin.post('/coins/discord/grant', P, async (req, res) => {
  const b = body(z.object({ discordId: z.string().regex(/^\d{5,25}$/), amount: z.number().int().min(1).max(10_000_000), reference: z.string().trim().min(1).max(100), reason: z.string().trim().max(200).optional() }), req);
  const u: any = await one('SELECT id FROM users WHERE discord_id = ?', [b.discordId]);
  if (!u) throw new HttpError(404, 'No panel account is linked to this Discord user. Ask them to link Discord on the OGCoins page.', { code: 'NOT_LINKED' });
  const name = await coinName();
  const r = await changeCoins({ userId: u.id, amount: b.amount, type: 'discord', reference: `dc:${b.reference}`, description: b.reason || 'Purchased on Discord', actorId: req.user!.id });
  if (!r.duplicate) { await audit(req, 'admin.coins.discord_grant', { type: 'user', id: u.id }, b); await notify(u.id, 'system', `+${b.amount} ${name}`, `${b.reason || 'Purchased on Discord'}. New balance: ${r.balance} ${name}.`, { link: '/coins' }); }
  res.json({ userId: u.id, ...r });
});

// Run the billing cycle now (renewal invoices, OGCoins auto-renew, suspensions) instead of waiting for the 10-minute timer.
coinsAdmin.post('/billing/run', requirePerm('admin.orders'), async (req, res) => {
  await billingTick(); await audit(req, 'admin.billing.run'); res.json({ ok: true });
});
