// Bundle a TypeScript module with esbuild (same aliases as the production build) and import it.
import { build } from 'esbuild';
import path from 'node:path';
import fs from 'node:fs';
import { pathToFileURL } from 'node:url';
const root = path.resolve(import.meta.dirname, '../..');
const cache = path.join(root, 'tests/.cache'); fs.mkdirSync(cache, { recursive: true });
export async function load(rel) {
  const out = path.join(cache, rel.replace(/[\/.]/g, '_') + '.mjs');
  await build({
    entryPoints: [path.join(root, rel)], outfile: out, bundle: true, platform: 'node', format: 'esm', target: 'node20', packages: 'external', logLevel: 'error',
    alias: { '@oghost/shared': path.join(root, 'packages/shared/src/index.ts'), '@oghost/extension-sdk': path.join(root, 'packages/extension-sdk/src/index.ts') },
    banner: { js: "import { createRequire as __cr } from 'node:module'; const require = __cr(import.meta.url);" },
  });
  return import(pathToFileURL(out).href + '?t=' + Date.now());
}
export const tmpdir = (p = 'oghost-test-') => fs.mkdtempSync(path.join(fs.realpathSync(process.env.TMPDIR || '/tmp'), p));
export { root };
