import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { Readable } from 'node:stream';
import { config } from './config';
import type { DiskAccount } from './disk';

export async function fetchJson<T = any>(url: string): Promise<T> {
  const r = await fetch(url, { headers: { 'User-Agent': config.userAgent, Accept: 'application/json' } });
  if (!r.ok) throw new Error(`GET ${url} -> HTTP ${r.status}`);
  return r.json() as Promise<T>;
}

/** Stream a remote file to disk, enforcing the server's disk allocation and verifying a checksum. */
export async function downloadTo(url: string, file: string, opts: { disk?: DiskAccount; hash?: { algo: 'sha1' | 'sha256' | 'sha512' | 'md5'; value: string }; onProgress?: (d: number, t: number) => void; allowHosts?: string[] } = {}) {
  const u = new URL(url);
  if (u.protocol !== 'https:') throw new Error('Only HTTPS downloads are allowed');
  if (opts.allowHosts && !opts.allowHosts.some(h => u.hostname === h || u.hostname.endsWith('.' + h))) throw new Error(`Download host ${u.hostname} is not on the allowlist`);
  const r = await fetch(url, { headers: { 'User-Agent': config.userAgent }, redirect: 'follow' });
  if (!r.ok || !r.body) throw new Error(`Download failed: HTTP ${r.status} for ${url}`);
  if (opts.allowHosts) { const fu = new URL(r.url); if (!opts.allowHosts.some(h => fu.hostname === h || fu.hostname.endsWith('.' + h))) throw new Error(`Redirected to non-allowlisted host ${fu.hostname}`); }
  const total = Number(r.headers.get('content-length') || 0);
  const reservation = opts.disk?.reserve(total || 64 * 1024 * 1024);
  await fs.promises.mkdir(path.dirname(file), { recursive: true });
  const tmp = `${file}.part`;
  const h = opts.hash ? crypto.createHash(opts.hash.algo) : null; let done = 0;
  try {
    await new Promise<void>((res, rej) => {
      const w = fs.createWriteStream(tmp, { mode: 0o640 });
      const s = Readable.fromWeb(r.body as any);
      s.on('data', (c: Buffer) => { done += c.length; h?.update(c); opts.onProgress?.(done, total); if (reservation && !total && done > 64 * 1024 * 1024 && opts.disk && opts.disk.available() < 0) { s.destroy(new Error('Disk allocation exceeded during download')); } });
      s.on('error', rej); w.on('error', rej); w.on('finish', () => res()); s.pipe(w);
    });
    if (h && opts.hash && h.digest('hex').toLowerCase() !== opts.hash.value.toLowerCase()) throw new Error('Checksum mismatch: download rejected');
    await fs.promises.rename(tmp, file);
    reservation?.release(done);
    return { bytes: done };
  } catch (e) { reservation?.release(0); await fs.promises.rm(tmp, { force: true }); throw e; }
}
