import crypto from 'node:crypto';
import type { PoolConnection } from 'mysql2/promise';
import { randomToken, sha256 } from '@oghost/shared';
import { q, one, exec, txRetry } from '../db';
import { config } from '../config';
import { HttpError } from '../lib/http';
import { getSetting } from './settings';
import { notify } from './notify';
import { audit } from './audit';

/**
 * OGCoins wallet. Rules:
 *  - The balance is a column on users; every change locks that row and writes one ledger row in the same transaction.
 *  - Debits are conditional (coin_balance >= amount) and the column has CHECK (coin_balance >= 0): a balance can never go negative.
 *  - (type, reference) is unique, so a retried webhook / bot call / Linkvertise hash / invoice payment can never credit or debit twice.
 */
export type CoinType = 'linkvertise' | 'redeem' | 'discord' | 'admin' | 'purchase' | 'renewal' | 'upgrade' | 'refund';
export const coinName = async () => String((await getSetting('coins.name')) || 'OGCoins');
export async function coinsEnabled() { return !!(await getSetting('coins.enabled')); }

export interface CoinChange { userId: number; amount: number; type: CoinType; reference: string; description: string; actorId?: number | null; invoiceId?: number | null }

/** Apply a balance change inside an existing transaction. Returns null when (type, reference) was already applied. */
export async function applyCoins(c: PoolConnection, ch: CoinChange): Promise<{ balance: number; txId: number } | null> {
  if (!Number.isSafeInteger(ch.amount) || ch.amount === 0) throw new HttpError(422, 'Amount must be a non-zero whole number');
  const dup: any = await one('SELECT id FROM coin_transactions WHERE type = ? AND reference = ?', [ch.type, ch.reference], c);
  if (dup) return null;
  const u: any = await one('SELECT id, coin_balance FROM users WHERE id = ? FOR UPDATE', [ch.userId], c);
  if (!u) throw new HttpError(404, 'User not found');
  const next = Number(u.coin_balance) + ch.amount;
  if (next < 0) throw new HttpError(402, `Not enough ${await coinName()}: this needs ${-ch.amount}, your balance is ${u.coin_balance}.`, { code: 'INSUFFICIENT_COINS', balance: Number(u.coin_balance), required: -ch.amount });
  await exec('UPDATE users SET coin_balance = ? WHERE id = ?', [next, ch.userId], c);
  try {
    const r = await exec('INSERT INTO coin_transactions (user_id, amount, balance_after, type, reference, description, actor_id, invoice_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
      [ch.userId, ch.amount, next, ch.type, ch.reference, ch.description.slice(0, 255), ch.actorId ?? null, ch.invoiceId ?? null], c);
    return { balance: next, txId: r.insertId };
  } catch (e: any) {
    if (e?.code === 'ER_DUP_ENTRY') throw Object.assign(new HttpError(409, 'This transaction was already applied'), { duplicate: true });
    throw e;
  }
}

/** Stand-alone change in its own transaction (idempotent). */
export async function changeCoins(ch: CoinChange) {
  try { const r = await txRetry(c => applyCoins(c, ch)); return r ? { ...r, duplicate: false } : { duplicate: true, balance: await balanceOf(ch.userId) }; }
  catch (e: any) { if (e?.duplicate) return { duplicate: true, balance: await balanceOf(ch.userId) }; throw e; }
}
export async function balanceOf(userId: number) { const u: any = await one('SELECT coin_balance FROM users WHERE id = ?', [userId]); return Number(u?.coin_balance ?? 0); }

// ---------------------------------------------------------------- Redeem codes
const CODE_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
export function makeCode(prefix = 'OG') {
  const b = crypto.randomBytes(12); let s = ''; for (const x of b) s += CODE_ALPHABET[x % CODE_ALPHABET.length];
  return `${prefix.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 8) || 'OG'}-${s.slice(0, 4)}-${s.slice(4, 8)}-${s.slice(8, 12)}`;
}
export const normCode = (c: string) => c.trim().toUpperCase().replace(/\s+/g, '');

export async function redeemCode(userId: number, raw: string) {
  if (!(await coinsEnabled())) throw new HttpError(503, 'OGCoins are disabled');
  const code = normCode(raw); if (!/^[A-Z0-9-]{4,40}$/.test(code)) throw new HttpError(422, 'That code is not valid');
  const name = await coinName();
  const r = await txRetry(async (c) => {
    const cc: any = await one('SELECT * FROM coin_codes WHERE code = ? FOR UPDATE', [code], c);
    if (!cc || !cc.active) throw new HttpError(422, 'That code is not valid');
    if (cc.expires_at && new Date(cc.expires_at) < new Date()) throw new HttpError(422, 'That code has expired');
    if (cc.uses >= cc.max_uses) throw new HttpError(422, 'That code has already been fully used');
    if (await one('SELECT id FROM coin_code_redemptions WHERE code_id = ? AND user_id = ?', [cc.id, userId], c)) throw new HttpError(409, 'You have already redeemed this code');
    await exec('INSERT INTO coin_code_redemptions (code_id, user_id) VALUES (?, ?)', [cc.id, userId], c);
    await exec('UPDATE coin_codes SET uses = uses + 1 WHERE id = ?', [cc.id], c);
    const w = await applyCoins(c, { userId, amount: cc.coins, type: 'redeem', reference: `code:${cc.id}:${userId}`, description: `Redeemed code ${code.slice(0, 7)}…` });
    return { coins: cc.coins as number, balance: w!.balance };
  });
  await notify(userId, 'system', `${r.coins} ${name} added`, `Code redeemed. New balance: ${r.balance} ${name}.`, { link: '/coins' });
  return r;
}

// ---------------------------------------------------------------- Linkvertise
/**
 * Flow (Linkvertise Anti-Bypassing):
 *  1. start(): creates a single-use claim (random token, stored hashed) and returns a Linkvertise link whose target is
 *     <APP_URL>/api/coins/linkvertise/return/<token>  (dynamic mode) or a static link the admin created (static mode).
 *  2. After the ad steps Linkvertise redirects the visitor to the target with ?hash=<64 chars>. The hash lives ~10 s on
 *     Linkvertise's side, so the panel verifies it server-to-server immediately: POST publisher.linkvertise.com/api/v1/anti_bypassing.
 *  3. Only a TRUE answer credits the wallet. The hash is single-use there, and also unique in our table.
 */
export async function linkvertiseConfig() {
  const [enabled, mode, userId, staticUrl, token, coins, daily, cooldown, minSeconds, ttl] = await Promise.all(['linkvertise.enabled', 'linkvertise.mode', 'linkvertise.userId', 'linkvertise.staticUrl', 'linkvertise.token', 'linkvertise.coinsPerLink', 'linkvertise.dailyLimit', 'linkvertise.cooldownSeconds', 'linkvertise.minSeconds', 'linkvertise.claimTtlMinutes'].map(k => getSetting(k)));
  const m = mode === 'static' ? 'static' : 'dynamic';
  const configured = !!token && (m === 'dynamic' ? /^\d+$/.test(String(userId || '')) : /^https:\/\//.test(String(staticUrl || '')));
  const ipDaily = Number(await getSetting('linkvertise.ipDailyLimit')) || Math.max(1, Number(daily) || 10) * 3;
  return { enabled: !!enabled && configured && (await coinsEnabled()), configured, mode: m as 'dynamic' | 'static', userId: String(userId || ''), staticUrl: String(staticUrl || ''), token: String(token || ''), coins: Math.max(1, Number(coins) || 10), daily: Math.max(1, Number(daily) || 10), ipDaily, cooldown: Math.max(0, Number(cooldown) || 0), minSeconds: Math.max(0, Number(minSeconds) || 0), ttlMinutes: Math.max(2, Number(ttl) || 30) };
}

export async function linkvertiseStatus(userId: number) {
  const cfg = await linkvertiseConfig();
  const done: any = await one("SELECT COUNT(*) AS n FROM linkvertise_claims WHERE user_id = ? AND status = 'completed' AND completed_at > NOW() - INTERVAL 1 DAY", [userId]);
  const last: any = await one('SELECT created_at FROM linkvertise_claims WHERE user_id = ? ORDER BY id DESC LIMIT 1', [userId]);
  const cooldownUntil = last && cfg.cooldown ? new Date(new Date(last.created_at).getTime() + cfg.cooldown * 1000) : null;
  return { enabled: cfg.enabled, coinsPerLink: cfg.coins, dailyLimit: cfg.daily, completedToday: Number(done.n), remainingToday: Math.max(0, cfg.daily - Number(done.n)), cooldownUntil: cooldownUntil && cooldownUntil > new Date() ? cooldownUntil : null };
}

export function dynamicLink(base: string, publisherId: string, target: string) {
  // Same format as Linkvertise's official full-script / dynamic links: /<publisher>/<random>/dynamic?r=<base64(encodeURI(target))>
  return `${base}/${publisherId}/${(Math.random() * 1000).toFixed(10)}/dynamic?r=${Buffer.from(encodeURI(target)).toString('base64')}`;
}

export async function startLinkvertise(userId: number, ipAddr: string) {
  const cfg = await linkvertiseConfig();
  if (!cfg.enabled) throw new HttpError(503, 'Earning through Linkvertise is not available right now');
  const st = await linkvertiseStatus(userId);
  if (st.remainingToday <= 0) throw new HttpError(429, `Daily limit reached (${cfg.daily} links per 24 hours). Come back later.`, { code: 'DAILY_LIMIT' });
  if (st.cooldownUntil) throw new HttpError(429, `Please wait ${Math.ceil((st.cooldownUntil.getTime() - Date.now()) / 1000)} seconds before starting another link.`, { code: 'COOLDOWN', retryAt: st.cooldownUntil });
  const ipDone: any = await one("SELECT COUNT(*) AS n FROM linkvertise_claims WHERE ip = ? AND status = 'completed' AND completed_at > NOW() - INTERVAL 1 DAY", [ipAddr]);
  if (Number(ipDone.n) >= cfg.ipDaily) throw new HttpError(429, 'Daily limit for your network reached. Come back later.', { code: 'IP_LIMIT' });
  const token = randomToken(32);
  await exec("UPDATE linkvertise_claims SET status = 'expired' WHERE user_id = ? AND status = 'pending'", [userId]); // one open claim per user
  await exec('INSERT INTO linkvertise_claims (token_hash, user_id, coins, ip) VALUES (?, ?, ?, ?)', [sha256(token), userId, cfg.coins, ipAddr]);
  const url = cfg.mode === 'dynamic' ? dynamicLink(config.linkvertiseLinkBase, cfg.userId, `${config.appUrl}/api/coins/linkvertise/return/${token}`) : cfg.staticUrl;
  return { url, coins: cfg.coins, expiresAt: new Date(Date.now() + cfg.ttlMinutes * 60_000), mode: cfg.mode };
}

/** Server-to-server Linkvertise anti-bypass check. Returns true only on an explicit TRUE. */
export async function verifyLinkvertiseHash(token: string, hash: string): Promise<boolean> {
  const url = `${config.linkvertiseApiBase}/api/v1/anti_bypassing?${new URLSearchParams({ token, hash })}`;
  const r = await fetch(url, { method: 'POST', signal: AbortSignal.timeout(8000) });
  const text = (await r.text()).trim();
  if (!r.ok) throw new HttpError(502, `Linkvertise verification failed (HTTP ${r.status})`);
  if (/^"?true"?$/i.test(text)) return true;
  try { const j = JSON.parse(text); return j === true || j?.status === true || j?.data === true || String(j?.status).toUpperCase() === 'TRUE'; } catch { return false; }
}

/** Handles the redirect back from Linkvertise. Returns a frontend path to redirect to. */
export async function completeLinkvertise(opts: { token?: string; hash?: string; sessionUserId?: number; ip: string }) {
  const cfg = await linkvertiseConfig(); const name = await coinName();
  const fail = async (claimId: number | null, reason: string) => { if (claimId) await exec("UPDATE linkvertise_claims SET status = 'failed', failure = ? WHERE id = ? AND status = 'pending'", [reason, claimId]); return `/coins?lv=${reason}`; };
  if (!cfg.enabled) return '/coins?lv=disabled';
  let claim: any;
  if (opts.token) claim = await one('SELECT * FROM linkvertise_claims WHERE token_hash = ?', [sha256(opts.token)]);
  else if (opts.sessionUserId) claim = await one("SELECT * FROM linkvertise_claims WHERE user_id = ? AND status = 'pending' ORDER BY id DESC LIMIT 1", [opts.sessionUserId]);
  else return '/coins?lv=login';
  if (!claim) return '/coins?lv=invalid';
  if (claim.status !== 'pending') return `/coins?lv=${claim.status === 'completed' ? 'used' : 'invalid'}`;
  // Another signed-in account opened this link: refuse, but leave the claim pending for its owner.
  if (opts.sessionUserId && opts.sessionUserId !== claim.user_id) return '/coins?lv=wrong_account';
  const age = (Date.now() - new Date(claim.created_at).getTime()) / 1000;
  if (age > cfg.ttlMinutes * 60) { await exec("UPDATE linkvertise_claims SET status = 'expired' WHERE id = ? AND status = 'pending'", [claim.id]); return '/coins?lv=expired'; }
  const hash = String(opts.hash || '');
  if (!/^[A-Za-z0-9]{32,128}$/.test(hash)) return fail(claim.id, 'not_verified');
  if (age < cfg.minSeconds) return fail(claim.id, 'too_fast');
  let ok = false;
  try { ok = await verifyLinkvertiseHash(cfg.token, hash); } catch (e) { console.warn('[coins] linkvertise verify error:', (e as Error).message); return fail(claim.id, 'verify_error'); }
  if (!ok) return fail(claim.id, 'not_verified');
  try {
    const res = await txRetry(async (c) => {
      const u = await exec("UPDATE linkvertise_claims SET status = 'completed', lv_hash = ?, completed_at = NOW() WHERE id = ? AND status = 'pending'", [hash, claim.id], c);
      if (!u.affectedRows) return null;
      await one('SELECT id FROM users WHERE id = ? FOR UPDATE', [claim.user_id], c); // serialize the daily-limit check per user
      const n: any = await one("SELECT COUNT(*) AS n FROM linkvertise_claims WHERE user_id = ? AND status = 'completed' AND completed_at > NOW() - INTERVAL 1 DAY", [claim.user_id], c);
      if (Number(n.n) > cfg.daily) throw new HttpError(429, 'daily');
      return applyCoins(c, { userId: claim.user_id, amount: claim.coins, type: 'linkvertise', reference: `lv:${hash}`, description: 'Completed a Linkvertise link' });
    });
    if (!res) return '/coins?lv=used';
    void notify(claim.user_id, 'system', `+${claim.coins} ${name}`, 'Thanks for completing the link.', { link: '/coins' }).catch(() => {});
    return `/coins?lv=ok&coins=${claim.coins}`;
  } catch (e: any) {
    if (e instanceof HttpError && e.message === 'daily') return fail(claim.id, 'daily_limit');
    if (e?.code === 'ER_DUP_ENTRY') return fail(claim.id, 'used');
    throw e;
  }
}

// ---------------------------------------------------------------- Discord account linking (OAuth2, scope "identify" only)
const discordRedirect = () => `${config.appUrl}/api/coins/discord/callback`;
export async function discordConfig() {
  const enabled = !!(await getSetting('discord.enabled')); const clientId = String((await getSetting('discord.clientId')) || ''); const secret = String((await getSetting('discord.clientSecret')) || '');
  return { enabled: enabled && !!clientId && !!secret, clientId, secret, inviteUrl: String((await getSetting('discord.inviteUrl')) || ''), shopText: String((await getSetting('discord.shopText')) || '') };
}
export async function discordConnectUrl(userId: number) {
  const cfg = await discordConfig(); if (!cfg.enabled) throw new HttpError(503, 'Discord linking is not configured');
  const state = randomToken(24);
  await exec('DELETE FROM oauth_states WHERE expires_at < NOW()');
  await exec('INSERT INTO oauth_states (state_hash, user_id, provider, expires_at) VALUES (?, ?, ?, ?)', [sha256(state), userId, 'discord', new Date(Date.now() + 10 * 60_000)]);
  return `https://discord.com/oauth2/authorize?${new URLSearchParams({ client_id: cfg.clientId, redirect_uri: discordRedirect(), response_type: 'code', scope: 'identify', state, prompt: 'consent' })}`;
}
export async function discordCallback(sessionUserId: number | undefined, code: string, state: string) {
  if (!sessionUserId) return '/coins?discord=login';
  const st: any = state ? await one("SELECT * FROM oauth_states WHERE state_hash = ? AND provider = 'discord'", [sha256(state)]) : null;
  if (st) await exec('DELETE FROM oauth_states WHERE state_hash = ?', [st.state_hash]);
  if (!st || st.user_id !== sessionUserId || new Date(st.expires_at) < new Date()) return '/coins?discord=state';
  if (!code) return '/coins?discord=denied';
  const cfg = await discordConfig(); if (!cfg.enabled) return '/coins?discord=disabled';
  const tr = await fetch(`${config.discordApiBase}/api/oauth2/token`, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ client_id: cfg.clientId, client_secret: cfg.secret, grant_type: 'authorization_code', code, redirect_uri: discordRedirect() }), signal: AbortSignal.timeout(10000) });
  const tok: any = await tr.json().catch(() => ({})); if (!tr.ok || !tok.access_token) return '/coins?discord=token';
  const ur = await fetch(`${config.discordApiBase}/api/users/@me`, { headers: { Authorization: `Bearer ${tok.access_token}` }, signal: AbortSignal.timeout(10000) });
  const du: any = await ur.json().catch(() => ({}));
  // The access token is not stored; revoke it right away (best effort).
  void fetch(`${config.discordApiBase}/api/oauth2/token/revoke`, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ client_id: cfg.clientId, client_secret: cfg.secret, token: tok.access_token }) }).catch(() => {});
  if (!ur.ok || !/^\d{5,25}$/.test(String(du.id || ''))) return '/coins?discord=token';
  const other: any = await one('SELECT id FROM users WHERE discord_id = ? AND id <> ?', [du.id, sessionUserId]);
  if (other) return '/coins?discord=taken';
  await exec('UPDATE users SET discord_id = ?, discord_username = ?, discord_linked_at = NOW() WHERE id = ?', [du.id, String(du.global_name ? `${du.global_name} (@${du.username})` : du.username || du.id).slice(0, 100), sessionUserId]);
  await audit(null, 'coins.discord_linked', { type: 'user', id: sessionUserId }, { discordId: du.id }, 'user');
  return '/coins?discord=linked';
}

// ---------------------------------------------------------------- Admin stats
export async function coinStats() {
  const circ: any = await one('SELECT COALESCE(SUM(coin_balance),0) AS total, SUM(coin_balance > 0) AS holders FROM users');
  const byType = await q<any>('SELECT type, SUM(GREATEST(amount,0)) AS earned, SUM(LEAST(amount,0)) AS spent, COUNT(*) AS n FROM coin_transactions WHERE created_at > NOW() - INTERVAL 1 DAY GROUP BY type');
  const lv: any = await one("SELECT SUM(status='completed') AS completed, SUM(status='failed') AS failed, SUM(status='pending') AS pending FROM linkvertise_claims WHERE created_at > NOW() - INTERVAL 1 DAY");
  return { inCirculation: Number(circ.total), holders: Number(circ.holders || 0), last24h: byType.map(r => ({ type: r.type, earned: Number(r.earned || 0), spent: -Number(r.spent || 0), count: Number(r.n) })), linkvertise24h: { completed: Number(lv?.completed || 0), failed: Number(lv?.failed || 0), pending: Number(lv?.pending || 0) } };
}
