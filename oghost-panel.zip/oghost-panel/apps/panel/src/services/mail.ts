import nodemailer from 'nodemailer';
import { getSetting } from './settings';
import { config } from '../config';

export async function mailConfigured() { return !!(await getSetting('smtp.host')); }
export async function sendMail(to: string, subject: string, text: string, html?: string) {
  const host = await getSetting<string>('smtp.host');
  if (!host || config.devMailLog) { console.log(`[mail:log-only] to=${to} subject="${subject}"\n${text}\n`); return { logged: true }; }
  const t = nodemailer.createTransport({ host, port: Number(await getSetting('smtp.port') || 587), secure: String(await getSetting('smtp.secure')) === 'true', auth: (await getSetting('smtp.user')) ? { user: await getSetting('smtp.user'), pass: await getSetting('smtp.password') } : undefined });
  const from = (await getSetting<string>('smtp.from')) || `OGHOST PANEL <no-reply@${new URL(config.appUrl).hostname}>`;
  const brand = `<div style="font-family:Inter,Arial,sans-serif;background:#0a0a0b;color:#eee;padding:24px"><h2 style="color:#ef4444;margin:0 0 12px">OGHOST</h2>${html || `<p>${text.replace(/\n/g, '<br>')}</p>`}<p style="color:#777;font-size:12px;margin-top:24px">Powered by SHIVAMBROOG</p></div>`;
  return t.sendMail({ from, to, subject, text, html: brand });
}
