'use strict';

const mineflayer = require('mineflayer');
const { pathfinder, Movements } = require('mineflayer-pathfinder');
const Brain = require('./brain');
const activities = require('./activities');
const PluginBypass = require('./pluginBypass');
const config = require('../config.json');

// ── Startup check ──────────────────────────────────────────────────────────
if (!process.env.GROQ_API_KEY) {
  console.error('[Bot] GROQ_API_KEY environment variable set nahi hai!');
  process.exit(1);
}

if (config.server.host === 'your-server.aternos.me') {
  console.warn('[Bot] WARNING: config.json mein apna server host update karo!');
  console.warn('[Bot] Ab bhi try kar raha hun connect karne ki...');
}

console.log(`[Bot] Server: ${config.server.host}:${config.server.port}`);
console.log(`[Bot] Username: ${config.bot.username}`);
console.log(`[Bot] Owner: ${config.bot.owner}`);

// ── Create bot ─────────────────────────────────────────────────────────────
const bot = mineflayer.createBot({
  host: config.server.host,
  port: config.server.port,
  username: config.bot.username,
  auth: config.bot.auth,
  version: config.server.version,
  keepAlive: true,
  chatLengthLimit: 256,
});

const brain = new Brain(config);
let bypass = null;
let autonomousLoop = null;
let isBusy = false;
let isFollowing = false;
let followTarget = null;
let followInterval = null;

// ── Load plugins ───────────────────────────────────────────────────────────
bot.loadPlugin(pathfinder);

try {
  const collectBlock = require('mineflayer-collectblock');
  bot.loadPlugin(collectBlock.plugin);
} catch (e) {
  console.log('[Bot] collectblock plugin load nahi hua, skip kar raha hun');
}

// ── Plugin bypass (Sonar / AuthMe / register) ──────────────────────────────
bypass = new PluginBypass(bot, config);

// ── Events ─────────────────────────────────────────────────────────────────
bot.once('spawn', () => {
  console.log('[Bot] Server mein spawn hua!');

  // Setup pathfinder
  const mcData = require('minecraft-data')(bot.version);
  const movements = new Movements(bot, mcData);
  movements.allowSprinting = true;
  movements.canDig = true;
  bot.pathfinder.setMovements(movements);

  bot.chat('Jai Hind! Main aa gaya server mein :)');

  // Start autonomous AI loop after 5 seconds
  setTimeout(() => startAutonomousLoop(), 5000);
});

bot.on('login', () => {
  console.log('[Bot] Login successful!');
});

bot.on('end', (reason) => {
  console.log(`[Bot] Disconnect hua: ${reason}`);
  clearAutonomousLoop();
  isBusy = false;
  isFollowing = false;
  if (followInterval) { clearInterval(followInterval); followInterval = null; }
  if (bypass) bypass.reset();
  // Auto-reconnect after 10 seconds
  setTimeout(() => {
    console.log('[Bot] Reconnect kar raha hun...');
    reconnect();
  }, 10000);
});

bot.on('error', (err) => {
  console.error(`[Bot] Error: ${err.message}`);
});

bot.on('kicked', (reason) => {
  console.log(`[Bot] Kicked: ${reason}`);
});

bot.on('death', () => {
  console.log('[Bot] Mar gaya! Respawn ho raha hun...');
  isBusy = false;
  bot.chat('arey yaar, mar gaya :(');
});

// ── Chat listener ──────────────────────────────────────────────────────────
bot.on('chat', async (username, message) => {
  // Ignore own messages
  if (username === config.bot.username.replace(/^\./, '')) return;
  if (username === config.bot.username) return;

  const owner = config.bot.owner;

  console.log(`[Chat] <${username}> ${message}`);

  // Only obey owner
  if (username === owner) {
    console.log(`[Bot] Owner command mila: "${message}"`);
    await handleOwnerCommand(message, username);
    return;
  }

  // Casual chat with others using AI
  if (message.toLowerCase().includes(config.bot.username.toLowerCase().replace('.', '')) ||
      message.toLowerCase().includes('bot') ||
      message.toLowerCase().includes('shivam')) {
    // Someone talking to the bot
    const response = await brain.processCommand(bot, `(Yaar ${username} ne kuch kaha) "${message}" — casual reply do`, username);
    if (response.chat) {
      setTimeout(() => bot.chat(response.chat), 1000 + Math.random() * 2000);
    }
  }
});

// ── Owner command handler ──────────────────────────────────────────────────
async function handleOwnerCommand(message, sender) {
  const lower = message.toLowerCase().trim();

  // Stop command
  if (lower === 'stop' || lower === 'ruk' || lower === 'ruko') {
    isBusy = false;
    isFollowing = false;
    if (followInterval) { clearInterval(followInterval); followInterval = null; }
    clearAutonomousLoop();
    bot.pathfinder.stop();
    bot.chat('Theek hai bhai, ruk gaya!');
    setTimeout(() => startAutonomousLoop(), 30000); // resume after 30s
    return;
  }

  // Resume
  if (lower === 'start' || lower === 'chalo' || lower === 'continue') {
    isBusy = false;
    bot.chat('Chalte hain!');
    startAutonomousLoop();
    return;
  }

  // Follow me
  if (lower === 'follow' || lower === 'aa mere paas' || lower === 'follow me' || lower === 'mere saath aa') {
    isFollowing = true;
    followTarget = sender;
    bot.chat(`Aa raha hun ${sender} bhai!`);
    startFollowing(sender);
    return;
  }

  // Stop following
  if (lower === 'stop follow' || lower === 'mat aao' || lower === 'ruko follow mat karo') {
    isFollowing = false;
    followTarget = null;
    if (followInterval) { clearInterval(followInterval); followInterval = null; }
    bot.chat('Theek hai, nahi aata!');
    return;
  }

  // Come here
  if (lower === 'come' || lower === 'aa' || lower === 'idhar aa') {
    bot.chat('Aa raha hun!');
    await activities.followPlayer(bot, sender);
    return;
  }

  // Mine command: "mine diamond" / "mine iron ore" / "kho diamond_ore"
  const mineMatch = lower.match(/^(?:mine|kho|khod)\s+(.+)$/);
  if (mineMatch) {
    const target = mineMatch[1].trim().replace(/\s+/g, '_');
    bot.chat(`Chalte hain ${target} khodne!`);
    clearAutonomousLoop();
    isBusy = true;
    const mined = await activities.mineSession(bot, target, 10, 64);
    bot.chat(mined > 0 ? `${mined} ${target} khoda bhai!` : `${target} nahi mila yaar :(`);
    isBusy = false;
    startAutonomousLoop();
    return;
  }

  // Craft command: "craft torch" / "bana torch"
  const craftMatch = lower.match(/^(?:craft|bana|banao)\s+(.+)$/);
  if (craftMatch) {
    const target = craftMatch[1].trim().replace(/\s+/g, '_');
    bot.chat(`${target} craft kar raha hun!`);
    clearAutonomousLoop();
    isBusy = true;
    const success = await activities.craft(bot, target);
    bot.chat(success ? `${target} ban gaya!` : `${target} craft nahi hua, materials nahi hain shayad`);
    isBusy = false;
    startAutonomousLoop();
    return;
  }

  // Inventory
  if (lower === 'inv' || lower === 'inventory' || lower === 'items' || lower === 'kya hai paas mein') {
    const items = bot.inventory.items();
    if (items.length === 0) {
      bot.chat('Kuch nahi hai mere paas :(');
    } else {
      const summary = items.slice(0, 8).map(i => `${i.name}x${i.count}`).join(', ');
      bot.chat(`Mere paas: ${summary}${items.length > 8 ? '...' : ''}`);
    }
    return;
  }

  // Status
  if (lower === 'status' || lower === 'health' || lower === 'kitna hp hai') {
    const pos = bot.entity.position;
    bot.chat(`HP: ${Math.floor(bot.health)}/20, Food: ${Math.floor(bot.food)}/20, Pos: ${Math.floor(pos.x)},${Math.floor(pos.y)},${Math.floor(pos.z)}`);
    return;
  }

  // Eat
  if (lower === 'kha' || lower === 'kha le' || lower === 'eat') {
    const ate = await activities.eat(bot);
    if (!ate) bot.chat('Kuch nahi khane ko mere paas :(');
    return;
  }

  // Explore
  if (lower === 'explore' || lower === 'ghoom' || lower === 'ghoom aao') {
    bot.chat('Chalte hain explore karte hain!');
    clearAutonomousLoop();
    isBusy = true;
    await activities.explore(bot);
    isBusy = false;
    startAutonomousLoop();
    return;
  }

  // Any other command — let AI handle it
  console.log('[Bot] AI se command process kara raha hun...');
  clearAutonomousLoop();
  isBusy = true;

  const decision = await brain.processCommand(bot, message, sender);
  console.log(`[Brain] Decision: ${JSON.stringify(decision)}`);

  if (decision.chat) {
    bot.chat(decision.chat);
  }

  await executeDecision(decision);
  isBusy = false;
  startAutonomousLoop();
}

// ── Execute AI decision ────────────────────────────────────────────────────
async function executeDecision(decision) {
  if (!decision || !decision.action) return;

  try {
    switch (decision.action) {
      case 'mine':
        if (decision.target) {
          await activities.mineSession(bot, decision.target, 5, 32);
        }
        break;

      case 'craft':
        if (decision.target) {
          await activities.craft(bot, decision.target);
        }
        break;

      case 'eat':
        await activities.eat(bot);
        break;

      case 'explore':
        await activities.explore(bot);
        break;

      case 'follow':
        if (decision.target) {
          await activities.followPlayer(bot, decision.target);
        }
        break;

      case 'build':
        await activities.buildShelter(bot);
        break;

      case 'sleep':
        await activities.sleepInBed(bot);
        break;

      case 'attack': {
        const mob = Object.values(bot.entities).find(e =>
          e.type === 'mob' && e.position.distanceTo(bot.entity.position) < 8
        );
        if (mob) {
          bot.attack(mob);
        }
        break;
      }

      case 'idle':
      default:
        // Do nothing
        break;
    }
  } catch (err) {
    console.log(`[Bot] Action execute karne mein error: ${err.message}`);
  }
}

// ── Autonomous loop ────────────────────────────────────────────────────────
function startAutonomousLoop() {
  clearAutonomousLoop();
  console.log('[Bot] Autonomous AI loop shuru ho raha hai...');

  autonomousLoop = setInterval(async () => {
    if (isBusy || isFollowing) return;

    // Emergency: health check
    if (bot.health < 5) {
      isBusy = true;
      bot.chat('arey bhai maar denge mujhe!');
      await activities.eat(bot);
      isBusy = false;
      return;
    }

    // Emergency: hunger
    if (bot.food < 6) {
      isBusy = true;
      await activities.eat(bot);
      isBusy = false;
      return;
    }

    isBusy = true;
    try {
      const decision = await brain.decide(bot);
      console.log(`[Brain] Autonomous: ${decision.thought} → ${decision.action}:${decision.target}`);

      if (decision.chat) {
        bot.chat(decision.chat);
      }

      await executeDecision(decision);
    } catch (err) {
      console.error('[Bot] Autonomous loop error:', err.message);
    } finally {
      isBusy = false;
    }
  }, config.ai.decisionInterval);
}

function clearAutonomousLoop() {
  if (autonomousLoop) {
    clearInterval(autonomousLoop);
    autonomousLoop = null;
  }
}

// ── Follow loop ─────────────────────────────────────────────────────────────
function startFollowing(username) {
  if (followInterval) clearInterval(followInterval);

  followInterval = setInterval(async () => {
    if (!isFollowing) return;
    const player = bot.players[username];
    if (!player || !player.entity) return;

    const dist = player.entity.position.distanceTo(bot.entity.position);
    if (dist > config.behavior.followDistance + 2) {
      try {
        await activities.followPlayer(bot, username);
      } catch (_) {}
    }
  }, 2000);
}

// ── Reconnect ──────────────────────────────────────────────────────────────
function reconnect() {
  const newBot = mineflayer.createBot({
    host: config.server.host,
    port: config.server.port,
    username: config.bot.username,
    auth: config.bot.auth,
    version: config.server.version,
    keepAlive: true,
  });
  // Re-attach would require full reload; just restart process
  process.exit(0); // Let the workflow auto-restart
}

// ── Anti-AFK ────────────────────────────────────────────────────────────────
setInterval(() => {
  if (bot.entity) {
    bot.swingArm();
  }
}, 45000);

console.log('[Bot] Bot initialize ho gaya, server se connect ho raha hai...');
