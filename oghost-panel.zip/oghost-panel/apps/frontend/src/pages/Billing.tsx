import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { Receipt, Printer, Coins } from 'lucide-react';
import { useAuth } from '../lib/auth';
import { useApi, useAction, toast } from '../lib/hooks';
import { post, api } from '../lib/api';
import { razorpayCheckout, cashfreeCheckout } from '../lib/checkout';
import { date, day, money, mb } from '../lib/format';
import { Badge, Card, Confirm, Empty, ErrorBox, Field, Loading, Modal, Notice, PageHeader, Spinner, Switch, Table, Tabs } from '../components/ui';

const coinsChanged = () => window.dispatchEvent(new Event('oghost:coins'));
const coinCfg = (config: any) => ({ on: !!config?.coins?.enabled, name: config?.coins?.name || 'OGCoins' });

export function Billing() {
  const [tab, setTab] = useState<'services' | 'invoices' | 'orders'>('services');
  return <><PageHeader title="Billing" subtitle="Services, invoices and orders." /><Tabs value={tab} onChange={setTab} tabs={[{ id: 'services', label: 'Services' }, { id: 'invoices', label: 'Invoices' }, { id: 'orders', label: 'Orders' }]} />{tab === 'services' ? <Services /> : tab === 'invoices' ? <Invoices /> : <Orders />}</>;
}
function Services() {
  const { data, error, loading, reload } = useApi<any>('/api/store/services'); const { busy, run } = useAction(); const nav = useNavigate();
  const [change, setChange] = useState<any>(null); const [cancel, setCancel] = useState<any>(null); const { config } = useAuth(); const cc = coinCfg(config);
  if (loading) return <Loading />; if (error) return <ErrorBox error={error} onRetry={reload} />;
  if (!data.services.length) return <div className="card"><Empty title="No services" icon={<Receipt className="h-8 w-8" />}><Link to="/store" className="link">Order a plan</Link></Empty></div>;
  return (
    <div className="space-y-3">
      {data.services.map((s: any) => (
        <div key={s.id} className="card card-pad flex flex-wrap items-center gap-4">
          <div className="min-w-0 flex-1"><div className="flex flex-wrap items-center gap-2 font-bold text-white">{s.product_name} · {s.plan_name}<Badge value={s.status} />{s.cancel_at_period_end ? <Badge value="cancelled" label="cancels at period end" /> : null}</div>
            <div className="mt-1 text-xs text-ink-400">{mb(s.memory_mb)} RAM · {s.cpu_percent / 100} CPU · {mb(s.disk_mb)} disk · {s.price_cents > 0 || s.coin_price == null ? `${money(s.price_cents, s.currency)} ` : ''}{cc.on && s.coin_price != null ? `${s.price_cents > 0 ? 'or ' : ''}${Number(s.coin_price).toLocaleString()} ${cc.name} ` : ''}{s.billing_cycle} · next due {day(s.next_due_at)}</div>
            {cc.on && s.coin_price != null && ['active', 'suspended'].includes(s.status) && s.billing_cycle !== 'one_time' && <div className="mt-2"><Switch checked={!!s.auto_renew_coins} disabled={busy === `ar${s.id}`} onChange={v => run(`ar${s.id}`, () => api('PUT', `/api/store/services/${s.id}/auto-renew`, { enabled: v }).then(reload), v ? `Auto-renew with ${cc.name} enabled` : 'Auto-renew disabled')} label={<span className="text-xs text-ink-300">Auto-renew with {cc.name} (charged up to 24 h before the due date)</span>} /></div>}
            {s.server_id && <Link className="link text-xs" to={`/server/${s.server_id}`}>Server: {s.server_name}</Link>}</div>
          <div className="flex flex-wrap gap-2">
            {['active', 'suspended'].includes(s.status) && s.billing_cycle !== 'one_time' && <button className="btn-secondary btn-sm" disabled={!!busy} onClick={() => run(`r${s.id}`, async () => { const r = await post(`/api/store/services/${s.id}/renew`); nav(`/billing/invoices/${r.invoiceId}`); })}>Renew</button>}
            {cc.on && s.coin_price != null && ['active', 'suspended'].includes(s.status) && s.billing_cycle !== 'one_time' && <button className="btn-secondary btn-sm" disabled={!!busy} onClick={() => run(`rc${s.id}`, async () => { await post(`/api/store/services/${s.id}/renew-coins`); coinsChanged(); reload(); }, `Renewed with ${cc.name}`)}>{busy === `rc${s.id}` ? <Spinner /> : <Coins className="h-4 w-4" />}Renew with {cc.name} ({Number(s.coin_price).toLocaleString()})</button>}
            {s.status === 'active' && <button className="btn-secondary btn-sm" onClick={() => setChange(s)}>Upgrade / downgrade</button>}
            {s.status === 'active' && !s.cancel_at_period_end && <button className="btn-danger btn-sm" onClick={() => setCancel(s)}>Cancel</button>}
            {s.status === 'active' && !!s.cancel_at_period_end && <button className="btn-secondary btn-sm" onClick={() => run('u', () => post(`/api/store/services/${s.id}/uncancel`).then(reload), 'Cancellation withdrawn')}>Keep service</button>}
          </div>
        </div>))}
      {change && <ChangePlan svc={change} onClose={() => { setChange(null); reload(); }} />}
      <CancelDialog svc={cancel} onClose={() => { setCancel(null); reload(); }} />
    </div>
  );
}
function ChangePlan({ svc, onClose }: { svc: any; onClose: () => void }) {
  const { data } = useApi<any>(`/api/store/services/${svc.id}/plans`); const { busy, run } = useAction(); const nav = useNavigate(); const [pid, setPid] = useState<number | null>(null);
  return (
    <Modal open onClose={onClose} title="Change plan" footer={<><button className="btn-secondary" onClick={onClose}>Close</button><button className="btn-primary" disabled={!pid || !!busy} onClick={() => run('c', async () => { const r = await post(`/api/store/services/${svc.id}/change-plan`, { planId: pid }); if (r.invoiceId) nav(`/billing/invoices/${r.invoiceId}`); else { toast(r.message || 'Plan changed', 'success'); onClose(); } })}>{busy && <Spinner />}Change plan</button></>}>
      {!data ? <Loading /> : <div className="space-y-2">{data.plans.map((p: any) => <label key={p.id} className="flex cursor-pointer items-center gap-3 rounded-lg border border-ink-700 p-3 hover:bg-ink-850"><input type="radio" name="plan" disabled={p.id === data.current} checked={pid === p.id} onChange={() => setPid(p.id)} /><div className="flex-1"><div className="font-semibold">{p.name} {p.id === data.current && <span className="text-xs text-ink-400">(current)</span>}</div><div className="text-xs text-ink-400">{mb(p.memory_mb)} · {p.cpu_percent / 100} CPU · {mb(p.disk_mb)}</div></div><div className="font-bold">{money(p.price_cents, p.currency)}</div></label>)}<p className="hint">Upgrades are charged pro-rata for the rest of the current period; resources change after payment. Downgrades apply immediately with credit noted on the next invoice when supported, and fail if your current usage exceeds the new limits.</p></div>}
    </Modal>
  );
}
function CancelDialog({ svc, onClose }: { svc: any; onClose: () => void }) {
  const { busy, run } = useAction(); const [immediate, setImmediate] = useState(false);
  return <Confirm open={!!svc} onClose={onClose} title="Cancel service" danger confirmLabel="Cancel service" busy={!!busy} phrase={immediate ? 'DELETE' : undefined} onConfirm={() => run('x', () => post(`/api/store/services/${svc.id}/cancel`, { immediate }).then(onClose), 'Service cancelled')}>
    <p>By default the service stays active until the end of the paid period.</p>
    <label className="flex items-center gap-2"><input type="checkbox" checked={immediate} onChange={e => setImmediate(e.target.checked)} />Cancel immediately and delete the server (cannot be undone)</label>
  </Confirm>;
}
function Invoices() {
  const { data, error, loading, reload } = useApi<any>('/api/store/invoices'); const { config } = useAuth(); const cc = coinCfg(config);
  if (loading) return <Loading />; if (error) return <ErrorBox error={error} onRetry={reload} />;
  if (!data.invoices.length) return <div className="card"><Empty title="No invoices yet" /></div>;
  return <Card pad><Table><thead><tr><th>Number</th><th>Status</th><th>Total</th><th>Due</th><th>Paid</th><th /></tr></thead><tbody>{data.invoices.map((i: any) => <tr key={i.id}><td className="font-mono">{i.number}</td><td><Badge value={i.status} /></td><td>{money(i.total_cents, i.currency)}{i.coin_total != null && cc.on && <div className="text-xs text-amber-300">or {Number(i.coin_total).toLocaleString()} {cc.name}</div>}</td><td>{day(i.due_at)}</td><td>{day(i.paid_at)}</td><td className="text-right"><Link className="btn-secondary btn-sm" to={`/billing/invoices/${i.id}`}>{i.status === 'unpaid' ? 'Pay' : 'View'}</Link></td></tr>)}</tbody></Table></Card>;
}
function Orders() {
  const { data, error, loading } = useApi<any>('/api/store/orders');
  if (loading) return <Loading />; if (error) return <ErrorBox error={error} />;
  if (!data.orders.length) return <div className="card"><Empty title="No orders yet" /></div>;
  return <Card><Table><thead><tr><th>#</th><th>Kind</th><th>Plan</th><th>Status</th><th>Amount</th><th>Created</th></tr></thead><tbody>{data.orders.map((o: any) => <tr key={o.id}><td>{o.id}</td><td>{o.kind}</td><td>{o.plan_name}</td><td><Badge value={o.status} /></td><td>{money(o.amount_cents, o.currency)}</td><td>{date(o.created_at)}</td></tr>)}</tbody></Table></Card>;
}

export function InvoicePage() {
  const { id } = useParams(); const [sp, setSp] = useSearchParams();
  const { data, error, loading, reload } = useApi<any>(`/api/store/invoices/${id}`, [id], 0);
  const gw = useApi<any>('/api/store/gateways'); const { busy, run } = useAction(); const { config } = useAuth(); const cc = coinCfg(config);
  const [pending, setPending] = useState<any>(null); const [ref, setRef] = useState('');
  useEffect(() => { // returning from a hosted checkout: ask the backend to confirm with the gateway API
    if (sp.get('checkout') === 'return' && data?.payments?.length) { const p = data.payments.find((x: any) => x.status === 'pending'); if (p) post(`/api/store/payments/${p.id}/refresh`).then(r => { toast(r.status === 'succeeded' ? 'Payment confirmed' : 'Payment not confirmed yet. It will update automatically when the gateway notifies us.', r.status === 'succeeded' ? 'success' : 'info'); reload(); }).catch(() => {}); setSp({}); }
  }, [data]);
  if (loading) return <Loading />; if (error) return <ErrorBox error={error} />;
  const inv = data.invoice;
  const pay = (g: string) => run(g, async () => {
    const r = await post(`/api/store/invoices/${inv.id}/pay`, { gateway: g });
    if (g === 'razorpay') { const res = await razorpayCheckout(r); const v = await post('/api/store/payments/razorpay/verify', res); toast(v.status === 'succeeded' ? 'Payment verified' : 'Payment received; awaiting confirmation', 'success'); reload(); }
    else if (g === 'stripe') window.location.href = r.url;
    else if (g === 'cashfree') await cashfreeCheckout(r);
    else setPending(r);
  });
  return (
    <>
      <PageHeader title={`Invoice ${inv.number}`} subtitle={<>Created {date(inv.created_at)} · due {day(inv.due_at)}</>} actions={<><Badge value={inv.status} /><button className="btn-secondary btn-sm" onClick={() => window.print()}><Printer className="h-4 w-4" />Print</button></>} />
      <div className="grid gap-5 lg:grid-cols-3">
        <Card title="Details" className="lg:col-span-2">
          <div className="mb-4 text-sm text-ink-400"><div className="font-semibold text-zinc-200">{data.company.name}</div>{data.company.address && <div className="whitespace-pre-line">{data.company.address}</div>}{data.company.taxId && <div>Tax ID: {data.company.taxId}</div>}</div>
          <Table><thead><tr><th>Description</th><th className="text-right">Amount</th></tr></thead><tbody>{inv.items.map((it: any, i: number) => <tr key={i}><td>{it.description}</td><td className="text-right">{money(it.amount_cents, inv.currency)}</td></tr>)}
            {inv.discount_cents > 0 && <tr><td className="text-emerald-400">Discount</td><td className="text-right text-emerald-400">-{money(inv.discount_cents, inv.currency)}</td></tr>}
            <tr><td className="font-bold text-white">Total</td><td className="text-right font-bold text-white">{money(inv.total_cents, inv.currency)}</td></tr>
            {inv.coin_total != null && cc.on && <tr><td className="text-amber-200">Or pay with {cc.name}</td><td className="text-right font-bold text-amber-200">{Number(inv.coin_total).toLocaleString()} {cc.name}</td></tr>}</tbody></Table>
          {data.payments.length > 0 && <><h3 className="mb-2 mt-6 text-xs font-bold uppercase tracking-wide text-ink-400">Payments</h3><Table><thead><tr><th>Gateway</th><th>Status</th><th>Amount</th><th>Reference</th><th>Date</th><th /></tr></thead><tbody>{data.payments.map((p: any) => <tr key={p.id}><td className="uppercase">{p.gateway}</td><td><Badge value={p.status} />{p.failure_reason && <div className="text-xs text-red-400">{p.failure_reason}</div>}</td><td>{money(p.amount_cents, p.currency)}{p.refunded_cents > 0 && <div className="text-xs text-ink-400">refunded {money(p.refunded_cents, p.currency)}</div>}</td><td className="font-mono text-xs">{p.reference || '—'}</td><td>{date(p.created_at)}</td><td>{p.status === 'pending' && ['stripe', 'cashfree', 'razorpay'].includes(p.gateway) && <button className="btn-secondary btn-sm" onClick={() => run('ref', () => post(`/api/store/payments/${p.id}/refresh`).then(reload))}>Check status</button>}</td></tr>)}</tbody></Table></>}
        </Card>
        <Card title="Pay">
          {inv.status === 'unpaid' && inv.coin_total != null && cc.on && <div className="mb-4 space-y-2 border-b border-ink-700 pb-4"><button className="btn-primary w-full justify-between" disabled={!!busy} onClick={() => run('coins', async () => { await post(`/api/store/invoices/${inv.id}/pay-coins`); coinsChanged(); reload(); }, `Paid with ${cc.name}`)}><span className="flex items-center gap-2"><Coins className="h-4 w-4" />Pay {Number(inv.coin_total).toLocaleString()} {cc.name}</span>{busy === 'coins' && <Spinner />}</button><Link to="/coins" className="link text-xs">Check balance / get {cc.name}</Link></div>}
          {inv.status !== 'unpaid' ? <Notice kind={inv.status === 'paid' ? 'success' : 'info'}>This invoice is {inv.status}.</Notice> : inv.total_cents === 0 && inv.coin_total != null ? <p className="hint">This invoice can only be paid with {cc.name}.</p> : !gw.data ? <Loading /> : !gw.data.gateways.length ? <Notice kind="warn">No payment methods are configured yet. Contact support.</Notice> :
            <div className="space-y-2">{gw.data.gateways.map((g: any) => <button key={g.id} className="btn-secondary w-full justify-between" disabled={!!busy} onClick={() => pay(g.id)}><span>{g.name}</span>{busy === g.id && <Spinner />}</button>)}
              <p className="hint">Invoices are marked paid only after the payment gateway confirms the payment (verified signature, API lookup or webhook) or an administrator approves a manual/UPI transfer.</p></div>}
        </Card>
      </div>
      <Modal open={!!pending} onClose={() => { setPending(null); reload(); }} title={pending?.gateway === 'upi' ? 'Pay with UPI' : 'Manual payment'} footer={<button className="btn-primary" disabled={ref.trim().length < 6 || !!busy} onClick={() => run('sub', () => post(`/api/store/payments/${pending.paymentId}/reference`, { reference: ref.trim() }).then(() => { setPending(null); setRef(''); reload(); }), 'Reference submitted for approval')}>Submit reference</button>}>
        {pending && <div className="space-y-4 text-sm">
          {pending.qr && <div className="flex flex-col items-center gap-2"><img src={pending.qr} alt="UPI QR code" className="h-52 w-52 rounded-lg bg-white p-2" /><a className="btn-secondary btn-sm sm:hidden" href={pending.uri}>Open UPI app</a><div className="text-center text-ink-300">Pay <b>{money(pending.amount, inv.currency)}</b> to <span className="font-mono">{pending.vpa}</span> ({pending.payee})</div></div>}
          <Notice kind="info">{pending.note || pending.instructions}</Notice>
          <Field label="Transaction reference (UTR / ID)"><input className="input font-mono" value={ref} onChange={e => setRef(e.target.value)} maxLength={64} /></Field>
        </div>}
      </Modal>
    </>
  );
}
