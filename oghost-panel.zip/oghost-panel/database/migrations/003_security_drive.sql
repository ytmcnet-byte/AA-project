CREATE TABLE security_scans (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  server_id INT UNSIGNED NOT NULL,
  file VARCHAR(500) NOT NULL,
  mode VARCHAR(16) NOT NULL,
  phase VARCHAR(32) NOT NULL,
  level VARCHAR(16) NOT NULL,
  sha256 CHAR(64) NOT NULL,
  size_bytes BIGINT UNSIGNED NOT NULL DEFAULT 0,
  reason VARCHAR(500) NULL,
  minecraft JSON NULL,
  findings JSON NULL,
  review_status ENUM('none','pending','approved','rejected') NOT NULL DEFAULT 'none',
  reviewed_by INT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_scan_server (server_id, created_at), INDEX idx_scan_level (level, review_status), INDEX idx_scan_sha (sha256),
  CONSTRAINT fk_scan_server FOREIGN KEY (server_id) REFERENCES servers(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE security_incidents (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  server_id INT UNSIGNED NULL,
  node_id INT UNSIGNED NULL,
  severity ENUM('low','medium','high') NOT NULL,
  category VARCHAR(50) NOT NULL,
  rule VARCHAR(100) NOT NULL,
  status ENUM('open','resolved','dismissed') NOT NULL DEFAULT 'open',
  action_taken VARCHAR(255) NULL,
  evidence JSON NULL,
  reviewed_by INT UNSIGNED NULL,
  review_note TEXT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_inc_status (status, severity), INDEX idx_inc_server (server_id), INDEX idx_inc_cat (category)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE security_appeals (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  server_id INT UNSIGNED NOT NULL,
  user_id INT UNSIGNED NOT NULL,
  message TEXT NOT NULL,
  status ENUM('open','accepted','rejected') NOT NULL DEFAULT 'open',
  response TEXT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_appeal_server FOREIGN KEY (server_id) REFERENCES servers(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE trusted_software (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  sha256 CHAR(64) NOT NULL UNIQUE,
  name VARCHAR(200) NOT NULL,
  note VARCHAR(500) NULL,
  added_by INT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE drive_connections (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL UNIQUE,
  google_email VARCHAR(191) NULL,
  google_sub VARCHAR(64) NULL,
  refresh_token_enc TEXT NOT NULL,
  access_token_enc TEXT NULL,
  access_expires_at DATETIME NULL,
  scopes VARCHAR(500) NULL,
  root_folder_id VARCHAR(128) NULL,
  status ENUM('connected','error','revoked') NOT NULL DEFAULT 'connected',
  last_error TEXT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_dc_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE drive_oauth_states (
  state CHAR(64) PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  return_to VARCHAR(300) NULL,
  code_verifier VARCHAR(128) NOT NULL,
  expires_at DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE drive_backup_configs (
  server_id INT UNSIGNED PRIMARY KEY,
  enabled TINYINT(1) NOT NULL DEFAULT 0,
  interval_minutes INT UNSIGNED NOT NULL DEFAULT 60,
  retention INT UNSIGNED NOT NULL DEFAULT 1,
  retry_count INT UNSIGNED NOT NULL DEFAULT 3,
  retry_delay_minutes INT UNSIGNED NOT NULL DEFAULT 5,
  failures_in_row INT UNSIGNED NOT NULL DEFAULT 0,
  running TINYINT(1) NOT NULL DEFAULT 0,
  running_since DATETIME NULL,
  last_success_at DATETIME NULL,
  last_attempt_at DATETIME NULL,
  next_run_at DATETIME NULL,
  last_error TEXT NULL,
  progress JSON NULL,
  folder_id VARCHAR(128) NULL,
  CONSTRAINT fk_dbc_server FOREIGN KEY (server_id) REFERENCES servers(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE drive_backups (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  server_id INT UNSIGNED NOT NULL,
  user_id INT UNSIGNED NOT NULL,
  file_id VARCHAR(128) NULL,
  name VARCHAR(200) NOT NULL,
  size_bytes BIGINT UNSIGNED NOT NULL DEFAULT 0,
  md5 CHAR(32) NULL,
  verified TINYINT(1) NOT NULL DEFAULT 0,
  status ENUM('uploading','completed','failed','deleted') NOT NULL DEFAULT 'uploading',
  trigger_type ENUM('scheduled','manual','safety') NOT NULL DEFAULT 'scheduled',
  error TEXT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  completed_at DATETIME NULL,
  deleted_at DATETIME NULL,
  INDEX idx_drb (server_id, status, completed_at),
  CONSTRAINT fk_drb_server FOREIGN KEY (server_id) REFERENCES servers(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE tickets (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  server_id INT UNSIGNED NULL,
  category VARCHAR(50) NOT NULL,
  subject VARCHAR(200) NOT NULL,
  priority ENUM('low','normal','high','urgent') NOT NULL DEFAULT 'normal',
  status ENUM('open','awaiting_staff','awaiting_customer','closed') NOT NULL DEFAULT 'open',
  assigned_to INT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_tickets_user (user_id), INDEX idx_tickets_status (status),
  CONSTRAINT fk_tickets_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE ticket_messages (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  ticket_id INT UNSIGNED NOT NULL,
  user_id INT UNSIGNED NOT NULL,
  body TEXT NOT NULL,
  is_staff TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_tm_ticket FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE ticket_attachments (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  message_id INT UNSIGNED NOT NULL,
  filename VARCHAR(200) NOT NULL,
  stored_name CHAR(64) NOT NULL,
  size_bytes INT UNSIGNED NOT NULL,
  mime VARCHAR(100) NOT NULL,
  CONSTRAINT fk_ta_msg FOREIGN KEY (message_id) REFERENCES ticket_messages(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
