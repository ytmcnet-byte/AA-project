import type { Router } from 'express';

/** Builds an OpenAPI 3.1 document by walking the real Express route table, so the docs never list endpoints that do not exist. */
const TAG_INFO: Record<string, string> = {
  auth: 'Login, registration, Google sign-in, 2FA, password reset', account: 'Profile, sessions, API keys, notifications', servers: 'Server control, console, files, backups, schedules, databases, network, subusers, plugins, versions',
  drive: 'Google Drive backup connection', store: 'Catalog, checkout, services, orders, invoices, payments', tickets: 'Support tickets', admin: 'Administration (requires admin permissions)', extensions: 'Routes registered by enabled extensions', webhooks: 'Payment gateway webhooks (signature verified)',
};
export function buildOpenApi(mounts: Array<[string, Router]>, version: string, serverUrl: string) {
  const paths: Record<string, any> = {};
  const walk = (prefix: string, router: any, tag: string) => {
    for (const layer of router?.stack || []) {
      if (layer.route) {
        const p = (prefix + (layer.route.path === '/' ? '' : layer.route.path)) || '/';
        const params: string[] = [];
        const oPath = p.replace(/\{\*(\w+)\}/g, (_: string, n: string) => (params.push(n), `{${n}}`)).replace(/:(\w+)/g, (_: string, n: string) => (params.push(n), `{${n}}`));
        const methods = Object.keys(layer.route.methods || {}).filter(m => m !== '_all');
        for (const m of methods.length ? methods : ['get', 'post', 'put', 'patch', 'delete']) {
          paths[oPath] ??= {};
          paths[oPath][m] = {
            tags: [tag], operationId: `${m}_${oPath.replace(/[^a-zA-Z0-9]+/g, '_')}`.replace(/_+$/, ''),
            parameters: params.map(n => ({ name: n, in: 'path', required: true, schema: { type: n === 'id' || n.endsWith('Id') ? 'integer' : 'string' } })),
            ...(['post', 'put', 'patch'].includes(m) ? { requestBody: { required: false, content: { 'application/json': { schema: { type: 'object' } } } } } : {}),
            responses: { 200: { description: 'Success' }, 401: { description: 'Not authenticated' }, 403: { description: 'Missing permission or API key scope' }, 422: { description: 'Validation error' } },
          };
        }
      } else if (layer.handle?.stack) walk(prefix, layer.handle, tag);
    }
  };
  for (const [prefix, r] of mounts) walk(prefix, r, prefix.split('/')[2] || 'api');
  return {
    openapi: '3.1.0',
    info: { title: 'OGHOST PANEL API', version, description: 'Powering the Next Generation of Game Hosting. Authenticate with an API key (`Authorization: Bearer ogh_...`, scoped) or a browser session cookie plus the `X-CSRF-Token` header for state-changing requests. Request bodies are validated server-side; validation errors return 422 with a message.' },
    servers: [{ url: serverUrl }],
    tags: Object.entries(TAG_INFO).map(([name, description]) => ({ name, description })),
    components: { securitySchemes: { apiKey: { type: 'http', scheme: 'bearer', bearerFormat: 'ogh_<prefix>_<secret>' }, session: { type: 'apiKey', in: 'cookie', name: 'oghost_session' } } },
    security: [{ apiKey: [] }, { session: [] }],
    paths: Object.fromEntries(Object.entries(paths).sort(([a], [b]) => a.localeCompare(b))),
  };
}

export const DOCS_HTML = `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>OGHOST PANEL API</title>
<style>body{margin:0;background:#0a0a0b;color:#e5e5e5;font:14px system-ui,sans-serif}header{padding:20px 28px;border-bottom:1px solid #26262b;background:linear-gradient(90deg,#1a0505,#0a0a0b)}h1{margin:0;font-size:20px;color:#fff}h1 b{color:#ef4444}main{padding:20px 28px;max-width:1100px}h2{color:#f87171;font-size:16px;margin:28px 0 6px;text-transform:capitalize}.d{color:#9ca3af;margin:0 0 10px}.r{display:flex;gap:12px;padding:6px 10px;border:1px solid #1f1f24;border-radius:6px;margin:4px 0;background:#111114;font-family:ui-monospace,monospace;font-size:13px}.m{width:60px;font-weight:700;text-transform:uppercase}.get{color:#60a5fa}.post{color:#4ade80}.put,.patch{color:#facc15}.delete{color:#f87171}input{width:100%;padding:8px 10px;background:#111114;border:1px solid #26262b;color:#fff;border-radius:6px;box-sizing:border-box}a{color:#f87171}footer{padding:20px 28px;color:#6b7280}</style></head>
<body><header><h1><b>OGHOST</b> PANEL API</h1><div class="d" id="info"></div><a href="/api/docs/openapi.json">openapi.json</a></header><main><input id="f" placeholder="Filter endpoints..."><div id="out"></div></main><footer>Powered by SHIVAMBROOG</footer>
<script>fetch('/api/docs/openapi.json').then(r=>r.json()).then(s=>{document.getElementById('info').textContent=s.info.description;const desc={};s.tags.forEach(t=>desc[t.name]=t.description);
const rows=[];for(const[p,ms]of Object.entries(s.paths))for(const[m,o]of Object.entries(ms))rows.push({p,m,t:o.tags[0]});
const render=f=>{const out=document.getElementById('out');out.innerHTML='';const g={};rows.filter(r=>!f||(r.m+' '+r.p).toLowerCase().includes(f)).forEach(r=>(g[r.t]=g[r.t]||[]).push(r));
for(const[t,rs]of Object.entries(g)){const h=document.createElement('h2');h.textContent=t+' ('+rs.length+')';out.appendChild(h);const d=document.createElement('p');d.className='d';d.textContent=desc[t]||'';out.appendChild(d);
rs.forEach(r=>{const e=document.createElement('div');e.className='r';const a=document.createElement('span');a.className='m '+r.m;a.textContent=r.m;const b=document.createElement('span');b.textContent=r.p;e.append(a,b);out.appendChild(e);});}};
render('');document.getElementById('f').oninput=e=>render(e.target.value.toLowerCase());});</script></body></html>`;
