// Fetch wrapper: cookie session + CSRF header, JSON errors surfaced as ApiError.
export class ApiError extends Error { constructor(public status: number, message: string, public data?: any) { super(message); } }
let csrfToken: string | null = null;
export const setCsrf = (t: string | null) => { csrfToken = t; };
export const getCsrf = () => csrfToken;

export async function api<T = any>(method: string, path: string, body?: unknown, opts: { raw?: boolean; headers?: Record<string, string>; signal?: AbortSignal } = {}): Promise<T> {
  const headers: Record<string, string> = { ...(opts.headers || {}) };
  let payload: BodyInit | undefined;
  if (body instanceof Blob || body instanceof ArrayBuffer || body instanceof Uint8Array || typeof body === 'string') { payload = body as BodyInit; headers['content-type'] ??= 'application/octet-stream'; }
  else if (body instanceof FormData) payload = body;
  else if (body !== undefined) { payload = JSON.stringify(body); headers['content-type'] = 'application/json'; }
  if (method !== 'GET' && csrfToken) headers['x-csrf-token'] = csrfToken;
  const r = await fetch(path.startsWith('/') ? path : `/api/${path}`, { method, headers, body: payload, credentials: 'same-origin', signal: opts.signal });
  const ct = r.headers.get('content-type') || '';
  if (!r.ok) {
    let data: any = null; try { data = ct.includes('json') ? await r.json() : { error: await r.text() }; } catch { /* empty */ }
    const msg = data?.issues?.length ? `${data.error}: ${data.issues.map((i: any) => `${i.path ? i.path + ' ' : ''}${i.message}`).join('; ')}` : data?.error || `Request failed (${r.status})`;
    if (r.status === 401 && !path.includes('/auth/')) window.dispatchEvent(new CustomEvent('oghost:unauthorized'));
    throw new ApiError(r.status, msg, data);
  }
  if (opts.raw) return (await r.text()) as any;
  return (ct.includes('json') ? r.json() : r.text()) as Promise<T>;
}
export const get = <T = any>(p: string) => api<T>('GET', p);
export const post = <T = any>(p: string, b: unknown = {}) => api<T>('POST', p, b);
export const put = <T = any>(p: string, b: unknown = {}) => api<T>('PUT', p, b);
export const patch = <T = any>(p: string, b: unknown = {}) => api<T>('PATCH', p, b);
export const del = <T = any>(p: string, b?: unknown) => api<T>('DELETE', p, b);

/** Uploads with progress (XHR, streaming body). */
export function upload(url: string, file: Blob, onProgress?: (pct: number) => void, method = 'PUT'): Promise<any> {
  return new Promise((resolve, reject) => {
    const x = new XMLHttpRequest(); x.open(method, url); x.withCredentials = true;
    if (csrfToken) x.setRequestHeader('x-csrf-token', csrfToken);
    x.setRequestHeader('content-type', 'application/octet-stream');
    x.upload.onprogress = (e) => { if (e.lengthComputable && onProgress) onProgress(Math.round((e.loaded / e.total) * 100)); };
    x.onload = () => { let d: any = null; try { d = JSON.parse(x.responseText); } catch { d = x.responseText; } x.status < 300 ? resolve(d) : reject(new ApiError(x.status, d?.error || `Upload failed (${x.status})`)); };
    x.onerror = () => reject(new ApiError(0, 'Network error during upload'));
    x.send(file);
  });
}
