// Loads gateway checkout scripts on demand. Payment success is always confirmed by the backend
// (signature verification / API lookup / webhook) — never by the browser redirect alone.
const loaded: Record<string, Promise<void>> = {};
export function loadScript(src: string) {
  return (loaded[src] ??= new Promise<void>((res, rej) => { const s = document.createElement('script'); s.src = src; s.async = true; s.onload = () => res(); s.onerror = () => { delete loaded[src]; rej(new Error(`Could not load ${src}`)); }; document.head.appendChild(s); }));
}
export async function razorpayCheckout(r: any): Promise<{ razorpay_order_id: string; razorpay_payment_id: string; razorpay_signature: string }> {
  await loadScript('https://checkout.razorpay.com/v1/checkout.js');
  return new Promise((resolve, reject) => {
    const rz = new (window as any).Razorpay({ key: r.keyId, order_id: r.orderId, amount: r.amount, currency: r.currency, name: r.name, description: r.description, prefill: r.prefill, theme: { color: '#dc2626' }, handler: resolve, modal: { ondismiss: () => reject(new Error('Payment window closed')) } });
    rz.on('payment.failed', (e: any) => reject(new Error(e?.error?.description || 'Payment failed')));
    rz.open();
  });
}
export async function cashfreeCheckout(r: any) {
  await loadScript('https://sdk.cashfree.com/js/v3/cashfree.js');
  const cf = (window as any).Cashfree({ mode: r.mode });
  await cf.checkout({ paymentSessionId: r.paymentSessionId, redirectTarget: '_self' });
}
