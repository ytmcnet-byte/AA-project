import { useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { Upload } from 'lucide-react';
import { useApi, useAction, toast } from '../../lib/hooks';
import { api, upload } from '../../lib/api';
import { useAuth } from '../../lib/auth';
import { date } from '../../lib/format';
import { Badge, Card, Confirm, Empty, ErrorBox, Field, Loading, Modal, Notice, PageHeader, Spinner, Switch } from '../../components/ui';
import { ExtensionFrame } from '../server/ExtensionPage';

const PERM_HELP: Record<string, string> = { routes: 'Add HTTP endpoints under /api/extensions/<id>/', storage: 'Store its own data in the panel database', settings: 'Read its settings', events: 'Receive panel events (server started, order paid, …)', ui: 'Show sandboxed pages in the panel', 'servers:read': 'Read server details', 'users:read': 'Read user accounts', notifications: 'Send notifications to users' };

export function ExtensionsAdmin() {
  const { data, error, loading, reload } = useApi<any>('/api/admin/extensions'); const { busy, run } = useAction();
  const [en, setEn] = useState<any>(null); const [grant, setGrant] = useState<string[]>([]); const [st, setSt] = useState<any>(null); const [rm, setRm] = useState<any>(null); const [keep, setKeep] = useState(true);
  const [file, setFile] = useState<File | null>(null); const [pct, setPct] = useState(0);
  if (loading) return <Loading />; if (error) return <ErrorBox error={error} onRetry={reload} />;
  return <><PageHeader title="Extensions" subtitle="Add features with OGHOST SDK extensions." actions={<label className="btn-primary cursor-pointer"><Upload className="h-4 w-4" />Install .zip<input type="file" accept=".zip" className="hidden" onChange={e => setFile(e.target.files?.[0] || null)} /></label>} />
    <Notice kind="warn" className="mb-4">{data.compatibility} Extension server code runs inside the panel process with the permissions you grant; install only extensions you trust. UI pages run in a sandboxed iframe.</Notice>
    {data.problems?.length > 0 && <Notice kind="error" className="mb-4">Problems loading: {data.problems.map((p: any) => `${p.dir || p.identifier}: ${p.error}`).join('; ')}</Notice>}
    {!data.extensions.length ? <Card><Empty title="No extensions installed" /></Card> : <div className="grid gap-4 lg:grid-cols-2">{data.extensions.map((x: any) => <Card key={x.id} title={<>{x.name} <span className="text-sm font-normal text-ink-400">v{x.version}</span></>} actions={<Badge value={x.enabled ? 'running' : 'offline'} label={x.enabled ? (x.status?.error ? 'error' : 'enabled') : 'disabled'} />}>
      <p className="text-sm text-ink-300">{x.description}</p><div className="mt-1 text-xs text-ink-500">{x.identifier} · by {x.author || 'unknown'} · installed {date(x.installedAt)}</div>
      {x.status?.error && <Notice kind="error" className="mt-2">{x.status.error}</Notice>}
      <div className="mt-3 text-xs"><span className="text-ink-400">Requests:</span> {x.permissions?.join(', ') || 'none'}{x.enabled && <><br /><span className="text-ink-400">Granted:</span> {x.granted.join(', ') || 'none'}</>}</div>
      {x.enabled && x.ui.filter((u: any) => u.area === 'admin').length > 0 && <div className="mt-3 flex flex-wrap gap-2">{x.ui.filter((u: any) => u.area === 'admin').map((u: any) => <Link key={u.id} className="btn-secondary btn-sm" to={`/admin/extensions/${x.identifier}/${u.id}`}>{u.title}</Link>)}</div>}
      <div className="mt-4 flex flex-wrap gap-2">{x.enabled ? <button className="btn-secondary btn-sm" onClick={() => run('d', () => api('POST', `/api/admin/extensions/${x.id}/disable`).then(reload), 'Disabled')}>Disable</button> : <button className="btn-primary btn-sm" onClick={() => { setEn(x); setGrant([]); }}>Review & enable</button>}
        {x.settingsSchema?.length > 0 && <button className="btn-secondary btn-sm" onClick={() => setSt({ x, v: Object.fromEntries(x.settingsSchema.map((s: any) => [s.key, x.settings?.[s.key]?.secret ? '' : x.settings?.[s.key] ?? s.default])) })}>Settings</button>}
        <button className="btn-ghost btn-sm text-red-400" onClick={() => { setRm(x); setKeep(true); }}>Uninstall</button></div>
    </Card>)}</div>}
    <Modal open={!!en} onClose={() => setEn(null)} title={`Enable ${en?.name}`} footer={<><button className="btn-secondary" onClick={() => setEn(null)}>Cancel</button><button className="btn-primary" disabled={!!busy || grant.length !== (en?.permissions?.length || 0)} onClick={() => run('e', async () => { const r = await api('POST', `/api/admin/extensions/${en.id}/enable`, { grant }); setEn(null); reload(); if (r.error) toast(r.error, 'error'); }, 'Enabled')}>Enable</button></>}>
      <p className="mb-3 text-sm">Review every requested permission. All of them must be granted to enable the extension; if you are not comfortable with one, leave the extension disabled.</p>
      <div className="space-y-2">{en?.permissions?.map((p: string) => <label key={p} className="flex items-start gap-2 text-sm"><input type="checkbox" className="mt-1" checked={grant.includes(p)} onChange={e => setGrant(e.target.checked ? [...grant, p] : grant.filter(g => g !== p))} /><span><span className="font-mono">{p}</span><span className="block text-xs text-ink-400">{PERM_HELP[p] || ''}</span></span></label>)}</div>
    </Modal>
    <Modal open={!!st} onClose={() => setSt(null)} title={`${st?.x.name} settings`} footer={<><button className="btn-secondary" onClick={() => setSt(null)}>Cancel</button><button className="btn-primary" onClick={() => run('s', () => api('PUT', `/api/admin/extensions/${st.x.id}/settings`, st.v).then(() => { setSt(null); reload(); }), 'Saved')}>Save</button></>}>
      <div className="grid gap-4">{st?.x.settingsSchema.map((s: any) => s.type === 'boolean' ? <Switch key={s.key} checked={!!st.v[s.key]} onChange={y => setSt({ ...st, v: { ...st.v, [s.key]: y } })} label={s.label} /> :
        <Field key={s.key} label={s.label} hint={s.description}><input className="input" type={s.type === 'number' ? 'number' : s.type === 'secret' ? 'password' : 'text'} value={st.v[s.key] ?? ''} onChange={e => setSt({ ...st, v: { ...st.v, [s.key]: s.type === 'number' ? Number(e.target.value) : e.target.value } })} /></Field>)}</div>
    </Modal>
    <Modal open={!!file} onClose={() => setFile(null)} title="Install extension" footer={<><button className="btn-secondary" onClick={() => setFile(null)}>Cancel</button><button className="btn-primary" disabled={!!busy} onClick={() => run('i', async () => { const r = await upload('/api/admin/extensions/install', file!, setPct); setFile(null); reload(); toast(`Installed ${r.identifier} v${r.version} (disabled). Review its permissions before enabling.`, 'success'); })}>{busy === 'i' && <Spinner />}Install</button></>}>
      <p className="text-sm">{file?.name}. The archive must contain an OGHOST <span className="font-mono">extension.json</span>. It is installed disabled.</p>{busy === 'i' && <p className="mt-2 text-sm">Uploading {pct}%</p>}
    </Modal>
    <Confirm open={!!rm} onClose={() => setRm(null)} danger title={`Uninstall ${rm?.name}`} confirmLabel="Uninstall" busy={busy === 'u'} onConfirm={() => run('u', () => api('DELETE', `/api/admin/extensions/${rm.id}${keep ? '?keepData=1' : ''}`).then(() => { setRm(null); reload(); }), 'Uninstalled')}>
      <Switch checked={keep} onChange={setKeep} label="Keep the extension's stored data" />
    </Confirm>
  </>;
}

export function AdminExtensionPage() {
  const { identifier, pageId } = useParams(); const { user } = useAuth(); const { data } = useApi<any>('/api/admin/extensions');
  const x = data?.extensions?.find((e: any) => e.identifier === identifier); const page = x?.ui?.find((u: any) => u.id === pageId && u.area === 'admin');
  if (!data) return <Loading />; if (!x?.enabled || !page) return <Notice kind="warn">This extension page is not available.</Notice>;
  return <><PageHeader title={page.title} subtitle={`${x.name} extension`} /><ExtensionFrame identifier={identifier!} page={page} context={{ area: 'admin', userId: user?.id, username: user?.username }} /></>;
}
