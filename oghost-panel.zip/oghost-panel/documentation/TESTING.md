# Testing

Tests use the built-in Node.js test runner (`node --test`). TypeScript sources are bundled on the fly with esbuild into `tests/.cache`.

## Unit tests (no services needed)

```bash
npm test
```

They cover path traversal and symlink escapes (including nested and dangling symlinks), Xmx validation against RAM, startup rendering and shell-injection rejection, Java version mapping, detection of numbered Java commands (`java8`, `java17`, `java-21`) and automatic Java selection by Minecraft version, TOTP (RFC 6238 test vector), signed node tokens, secret encryption and tamper detection, disk reservations and size accounting, the quota hook (no shell, fixed arguments), and the JAR scanner (SAFE / SUSPICIOUS / HIGH RISK cases, nested JARs, trusted hashes, non-zip files).

## End-to-end tests (running panel + agent)

Requirements: a running panel (`PANEL_URL`, default `http://127.0.0.1:8080`), at least one online node, the admin login (`E2E_ADMIN`, `E2E_PASSWORD`), and database access through the panel's `.env`. Tests create servers named `e2e-*` with the Custom JAR egg and delete them again.

```bash
# optional: point the panel at the Google mock for the Drive test
GOOGLE_OAUTH_BASE=http://127.0.0.1:9555 GOOGLE_DRIVE_API_BASE=http://127.0.0.1:9555 \
  LINKVERTISE_API_BASE=http://127.0.0.1:9556 DISCORD_API_BASE=http://127.0.0.1:9556 bash scripts/oghost.sh restart panel

E2E_DRIVE_MOCK_PORT=9555 E2E_AGENT_DATA_ROOT=~/oghost-agent/.server npm run test:all
```

| File | Covers |
| --- | --- |
| `servers.test.mjs` | Concurrent creation gets unique numeric IDs, servers with the same name work, only numeric folder names on disk, deleted IDs are reused only after deletion completes |
| `files.test.mjs` | Traversal blocked through the API, archive symlinks ignored on extract, disk limit enforced on uploads/writes |
| `payments.test.mjs` | Razorpay signature, amount check and replay protection. Stripe stale timestamps and bad signatures |
| `drive.test.mjs` | Full Drive flow against the mock (see DRIVE.md) |
| `coins.test.mjs` | OGCoins: redeem codes (once per account, max uses, races), concurrent overspend, buying a coin plan (402 + stock restore, then provisioning), renew with coins, prepay cap, auto-renew, free renewal, Linkvertise (success, replay, too fast, bypassed hash, wrong account, daily limit), Discord OAuth link and idempotent bot grants. Starts `tests/mocks/coins-mock.mjs` on `E2E_COINS_MOCK_PORT` (default 9556); the panel must run with `LINKVERTISE_API_BASE` and `DISCORD_API_BASE` pointing at it. It creates and removes one real server on the test node. |

Tests skip with a reason when the panel isn't reachable or the mock port isn't set.

## Last result

24 of 24 tests passed (19 unit, 5 end-to-end) on Node.js 20+ with MariaDB, two local agents, and Java 17/21.

## Bugs found during testing and review, and fixed

- `safeResolve` allowed a dangling symlink to point outside the server root. Every path component is now checked with `lstat`.
- A race in the settings cache could serve stale values after an update. A generation counter now guards it.
- mysql2 pre-decoded JSON columns, so string settings read as `null`. A type cast now returns raw JSON text for `parse()`.
- An unverified Drive upload was left in the customer's Drive after a failed MD5 check. It is now deleted.
- Concurrent creates on MariaDB 11.8 could fail with errno 1020 (snapshot conflict). Database-only transactions now retry.
- A Drive restore continued even if the local safety backup failed. It now aborts without changing any files.
- Automatic Java selection always chose the newest Java, which can break old versions such as 1.8. It now picks the lowest Java that fits the server's Minecraft version.
