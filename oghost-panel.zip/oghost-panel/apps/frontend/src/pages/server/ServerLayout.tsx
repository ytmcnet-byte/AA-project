import { createContext, useContext, useEffect, useState } from 'react';
import { NavLink, Outlet, useParams } from 'react-router-dom';
import { Play, Square, RotateCw, Skull, ShieldAlert, Copy } from 'lucide-react';
import { useApi, useAction, toast } from '../../lib/hooks';
import { get, post } from '../../lib/api';
import { cls } from '../../lib/format';
import { Badge, ErrorBox, Loading, Notice, Spinner } from '../../components/ui';

export interface ServerCtx { server: any; reload: () => void; can: (p: string) => boolean; id: number; state: string; setState: (s: string) => void }
const Ctx = createContext<ServerCtx>(null as any);
export const useServer = () => useContext(Ctx);

const TABS: Array<{ to: string; label: string; perm?: string }> = [
  { to: '', label: 'Console', perm: 'control.console' }, { to: 'files', label: 'Files', perm: 'file.read' }, { to: 'startup', label: 'Startup', perm: 'startup.read' },
  { to: 'version', label: 'Version', perm: 'startup.version' }, { to: 'plugins', label: 'Plugins', perm: 'plugin.read' }, { to: 'backups', label: 'Backups', perm: 'backup.read' },
  { to: 'schedules', label: 'Schedules', perm: 'schedule.read' }, { to: 'databases', label: 'Databases', perm: 'database.read' }, { to: 'network', label: 'Network', perm: 'allocation.read' },
  { to: 'users', label: 'Users', perm: 'user.read' }, { to: 'activity', label: 'Activity', perm: 'activity.read' }, { to: 'security', label: 'Security' }, { to: 'settings', label: 'Settings' },
];

export function ServerLayout() {
  const { id } = useParams(); const sid = Number(id);
  const { data, error, loading, reload } = useApi<any>(`/api/servers/${sid}`, [sid], 15000);
  const [state, setState] = useState('unknown'); const [exts, setExts] = useState<any[]>([]);
  useEffect(() => { if (data?.server) setState(data.server.live?.state || data.server.state); }, [data]);
  useEffect(() => { get('/api/extensions').then(r => setExts(r.extensions.flatMap((e: any) => e.ui.filter((u: any) => u.area === 'server').map((u: any) => ({ ...u, identifier: e.identifier }))))).catch(() => {}); }, []);
  if (loading && !data) return <Loading />;
  if (error && !data) return <ErrorBox error={error} onRetry={reload} />;
  const s = data.server; const perms: string[] = s.permissions || [];
  const can = (p: string) => perms.includes(p);
  const addr = s.allocations?.find((a: any) => a.is_primary); const addrText = addr ? `${addr.alias || addr.ip}:${addr.port}` : null;
  return (
    <Ctx.Provider value={{ server: s, reload, can, id: sid, state, setState }}>
      <div className="mb-4 flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-2"><h1 className="truncate text-xl font-extrabold text-white sm:text-2xl">{s.name}</h1><Badge value={state} />{s.suspended && <Badge value="suspended" />}{s.securityBlocked && <Badge value="high" label="security hold" />}</div>
          <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-ink-400"><span>{s.egg.name}{s.installedVersion ? ` ${s.installedVersion}` : ''}</span><span>Node {s.node.name} <Badge value={s.node.status} /></span><span className="font-mono">ID {s.nodeId}/{s.nodeServerId}</span>
            {addrText && <button className="inline-flex items-center gap-1 font-mono hover:text-white" onClick={() => { navigator.clipboard?.writeText(addrText); toast('Address copied', 'success'); }}>{addrText}<Copy className="h-3 w-3" /></button>}</div>
        </div>
        <PowerButtons />
      </div>
      {s.suspended && <Notice kind="error" className="mb-4">This server is suspended{s.suspendedUntil ? ` until ${new Date(s.suspendedUntil).toLocaleString()}` : ''}. {s.suspensionReason}</Notice>}
      {s.securityBlocked && <Notice kind="error" className="mb-4"><ShieldAlert className="mr-1 inline h-4 w-4" />The OGHOST Security Center has placed this server on hold. See the Security tab for details and to appeal.</Notice>}
      {s.node.maintenance && <Notice kind="warn" className="mb-4">Node {s.node.name} is in maintenance mode. Some actions may be unavailable.</Notice>}
      {s.node.status !== 'online' && <Notice kind="warn" className="mb-4">Node {s.node.name} is {s.node.status}. Live status and console are unavailable until it reconnects.</Notice>}
      <nav className="no-scrollbar -mx-4 mb-5 flex gap-1 overflow-x-auto border-b border-ink-800 px-4 sm:mx-0 sm:px-0">
        {TABS.filter(t => !t.perm || can(t.perm)).map(t => <NavLink key={t.to} to={t.to} end={t.to === ''} className={({ isActive }) => cls('whitespace-nowrap border-b-2 px-3 py-2.5 text-sm font-medium transition', isActive ? 'border-brand-500 text-white' : 'border-transparent text-ink-400 hover:text-zinc-200')}>{t.label}</NavLink>)}
        {exts.map(e => <NavLink key={`${e.identifier}/${e.id}`} to={`ext/${e.identifier}/${e.id}`} className={({ isActive }) => cls('whitespace-nowrap border-b-2 px-3 py-2.5 text-sm font-medium', isActive ? 'border-brand-500 text-white' : 'border-transparent text-ink-400 hover:text-zinc-200')}>{e.title}</NavLink>)}
      </nav>
      <Outlet />
    </Ctx.Provider>
  );
}

function PowerButtons() {
  const { server, can, state, setState, id } = useServer(); const { busy, run } = useAction();
  const p = (action: string) => run(action, async () => { const r = await post(`/api/servers/${id}/power`, { action }); if (r?.state) setState(r.state); }, `${action[0].toUpperCase()}${action.slice(1)} signal sent`);
  const disabled = server.suspended || server.node.status !== 'online';
  const running = ['running', 'starting'].includes(state);
  return (
    <div className="flex flex-wrap gap-2">
      {can('control.start') && <button className="btn-primary btn-sm" disabled={disabled || running || state === 'stopping' || state === 'installing' || !!busy} onClick={() => p('start')}>{busy === 'start' ? <Spinner /> : <Play className="h-4 w-4" />}Start</button>}
      {can('control.restart') && <button className="btn-secondary btn-sm" disabled={disabled || !running || !!busy} onClick={() => p('restart')}>{busy === 'restart' ? <Spinner /> : <RotateCw className="h-4 w-4" />}Restart</button>}
      {can('control.stop') && <button className="btn-secondary btn-sm" disabled={disabled || !['running', 'starting'].includes(state) || !!busy} onClick={() => p('stop')}>{busy === 'stop' ? <Spinner /> : <Square className="h-4 w-4" />}Stop</button>}
      {can('control.stop') && <button className="btn-danger btn-sm" disabled={disabled || !['running', 'starting', 'stopping'].includes(state) || !!busy} onClick={() => p('kill')} title="Force kill the process (may lose unsaved data)"><Skull className="h-4 w-4" />Kill</button>}
    </div>
  );
}
