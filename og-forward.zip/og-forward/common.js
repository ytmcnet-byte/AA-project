'use strict';
// OG Forward - shared helpers (server.js aur agent.js dono use karte hain)
const crypto = require('crypto');

const log = (...a) => console.log(new Date().toISOString(), ...a);
const rand = (n) => crypto.randomBytes(n).toString('hex');

// Control channel par line-delimited JSON bhejna
const send = (sock, obj) => {
  if (!sock.destroyed && sock.writable) sock.write(JSON.stringify(obj) + '\n');
};

// Auth: token kabhi network par nahi jaata, sirf HMAC jaata hai
const mac = (token, nonce, user) =>
  crypto.createHmac('sha256', String(token)).update(`${nonce}:${user}`).digest('hex');

function safeEq(a, b) {
  const x = Buffer.from(String(a));
  const y = Buffer.from(String(b));
  return x.length === y.length && crypto.timingSafeEqual(x, y);
}

// Socket se '\n' separated lines padhta hai.
// detach() call karne par bacha hua raw data socket me wapas daal deta hai
// (data connection me header ke baad raw bytes aate hain).
function lineStream(sock, onLine, maxLen = 65536) {
  let buf = Buffer.alloc(0);
  let active = true;
  const onData = (d) => {
    buf = Buffer.concat([buf, d]);
    let i;
    while (active && (i = buf.indexOf(10)) !== -1) {
      const line = buf.subarray(0, i).toString('utf8');
      buf = buf.subarray(i + 1);
      onLine(line);
    }
    if (active && buf.length > maxLen) sock.destroy();
  };
  sock.on('data', onData);
  return {
    detach() {
      active = false;
      sock.removeListener('data', onData);
      sock.pause();
      if (buf.length) sock.unshift(buf);
      buf = Buffer.alloc(0);
    },
  };
}

// Do sockets ko aapas me jod do (full duplex), cleanup ke saath
function bridge(a, b) {
  a.pipe(b);
  b.pipe(a);
  const kill = () => { a.destroy(); b.destroy(); };
  a.on('error', kill);
  b.on('error', kill);
  const onClose = (other) => () => {
    if (other.destroyed) return;
    other.end();
    const t = setTimeout(() => other.destroy(), 3000);
    other.once('close', () => clearTimeout(t));
  };
  a.once('close', onClose(b));
  b.once('close', onClose(a));
}

module.exports = { log, rand, send, mac, safeEq, lineStream, bridge };
