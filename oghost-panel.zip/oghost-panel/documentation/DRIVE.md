# Google Drive backups

Each customer connects **their own** Google Drive. Server backups are streamed from the node straight to that customer's Drive, so the hosting provider's disk is only used for a temporary archive while an upload is running.

## Google Cloud setup (administrator)

1. Open the Google Cloud Console → **APIs & Services** and enable the **Google Drive API**.
2. Set up the **OAuth consent screen** (External). Add the scope `https://www.googleapis.com/auth/drive.file` (plus `openid` and `email` to show the connected account). Publish the app, or add test users while it is in testing.
3. Create **Credentials → OAuth client ID → Web application** with this authorized redirect URI:

```
<APP_URL>/api/drive/callback
```

4. In **Admin → Settings → Google Drive**, enter the client ID and secret, enable Drive backups, and set the default interval and the maximum retention customers may choose.

## Security properties

- **Minimum scope:** `drive.file` only. The panel can only see and manage files it created. It cannot list or read anything else in the customer's Drive, and administrators have no way to browse customers' personal Drive files. The admin **Drive Backups** page only shows connection counts and backup statistics.
- **OAuth:** authorization code flow with PKCE and a single-use `state` bound to the logged-in user, with a 10-minute expiry. The callback rejects a missing or foreign state.
- **Tokens:** refresh and access tokens are encrypted at rest (AES-256-GCM) and are never sent to the frontend. Agents only receive a short-lived access token for a single upload or download.
- **Disconnect** revokes the token at Google and deletes it from the database. Backups already in Drive stay there, owned by the customer.

## Behaviour

| Setting | Default | Options |
| --- | --- | --- |
| Interval | 60 minutes (hourly) | 15 minutes – 7 days |
| Retention | 1 | 1, 2, 3, 5, 7 (capped by `drive.maxRetention`) |
| Retries | configurable count and delay per server | |

Folder layout in the customer's Drive: `OGHOST/Node-<nodeId>/Server-<serverId>/` (numeric IDs, never display names). Missing or deleted folders are recreated.

A backup runs like this:
1. The node creates a temporary archive in its `temporary/` folder.
2. It streams the archive to Drive using a **resumable upload** in 8 MiB chunks (the whole file is never held in RAM), resuming after interrupted chunks.
3. The upload is **verified**: the size and MD5 from Drive must match the local archive. If verification fails, the unverified upload is deleted from Drive and the backup is marked failed.
4. **Only after verification** are older backups beyond the retention count deleted. The previous successful backup is never deleted before a new one has been fully uploaded and verified. A failed upload, for example because the Drive is full, leaves the previous backup untouched.
5. The temporary archive is deleted.

**Restore** (server must be stopped): the selected backup is downloaded to the node and its MD5 is checked. Then a **local safety backup** of the current files is created on the node (it appears in the server's Backups tab). If the safety backup fails, the restore is aborted and no files are changed. Only then are the files replaced. Safety backups do not count toward Drive retention, and they can be deleted from the Backups tab once you no longer need them.

Customers see failures in the server's **Drive Backups** tab and get notifications, for example when Drive is full, access was revoked or verification failed.

## Limitations

- An access token lasts about one hour. Very large uploads over slow links that take longer than that will fail and be retried.
- Google may throttle uploads or enforce the user's storage quota. These errors are shown to the customer.

## Testing without a Google account

`tests/mocks/google-mock.mjs` implements the OAuth token/revoke endpoints and the Drive v3 endpoints used by OGHOST (files, resumable upload, download). Start the panel with:

```bash
GOOGLE_OAUTH_BASE=http://127.0.0.1:9555 GOOGLE_DRIVE_API_BASE=http://127.0.0.1:9555 bash scripts/oghost.sh restart panel
E2E_DRIVE_MOCK_PORT=9555 node --test tests/e2e/drive.test.mjs
```

The test covers connecting, the folder layout, retention, a quota failure that keeps the previous backup, an MD5 mismatch that deletes the bad upload, restore with a safety backup, and that no tokens appear in API responses.
