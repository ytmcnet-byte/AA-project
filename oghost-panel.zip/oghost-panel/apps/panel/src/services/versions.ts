import { HttpError } from '../lib/http';

const UA = { 'User-Agent': 'OGHOST-Panel/1.0 (game hosting panel; contact via panel admin)' };
const cache = new Map<string, { at: number; data: any }>();
async function get(url: string, ttl = 10 * 60_000) {
  const c = cache.get(url); if (c && Date.now() - c.at < ttl) return c.data;
  const r = await fetch(url, { headers: { ...UA, Accept: 'application/json' } }); if (!r.ok) throw new HttpError(502, `Upstream ${new URL(url).hostname} returned ${r.status}`);
  const ct = r.headers.get('content-type') || ''; const data = ct.includes('json') ? await r.json() : await r.text(); cache.set(url, { at: Date.now(), data }); return data;
}
export interface VersionEntry { id: string; stable: boolean; java?: number | null; }

/** Lists versions from each project's official API. */
export async function listVersions(installer: string): Promise<VersionEntry[]> {
  switch (installer) {
    case 'vanilla': case 'spigot': case 'quilt': case 'forge': {
      const m = await get('https://piston-meta.mojang.com/mc/game/version_manifest_v2.json');
      let list: VersionEntry[] = m.versions.filter((v: any) => v.type === 'release').map((v: any) => ({ id: v.id, stable: true }));
      if (installer === 'forge') { const p = await get('https://files.minecraftforge.net/net/minecraftforge/forge/promotions_slim.json'); const ok = new Set(Object.keys(p.promos).map(k => k.replace(/-(latest|recommended)$/, ''))); list = list.filter(v => ok.has(v.id)); }
      return list;
    }
    case 'paper': case 'folia': case 'velocity': case 'waterfall': {
      const d = await get(`https://fill.papermc.io/v3/projects/${installer}/versions`);
      return d.versions.map((v: any) => ({ id: v.version.id, stable: !/pre|rc|snapshot/i.test(v.version.id) && v.version.support?.status !== 'UNSUPPORTED', java: v.version.java?.version?.minimum ?? null, builds: v.builds?.length }));
    }
    case 'purpur': { const d = await get('https://api.purpurmc.org/v2/purpur'); return [...d.versions].reverse().map((id: string) => ({ id, stable: true })); }
    case 'fabric': { const d = await get('https://meta.fabricmc.net/v2/versions/game'); return d.filter((v: any) => v.stable).map((v: any) => ({ id: v.version, stable: v.stable })); }
    case 'neoforge': { const d = await get('https://maven.neoforged.net/api/maven/versions/releases/net/neoforged/neoforge'); return [...d.versions].reverse().slice(0, 200).map((id: string) => ({ id, stable: !/beta|alpha/.test(id) })); }
    case 'bedrock': { const d = await get('https://net-secondary.web.minecraft-services.net/api/v1.0/download/links', 60 * 60_000); const l = d.result.links.find((x: any) => x.downloadType === 'serverBedrockLinux'); return [{ id: l.downloadUrl.match(/bedrock-server-([\d.]+)\.zip/)[1], stable: true }]; }
    case 'pocketmine': { const d = await get('https://api.github.com/repos/pmmp/PocketMine-MP/releases?per_page=30'); return d.filter((r: any) => !r.draft).map((r: any) => ({ id: r.tag_name, stable: !r.prerelease })); }
    case 'pufferfish': return ['1.21', '1.20', '1.19', '1.18', '1.17'].map(id => ({ id, stable: true }));
    case 'bungeecord': return [{ id: 'latest', stable: true }];
    default: throw new HttpError(400, `Version listing is not available for installer "${installer}"`);
  }
}

export async function listBuilds(installer: string, version: string): Promise<Array<{ id: string; channel?: string; time?: string }>> {
  switch (installer) {
    case 'paper': case 'folia': case 'velocity': case 'waterfall': { const d = await get(`https://fill.papermc.io/v3/projects/${installer}/versions/${encodeURIComponent(version)}/builds`); return d.map((b: any) => ({ id: String(b.id), channel: b.channel, time: b.time })); }
    case 'purpur': { const d = await get(`https://api.purpurmc.org/v2/purpur/${encodeURIComponent(version)}`); return [...d.builds.all].reverse().slice(0, 100).map((id: string) => ({ id })); }
    case 'fabric': { const d = await get(`https://meta.fabricmc.net/v2/versions/loader/${encodeURIComponent(version)}`); return d.slice(0, 50).map((l: any) => ({ id: l.loader.version, channel: l.loader.stable ? 'STABLE' : 'BETA' })); }
    case 'forge': { const p = await get('https://files.minecraftforge.net/net/minecraftforge/forge/promotions_slim.json'); return ['recommended', 'latest'].filter(k => p.promos[`${version}-${k}`]).map(k => ({ id: p.promos[`${version}-${k}`], channel: k.toUpperCase() })); }
    default: return [];
  }
}
