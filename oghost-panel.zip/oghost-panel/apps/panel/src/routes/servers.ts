import { Router, type Request } from 'express';
import { javaCompatibility, validateHeap, validateVariables, renderStartup, requiredJavaFor, BUILTIN_EGGS } from '@oghost/shared';
import { q, one, exec, json, parse, tx, txRetry } from '../db';
import { body, z, HttpError, bad, idParam, forbidden, paginate } from '../lib/http';
import { requireAuth, hasPerm, SERVER_PERMISSIONS } from '../lib/auth';
import { serverAccess, assertWritable } from '../lib/access';
import { getNode, agent, agentStream, type NodeRow } from '../services/nodes';
import { getEgg, power, buildSpec, syncSpec, pushAndInstall, type ServerRow } from '../services/servers';
import { serverActivity } from '../services/audit';
import { requestBackup, deleteBackup, restoreBackup, backupUsage, cleanupSafetyBackups } from '../services/backups';
import { listVersions, listBuilds } from '../services/versions';
import { searchPlugins, pluginVersions, downloadHosts, loaderInfo } from '../services/plugins';
import { createServerDatabase, deleteServerDatabase, rotateDatabasePassword, listServerDatabases } from '../services/databases';
import { nextRun, runSchedule } from '../services/scheduler';
import { enqueue } from '../services/jobs';
import { notifyAdmins } from '../services/notify';
import { loadUserById } from '../lib/auth';

export const serversRouter = Router();
serversRouter.use(requireAuth);

const nodeOf = (s: ServerRow) => getNode(s.node_id);
const A = (s: ServerRow) => `/api/servers/${s.node_server_id}`;
async function live(s: ServerRow, n?: NodeRow) {
  const node = n || await nodeOf(s);
  if (node.status !== 'online') return { state: s.state === 'installing' ? 'installing' : 'unknown', reachable: false, reason: `Node ${node.name} is ${node.status}` };
  try { return { ...(await agent(node, 'GET', A(s), undefined, { serverId: s.node_server_id, timeoutMs: 5000 })), reachable: true }; }
  catch (e: any) { return { state: 'unknown', reachable: false, reason: e.message }; }
}
function publicServer(s: any, extra: Record<string, unknown> = {}) {
  return { id: s.id, uuid: s.uuid, nodeId: s.node_id, nodeServerId: s.node_server_id, ownerId: s.owner_id, name: s.name, description: s.description, eggId: s.egg_id, state: s.state, statusDetail: s.status_detail,
    limits: { memoryMb: s.memory_mb, cpuPercent: s.cpu_percent, diskMb: s.disk_mb, swapMb: s.swap_mb, databases: s.database_limit, allocations: s.allocation_limit, backups: s.backup_limit, backupStorageMb: s.backup_storage_mb, maxUploadMb: s.max_upload_mb },
    xmsMb: s.xms_mb, xmxMb: s.xmx_mb, javaPath: s.java_path, autoRestart: !!s.auto_restart, suspended: !!s.suspended_at, suspendedUntil: s.suspended_until, suspensionReason: s.suspension_reason,
    securityLevel: s.security_level, securityBlocked: !!s.security_blocked, installedVersion: s.installed_version, installedBuild: s.installed_build, deleting: s.state === 'deleting', createdAt: s.created_at, ...extra };
}

// ---------- list & details
serversRouter.get('/', async (req, res) => {
  const all = req.query.all === '1' && hasPerm(req.user, 'admin.servers');
  const rows = await q(`SELECT s.*, n.name AS node_name, n.status AS node_status, n.fqdn, e.name AS egg_name, e.slug AS egg_slug,
      (SELECT CONCAT(COALESCE(a.alias, a.ip), ':', a.port) FROM allocations a WHERE a.server_id = s.id AND a.is_primary = 1 LIMIT 1) AS address,
      IF(s.owner_id = ?, 'owner', 'subuser') AS relation
    FROM servers s JOIN nodes n ON n.id = s.node_id JOIN eggs e ON e.id = s.egg_id
    WHERE ${all ? '1=1' : 's.owner_id = ? OR s.id IN (SELECT server_id FROM server_subusers WHERE user_id = ?)'} ORDER BY s.id`, all ? [req.user!.id] : [req.user!.id, req.user!.id, req.user!.id]);
  // live states come from the latest node heartbeat (stored in servers.state); no fake values
  res.json({ servers: rows.map((s: any) => publicServer(s, { node: { id: s.node_id, name: s.node_name, status: s.node_status }, egg: { name: s.egg_name, slug: s.egg_slug }, address: s.address, relation: s.relation })) });
});

serversRouter.get('/:id', async (req, res) => {
  const s = await serverAccess(req, null); const node = await nodeOf(s); const egg = await getEgg(s.egg_id);
  const allocs = await q('SELECT id, ip, port, alias, notes, is_primary, reachable, protocol FROM allocations WHERE server_id = ? ORDER BY is_primary DESC, port', [s.id]);
  const stats = await q('SELECT cpu, memory, disk, at FROM server_stats WHERE server_id = ? ORDER BY id DESC LIMIT 60', [s.id]).catch(() => []);
  res.json({ server: publicServer(s, { node: { id: node.id, name: node.name, status: node.status, fqdn: node.fqdn, publicIp: node.public_ip, maintenance: !!node.maintenance, quotaSupport: parse(node.heartbeat, {} as any)?.disk?.quotaSupport ?? 'unknown', cpulimit: parse(node.heartbeat, {} as any)?.cpulimit ?? null },
    egg: { id: egg.id, slug: egg.slug, name: egg.definition.name, runtime: egg.definition.runtime, installer: egg.definition.installer, category: egg.definition.category, notes: egg.definition.notes },
    allocations: allocs, permissions: s._perms, live: await live(s, node), history: stats.reverse() }) });
});
serversRouter.get('/:id/resources', async (req, res) => { const s = await serverAccess(req, null); res.json(await live(s)); });

// ---------- power / console
serversRouter.post('/:id/power', async (req, res) => {
  const { action } = body(z.object({ action: z.enum(['start', 'stop', 'restart', 'kill']) }), req);
  const s = await serverAccess(req, action === 'kill' ? 'control.stop' : `control.${action}`);
  const r = await power(s.id, action); await serverActivity(req, s.id, `server.power.${action}`); res.json(r);
});
serversRouter.post('/:id/command', async (req, res) => {
  const { command } = body(z.object({ command: z.string().min(1).max(1000) }), req); const s = await serverAccess(req, 'control.console'); assertWritable(s);
  // The command is written to the game server's stdin only; it is never executed by a shell.
  await agent(await nodeOf(s), 'POST', `${A(s)}/command`, { command }, { serverId: s.node_server_id }); await serverActivity(req, s.id, 'server.console.command', { command: command.slice(0, 200) }); res.json({ ok: true });
});
serversRouter.get('/:id/logs', async (req, res) => { const s = await serverAccess(req, 'control.console'); res.json(await agent(await nodeOf(s), 'GET', `${A(s)}/logs?lines=${Math.min(5000, Number(req.query.lines) || 500)}`, undefined, { serverId: s.node_server_id })); });

// ---------- settings
serversRouter.patch('/:id/settings', async (req, res) => {
  const b = body(z.object({ name: z.string().trim().min(1).max(100).optional(), description: z.string().max(2000).nullable().optional(), autoRestart: z.boolean().optional() }), req);
  const s = await serverAccess(req, 'settings.rename');
  if (b.name !== undefined) await exec('UPDATE servers SET name = ? WHERE id = ?', [b.name, s.id]); // names need not be unique: storage uses numeric IDs
  if (b.description !== undefined) await exec('UPDATE servers SET description = ? WHERE id = ?', [b.description, s.id]);
  if (b.autoRestart !== undefined) { await exec('UPDATE servers SET auto_restart = ? WHERE id = ?', [b.autoRestart ? 1 : 0, s.id]); await syncSpec(s.id).catch(() => {}); }
  await serverActivity(req, s.id, 'server.settings.updated', b); res.json({ ok: true });
});
serversRouter.post('/:id/reinstall', async (req, res) => {
  body(z.object({ confirm: z.literal(true) }), req); const s = await serverAccess(req, 'settings.reinstall'); assertWritable(s);
  if (s.security_blocked) throw forbidden('Reinstall is blocked while the server is under security review');
  const st = await live(s); if (['running', 'starting', 'stopping'].includes(st.state)) throw new HttpError(409, 'Stop the server before reinstalling');
  await pushAndInstall(s.id, true); await serverActivity(req, s.id, 'server.reinstall'); res.json({ ok: true });
});

// ---------- startup / java / heap
serversRouter.get('/:id/startup', async (req, res) => {
  const s = await serverAccess(req, 'startup.read'); const egg = await getEgg(s.egg_id); const node = await nodeOf(s);
  const javaInstalls = parse(node.heartbeat, {} as any)?.java ?? [];
  const vars = parse<Record<string, string>>(s.variables, {});
  const selected = javaInstalls.find((j: any) => j.path === s.java_path) || null;
  const warnings = [...javaCompatibility(egg.definition, selected?.major ?? (javaInstalls[0]?.major ?? null), vars.MC_VERSION || s.installed_version || undefined)];
  if (!s.java_path && egg.definition.runtime === 'java') warnings.push(javaInstalls.length ? 'No Java selected: the node will pick the newest compatible Java automatically.' : 'No Java installation was detected on this node.');
  let preview: string[] = []; try { preview = renderStartup(s.startup, { JAVA: s.java_path || 'java', XMS: s.xms_mb, XMX: s.xmx_mb, PORT: 25565, PORT_V6: 25566, ...vars }); } catch (e: any) { warnings.push(e.message); }
  res.json({ startup: s.startup, editableStartup: hasPerm(req.user, 'admin.servers'), preview: preview.join(' '), memoryMb: s.memory_mb, xmsMb: s.xms_mb, xmxMb: s.xmx_mb, javaPath: s.java_path, java: javaInstalls, runtime: egg.definition.runtime,
    requiredJava: Math.max(egg.definition.javaMin || 0, requiredJavaFor(vars.MC_VERSION || s.installed_version || undefined) || 0) || null,
    variables: egg.definition.variables.map(v => ({ ...v, value: vars[v.key] ?? v.default })), warnings });
});
serversRouter.patch('/:id/startup', async (req, res) => {
  const b = body(z.object({ variables: z.record(z.string(), z.string().max(512)).optional(), xmsMb: z.number().int().optional(), xmxMb: z.number().int().optional(), javaPath: z.string().max(500).nullable().optional(), startup: z.string().max(1000).optional() }), req);
  const s = await serverAccess(req, 'startup.update'); assertWritable(s); const egg = await getEgg(s.egg_id); const isAdm = hasPerm(req.user, 'admin.servers');
  const cur = parse<Record<string, string>>(s.variables, {}); const next = { ...cur };
  for (const [k, v] of Object.entries(b.variables || {})) {
    const def = egg.definition.variables.find(x => x.key === k); if (!def) throw bad(`Unknown variable ${k}`);
    if (!def.userEditable && !isAdm) throw forbidden(`Variable ${k} can only be changed by an administrator`);
    next[k] = v;
  }
  const vars = validateVariables(egg.definition, next, true);
  const xms = b.xmsMb ?? s.xms_mb, xmx = b.xmxMb ?? s.xmx_mb; let warnings: string[] = [];
  if (egg.definition.runtime === 'java') warnings = validateHeap(s.memory_mb, xms, xmx);
  let javaPath = s.java_path;
  if (b.javaPath !== undefined) {
    if (b.javaPath === null || b.javaPath === '') javaPath = null;
    else { const node = await nodeOf(s); const list = parse(node.heartbeat, {} as any)?.java ?? []; if (!list.some((j: any) => j.path === b.javaPath)) throw bad('That Java executable was not detected on the node. Ask an admin to refresh Java detection.'); javaPath = b.javaPath; }
  }
  let startup = s.startup; if (b.startup !== undefined) { if (!isAdm) throw forbidden('Only administrators can change the startup command'); renderStartup(b.startup, { JAVA: 'java', XMS: 1, XMX: 1, PORT: 1, PORT_V6: 1, ...vars }); startup = b.startup; }
  await exec('UPDATE servers SET variables = ?, xms_mb = ?, xmx_mb = ?, java_path = ?, startup = ? WHERE id = ?', [json(vars), xms, xmx, javaPath, startup, s.id]);
  await syncSpec(s.id).catch(() => {}); await serverActivity(req, s.id, 'server.startup.updated', { variables: Object.keys(b.variables || {}), xms, xmx, javaPath });
  res.json({ ok: true, warnings, appliesOnNextStart: true });
});

// ---------- version changer (official APIs, safety backup, rollback)
const versionKeys = (installer: string) => ({ bedrock: ['BEDROCK_VERSION'], pocketmine: ['PMMP_VERSION'], neoforge: ['NEOFORGE_VERSION'], forge: ['MC_VERSION', 'FORGE_VERSION'], fabric: ['MC_VERSION', 'LOADER_VERSION'], quilt: ['MC_VERSION', 'LOADER_VERSION'] } as Record<string, string[]>)[installer] || ['MC_VERSION', 'BUILD'];
serversRouter.get('/:id/versions', async (req, res) => {
  const s = await serverAccess(req, 'startup.version'); const egg = await getEgg(s.egg_id);
  const installer = String(req.query.installer || egg.definition.installer);
  if (req.query.version) return res.json({ builds: await listBuilds(installer, String(req.query.version)) });
  const eggs = (await q('SELECT id, slug, name, definition FROM eggs ORDER BY name')).map((e: any) => { const d = parse<any>(e.definition, {}); return { id: e.id, slug: e.slug, name: e.name, installer: d.installer, category: d.category }; });
  res.json({ installer, current: { version: s.installed_version, build: s.installed_build, variables: parse(s.variables, {}) }, versions: egg.definition.installer === 'custom' ? [] : await listVersions(installer), softwares: eggs.filter(e => e.category === egg.definition.category && e.installer !== 'custom') });
});
serversRouter.post('/:id/version', async (req, res) => {
  const b = body(z.object({ version: z.string().max(40), build: z.string().max(40).optional(), eggId: z.number().int().optional(), backup: z.boolean().default(true), confirm: z.literal(true) }), req);
  const s = await serverAccess(req, 'startup.version'); assertWritable(s); if (s.security_blocked) throw forbidden('Blocked by the Security Center');
  const st = await live(s); if (!['offline', 'crashed', 'install_failed'].includes(st.state)) throw new HttpError(409, 'Stop the server before changing version');
  let egg = await getEgg(s.egg_id);
  if (b.eggId && b.eggId !== s.egg_id) { const ne = await getEgg(b.eggId); if (ne.definition.category !== egg.definition.category) throw bad('You can only switch between compatible server software of the same category'); egg = ne; }
  const keys = versionKeys(egg.definition.installer);
  const vars = { ...Object.fromEntries(egg.definition.variables.map(v => [v.key, v.default])), ...parse<Record<string, string>>(s.variables, {}) };
  if (keys[0] === 'MC_VERSION' || keys.length === 1) vars[keys[0]] = b.version; if (keys[1]) vars[keys[1]] = b.build || egg.definition.variables.find(v => v.key === keys[1])?.default || 'latest';
  const validated = validateVariables(egg.definition, vars, true);
  const job = await enqueue('server.version', { serverId: s.id, eggId: egg.id, variables: validated, backup: b.backup, userId: req.user!.id }, { uniqueKey: `version:${s.id}`, maxAttempts: 1 });
  if (!job) throw new HttpError(409, 'A version change is already in progress');
  await serverActivity(req, s.id, 'server.version.requested', { egg: egg.slug, version: b.version, build: b.build }); res.status(202).json({ jobId: job });
});
serversRouter.get('/:id/version/rollbacks', async (req, res) => { const s = await serverAccess(req, 'startup.version'); res.json(await agent(await nodeOf(s), 'GET', `${A(s)}/version/rollbacks`, undefined, { serverId: s.node_server_id })); });
serversRouter.post('/:id/version/rollback', async (req, res) => {
  const b = body(z.object({ rollbackId: z.string().regex(/^v\d+$/) }), req); const s = await serverAccess(req, 'startup.version'); assertWritable(s);
  const r = await agent(await nodeOf(s), 'POST', `${A(s)}/version/rollback`, b, { serverId: s.node_server_id, timeoutMs: 600_000 });
  if (r.previous?.variables) { const e: any = await one('SELECT id FROM eggs WHERE slug = ?', [r.previous.egg]); await exec('UPDATE servers SET variables = ?, egg_id = COALESCE(?, egg_id), startup = COALESCE(?, startup), installed_version = ? WHERE id = ?', [json(r.previous.variables), e?.id ?? null, r.previous.startup ?? null, r.previous.variables.MC_VERSION || r.previous.variables.BEDROCK_VERSION || null, s.id]); await syncSpec(s.id).catch(() => {}); }
  await serverActivity(req, s.id, 'server.version.rollback', b); res.json({ ok: true });
});
serversRouter.get('/:id/jobs/:jobId', async (req, res) => { const s = await serverAccess(req, null); const j: any = await one('SELECT id, type, status, attempts, last_error, result, created_at, finished_at, payload FROM jobs WHERE id = ?', [idParam(req, 'jobId')]); if (!j || parse<any>(j.payload, {}).serverId !== s.id) throw new HttpError(404, 'Job not found'); delete j.payload; res.json({ job: j }); });

// ---------- files (proxied to the node agent; the agent enforces path safety & disk limits)
const FILE_PERMS: Record<string, string> = { list: 'file.read', contents: 'file.read', download: 'file.read', search: 'file.read', size: 'file.read', write: 'file.write', upload: 'file.write', rename: 'file.write', copy: 'file.write', mkdir: 'file.write', chmod: 'file.write', delete: 'file.delete', compress: 'file.archive', extract: 'file.archive' };
serversRouter.all('/:id/files/:op', async (req, res) => {
  const op = String(req.params.op); const perm = FILE_PERMS[op]; if (!perm) throw new HttpError(404, 'Unknown file operation');
  const method = ['list', 'contents', 'download', 'search', 'size'].includes(op) ? 'GET' : op === 'upload' ? 'PUT' : 'POST';
  if (req.method !== method) throw new HttpError(405, `Use ${method} for ${op}`);
  const s = await serverAccess(req, perm); const node = await nodeOf(s);
  if (method !== 'GET') { assertWritable(s); if (s.security_blocked) throw forbidden('File changes are blocked while this server is under security review'); }
  const qs = new URLSearchParams(Object.entries(req.query).map(([k, v]) => [k, String(v)])).toString();
  const path = `${A(s)}/files/${op}${qs ? `?${qs}` : ''}`;
  if (op === 'upload' || op === 'download' || op === 'write') {
    if (op === 'write') { const raw: Buffer = Buffer.isBuffer(req.body) ? req.body : Buffer.from(typeof req.body === 'string' ? req.body : (req.body?.content ?? '')); return res.json(await writeFile(node, s, path, raw)); }
    await serverActivity(req, s.id, `server.file.${op}`, { path: req.query.path || req.query.directory, name: req.query.name });
    return agentStream(node, req, res, method, path, s.node_server_id);
  }
  const r = await agent(node, method, path, method === 'POST' ? req.body : undefined, { serverId: s.node_server_id, timeoutMs: ['compress', 'extract', 'search', 'size'].includes(op) ? 1800_000 : 30_000, raw: op === 'contents' });
  if (method === 'POST') await serverActivity(req, s.id, `server.file.${op}`, typeof req.body === 'object' ? req.body : {});
  if (op === 'contents') return res.type('text/plain').send(r);
  res.json(r);
});
async function writeFile(node: NodeRow, s: ServerRow, path: string, data: Buffer) {
  const { nodeToken, agentUrl } = await import('../services/nodes');
  const r = await fetch(`${agentUrl(node)}${path}`, { method: 'POST', headers: { Authorization: `Bearer ${nodeToken(node, { serverId: s.node_server_id })}`, 'Content-Type': 'application/octet-stream' }, body: new Uint8Array(data) });
  const t = await r.text(); if (!r.ok) { let m = t; try { m = JSON.parse(t).error; } catch { /* */ } throw new HttpError(r.status, m); } return JSON.parse(t);
}

// ---------- backups (local node storage, counted against the server backup limit)
serversRouter.get('/:id/backups', async (req, res) => { const s = await serverAccess(req, 'backup.read'); res.json({ backups: await q('SELECT id, uuid, name, status, size_bytes, sha256, error, locked, is_safety, created_at, completed_at FROM backups WHERE server_id = ? ORDER BY id DESC', [s.id]), usage: await backupUsage(s.id), limit: s.backup_limit, storageMb: s.backup_storage_mb }); });
serversRouter.post('/:id/backups', async (req, res) => { const b = body(z.object({ name: z.string().max(150).optional(), locked: z.boolean().optional() }), req); const s = await serverAccess(req, 'backup.create'); assertWritable(s); const r = await requestBackup(s.id, b.name || `Backup ${new Date().toISOString().slice(0, 16).replace('T', ' ')}`, { locked: b.locked }); await serverActivity(req, s.id, 'server.backup.created', { uuid: r.uuid }); res.status(202).json({ backup: r }); });
const ownBackup = async (req: Request, s: ServerRow) => { const b: any = await one('SELECT * FROM backups WHERE id = ? AND server_id = ?', [idParam(req, 'bid'), s.id]); if (!b) throw new HttpError(404, 'Backup not found'); return b; };
serversRouter.post('/:id/backups/:bid/lock', async (req, res) => { const s = await serverAccess(req, 'backup.create'); const b = await ownBackup(req, s); await exec('UPDATE backups SET locked = 1 - locked WHERE id = ?', [b.id]); res.json({ ok: true, locked: !b.locked }); });
serversRouter.delete('/:id/backups/:bid', async (req, res) => { const s = await serverAccess(req, 'backup.delete'); const b = await ownBackup(req, s); await deleteBackup(b.id); await serverActivity(req, s.id, 'server.backup.deleted', { uuid: b.uuid }); res.json({ ok: true }); });
serversRouter.post('/:id/backups/:bid/restore', async (req, res) => {
  const bb = body(z.object({ truncate: z.boolean().default(false), confirm: z.literal(true) }), req); const s = await serverAccess(req, 'backup.restore'); assertWritable(s); const b = await ownBackup(req, s);
  const r = await restoreBackup(b.id, bb.truncate); await serverActivity(req, s.id, 'server.backup.restored', { uuid: b.uuid, truncate: bb.truncate }); res.json(r);
});
serversRouter.get('/:id/backups/:bid/download', async (req, res) => { const s = await serverAccess(req, 'backup.download'); const b = await ownBackup(req, s); if (b.status !== 'completed') throw new HttpError(409, 'Backup is not complete'); res.setHeader('Content-Disposition', `attachment; filename="server-${s.id}-${b.uuid}.zip"`); await serverActivity(req, s.id, 'server.backup.downloaded', { uuid: b.uuid }); await agentStream(await nodeOf(s), req, res, 'GET', `${A(s)}/backups/${b.uuid}/download`, s.node_server_id); });

// ---------- schedules
const taskSchema = z.object({ action: z.enum(['start', 'stop', 'restart', 'kill', 'command', 'backup', 'delete_old_backups', 'notify']), payload: z.string().max(1000).nullable().optional(), delaySeconds: z.number().int().min(0).max(900).default(0), continueOnFailure: z.boolean().default(false) });
const schedSchema = z.object({ name: z.string().min(1).max(100), cron: z.string().max(100).nullable().optional(), runOnceAt: z.string().datetime({ offset: true }).nullable().optional(), timezone: z.string().max(64).default('UTC'), enabled: z.boolean().default(true), onlyWhenOnline: z.boolean().default(false), notifyOnFailure: z.boolean().default(true), tasks: z.array(taskSchema).max(20).default([]) });
serversRouter.get('/:id/schedules', async (req, res) => {
  const s = await serverAccess(req, 'schedule.read'); const list = await q('SELECT * FROM schedules WHERE server_id = ? ORDER BY id', [s.id]);
  for (const x of list as any[]) { x.tasks = await q('SELECT * FROM schedule_tasks WHERE schedule_id = ? ORDER BY sequence', [x.id]); x.runs = await q('SELECT id, status, output, started_at, finished_at FROM schedule_runs WHERE schedule_id = ? ORDER BY id DESC LIMIT 20', [x.id]); }
  res.json({ schedules: list });
});
async function saveSchedule(serverId: number, b: z.infer<typeof schedSchema>, id?: number) {
  if (!b.cron && !b.runOnceAt) throw bad('Provide a cron expression or a one-time date');
  const once = b.runOnceAt ? new Date(b.runOnceAt) : null; if (once && once < new Date()) throw bad('One-time schedule date is in the past');
  const next = nextRun(b.cron || null, once, b.timezone);
  for (const t of b.tasks) if (t.action === 'command' && !t.payload) throw bad('Command tasks need a command');
  return tx(async (c) => {
    let sid = id;
    if (sid) await exec('UPDATE schedules SET name=?, cron=?, run_once_at=?, timezone=?, enabled=?, only_when_online=?, notify_on_failure=?, next_run_at=? WHERE id = ? AND server_id = ?', [b.name, b.cron || null, once, b.timezone, b.enabled ? 1 : 0, b.onlyWhenOnline ? 1 : 0, b.notifyOnFailure ? 1 : 0, b.enabled ? next : null, sid, serverId], c);
    else sid = (await exec('INSERT INTO schedules (server_id, name, cron, run_once_at, timezone, enabled, only_when_online, notify_on_failure, next_run_at) VALUES (?,?,?,?,?,?,?,?,?)', [serverId, b.name, b.cron || null, once, b.timezone, b.enabled ? 1 : 0, b.onlyWhenOnline ? 1 : 0, b.notifyOnFailure ? 1 : 0, b.enabled ? next : null], c)).insertId;
    await exec('DELETE FROM schedule_tasks WHERE schedule_id = ?', [sid], c);
    let i = 0; for (const t of b.tasks) await exec('INSERT INTO schedule_tasks (schedule_id, sequence, action, payload, delay_seconds, continue_on_failure) VALUES (?,?,?,?,?,?)', [sid, i++, t.action, t.payload ?? null, t.delaySeconds, t.continueOnFailure ? 1 : 0], c);
    return { id: sid, nextRunAt: next };
  });
}
serversRouter.post('/:id/schedules', async (req, res) => { const b = body(schedSchema, req); const s = await serverAccess(req, 'schedule.manage'); const c: any = await one('SELECT COUNT(*) AS c FROM schedules WHERE server_id = ?', [s.id]); if (Number(c.c) >= 25) throw new HttpError(409, 'Schedule limit reached (25)'); const r = await saveSchedule(s.id, b); await serverActivity(req, s.id, 'server.schedule.created', { id: r.id }); res.status(201).json(r); });
serversRouter.put('/:id/schedules/:sid', async (req, res) => { const b = body(schedSchema, req); const s = await serverAccess(req, 'schedule.manage'); const ex = await one('SELECT id FROM schedules WHERE id = ? AND server_id = ?', [idParam(req, 'sid'), s.id]); if (!ex) throw new HttpError(404, 'Schedule not found'); res.json(await saveSchedule(s.id, b, idParam(req, 'sid'))); });
serversRouter.delete('/:id/schedules/:sid', async (req, res) => { const s = await serverAccess(req, 'schedule.manage'); await exec('DELETE FROM schedules WHERE id = ? AND server_id = ?', [idParam(req, 'sid'), s.id]); res.json({ ok: true }); });
serversRouter.post('/:id/schedules/:sid/run', async (req, res) => { const s = await serverAccess(req, 'schedule.manage'); const sc: any = await one('SELECT * FROM schedules WHERE id = ? AND server_id = ?', [idParam(req, 'sid'), s.id]); if (!sc) throw new HttpError(404, 'Schedule not found'); if (sc.is_processing) throw new HttpError(409, 'Schedule is already running'); const j = await enqueue('schedule.run', { scheduleId: sc.id, manual: true }, { uniqueKey: `schedule:${sc.id}`, maxAttempts: 1 }); if (!j) throw new HttpError(409, 'Schedule is already queued'); res.status(202).json({ jobId: j }); });
serversRouter.post('/schedules/preview', async (req, res) => { const b = body(z.object({ cron: z.string(), timezone: z.string().default('UTC') }), req); const out: Date[] = []; let d = new Date(); for (let i = 0; i < 5; i++) { const n = nextRun(b.cron, null, b.timezone, d); if (!n) break; out.push(n); d = new Date(n.getTime() + 1000); } res.json({ next: out }); });
void runSchedule;

// ---------- databases
serversRouter.get('/:id/databases', async (req, res) => { const s = await serverAccess(req, 'database.read'); const list = await listServerDatabases(s.id); res.json({ databases: list.map(d => ({ ...d, password: s._perms.includes('database.view_password') ? d.password : null })), limit: s.database_limit }); });
serversRouter.post('/:id/databases', async (req, res) => { const b = body(z.object({ name: z.string(), remote: z.string().default('%') }), req); const s = await serverAccess(req, 'database.manage'); assertWritable(s); const r = await createServerDatabase(s, b.name, b.remote); await serverActivity(req, s.id, 'server.database.created', { database: r.database }); res.status(201).json(r); });
serversRouter.post('/:id/databases/:did/rotate', async (req, res) => { const s = await serverAccess(req, 'database.manage'); const d = await one('SELECT id FROM server_databases WHERE id = ? AND server_id = ?', [idParam(req, 'did'), s.id]); if (!d) throw new HttpError(404, 'Database not found'); res.json({ password: await rotateDatabasePassword(idParam(req, 'did')) }); });
serversRouter.delete('/:id/databases/:did', async (req, res) => { const s = await serverAccess(req, 'database.manage'); const d = await one('SELECT id FROM server_databases WHERE id = ? AND server_id = ?', [idParam(req, 'did'), s.id]); if (!d) throw new HttpError(404, 'Database not found'); await deleteServerDatabase(idParam(req, 'did')); await serverActivity(req, s.id, 'server.database.deleted', { id: idParam(req, 'did') }); res.json({ ok: true }); });

// ---------- network / allocations
serversRouter.get('/:id/allocations', async (req, res) => { const s = await serverAccess(req, 'allocation.read'); const node = await nodeOf(s); res.json({ allocations: await q('SELECT id, ip, port, alias, notes, is_primary, reachable, checked_at, protocol FROM allocations WHERE server_id = ? ORDER BY is_primary DESC, port', [s.id]), limit: s.allocation_limit, publicIp: node.public_ip, note: 'Ports marked "reachable" passed an external connectivity check from the panel. "unknown" means not yet verified; firewalls or NAT may still block them.' }); });
serversRouter.post('/:id/allocations', async (req, res) => {
  const s = await serverAccess(req, 'allocation.manage');
  const r = await txRetry(async (c) => {
    const cnt: any = await one('SELECT COUNT(*) AS c FROM allocations WHERE server_id = ?', [s.id], c); if (Number(cnt.c) >= s.allocation_limit) throw new HttpError(409, `Allocation limit reached (${s.allocation_limit})`);
    const a: any = await one('SELECT id, ip, port FROM allocations WHERE node_id = ? AND server_id IS NULL ORDER BY port LIMIT 1 FOR UPDATE', [s.node_id], c); if (!a) throw new HttpError(409, 'No free ports on this node');
    await exec('UPDATE allocations SET server_id = ?, is_primary = 0 WHERE id = ?', [s.id, a.id], c); return a;
  });
  await syncSpec(s.id).catch(() => {}); await serverActivity(req, s.id, 'server.allocation.added', r); res.status(201).json({ allocation: r });
});
serversRouter.patch('/:id/allocations/:aid', async (req, res) => {
  const b = body(z.object({ notes: z.string().max(255).nullable().optional(), primary: z.literal(true).optional() }), req); const s = await serverAccess(req, 'allocation.manage');
  const a: any = await one('SELECT * FROM allocations WHERE id = ? AND server_id = ?', [idParam(req, 'aid'), s.id]); if (!a) throw new HttpError(404, 'Allocation not found');
  if (b.notes !== undefined) await exec('UPDATE allocations SET notes = ? WHERE id = ?', [b.notes, a.id]);
  if (b.primary) { await txRetry(async c => { await exec('UPDATE allocations SET is_primary = 0 WHERE server_id = ?', [s.id], c); await exec('UPDATE allocations SET is_primary = 1 WHERE id = ?', [a.id], c); }); await syncSpec(s.id).catch(() => {}); }
  res.json({ ok: true });
});
serversRouter.delete('/:id/allocations/:aid', async (req, res) => { const s = await serverAccess(req, 'allocation.manage'); const a: any = await one('SELECT * FROM allocations WHERE id = ? AND server_id = ?', [idParam(req, 'aid'), s.id]); if (!a) throw new HttpError(404, 'Allocation not found'); if (a.is_primary) throw new HttpError(409, 'The primary allocation cannot be removed'); await exec('UPDATE allocations SET server_id = NULL, notes = NULL WHERE id = ?', [a.id]); await syncSpec(s.id).catch(() => {}); res.json({ ok: true }); });

// ---------- subusers
serversRouter.get('/:id/users', async (req, res) => { const s = await serverAccess(req, 'user.read'); res.json({ users: await q('SELECT su.id, su.user_id, su.permissions, su.created_at, u.email, u.username FROM server_subusers su JOIN users u ON u.id = su.user_id WHERE su.server_id = ?', [s.id]), permissions: SERVER_PERMISSIONS }); });
serversRouter.post('/:id/users', async (req, res) => {
  const b = body(z.object({ email: z.string().email(), permissions: z.array(z.string()) }), req); const s = await serverAccess(req, 'user.manage');
  for (const p of b.permissions) { if (!SERVER_PERMISSIONS.includes(p)) throw bad(`Unknown permission ${p}`); if (!s._perms.includes(p)) throw forbidden(`You cannot grant ${p}`); }
  const u: any = await one('SELECT id FROM users WHERE email = ?', [b.email.toLowerCase()]); if (!u) throw new HttpError(404, 'No account exists with that email. Ask them to register first.');
  if (u.id === s.owner_id) throw bad('That user owns this server');
  await exec('INSERT INTO server_subusers (server_id, user_id, permissions) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE permissions = VALUES(permissions)', [s.id, u.id, json(b.permissions)]);
  await serverActivity(req, s.id, 'server.subuser.added', { email: b.email, permissions: b.permissions }); res.status(201).json({ ok: true });
});
serversRouter.put('/:id/users/:uid', async (req, res) => { const b = body(z.object({ permissions: z.array(z.string()) }), req); const s = await serverAccess(req, 'user.manage'); for (const p of b.permissions) { if (!SERVER_PERMISSIONS.includes(p)) throw bad(`Unknown permission ${p}`); if (!s._perms.includes(p)) throw forbidden(`You cannot grant ${p}`); } await exec('UPDATE server_subusers SET permissions = ? WHERE server_id = ? AND user_id = ?', [json(b.permissions), s.id, idParam(req, 'uid')]); res.json({ ok: true }); });
serversRouter.delete('/:id/users/:uid', async (req, res) => { const s = await serverAccess(req, 'user.manage'); await exec('DELETE FROM server_subusers WHERE server_id = ? AND user_id = ?', [s.id, idParam(req, 'uid')]); await serverActivity(req, s.id, 'server.subuser.removed', { userId: idParam(req, 'uid') }); res.json({ ok: true }); });

// ---------- activity
serversRouter.get('/:id/activity', async (req, res) => { const s = await serverAccess(req, 'activity.read'); const p = paginate(req); res.json({ activity: await q('SELECT a.id, a.event, a.metadata, a.ip, a.created_at, u.username FROM server_activity a LEFT JOIN users u ON u.id = a.user_id WHERE a.server_id = ? ORDER BY a.id DESC LIMIT ? OFFSET ?', [s.id, p.limit, p.offset]), page: p.page }); });

// ---------- plugins / mods
const installerOf = async (s: ServerRow) => (await getEgg(s.egg_id)).definition.installer;
serversRouter.get('/:id/plugins/sources', async (req, res) => { await serverAccess(req, 'plugin.read'); const repos = await q("SELECT id, name, type FROM plugin_repositories WHERE enabled = 1 ORDER BY id"); const builtin = ['modrinth', 'hangar', 'spiget', 'github']; const enabled = new Set(repos.filter((r: any) => r.type !== 'custom').map((r: any) => r.type)); res.json({ sources: [...builtin.filter(b => !repos.some((r: any) => r.type === b) || enabled.has(b)).map(b => ({ id: b, name: { modrinth: 'Modrinth', hangar: 'Hangar (PaperMC)', spiget: 'SpigotMC (via Spiget)', github: 'GitHub Releases' }[b] })), ...repos.filter((r: any) => r.type === 'custom').map((r: any) => ({ id: `custom:${r.id}`, name: r.name }))] }); });
serversRouter.get('/:id/plugins/search', async (req, res) => { const s = await serverAccess(req, 'plugin.read'); const inst = await installerOf(s); const v = parse<any>(s.variables, {}); res.json({ folder: loaderInfo(inst).folder, results: await searchPlugins(String(req.query.source || 'modrinth'), String(req.query.q || ''), inst, String(req.query.gameVersion || v.MC_VERSION || s.installed_version || ''), req.query.category ? String(req.query.category) : undefined) }); });
serversRouter.get('/:id/plugins/versions', async (req, res) => { const s = await serverAccess(req, 'plugin.read'); const inst = await installerOf(s); res.json({ versions: await pluginVersions(String(req.query.source), String(req.query.project), inst, req.query.gameVersion ? String(req.query.gameVersion) : undefined) }); });
serversRouter.get('/:id/plugins', async (req, res) => {
  const s = await serverAccess(req, 'plugin.read');
  const files = await agent(await nodeOf(s), 'GET', `${A(s)}/plugins`, undefined, { serverId: s.node_server_id });
  res.json({ ...files, tracked: await q('SELECT * FROM plugin_installs WHERE server_id = ?', [s.id]) });
});
serversRouter.post('/:id/plugins/install', async (req, res) => {
  const b = body(z.object({ source: z.string().max(20), project: z.string().max(100), projectName: z.string().max(200).optional(), version: z.string().max(100), withDependencies: z.boolean().default(true) }), req);
  const s = await serverAccess(req, 'plugin.manage'); assertWritable(s); if (s.security_blocked) throw forbidden('Blocked by the Security Center');
  const inst = await installerOf(s); const L = loaderInfo(inst); const node = await nodeOf(s); const hosts = await downloadHosts(b.source);
  const installed: any[] = []; const skipped: any[] = []; const seen = new Set<string>();
  const v = parse<any>(s.variables, {}); const gv = v.MC_VERSION && v.MC_VERSION !== 'latest' ? v.MC_VERSION : s.installed_version || undefined;
  const installOne = async (project: string, versionId: string | null, name: string, depth: number) => {
    if (seen.has(project) || depth > 3) return; seen.add(project);
    const versions = await pluginVersions(b.source, project, inst, versionId ? undefined : gv);
    const ver = versionId ? versions.find(x => x.id === versionId) : versions.find(x => x.downloadable);
    if (!ver?.file || !ver.downloadable) { skipped.push({ project, name, reason: 'No downloadable JAR for this server version (external or premium resource?)' }); return; }
    const existing: any = await one('SELECT file FROM plugin_installs WHERE server_id = ? AND source = ? AND project_id = ?', [s.id, b.source, project]);
    // The agent only downloads + statically scans the file. Downloaded plugins are never executed during installation.
    const r = await agent(node, 'POST', `${A(s)}/plugins/install`, { url: ver.file.url, filename: ver.file.filename, folder: L.folder, hash: ver.file.hash, allowHosts: hosts, replace: existing && existing.file !== `${L.folder}/${ver.file.filename}` ? [existing.file.split('/').pop()] : [] }, { serverId: s.node_server_id, timeoutMs: 300_000 });
    await exec('INSERT INTO plugin_installs (server_id, source, project_id, project_name, version_id, version_name, file) VALUES (?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE version_id = VALUES(version_id), version_name = VALUES(version_name), file = VALUES(file), installed_at = NOW()', [s.id, b.source, project, name.slice(0, 200), ver.id, ver.name.slice(0, 100), r.file]);
    installed.push({ project, name, version: ver.name, file: r.file, scan: r.scan, backedUp: r.backedUp });
    if (b.withDependencies) for (const d of ver.dependencies.filter(d => d.required)) { if (b.source === 'hangar' || b.source === 'modrinth') await installOne(d.id, null, d.name || d.id, depth + 1).catch(e => skipped.push({ project: d.id, reason: e.message })); else skipped.push({ project: d.id, reason: 'Install this dependency manually' }); }
  };
  await installOne(b.project, b.version, b.projectName || b.project, 0);
  await serverActivity(req, s.id, 'server.plugin.installed', { source: b.source, project: b.project, installed: installed.map(i => i.file) });
  res.json({ installed, skipped, restartRequired: installed.length > 0 });
});
serversRouter.post('/:id/plugins/delete', async (req, res) => { const b = body(z.object({ file: z.string().regex(/^(plugins|mods)\/[^/]+\.jar$/) }), req); const s = await serverAccess(req, 'plugin.manage'); await agent(await nodeOf(s), 'POST', `${A(s)}/plugins/delete`, b, { serverId: s.node_server_id }); await exec('DELETE FROM plugin_installs WHERE server_id = ? AND file = ?', [s.id, b.file]); await serverActivity(req, s.id, 'server.plugin.deleted', b); res.json({ ok: true }); });
serversRouter.post('/:id/plugins/check-updates', async (req, res) => {
  const s = await serverAccess(req, 'plugin.read'); const inst = await installerOf(s); const tracked = await q('SELECT * FROM plugin_installs WHERE server_id = ?', [s.id]); const v = parse<any>(s.variables, {}); const out = [];
  for (const t of tracked as any[]) { try { const vs = await pluginVersions(t.source, t.project_id, inst, v.MC_VERSION !== 'latest' ? v.MC_VERSION : undefined); const latest = vs.find(x => x.downloadable); if (latest) { await exec('UPDATE plugin_installs SET latest_version_id = ?, latest_version_name = ?, checked_at = NOW() WHERE id = ?', [latest.id, latest.name.slice(0, 100), t.id]); out.push({ project: t.project_id, name: t.project_name, current: t.version_name, latest: latest.name, latestId: latest.id, update: latest.id !== t.version_id }); } } catch (e: any) { out.push({ project: t.project_id, error: e.message }); } }
  res.json({ updates: out });
});

// ---------- security (customer view of their own server's scans, appeals, rescans)
serversRouter.get('/:id/security', async (req, res) => {
  const s = await serverAccess(req, null);
  res.json({ level: s.security_level, blocked: !!s.security_blocked, suspendedUntil: s.suspended_until, reason: s.suspension_reason,
    scans: await q('SELECT id, file, mode, sha256, level, reason, findings, phase, review_status, created_at FROM security_scans WHERE server_id = ? ORDER BY id DESC LIMIT 50', [s.id]),
    incidents: await q('SELECT id, severity, category, rule, status, action_taken, created_at FROM security_incidents WHERE server_id = ? ORDER BY id DESC LIMIT 20', [s.id]),
    appeals: await q('SELECT id, message, status, response, created_at FROM security_appeals WHERE server_id = ? ORDER BY id DESC', [s.id]) });
});
serversRouter.post('/:id/security/appeal', async (req, res) => {
  const b = body(z.object({ message: z.string().min(10).max(4000), incidentId: z.number().int().optional() }), req); const s = await serverAccess(req, null);
  if (s.owner_id !== req.user!.id) throw forbidden('Only the server owner can appeal');
  const open = await one("SELECT id FROM security_appeals WHERE server_id = ? AND status = 'open'", [s.id]); if (open) throw new HttpError(409, 'An appeal is already open for this server');
  await exec('INSERT INTO security_appeals (server_id, user_id, message) VALUES (?, ?, ?)', [s.id, req.user!.id, b.incidentId ? `[incident #${b.incidentId}] ${b.message}` : b.message]);
  await notifyAdmins('admin.security', 'security', `Security appeal for server #${s.id}`, b.message.slice(0, 300), { link: `/admin/security?server=${s.id}` }); res.status(201).json({ ok: true });
});
serversRouter.post('/:id/security/rescan', async (req, res) => { const s = await serverAccess(req, 'file.read'); res.json(await agent(await nodeOf(s), 'POST', `${A(s)}/scan`, undefined, { serverId: s.node_server_id, timeoutMs: 600_000 })); });

void buildSpec; void loadUserById; void BUILTIN_EGGS; void cleanupSafetyBackups;
