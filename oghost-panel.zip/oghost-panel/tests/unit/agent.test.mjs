import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { load, tmpdir } from '../helpers/load.mjs';
const home = tmpdir('oghost-agent-');
const hook = path.join(home, 'quota-hook.sh'); const hookLog = path.join(home, 'hook.log');
fs.writeFileSync(hook, `#!/bin/sh\necho "$@" >> ${hookLog}\n[ "$1" = set ] && [ "$4" -gt 100000 ] && { echo "over host limit" >&2; exit 2; }\necho applied\n`, { mode: 0o755 });
// Fake VPS layout with numbered Java commands, like `java8 -jar server.jar` / `java17 -jar server.jar`.
const jbin = path.join(home, 'javabins'); fs.mkdirSync(jbin);
fs.writeFileSync(path.join(jbin, 'java8'), '#!/bin/sh\necho \'openjdk version "1.8.0_402"\' >&2\necho \'OpenJDK Runtime Environment (Temurin)(build 1.8.0_402-b06)\' >&2\n', { mode: 0o755 });
fs.symlinkSync('/usr/lib/jvm/java-17-openjdk-amd64/bin/java', path.join(jbin, 'java17'));
fs.writeFileSync(path.join(jbin, 'java-21'), '#!/bin/sh\nexec /usr/lib/jvm/java-21-openjdk-amd64/bin/java "$@"\n', { mode: 0o755 });
fs.writeFileSync(path.join(jbin, 'javac'), '#!/bin/sh\nexit 1\n', { mode: 0o755 });
Object.assign(process.env, { JAVA_SEARCH_PATHS: jbin, NODE_ID: '1', NODE_SECRET: 'x'.repeat(64), PANEL_URL: 'http://127.0.0.1:1', DATA_ROOT: path.join(home, '.server'), QUOTA_HOOK: hook });
const D = await load('apps/node-agent/src/disk.ts');
const Q = await load('apps/node-agent/src/quota.ts');

test('disk reservation refuses writes beyond the allocation (server-side accounting)', async () => {
  const dir = tmpdir(); fs.writeFileSync(path.join(dir, 'a.bin'), Buffer.alloc(600 * 1024));
  const acc = new D.DiskAccount(dir, 1024 * 1024); await acc.rescan();
  assert.ok(acc.used >= 600 * 1024);
  const r1 = acc.reserve(300 * 1024);
  assert.throws(() => acc.reserve(300 * 1024), e => e.status === 507, 'concurrent reservations count against the limit');
  r1.release(300 * 1024); assert.ok(acc.used >= 900 * 1024);
  assert.throws(() => acc.reserve(200 * 1024), /Disk allocation exceeded/);
  const unl = new D.DiskAccount(dir, 0); unl.reserve(10 ** 12).release(0);
});
test('disk size counts nested files and ignores symlink targets', async () => {
  const dir = tmpdir(); fs.mkdirSync(path.join(dir, 'x/y'), { recursive: true }); fs.writeFileSync(path.join(dir, 'x/y/f'), Buffer.alloc(256 * 1024));
  const big = tmpdir(); fs.writeFileSync(path.join(big, 'huge'), Buffer.alloc(4 * 1024 * 1024)); fs.symlinkSync(big, path.join(dir, 'link'));
  const n = await D.dirSize(dir); assert.ok(n >= 256 * 1024 && n < 2 * 1024 * 1024, `size ${n}`);
});
test('optional host-admin quota hook is called without a shell, with fixed arguments', async () => {
  const sdir = path.join(home, '.server/nodes/1/servers/7');
  const ok = await Q.quotaHook('set', 7, sdir, 4096); assert.equal(ok.applied, true);
  const bad = await Q.quotaHook('set', 8, sdir, 200000); assert.equal(bad.applied, false); assert.match(bad.message, /over host limit/);
  await Q.quotaHook('clear', 7, sdir);
  assert.deepEqual(fs.readFileSync(hookLog, 'utf8').trim().split('\n'), [`set 7 ${sdir} 4096`, `set 8 ${sdir} 200000`, `clear 7 ${sdir}`]);
});

test('detects numbered Java commands (java8, java17, java-21) and picks Java by Minecraft version', async () => {
  const J = await load('apps/node-agent/src/java.ts');
  const S = await load('packages/shared/src/startup.ts');
  const list = await J.detectJava();
  const majors = [...new Set(list.map(j => j.major))];
  for (const m of [8, 17, 21]) assert.ok(majors.includes(m), `Java ${m} detected (got ${majors})`);
  assert.ok(list.some(j => j.path.endsWith('/javabins/java8')), 'wrapper script java8 kept as its own path');
  assert.ok(!list.some(j => j.path.endsWith('javac')), 'javac is not a runtime');
  assert.equal(list.filter(j => j.major === 17).length, 1, 'java17 symlink deduplicated with the real JDK 17');
  const pick = (mc, eggMin) => S.pickJava(list, { mcVersion: mc, eggMin })?.major;
  assert.equal(pick('1.8.8'), 8);
  assert.equal(pick('1.12.2'), 8);
  assert.equal(pick('1.18.2'), 17);
  assert.equal(pick('1.20.4'), 17);
  assert.equal(pick('1.21.4'), 21);
  assert.equal(pick('1.20.4', 21), 21, 'egg minimum respected');
  assert.equal(pick('26.1'), undefined, 'no Java 25 here -> none (never a too-old Java)');
  assert.equal(pick(null), 21, 'unknown version -> newest');
});
