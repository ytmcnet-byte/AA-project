import { execFile } from 'node:child_process';
import fs from 'node:fs';
import { config } from './config';

/**
 * Optional host-admin kernel quota integration.
 * QUOTA_HOOK points at an executable provided by the host administrator (for example a script
 * that calls `setquota`/`xfs_quota` via a narrowly-scoped sudoers rule). It is called WITHOUT a shell:
 *   <hook> set   <serverId> <absoluteServerDir> <diskMb>
 *   <hook> clear <serverId> <absoluteServerDir>
 * Exit code 0 = applied. Any other result is logged and the agent keeps application-level enforcement.
 * Arguments are numeric IDs and agent-generated paths only; customer input never reaches the hook.
 */
export type QuotaResult = { applied: boolean; message: string; at: number };
export function quotaHook(action: 'set' | 'clear', id: number, dir: string, diskMb?: number): Promise<QuotaResult | null> {
  if (!config.quotaHook) return Promise.resolve(null);
  if (!fs.existsSync(config.quotaHook)) return Promise.resolve({ applied: false, message: `QUOTA_HOOK not found: ${config.quotaHook}`, at: Date.now() });
  const args = action === 'set' ? ['set', String(id), dir, String(Math.max(1, Math.floor(diskMb || 0)))] : ['clear', String(id), dir];
  return new Promise(res => execFile(config.quotaHook, args, { timeout: 30_000, env: { PATH: process.env.PATH || '/usr/bin:/bin' } }, (err, stdout, stderr) => {
    const msg = `${stdout}${stderr}`.trim().slice(0, 500);
    if (err) console.warn(`[agent] quota hook ${action} for server ${id} failed: ${msg || err.message}`);
    res({ applied: !err, message: msg || (err ? err.message : 'ok'), at: Date.now() });
  }));
}
