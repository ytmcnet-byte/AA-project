import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';

function loadEnvFile(file: string) {
  if (!fs.existsSync(file)) return;
  for (const line of fs.readFileSync(file, 'utf8').split('\n')) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/); if (!m) continue;
    if (process.env[m[1]] === undefined) process.env[m[1]] = m[2].replace(/^["']|["']$/g, '');
  }
}
loadEnvFile(process.env.AGENT_ENV_FILE || path.resolve(process.cwd(), 'agent.env'));

const expandHome = (p: string) => p.replace(/^~(?=$|\/)/, os.homedir());
const req = (k: string) => { const v = process.env[k]; if (!v) { console.error(`[agent] Missing required config ${k}`); process.exit(1); } return v; };

export const config = {
  nodeId: Number(req('NODE_ID')),
  secret: req('NODE_SECRET'),
  panelUrl: req('PANEL_URL').replace(/\/$/, ''),
  host: process.env.AGENT_HOST || '0.0.0.0',
  port: Number(process.env.AGENT_PORT || 8443),
  tlsCert: process.env.AGENT_TLS_CERT ? expandHome(process.env.AGENT_TLS_CERT) : '',
  tlsKey: process.env.AGENT_TLS_KEY ? expandHome(process.env.AGENT_TLS_KEY) : '',
  panelCa: process.env.PANEL_CA ? expandHome(process.env.PANEL_CA) : '',
  dataRoot: path.resolve(expandHome(process.env.DATA_ROOT || path.join(process.cwd(), '.server'))),
  javaSearchPaths: (process.env.JAVA_SEARCH_PATHS || '').split(':').filter(Boolean).map(expandHome),
  cpulimitPath: expandHome(process.env.CPULIMIT_PATH || '~/bin/cpulimit'),
  heartbeatSeconds: Number(process.env.HEARTBEAT_SECONDS || 15),
  diskScanSeconds: Number(process.env.DISK_SCAN_SECONDS || 60),
  diskExceededAction: (process.env.DISK_EXCEEDED_ACTION || 'warn') as 'warn' | 'stop',
  quotaHook: process.env.QUOTA_HOOK ? expandHome(process.env.QUOTA_HOOK) : '',
  runAsUidBase: Number(process.env.RUN_AS_UID_BASE || 0),
  maxConsoleLines: 2000,
  userAgent: 'OGHOST-Panel-Agent/1.0 (+https://github.com/oghost; contact: admin)',
};

export const nodeDir = path.join(config.dataRoot, 'nodes', String(config.nodeId));
export const dirs = {
  servers: path.join(nodeDir, 'servers'),
  backups: path.join(nodeDir, 'backups'),
  temporary: path.join(nodeDir, 'temporary'),
  metadata: path.join(nodeDir, 'metadata'),
};
for (const d of Object.values(dirs)) fs.mkdirSync(d, { recursive: true, mode: 0o750 });
export const serverDir = (id: number) => path.join(dirs.servers, String(id));
export const backupDir = (id: number) => path.join(dirs.backups, String(id));
