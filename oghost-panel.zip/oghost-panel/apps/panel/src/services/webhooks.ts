import crypto from 'node:crypto';
import { q, exec, parse } from '../db';
import { decryptSecret } from '@oghost/shared';
import { config } from '../config';

export const WEBHOOK_EVENTS = ['server.created', 'server.deleted', 'server.suspended', 'invoice.paid', 'order.created', 'security.incident', 'node.offline', 'ticket.created', 'user.registered'];
export async function deliverWebhook(h: any, event: string, data: unknown) {
  const body = JSON.stringify({ event, data, sentAt: new Date().toISOString() }); const t = Math.floor(Date.now() / 1000);
  const sig = crypto.createHmac('sha256', decryptSecret(h.secret_enc, config.appKey)).update(`${t}.${body}`).digest('hex');
  let status: string;
  try { const r = await fetch(h.url, { method: 'POST', headers: { 'Content-Type': 'application/json', 'User-Agent': 'OGHOST-Webhooks/1.0', 'X-OGHOST-Event': event, 'X-OGHOST-Signature': `t=${t},v1=${sig}` }, body, signal: AbortSignal.timeout(10_000), redirect: 'manual' }); status = String(r.status); }
  catch (e: any) { status = `error: ${String(e.cause?.code || e.message).slice(0, 80)}`; }
  await exec('UPDATE outgoing_webhooks SET last_status = ?, last_delivery_at = NOW() WHERE id = ?', [status, h.id]); return status;
}
/** Outgoing webhooks, signed with HMAC-SHA256 (header X-OGHOST-Signature: t=<unix>,v1=<hex> over "<t>.<body>"). */
type Listener = (event: string, data: unknown) => void | Promise<void>;
const listeners = new Set<Listener>();
/** In-process subscribers (used by extensions). Errors in listeners never affect the panel. */
export function onPanelEvent(fn: Listener) { listeners.add(fn); return () => listeners.delete(fn); }
export async function dispatchWebhook(event: string, data: unknown) {
  for (const l of listeners) { try { await l(event, data); } catch (e: any) { console.error('[events] listener failed', e?.message); } }
  const hooks = await q('SELECT * FROM outgoing_webhooks WHERE enabled = 1').catch(() => []);
  for (const h of hooks as any[]) { const events = parse<string[]>(h.events, []); if (!events.includes('*') && !events.includes(event)) continue; await deliverWebhook(h, event, data); }
}
