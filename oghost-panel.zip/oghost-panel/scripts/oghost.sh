#!/usr/bin/env bash
# Start/stop helper for hosts without systemd --user. Non-root, uses nohup + pid files.
# Usage: scripts/oghost.sh start|stop|restart|status panel|agent
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
act="${1:-}"; what="${2:-panel}"
[ "$what" = panel ] || [ "$what" = agent ] || { echo "Usage: $0 start|stop|restart|status panel|agent"; exit 1; }
if [ "$what" = panel ]; then RUN="$ROOT/logs"; else RUN="$HOME/oghost-agent/logs"; fi
mkdir -p "$RUN"; PID="$RUN/$what.pid"; LOG="$RUN/$what.log"
alive() { [ -f "$PID" ] && kill -0 "$(cat "$PID")" 2>/dev/null; }
start() { if alive; then echo "$what already running (pid $(cat "$PID"))"; return; fi
  if command -v setsid >/dev/null; then setsid nohup bash "$ROOT/scripts/run.sh" "$what" >>"$LOG" 2>&1 < /dev/null & else nohup bash "$ROOT/scripts/run.sh" "$what" >>"$LOG" 2>&1 < /dev/null & fi; echo $! >"$PID"; sleep 2
  if alive; then echo "$what started (pid $(cat "$PID")), log: $LOG"; else echo "$what failed to start; see $LOG"; tail -n 20 "$LOG"; exit 1; fi; }
stop() { if ! alive; then echo "$what not running"; rm -f "$PID"; return; fi
  local p; p="$(cat "$PID")"; kill -TERM "$p"
  # the agent stops game servers gracefully before exiting; allow up to 90 s
  for _ in $(seq 1 90); do kill -0 "$p" 2>/dev/null || break; sleep 1; done
  kill -0 "$p" 2>/dev/null && { echo "forcing $what to exit"; kill -KILL "$p"; }; rm -f "$PID"; echo "$what stopped"; }
case "$act" in
  start) start ;; stop) stop ;; restart) stop; start ;;
  status) if alive; then echo "$what running (pid $(cat "$PID"))"; else echo "$what stopped"; exit 3; fi ;;
  *) echo "Usage: $0 start|stop|restart|status panel|agent"; exit 1 ;;
esac
