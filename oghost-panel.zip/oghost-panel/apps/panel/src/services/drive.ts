import crypto from 'node:crypto';
import { encryptSecret, decryptSecret, randomToken } from '@oghost/shared';
import { q, one, exec, json } from '../db';
import { config } from '../config';
import { HttpError } from '../lib/http';
import { getSetting } from './settings';
import { getServer } from './servers';
import { getNode, agent } from './nodes';
import { notify } from './notify';
import { registerJob, enqueue } from './jobs';
import { serverActivity } from './audit';

/**
 * Per-customer Google Drive backups.
 * - OAuth 2.0 authorization code + PKCE + single-use state bound to the user.
 * - Minimum scope drive.file: the panel can only see files it created itself.
 * - Refresh/access tokens are encrypted at rest and never sent to the browser. Node agents receive only
 *   a short-lived access token for the duration of one upload/restore.
 * - The previous successful backup is deleted only after the new upload is complete AND verified.
 */
export const DRIVE_SCOPES = ['https://www.googleapis.com/auth/drive.file', 'openid', 'email'];
export const RETENTION_OPTIONS = [1, 2, 3, 5, 7];
const enc = (s: string) => encryptSecret(s, config.appKey); const dec = (s: string) => decryptSecret(s, config.appKey);
const redirectUri = () => `${config.appUrl}/api/drive/callback`;

async function clientCreds() {
  const id = await getSetting<string>('google.clientId'); const secret = await getSetting<string>('google.clientSecret');
  if (!id || !secret) throw new HttpError(503, 'Google Drive integration is not configured by the administrator');
  if (!(await getSetting('drive.enabled'))) throw new HttpError(503, 'Google Drive backups are disabled');
  return { id, secret };
}

export async function authUrl(userId: number, returnTo: string) {
  const { id } = await clientCreds();
  const state = randomToken(32).slice(0, 64); const verifier = randomToken(48).slice(0, 96);
  const challenge = crypto.createHash('sha256').update(verifier).digest('base64url');
  await exec('DELETE FROM drive_oauth_states WHERE expires_at < NOW() OR user_id = ?', [userId]);
  await exec('INSERT INTO drive_oauth_states (state, user_id, return_to, code_verifier, expires_at) VALUES (?, ?, ?, ?, DATE_ADD(NOW(), INTERVAL 10 MINUTE))', [state, userId, returnTo.startsWith('/') && !returnTo.startsWith('//') ? returnTo.slice(0, 300) : '/', verifier]);
  const p = new URLSearchParams({ client_id: id, redirect_uri: redirectUri(), response_type: 'code', scope: DRIVE_SCOPES.join(' '), access_type: 'offline', prompt: 'consent', include_granted_scopes: 'false', state, code_challenge: challenge, code_challenge_method: 'S256' });
  return `${config.googleAuthUrl}?${p}`;
}

export async function handleCallback(userId: number, state: string, code: string) {
  const st: any = await one('SELECT * FROM drive_oauth_states WHERE state = ? AND expires_at > NOW()', [state]);
  await exec('DELETE FROM drive_oauth_states WHERE state = ?', [state]); // single use
  if (!st || st.user_id !== userId) throw new HttpError(400, 'Invalid or expired OAuth state. Please try connecting again.');
  const { id, secret } = await clientCreds();
  const r = await fetch(`${config.googleOauthBase}/token`, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ code, client_id: id, client_secret: secret, redirect_uri: redirectUri(), grant_type: 'authorization_code', code_verifier: st.code_verifier }) });
  const t: any = await r.json().catch(() => ({})); if (!r.ok || !t.access_token) throw new HttpError(400, `Google rejected the authorization: ${t.error_description || t.error || r.status}`);
  if (!t.refresh_token) throw new HttpError(400, 'Google did not return a refresh token. Remove OGHOST from your Google account permissions and connect again.');
  const scopes = String(t.scope || ''); if (!scopes.includes('drive.file')) throw new HttpError(400, 'The Google Drive permission was not granted');
  let email: string | null = null, sub: string | null = null;
  if (t.id_token) { try { const p = JSON.parse(Buffer.from(String(t.id_token).split('.')[1], 'base64url').toString()); if (p.aud === id) { email = p.email ?? null; sub = p.sub ?? null; } } catch { /* id_token came directly from Google's token endpoint over TLS */ } }
  await exec(`INSERT INTO drive_connections (user_id, google_email, google_sub, refresh_token_enc, access_token_enc, access_expires_at, scopes, status, last_error, root_folder_id) VALUES (?, ?, ?, ?, ?, DATE_ADD(NOW(), INTERVAL ? SECOND), ?, 'connected', NULL, NULL)
    ON DUPLICATE KEY UPDATE google_email = VALUES(google_email), google_sub = VALUES(google_sub), refresh_token_enc = VALUES(refresh_token_enc), access_token_enc = VALUES(access_token_enc), access_expires_at = VALUES(access_expires_at), scopes = VALUES(scopes), status = 'connected', last_error = NULL, root_folder_id = IF(google_sub <=> VALUES(google_sub), root_folder_id, NULL)`,
    [userId, email, sub, enc(t.refresh_token), enc(t.access_token), Math.max(60, Number(t.expires_in || 3600) - 120), scopes.slice(0, 500)]);
  // a different Google account means previously stored folder ids are invalid
  return st.return_to || '/';
}

export async function accessToken(userId: number): Promise<string> {
  const c: any = await one('SELECT * FROM drive_connections WHERE user_id = ?', [userId]);
  if (!c || c.status === 'revoked') throw Object.assign(new HttpError(409, 'Google Drive is not connected'), { driveKind: 'not_connected' });
  if (c.access_token_enc && c.access_expires_at && new Date(c.access_expires_at).getTime() > Date.now() + 5 * 60_000) return dec(c.access_token_enc);
  const { id, secret } = await clientCreds();
  const r = await fetch(`${config.googleOauthBase}/token`, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ client_id: id, client_secret: secret, refresh_token: dec(c.refresh_token_enc), grant_type: 'refresh_token' }) });
  const t: any = await r.json().catch(() => ({}));
  if (!r.ok || !t.access_token) {
    const revoked = t.error === 'invalid_grant';
    await exec('UPDATE drive_connections SET status = ?, last_error = ? WHERE user_id = ?', [revoked ? 'revoked' : 'error', `Token refresh failed: ${t.error || r.status}`, userId]);
    throw Object.assign(new HttpError(409, revoked ? 'Google Drive access was revoked or expired. Reconnect Google Drive.' : `Google token refresh failed (${t.error || r.status})`), { driveKind: revoked ? 'revoked' : 'auth' });
  }
  await exec("UPDATE drive_connections SET access_token_enc = ?, access_expires_at = DATE_ADD(NOW(), INTERVAL ? SECOND), status = 'connected', last_error = NULL WHERE user_id = ?", [enc(t.access_token), Math.max(60, Number(t.expires_in || 3600) - 120), userId]);
  return t.access_token;
}

async function dapi(token: string, method: string, path: string, body?: unknown) {
  const r = await fetch(`${config.driveApiBase}${path}`, { method, headers: { Authorization: `Bearer ${token}`, ...(body ? { 'Content-Type': 'application/json' } : {}) }, body: body ? JSON.stringify(body) : undefined });
  const text = await r.text(); let data: any = null; try { data = text ? JSON.parse(text) : null; } catch { data = text; }
  if (!r.ok) { const reason = data?.error?.errors?.[0]?.reason || data?.error?.status || ''; throw Object.assign(new HttpError(r.status === 404 ? 404 : 502, `Google Drive: ${data?.error?.message || r.status}`), { driveKind: /storageQuotaExceeded|quotaExceeded/i.test(reason) ? 'quota' : r.status === 401 ? 'auth' : r.status === 403 ? 'permission' : r.status === 404 ? 'not_found' : 'api', status: r.status }); }
  return data;
}
async function findOrCreateFolder(token: string, name: string, parent: string | null) {
  const qs = `name = '${name.replace(/'/g, "\\'")}' and mimeType = 'application/vnd.google-apps.folder' and trashed = false${parent ? ` and '${parent}' in parents` : ` and 'root' in parents`}`;
  const found = await dapi(token, 'GET', `/drive/v3/files?q=${encodeURIComponent(qs)}&fields=files(id,name)&spaces=drive&pageSize=1`);
  if (found?.files?.[0]) return found.files[0].id as string;
  const created = await dapi(token, 'POST', '/drive/v3/files?fields=id', { name, mimeType: 'application/vnd.google-apps.folder', ...(parent ? { parents: [parent] } : {}) });
  return created.id as string;
}
async function folderValid(token: string, id: string | null) { if (!id) return false; try { const f = await dapi(token, 'GET', `/drive/v3/files/${id}?fields=id,trashed`); return !f.trashed; } catch (e: any) { if (e.status === 404) return false; throw e; } }

/** Folder layout OGHOST/Node-<nodeId>/Server-<nodeServerId> (numeric IDs, never display names). */
export async function ensureServerFolder(userId: number, serverId: number, token: string) {
  const s = await getServer(serverId); const cfg: any = await one('SELECT folder_id FROM drive_backup_configs WHERE server_id = ?', [serverId]);
  if (cfg?.folder_id && await folderValid(token, cfg.folder_id)) return cfg.folder_id as string;
  const conn: any = await one('SELECT root_folder_id FROM drive_connections WHERE user_id = ?', [userId]);
  let root = conn?.root_folder_id; if (!(await folderValid(token, root))) { root = await findOrCreateFolder(token, 'OGHOST', null); await exec('UPDATE drive_connections SET root_folder_id = ? WHERE user_id = ?', [root, userId]); }
  const nodeF = await findOrCreateFolder(token, `Node-${s.node_id}`, root); const srvF = await findOrCreateFolder(token, `Server-${s.node_server_id}`, nodeF);
  await exec('UPDATE drive_backup_configs SET folder_id = ? WHERE server_id = ?', [srvF, serverId]); return srvF;
}

export async function getConfig(serverId: number) {
  let c: any = await one('SELECT * FROM drive_backup_configs WHERE server_id = ?', [serverId]);
  if (!c) { await exec('INSERT IGNORE INTO drive_backup_configs (server_id, interval_minutes, retention) VALUES (?, ?, 1)', [serverId, Number(await getSetting('drive.defaultIntervalMinutes')) || 60]); c = await one('SELECT * FROM drive_backup_configs WHERE server_id = ?', [serverId]); }
  return c;
}

/** One backup run. Never overlaps for the same server (atomic running flag). */
export async function runDriveBackup(serverId: number, trigger: 'scheduled' | 'manual' | 'safety' = 'scheduled') {
  const s = await getServer(serverId); const cfg = await getConfig(serverId);
  const lock = await exec('UPDATE drive_backup_configs SET running = 1, running_since = NOW(), last_attempt_at = NOW(), progress = NULL WHERE server_id = ? AND running = 0', [serverId]);
  if (!lock.affectedRows) throw Object.assign(new HttpError(409, 'A Google Drive backup is already running for this server'), { noRetry: true });
  const name = `oghost-node${s.node_id}-server${s.node_server_id}-${new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19)}.zip`;
  const row = await exec('INSERT INTO drive_backups (server_id, user_id, name, status, trigger_type) VALUES (?, ?, ?, ?, ?)', [serverId, s.owner_id, name, 'uploading', trigger]);
  try {
    const token = await accessToken(s.owner_id);
    const folder = await ensureServerFolder(s.owner_id, serverId, token);
    const node = await getNode(s.node_id);
    const up = await agent(node, 'POST', `/api/servers/${s.node_server_id}/drive/upload`, { accessToken: token, parentId: folder, name, apiBase: config.driveApiBase }, { serverId: s.node_server_id, timeoutMs: 6 * 3600_000 });
    // Independent verification from the panel: the file must exist in Drive with the same size and MD5
    const meta = await dapi(token, 'GET', `/drive/v3/files/${up.fileId}?fields=id,size,md5Checksum,trashed`);
    const verified = !meta.trashed && Number(meta.size) === Number(up.size) && (!meta.md5Checksum || meta.md5Checksum === up.md5);
    if (!verified) throw Object.assign(new Error('Uploaded file failed verification in Google Drive'), { driveKind: 'verify' });
    await exec("UPDATE drive_backups SET file_id = ?, size_bytes = ?, md5 = ?, verified = 1, status = 'completed', completed_at = NOW() WHERE id = ?", [up.fileId, up.size, up.md5, row.insertId]);
    const pruned = await applyRetention(serverId, token, cfg.retention);
    await exec('UPDATE drive_backup_configs SET failures_in_row = 0, last_success_at = NOW(), last_error = NULL, next_run_at = IF(enabled = 1, DATE_ADD(NOW(), INTERVAL interval_minutes MINUTE), NULL) WHERE server_id = ?', [serverId]);
    await serverActivity(null, serverId, 'server.drive_backup.completed', { size: up.size, pruned });
    return { fileId: up.fileId, size: up.size, pruned };
  } catch (e: any) {
    const kind = e.driveKind || (e.status === 507 ? 'space' : /unreachable|timeout/i.test(e.message) ? 'node' : 'error');
    await exec("UPDATE drive_backups SET status = 'failed', error = ?, completed_at = NOW() WHERE id = ?", [`[${kind}] ${String(e.message).slice(0, 1900)}`, row.insertId]);
    const c2: any = await one('SELECT failures_in_row, retry_count, retry_delay_minutes, interval_minutes, enabled FROM drive_backup_configs WHERE server_id = ?', [serverId]);
    const fails = Number(c2.failures_in_row) + 1; const retry = fails <= c2.retry_count && !['revoked', 'not_connected'].includes(kind);
    await exec('UPDATE drive_backup_configs SET failures_in_row = ?, last_error = ?, next_run_at = ? WHERE server_id = ?', [fails, `[${kind}] ${String(e.message).slice(0, 1000)}`, c2.enabled ? new Date(Date.now() + (retry ? c2.retry_delay_minutes : c2.interval_minutes) * 60_000) : null, serverId]);
    // The previous successful backup is intentionally kept.
    if (fails === 1 || !retry) await notify(s.owner_id, 'backup', `Google Drive backup failed for ${s.name}`, `${humanKind(kind)} ${e.message}. Your previous Drive backup was kept.${retry ? ` Retrying in ${c2.retry_delay_minutes} minutes.` : ''}`, { link: `/server/${serverId}/backups`, email: !retry });
    throw Object.assign(e, { noRetry: true });
  } finally {
    await exec('UPDATE drive_backup_configs SET running = 0, running_since = NULL WHERE server_id = ?', [serverId]);
  }
}
const humanKind = (k: string) => ({ quota: 'Your Google Drive is full.', revoked: 'Google Drive access was revoked.', not_connected: 'Google Drive is not connected.', auth: 'Google authentication failed.', permission: 'Google Drive denied permission.', node: 'The game node was unreachable.', space: 'The node has no temporary space to stage the backup.', verify: 'Upload verification failed.' } as Record<string, string>)[k] || 'Backup error:';

/** Delete older verified backups beyond the retention count. Runs only after a new verified upload. */
async function applyRetention(serverId: number, token: string, retention: number) {
  const keep = Math.max(1, retention);
  const list = await q("SELECT id, file_id FROM drive_backups WHERE server_id = ? AND status = 'completed' AND verified = 1 AND trigger_type <> 'safety' ORDER BY completed_at DESC, id DESC", [serverId]);
  let n = 0;
  for (const b of list.slice(keep) as any[]) {
    try { await dapi(token, 'DELETE', `/drive/v3/files/${b.file_id}`); } catch (e: any) { if (e.status !== 404) { console.error('[drive] retention delete failed', e.message); continue; } }
    await exec("UPDATE drive_backups SET status = 'deleted', deleted_at = NOW() WHERE id = ?", [b.id]); n++;
  }
  return n;
}

export async function restoreDriveBackup(serverId: number, backupId: number) {
  const s = await getServer(serverId); const b: any = await one("SELECT * FROM drive_backups WHERE id = ? AND server_id = ? AND status = 'completed'", [backupId, serverId]); if (!b) throw new HttpError(404, 'Drive backup not found');
  if (b.user_id !== s.owner_id) throw new HttpError(403, 'This backup belongs to a different Google account owner');
  const token = await accessToken(s.owner_id); const node = await getNode(s.node_id);
  const safetyUuid = crypto.randomUUID();
  await exec("INSERT INTO backups (uuid, server_id, name, status, is_safety) VALUES (?, ?, ?, 'creating', 1)", [safetyUuid, serverId, `Safety backup before Drive restore #${backupId}`]);
  try {
    const r = await agent(node, 'POST', `/api/servers/${s.node_server_id}/drive/restore`, { accessToken: token, fileId: b.file_id, apiBase: config.driveApiBase, safetyBackupUuid: safetyUuid, truncate: true }, { serverId: s.node_server_id, timeoutMs: 6 * 3600_000 });
    if (r.safety?.uuid) await exec("UPDATE backups SET status = 'completed', size_bytes = ?, sha256 = ?, completed_at = NOW() WHERE uuid = ?", [r.safety.size, r.safety.sha256, safetyUuid]);
    else await exec("UPDATE backups SET status = 'failed', error = ? WHERE uuid = ?", [r.safety?.error || 'not created', safetyUuid]);
    await serverActivity(null, serverId, 'server.drive_backup.restored', { backupId }); return r;
  } catch (e) { await exec("UPDATE backups SET status = 'failed', error = ? WHERE uuid = ? AND status = 'creating'", [String((e as Error).message).slice(0, 500), safetyUuid]); throw e; }
}

export async function disconnectDrive(userId: number) {
  const c: any = await one('SELECT * FROM drive_connections WHERE user_id = ?', [userId]); if (!c) return;
  try { await fetch(`${config.googleOauthBase}/revoke`, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ token: dec(c.refresh_token_enc) }) }); } catch { /* best effort */ }
  await exec('DELETE FROM drive_connections WHERE user_id = ?', [userId]);
  await exec('UPDATE drive_backup_configs SET enabled = 0, next_run_at = NULL, folder_id = NULL WHERE server_id IN (SELECT id FROM servers WHERE owner_id = ?)', [userId]);
}

registerJob('drive.backup', async (p) => runDriveBackup(p.serverId, p.trigger || 'scheduled'));
export async function tickDrive() {
  await exec('UPDATE drive_backup_configs SET running = 0, running_since = NULL WHERE running = 1 AND running_since < DATE_SUB(NOW(), INTERVAL 7 HOUR)');
  const due = await q("SELECT c.server_id FROM drive_backup_configs c JOIN servers s ON s.id = c.server_id JOIN drive_connections d ON d.user_id = s.owner_id AND d.status <> 'revoked' WHERE c.enabled = 1 AND c.running = 0 AND c.next_run_at <= NOW() AND s.state NOT IN ('deleting','transferring','installing') AND s.suspended_at IS NULL LIMIT 50");
  for (const d of due as any[]) { await exec('UPDATE drive_backup_configs SET next_run_at = DATE_ADD(NOW(), INTERVAL interval_minutes MINUTE) WHERE server_id = ?', [d.server_id]); await enqueue('drive.backup', { serverId: d.server_id }, { uniqueKey: `drive:${d.server_id}`, maxAttempts: 1 }); }
}
/** Aggregate statistics for administrators. Deliberately contains no file listings of customers' Drives. */
export async function driveAdminStats() {
  const a: any = await one("SELECT COUNT(*) AS connected, SUM(status = 'error') AS errors, SUM(status = 'revoked') AS revoked FROM drive_connections");
  const b: any = await one("SELECT COUNT(*) AS enabled, SUM(running) AS running, SUM(failures_in_row > 0) AS failing FROM drive_backup_configs WHERE enabled = 1");
  const c: any = await one("SELECT SUM(status = 'completed' AND completed_at > DATE_SUB(NOW(), INTERVAL 1 DAY)) AS ok24, SUM(status = 'failed' AND completed_at > DATE_SUB(NOW(), INTERVAL 1 DAY)) AS failed24, COALESCE(SUM(IF(status = 'completed', size_bytes, 0)),0) AS bytes FROM drive_backups");
  const failures = await q("SELECT b.server_id, b.error, b.completed_at FROM drive_backups b WHERE b.status = 'failed' ORDER BY b.id DESC LIMIT 25");
  return { connections: Number(a.connected) || 0, connectionErrors: Number(a.errors) || 0, revoked: Number(a.revoked) || 0, serversEnabled: Number(b.enabled) || 0, running: Number(b.running) || 0, failing: Number(b.failing) || 0, completed24h: Number(c.ok24) || 0, failed24h: Number(c.failed24) || 0, storedBytes: Number(c.bytes) || 0, recentFailures: failures };
}
void json;
