import { signToken } from '@oghost/shared';
import { config } from './config';

const queue: Array<{ type: string; serverId: number | null; data: any; at: number }> = [];
let flushing = false;

export async function panelFetch(pathname: string, body: unknown) {
  const token = signToken({ aud: 'panel', nodeId: config.nodeId }, config.secret, 60);
  const r = await fetch(`${config.panelUrl}${pathname}`, { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` }, body: JSON.stringify(body) });
  if (!r.ok) throw new Error(`Panel ${pathname} -> ${r.status} ${await r.text().catch(() => '')}`);
  return r.json().catch(() => ({}));
}
/** Queue an event for the panel (crash, security, state changes). Retries until delivered. */
export function report(type: string, serverId: number | null, data: any) { queue.push({ type, serverId, data, at: Date.now() }); if (queue.length > 5000) queue.shift(); void flush(); }
async function flush() {
  if (flushing || !queue.length) return; flushing = true;
  try { while (queue.length) { const batch = queue.slice(0, 100); await panelFetch('/api/remote/events', { events: batch }); queue.splice(0, batch.length); } }
  catch { setTimeout(() => { flushing = false; void flush(); }, 10_000); return; }
  flushing = false;
}
