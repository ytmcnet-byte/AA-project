import { useEffect, useState, type ReactNode } from 'react';
import { X, Loader2, CheckCircle2, AlertTriangle, Info } from 'lucide-react';
import { cls } from '../lib/format';

export function Logo({ size = 32, withText = true }: { size?: number; withText?: boolean }) {
  return (
    <div className="flex items-center gap-2.5">
      <svg width={size} height={size} viewBox="0 0 64 64" aria-hidden><rect width="64" height="64" rx="14" fill="#140708" /><path d="M32 8c-11 0-19 8.5-19 19.5V54l6.5-5 6.5 5 6-5 6 5 6.5-5 6.5 5V27.5C51 16.5 43 8 32 8z" fill="#dc2626" /><circle cx="25" cy="28" r="4.5" fill="#0a0a0b" /><circle cx="39" cy="28" r="4.5" fill="#0a0a0b" /></svg>
      {withText && <div className="leading-none"><div className="text-[15px] font-extrabold tracking-wider text-white">OGHOST <span className="text-brand-500">PANEL</span></div></div>}
    </div>
  );
}
export const Spinner = ({ className = '' }: { className?: string }) => <Loader2 className={cls('h-4 w-4 animate-spin', className)} />;
export function Loading({ label = 'Loading…' }: { label?: string }) { return <div className="flex items-center justify-center gap-2 py-16 text-sm text-ink-400"><Spinner /> {label}</div>; }
export function ErrorBox({ error, onRetry }: { error: string; onRetry?: () => void }) {
  return <div className="flex items-start gap-3 rounded-lg border border-red-900/60 bg-red-950/40 p-3 text-sm text-red-200"><AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" /><div className="flex-1">{error}</div>{onRetry && <button className="btn-secondary btn-sm" onClick={onRetry}>Retry</button>}</div>;
}
export function Notice({ kind = 'info', children, className = '' }: { kind?: 'info' | 'warn' | 'error' | 'success'; children: ReactNode; className?: string }) {
  const s = { info: 'border-sky-900/60 bg-sky-950/30 text-sky-200', warn: 'border-amber-900/60 bg-amber-950/30 text-amber-200', error: 'border-red-900/60 bg-red-950/40 text-red-200', success: 'border-emerald-900/60 bg-emerald-950/30 text-emerald-200' }[kind];
  const I = { info: Info, warn: AlertTriangle, error: AlertTriangle, success: CheckCircle2 }[kind];
  return <div className={cls('flex items-start gap-2.5 rounded-lg border p-3 text-sm', s, className)}><I className="mt-0.5 h-4 w-4 shrink-0" /><div className="flex-1 min-w-0">{children}</div></div>;
}
export function Empty({ title, children, icon }: { title: string; children?: ReactNode; icon?: ReactNode }) {
  return <div className="flex flex-col items-center justify-center gap-2 px-4 py-14 text-center"><div className="text-ink-400">{icon}</div><div className="font-semibold text-zinc-200">{title}</div>{children && <div className="max-w-md text-sm text-ink-400">{children}</div>}</div>;
}
export function PageHeader({ title, subtitle, actions }: { title: ReactNode; subtitle?: ReactNode; actions?: ReactNode }) {
  return <div className="mb-5 flex flex-wrap items-end justify-between gap-3"><div className="min-w-0"><h1 className="truncate text-xl font-bold text-white sm:text-2xl">{title}</h1>{subtitle && <div className="mt-1 text-sm text-ink-400">{subtitle}</div>}</div>{actions && <div className="flex flex-wrap items-center gap-2">{actions}</div>}</div>;
}
export function Card({ title, actions, children, className = '', pad = true }: { title?: ReactNode; actions?: ReactNode; children: ReactNode; className?: string; pad?: boolean }) {
  return <section className={cls('card', className)}>{(title || actions) && <div className="flex flex-wrap items-center justify-between gap-2 border-b border-ink-700 px-4 py-3 sm:px-5"><h2 className="text-sm font-bold uppercase tracking-wide text-zinc-100">{title}</h2>{actions && <div className="flex flex-wrap items-center gap-2">{actions}</div>}</div>}<div className={pad ? 'card-pad' : ''}>{children}</div></section>;
}
const STATE_STYLES: Record<string, string> = {
  running: 'border-emerald-800 bg-emerald-950/60 text-emerald-300', online: 'border-emerald-800 bg-emerald-950/60 text-emerald-300', safe: 'border-emerald-800 bg-emerald-950/60 text-emerald-300', completed: 'border-emerald-800 bg-emerald-950/60 text-emerald-300', paid: 'border-emerald-800 bg-emerald-950/60 text-emerald-300', active: 'border-emerald-800 bg-emerald-950/60 text-emerald-300', done: 'border-emerald-800 bg-emerald-950/60 text-emerald-300', success: 'border-emerald-800 bg-emerald-950/60 text-emerald-300', reachable: 'border-emerald-800 bg-emerald-950/60 text-emerald-300', open: 'border-sky-800 bg-sky-950/60 text-sky-300', approved: 'border-emerald-800 bg-emerald-950/60 text-emerald-300', resolved: 'border-emerald-800 bg-emerald-950/60 text-emerald-300', accepted: 'border-emerald-800 bg-emerald-950/60 text-emerald-300',
  starting: 'border-amber-800 bg-amber-950/60 text-amber-300', stopping: 'border-amber-800 bg-amber-950/60 text-amber-300', installing: 'border-amber-800 bg-amber-950/60 text-amber-300', pending: 'border-amber-800 bg-amber-950/60 text-amber-300', creating: 'border-amber-800 bg-amber-950/60 text-amber-300', running_job: 'border-amber-800 bg-amber-950/60 text-amber-300', queued: 'border-amber-800 bg-amber-950/60 text-amber-300', suspicious: 'border-amber-800 bg-amber-950/60 text-amber-300', unpaid: 'border-amber-800 bg-amber-950/60 text-amber-300', awaiting_approval: 'border-amber-800 bg-amber-950/60 text-amber-300', transferring: 'border-amber-800 bg-amber-950/60 text-amber-300', restoring: 'border-amber-800 bg-amber-950/60 text-amber-300', uploading: 'border-amber-800 bg-amber-950/60 text-amber-300', maintenance: 'border-amber-800 bg-amber-950/60 text-amber-300', answered: 'border-sky-800 bg-sky-950/60 text-sky-300', customer_reply: 'border-amber-800 bg-amber-950/60 text-amber-300',
  offline: 'border-ink-600 bg-ink-800 text-ink-300', unknown: 'border-ink-600 bg-ink-800 text-ink-300', unscanned: 'border-ink-600 bg-ink-800 text-ink-300', closed: 'border-ink-600 bg-ink-800 text-ink-300', cancelled: 'border-ink-600 bg-ink-800 text-ink-300', none: 'border-ink-600 bg-ink-800 text-ink-300', expired: 'border-ink-600 bg-ink-800 text-ink-300', refunded: 'border-ink-600 bg-ink-800 text-ink-300',
  crashed: 'border-red-800 bg-red-950/60 text-red-300', failed: 'border-red-800 bg-red-950/60 text-red-300', install_failed: 'border-red-800 bg-red-950/60 text-red-300', high_risk: 'border-red-800 bg-red-950/60 text-red-300', suspended: 'border-red-800 bg-red-950/60 text-red-300', deleting: 'border-red-800 bg-red-950/60 text-red-300', rejected: 'border-red-800 bg-red-950/60 text-red-300', blocked: 'border-red-800 bg-red-950/60 text-red-300', critical: 'border-red-800 bg-red-950/60 text-red-300', high: 'border-red-800 bg-red-950/60 text-red-300', overdue: 'border-red-800 bg-red-950/60 text-red-300', unreachable: 'border-red-800 bg-red-950/60 text-red-300', medium: 'border-amber-800 bg-amber-950/60 text-amber-300', low: 'border-sky-800 bg-sky-950/60 text-sky-300',
};
export function Badge({ value, label, className = '' }: { value: string | null | undefined; label?: string; className?: string }) {
  const v = String(value ?? 'unknown');
  return <span className={cls('badge', STATE_STYLES[v] || 'border-ink-600 bg-ink-800 text-ink-300', className)}>{v === 'running' || v === 'online' ? <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" /> : null}{label ?? v.replace(/_/g, ' ')}</span>;
}
export function Modal({ open, onClose, title, children, footer, wide = false }: { open: boolean; onClose: () => void; title: ReactNode; children: ReactNode; footer?: ReactNode; wide?: boolean }) {
  useEffect(() => { if (!open) return; const h = (e: KeyboardEvent) => e.key === 'Escape' && onClose(); window.addEventListener('keydown', h); return () => window.removeEventListener('keydown', h); }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/70 p-0 backdrop-blur-sm sm:items-center sm:p-4" onMouseDown={e => e.target === e.currentTarget && onClose()}>
      <div className={cls('card flex max-h-[92vh] w-full flex-col rounded-b-none sm:rounded-xl', wide ? 'sm:max-w-4xl' : 'sm:max-w-lg')} role="dialog" aria-modal>
        <div className="flex items-center justify-between border-b border-ink-700 px-5 py-3.5"><h3 className="font-bold text-white">{title}</h3><button className="btn-ghost btn-sm" onClick={onClose} aria-label="Close"><X className="h-4 w-4" /></button></div>
        <div className="overflow-y-auto px-5 py-4">{children}</div>
        {footer && <div className="flex flex-wrap justify-end gap-2 border-t border-ink-700 px-5 py-3">{footer}</div>}
      </div>
    </div>
  );
}
/** Confirmation dialog; optional typed confirmation phrase for destructive actions. */
export function Confirm({ open, onClose, onConfirm, title, children, confirmLabel = 'Confirm', danger = false, phrase, busy }: { open: boolean; onClose: () => void; onConfirm: () => void; title: string; children?: ReactNode; confirmLabel?: string; danger?: boolean; phrase?: string; busy?: boolean }) {
  const [typed, setTyped] = useState('');
  useEffect(() => { if (open) setTyped(''); }, [open]);
  return (
    <Modal open={open} onClose={onClose} title={title} footer={<><button className="btn-secondary" onClick={onClose}>Cancel</button><button className={danger ? 'btn-danger' : 'btn-primary'} disabled={busy || (!!phrase && typed !== phrase)} onClick={onConfirm}>{busy && <Spinner />}{confirmLabel}</button></>}>
      <div className="space-y-3 text-sm text-ink-300">{children}{phrase && <div><label className="label">Type <code className="rounded bg-ink-800 px-1.5 py-0.5 text-brand-400">{phrase}</code> to confirm</label><input className="input font-mono" value={typed} onChange={e => setTyped(e.target.value)} autoFocus /></div>}</div>
    </Modal>
  );
}
export function Field({ label, hint, children, className = '' }: { label: ReactNode; hint?: ReactNode; children: ReactNode; className?: string }) {
  return <div className={className}><label className="label">{label}</label>{children}{hint && <div className="hint">{hint}</div>}</div>;
}
export function Switch({ checked, onChange, label, disabled }: { checked: boolean; onChange: (v: boolean) => void; label?: ReactNode; disabled?: boolean }) {
  return <label className={cls('inline-flex cursor-pointer items-center gap-2.5 text-sm', disabled && 'opacity-50')}><button type="button" role="switch" aria-checked={checked} disabled={disabled} onClick={() => onChange(!checked)} className={cls('relative h-5 w-9 rounded-full transition', checked ? 'bg-brand-600' : 'bg-ink-600')}><span className={cls('absolute top-0.5 h-4 w-4 rounded-full bg-white transition', checked ? 'left-[18px]' : 'left-0.5')} /></button>{label}</label>;
}
export function Bar({ value, max, className = '' }: { value: number; max: number; className?: string }) {
  const p = max > 0 ? Math.min(100, (value / max) * 100) : 0;
  return <div className={cls('h-1.5 w-full overflow-hidden rounded-full bg-ink-700', className)}><div className={cls('h-full rounded-full transition-all', p > 90 ? 'bg-red-500' : p > 70 ? 'bg-amber-500' : 'bg-brand-600')} style={{ width: `${p}%` }} /></div>;
}
export function Tabs<T extends string>({ value, onChange, tabs }: { value: T; onChange: (v: T) => void; tabs: Array<{ id: T; label: ReactNode }> }) {
  return <div className="mb-4 flex gap-1 overflow-x-auto overflow-y-hidden shadow-[inset_0_-1px_0_#222228]">{tabs.map(t => <button key={t.id} onClick={() => onChange(t.id)} className={cls('whitespace-nowrap border-b-2 px-3 py-2 text-sm font-semibold transition', value === t.id ? 'border-brand-500 text-white' : 'border-transparent text-ink-400 hover:text-zinc-200')}>{t.label}</button>)}</div>;
}
export function Stat({ label, value, sub, icon }: { label: string; value: ReactNode; sub?: ReactNode; icon?: ReactNode }) {
  return <div className="card card-pad"><div className="flex items-center justify-between text-xs font-semibold uppercase tracking-wide text-ink-400">{label}<span className="text-brand-500">{icon}</span></div><div className="mt-2 text-2xl font-bold text-white">{value}</div>{sub && <div className="mt-1 text-xs text-ink-400">{sub}</div>}</div>;
}
export function Toaster() {
  const [items, setItems] = useState<Array<{ id: number; message: string; kind: string }>>([]);
  useEffect(() => {
    let n = 0;
    const h = (e: Event) => { const d = (e as CustomEvent).detail; const id = ++n + Date.now(); setItems(x => [...x.slice(-4), { id, ...d }]); setTimeout(() => setItems(x => x.filter(i => i.id !== id)), d.kind === 'error' ? 7000 : 4000); };
    window.addEventListener('oghost:toast', h); return () => window.removeEventListener('oghost:toast', h);
  }, []);
  return <div className="pointer-events-none fixed bottom-4 right-4 z-[60] flex w-[min(92vw,380px)] flex-col gap-2">{items.map(t => <div key={t.id} className={cls('pointer-events-auto rounded-lg border px-4 py-3 text-sm shadow-2xl', t.kind === 'error' ? 'border-red-800 bg-red-950 text-red-100' : t.kind === 'success' ? 'border-emerald-800 bg-emerald-950 text-emerald-100' : 'border-ink-600 bg-ink-800 text-zinc-100')}>{t.message}</div>)}</div>;
}
export function Pager({ page, setPage, hasMore }: { page: number; setPage: (p: number) => void; hasMore: boolean }) {
  return <div className="flex items-center justify-end gap-2 pt-3 text-sm"><button className="btn-secondary btn-sm" disabled={page <= 1} onClick={() => setPage(page - 1)}>Previous</button><span className="text-ink-400">Page {page}</span><button className="btn-secondary btn-sm" disabled={!hasMore} onClick={() => setPage(page + 1)}>Next</button></div>;
}
export function Table({ children }: { children: ReactNode }) { return <div className="-mx-4 overflow-x-auto sm:-mx-5"><table className="table min-w-full">{children}</table></div>; }
