'use strict';

const Groq = require('groq-sdk');

const groq = new Groq({ apiKey: process.env.GROQ_API_KEY });

const SYSTEM_PROMPT = `Tu ek expert Minecraft player hai jiska naam .SHIVAM_BRO2234 hai.
Tu ek real player ki tarah behave karta hai — mine karta hai, craft karta hai, build karta hai, explore karta hai, survive karta hai.

RULES:
1. Tu hamesha JSON format mein respond karega, aur kuch nahi.
2. Response format:
{
  "thought": "Tu kya soch raha hai (1 line, Hinglish mein)",
  "chat": "Jo server chat mein bolna hai (optional, null if nothing)",
  "action": "mine | craft | build | explore | eat | sleep | follow | idle | attack",
  "target": "action ka target (block name, item name, ya null)",
  "priority": "high | medium | low"
}

SURVIVAL PRIORITIES (highest to lowest):
- Health < 5: eat/flee immediately
- Hunger < 6: find food and eat
- Night time (no shelter/bed): find shelter or sleep
- No tools: craft wooden/stone tools
- Inventory full: dump junk, keep valuables
- Otherwise: mine valuable ores, expand base, explore

MINING priorities: diamond > iron > coal > stone
CRAFTING priorities: sword > pickaxe > axe > shovel > food items
BUILDING: simple shelters, chests, furnaces

Chat mein kabhi kabhi chhoti Hinglish baatein karo jaise ek player karta hai.
Example chat: "bhai kya scene hai", "diamond mil gaya!", "yaar kuch nahi mil raha", "chalte hain explore karte hain"
`;

class Brain {
  constructor(config) {
    this.config = config;
    this.history = [];
    this.currentAction = null;
    this.lastDecision = null;
  }

  buildContext(bot) {
    const pos = bot.entity.position;
    const health = bot.health;
    const food = bot.food;
    const time = bot.time.timeOfDay;
    const isNight = time > 13000 && time < 23000;

    // Inventory summary
    const inventory = {};
    bot.inventory.items().forEach(item => {
      inventory[item.name] = (inventory[item.name] || 0) + item.count;
    });

    // Nearby blocks (simple check)
    const nearbyBlocks = [];
    const blockTypes = ['diamond_ore', 'iron_ore', 'coal_ore', 'gold_ore', 'emerald_ore', 'ancient_debris', 'oak_log', 'gravel', 'grass_block', 'stone'];
    for (const blockName of blockTypes) {
      const block = bot.findBlock({
        matching: bot.registry.blocksByName[blockName]?.id,
        maxDistance: 16,
        count: 1,
      });
      if (block) nearbyBlocks.push(blockName);
    }

    // Nearby entities
    const nearbyEntities = Object.values(bot.entities)
      .filter(e => e !== bot.entity && e.position.distanceTo(pos) < 16)
      .map(e => e.name || e.username || 'unknown')
      .slice(0, 5);

    // Held item
    const heldItem = bot.heldItem ? bot.heldItem.name : 'nothing';

    return {
      position: { x: Math.floor(pos.x), y: Math.floor(pos.y), z: Math.floor(pos.z) },
      health: Math.floor(health),
      food: Math.floor(food),
      isNight,
      inventory,
      nearbyBlocks,
      nearbyEntities,
      heldItem,
      currentAction: this.currentAction,
    };
  }

  async decide(bot) {
    const context = this.buildContext(bot);
    const contextStr = JSON.stringify(context, null, 2);

    const userMessage = `Meri current situation:\n${contextStr}\n\nAb kya karna chahiye?`;

    this.history.push({ role: 'user', content: userMessage });
    if (this.history.length > 10) this.history = this.history.slice(-10);

    try {
      const completion = await groq.chat.completions.create({
        model: this.config.ai.model,
        messages: [
          { role: 'system', content: SYSTEM_PROMPT },
          ...this.history,
        ],
        max_tokens: this.config.ai.maxTokens,
        temperature: 0.7,
        response_format: { type: 'json_object' },
      });

      const responseText = completion.choices[0].message.content;
      const decision = JSON.parse(responseText);
      this.history.push({ role: 'assistant', content: responseText });
      this.lastDecision = decision;
      return decision;
    } catch (err) {
      console.error('[Brain] Groq error:', err.message);
      return { thought: 'Kuch galat hua, idle ho raha hun', chat: null, action: 'idle', target: null, priority: 'low' };
    }
  }

  async processCommand(bot, command, sender) {
    const prompt = `${sender} ne command diya: "${command}"\n\nMeri current situation:\n${JSON.stringify(this.buildContext(bot), null, 2)}\n\nIs command ko follow karo. JSON mein response do.`;

    try {
      const completion = await groq.chat.completions.create({
        model: this.config.ai.model,
        messages: [
          { role: 'system', content: SYSTEM_PROMPT },
          { role: 'user', content: prompt },
        ],
        max_tokens: this.config.ai.maxTokens,
        temperature: 0.5,
        response_format: { type: 'json_object' },
      });

      const responseText = completion.choices[0].message.content;
      return JSON.parse(responseText);
    } catch (err) {
      console.error('[Brain] Command processing error:', err.message);
      return { thought: 'Command samajh nahi aaya', chat: `${sender} bhai, samajh nahi aaya`, action: 'idle', target: null, priority: 'medium' };
    }
  }
}

module.exports = Brain;
