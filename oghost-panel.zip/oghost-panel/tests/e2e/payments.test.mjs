// Payments are marked paid only by verified, server-to-server gateway webhooks — never by a browser redirect.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { skip, admin, db, PANEL } from './common.mjs';
const RZP = 'e2e-razorpay-whsec-' + crypto.randomBytes(4).toString('hex');
const STRIPE = 'whsec_e2e_' + crypto.randomBytes(4).toString('hex');
const post = (path, body, headers) => fetch(PANEL + path, { method: 'POST', headers: { 'content-type': 'application/json', ...headers }, body });

test('Razorpay webhook: signature, amount and replay protection', { skip }, async () => {
  const c = await admin(); const conn = await db();
  try {
    await c.put('/api/admin/settings', { 'razorpay.webhookSecret': RZP });
    const inv = await c.post('/api/admin/invoices', { userId: 1, items: [{ description: 'e2e webhook test', amount_cents: 49900 }], currency: 'INR' });
    const orderId = 'order_e2e_' + crypto.randomBytes(5).toString('hex');
    const [pr] = await conn.query("INSERT INTO payments (invoice_id, user_id, gateway, gateway_order_id, amount_cents, currency, status) VALUES (?, 1, 'razorpay', ?, 49900, 'INR', 'pending')", [inv.id, orderId]);
    const status = async () => (await conn.query('SELECT status FROM invoices WHERE id = ?', [inv.id]))[0][0].status;
    const ev = (amount, id) => JSON.stringify({ event: 'payment.captured', payload: { payment: { entity: { id, order_id: orderId, amount, currency: 'INR' } } } });
    const sign = (b) => crypto.createHmac('sha256', RZP).update(b).digest('hex');

    let b = ev(49900, 'pay_forged_' + orderId);
    assert.equal((await post('/api/webhooks/razorpay', b, { 'x-razorpay-signature': 'deadbeef', 'x-razorpay-event-id': 'evt_bad' })).status, 400, 'bad signature rejected');
    assert.equal(await status(), 'unpaid');
    b = ev(100, 'pay_cheap_' + orderId);
    assert.equal((await post('/api/webhooks/razorpay', b, { 'x-razorpay-signature': sign(b), 'x-razorpay-event-id': 'evt_cheap_' + orderId })).status, 200);
    assert.equal(await status(), 'unpaid', 'amount mismatch does not pay the invoice');
    b = ev(49900, 'pay_ok_' + orderId);
    const evId = 'evt_ok_' + orderId;
    const okr = await post('/api/webhooks/razorpay', b, { 'x-razorpay-signature': sign(b), 'x-razorpay-event-id': evId });
    assert.equal(okr.status, 200, await okr.clone().text());
    assert.equal(await status(), 'paid');
    const [[p]] = await conn.query('SELECT status, gateway_payment_id FROM payments WHERE id = ?', [pr.insertId]);
    assert.equal(p.status, 'succeeded'); assert.equal(p.gateway_payment_id, 'pay_ok_' + orderId);
    assert.equal((await post('/api/webhooks/razorpay', b, { 'x-razorpay-signature': sign(b), 'x-razorpay-event-id': evId })).status, 200, 'replay accepted idempotently');
    const [[n]] = await conn.query("SELECT COUNT(*) AS n FROM webhook_events WHERE gateway = 'razorpay' AND event_id = ?", [evId]);
    assert.equal(Number(n.n), 1, 'event recorded once');
  } finally { await conn.end(); }
});

test('Stripe webhook: stale timestamps and bad signatures are rejected', { skip }, async () => {
  const c = await admin(); await c.put('/api/admin/settings', { 'stripe.webhookSecret': STRIPE });
  const body = JSON.stringify({ id: 'evt_e2e_' + Date.now(), type: 'checkout.session.completed', data: { object: { id: 'cs_unknown', payment_status: 'paid', amount_total: 1 } } });
  const sig = (t) => `t=${t},v1=${crypto.createHmac('sha256', STRIPE).update(`${t}.${body}`).digest('hex')}`;
  const now = Math.floor(Date.now() / 1000);
  assert.equal((await post('/api/webhooks/stripe', body, { 'stripe-signature': sig(now - 3600) })).status, 400, 'stale');
  assert.equal((await post('/api/webhooks/stripe', body, { 'stripe-signature': `t=${now},v1=00` })).status, 400, 'bad signature');
  assert.equal((await post('/api/webhooks/stripe', body, { 'stripe-signature': sig(now) })).status, 200, 'valid signature accepted (unknown session ignored)');
});
