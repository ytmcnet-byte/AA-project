import type { Request, Response } from 'express';
import { Readable } from 'node:stream';
import { signToken, decryptSecret } from '@oghost/shared';
import { one } from '../db';
import { config } from '../config';
import { HttpError } from '../lib/http';

export interface NodeRow { id: number; name: string; fqdn: string; scheme: string; port: number; public_ip: string; secret_enc: string; maintenance: number; emergency: number; status: string; memory_mb: number; disk_mb: number; memory_overalloc: number; disk_overalloc: number; cpu_percent: number; max_servers: number; location_id: number; heartbeat: any; arch: string | null; last_heartbeat_at: Date | null; }

export async function getNode(id: number): Promise<NodeRow> { const n = await one<NodeRow>('SELECT * FROM nodes WHERE id = ?', [id]); if (!n) throw new HttpError(404, 'Node not found'); return n; }
export const nodeSecret = (n: NodeRow) => decryptSecret(n.secret_enc, config.appKey);
export const agentUrl = (n: NodeRow) => `${n.scheme}://${n.fqdn}:${n.port}`;
export const nodeToken = (n: NodeRow, extra: Record<string, unknown> = {}, ttl = 60) => signToken({ aud: 'node', nodeId: n.id, ...extra }, nodeSecret(n), ttl);

/** JSON call to a node agent with a short-lived signed token. */
export async function agent<T = any>(n: NodeRow, method: string, path: string, body?: unknown, opts: { serverId?: number; timeoutMs?: number; raw?: boolean } = {}): Promise<T> {
  const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), opts.timeoutMs ?? 30_000);
  try {
    const r = await fetch(`${agentUrl(n)}${path}`, { method, signal: ctl.signal, headers: { Authorization: `Bearer ${nodeToken(n, opts.serverId ? { serverId: opts.serverId } : {})}`, ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}) }, body: body !== undefined ? JSON.stringify(body) : undefined });
    const text = await r.text(); let data: any = text; try { data = JSON.parse(text); } catch { /* text */ }
    if (!r.ok) throw Object.assign(new HttpError(r.status === 401 ? 502 : r.status, `Node ${n.name}: ${data?.error || text || r.statusText}`, data?.driveKind ? { driveKind: data.driveKind } : {}), { fromNode: true, driveKind: data?.driveKind });
    return (opts.raw ? text : data) as T;
  } catch (e: any) {
    if (e instanceof HttpError) throw e;
    throw Object.assign(new HttpError(502, `Node ${n.name} is unreachable (${e.name === 'AbortError' ? 'timeout' : e.cause?.code || e.message})`), { fromNode: true });
  } finally { clearTimeout(t); }
}

/** Stream proxy: pipes request body to the agent and the agent response back to the client (uploads/downloads). */
export async function agentStream(n: NodeRow, req: Request, res: Response, method: string, path: string, serverId: number, extraHeaders: Record<string, string> = {}) {
  const headers: Record<string, string> = { Authorization: `Bearer ${nodeToken(n, { serverId }, 300)}`, ...extraHeaders };
  if (req.headers['content-length']) headers['Content-Length'] = String(req.headers['content-length']);
  if (req.headers['x-file-size']) headers['X-File-Size'] = String(req.headers['x-file-size']);
  if (req.headers['content-type']) headers['Content-Type'] = String(req.headers['content-type']);
  let r: globalThis.Response;
  try { r = await fetch(`${agentUrl(n)}${path}`, { method, headers, body: method === 'GET' ? undefined : (req as any), duplex: 'half' } as any); }
  catch (e: any) { throw new HttpError(502, `Node ${n.name} is unreachable (${e.cause?.code || e.message})`); }
  res.status(r.status);
  for (const h of ['content-type', 'content-length', 'content-disposition', 'x-md5']) { const v = r.headers.get(h); if (v) res.setHeader(h, v); }
  if (!r.body) return res.end();
  Readable.fromWeb(r.body as any).pipe(res);
}

/** Pipe one agent's download stream into another agent's upload endpoint (server transfer / clone). */
export async function agentPipe(src: NodeRow, srcPath: string, srcServer: number, dst: NodeRow, dstPath: string, dstServer: number) {
  const a = await fetch(`${agentUrl(src)}${srcPath}`, { headers: { Authorization: `Bearer ${nodeToken(src, { serverId: srcServer }, 3600)}` } });
  if (!a.ok || !a.body) throw new HttpError(502, `Source node error: ${await a.text()}`);
  const b = await fetch(`${agentUrl(dst)}${dstPath}`, { method: 'PUT', headers: { Authorization: `Bearer ${nodeToken(dst, { serverId: dstServer }, 3600)}`, 'Content-Length': a.headers.get('content-length') || '', 'X-File-Size': a.headers.get('content-length') || '' }, body: a.body as any, duplex: 'half' } as any);
  const t = await b.text(); if (!b.ok) throw new HttpError(502, `Target node error: ${t}`);
  return JSON.parse(t);
}
export const wsToken = (n: NodeRow, serverId: number, perms: string[]) => signToken({ aud: 'node-ws', nodeId: n.id, serverId, perms }, nodeSecret(n), 120);
