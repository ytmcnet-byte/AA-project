import { Router } from 'express';
import { HttpError } from '../../lib/http';
import { requireAuth, isAdmin } from '../../lib/auth';
import { coreAdmin } from './core';
import { infraAdmin } from './infra';
import { commerceAdmin } from './commerce';
import { systemAdmin } from './system';
import { extensionsAdmin } from './extensions';
import { coinsAdmin } from './coins';

export const adminRouter = Router();
adminRouter.use(requireAuth, (req, _res, next) => (isAdmin(req.user) ? next() : next(new HttpError(403, 'Administrator access required'))));
adminRouter.use(coreAdmin, infraAdmin, commerceAdmin, systemAdmin, extensionsAdmin, coinsAdmin);
