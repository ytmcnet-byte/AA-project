import { Router, type Request, type Response, type NextFunction } from 'express';
import express from 'express';
import { verifyToken, decryptSecret } from '@oghost/shared';
import { q, one, exec, json, parse } from '../db';
import { config } from '../config';
import { HttpError } from '../lib/http';
import { toNodeServer, syncSpec } from '../services/servers';
import { handleScanEvent, handleRuntimeEvent, trustedHashes } from '../services/security';
import { notify, notifyAdmins } from '../services/notify';
import { serverActivity } from '../services/audit';
import { emitServer } from '../realtime';

/** Endpoints called by node agents. Authenticated with short-lived tokens signed by the node's own secret (aud "panel"). */
export const remoteRouter = Router();
remoteRouter.use(express.json({ limit: '5mb' }));
async function nodeAuth(req: Request, _res: Response, next: NextFunction) {
  try {
    const tok = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    const claimed = JSON.parse(Buffer.from(tok.split('.')[1] || '', 'base64url').toString() || '{}');
    const node: any = await one('SELECT * FROM nodes WHERE id = ?', [Number(claimed.nodeId)]); if (!node) throw new Error('unknown node');
    const p = verifyToken<{ aud: string; nodeId: number }>(tok, decryptSecret(node.secret_enc, config.appKey));
    if (p.aud !== 'panel' || p.nodeId !== node.id) throw new Error('bad audience');
    (req as any).node = node; next();
  } catch (e: any) { next(new HttpError(401, `Node authentication failed: ${e.message}`)); }
}
remoteRouter.use(nodeAuth);

const PRESERVE = new Set(['deleting', 'transferring']);
remoteRouter.post('/heartbeat', async (req, res) => {
  const node = (req as any).node; const hb = req.body;
  const wasOffline = node.status !== 'online';
  await exec("UPDATE nodes SET status = 'online', last_heartbeat_at = NOW(), heartbeat = ?, arch = ? WHERE id = ?", [json(hb), String(hb.arch || '').slice(0, 16), node.id]);
  await exec('INSERT INTO node_stats (node_id, cpu, mem_used, mem_total, disk_used, disk_total, rx, tx) VALUES (?,?,?,?,?,?,?,?)', [node.id, Number(hb.cpu?.usagePercent) || 0, (hb.memory?.total || 0) - (hb.memory?.free || 0), hb.memory?.total || 0, (hb.disk?.total || 0) - (hb.disk?.free || 0), hb.disk?.total || 0, hb.network?.rxBytes || 0, hb.network?.txBytes || 0]);
  const known = await q('SELECT id, node_server_id, state FROM servers WHERE node_id = ?', [node.id]); const byNid = new Map(known.map((s: any) => [s.node_server_id, s]));
  const reported = new Set<number>(); const missing: number[] = [];
  for (const s of hb.servers || []) {
    const row: any = byNid.get(Number(s.id)); reported.add(Number(s.id)); if (!row) continue;
    if (!PRESERVE.has(row.state) && row.state !== s.state) await exec('UPDATE servers SET state = ? WHERE id = ?', [s.state, row.id]);
    await exec('INSERT INTO server_stats (server_id, cpu, memory, disk) VALUES (?, ?, ?, ?)', [row.id, Number(s.cpu) || 0, Number(s.memory) || 0, Number(s.diskBytes) || 0]);
  }
  // Servers the panel knows but the node does not (e.g. agent metadata lost): push the spec again.
  for (const s of known as any[]) if (!reported.has(s.node_server_id) && !PRESERVE.has(s.state)) missing.push(s.id);
  for (const id of missing.slice(0, 20)) await syncSpec(id).catch(() => {});
  if (hb.runningAsRoot) await notifyDedup(`root:${node.id}`, () => notifyAdmins('admin.nodes', 'security', `Node ${node.name} agent is running as root`, 'Game servers must not run as root. Restart the agent as an unprivileged user.'));
  if (wasOffline) await notifyAdmins('admin.nodes', 'node_offline', `Node ${node.name} is online`, `Heartbeat received (agent ${hb.version}, ${hb.arch}).`).catch(() => {});
  res.json({ ok: true, trusted: await trustedHashes() });
});

const dedup = new Map<string, number>();
async function notifyDedup(key: string, fn: () => Promise<unknown>, ms = 24 * 3600_000) { const t = dedup.get(key) || 0; if (Date.now() - t < ms) return; dedup.set(key, Date.now()); await fn().catch(() => {}); }

remoteRouter.post('/events', async (req, res) => {
  const node = (req as any).node; const events: any[] = Array.isArray(req.body.events) ? req.body.events : [];
  for (const ev of events) {
    try {
      const s = ev.serverId != null ? await toNodeServer(node.id, Number(ev.serverId)) : null;
      if (ev.serverId != null && !s) continue; // server deleted meanwhile
      const d = ev.data || {};
      switch (ev.type) {
        case 'state': if (s && !PRESERVE.has(s.state)) { await exec('UPDATE servers SET state = ? WHERE id = ?', [d.state, s.id]); emitServer(s.id, 'state', d.state); } break;
        case 'installed': {
          const vars = { ...parse<Record<string, string>>(s!.variables, {}), ...(d.variables || {}) };
          await exec("UPDATE servers SET state = IF(state IN ('deleting','transferring'), state, 'offline'), status_detail = NULL, installed_version = COALESCE(?, installed_version), installed_build = COALESCE(?, installed_build), installed_at = NOW(), variables = ? WHERE id = ?", [d.resolvedVersion ?? null, d.resolvedBuild ?? null, json(vars), s!.id]);
          if (d.variables) await syncSpec(s!.id).catch(() => {});
          await serverActivity(null, s!.id, d.reinstall ? 'server.reinstalled' : 'server.installed', { version: d.resolvedVersion, build: d.resolvedBuild });
          await notify(s!.owner_id, 'system', `${s!.name} is ready`, `Installation finished${d.resolvedVersion ? ` (version ${d.resolvedVersion})` : ''}.`, { link: `/server/${s!.id}` });
          break;
        }
        case 'install_failed': await exec("UPDATE servers SET state = 'install_failed', status_detail = ? WHERE id = ?", [String(d.error).slice(0, 250), s!.id]); await notify(s!.owner_id, 'system', `Installation failed for ${s!.name}`, String(d.error), { link: `/server/${s!.id}`, email: true }); break;
        case 'crash': await serverActivity(null, s!.id, 'server.crashed', d); await notifyDedup(`crash:${s!.id}`, () => notify(s!.owner_id, 'server_crash', `${s!.name} crashed`, `Exit code ${d.code ?? '?'}${d.signal ? `, signal ${d.signal}` : ''}. ${d.reason || ''}`.trim(), { link: `/server/${s!.id}`, email: true }), 10 * 60_000); break;
        case 'oom': await serverActivity(null, s!.id, 'server.oom', d); await notifyDedup(`oom:${s!.id}`, () => notify(s!.owner_id, 'server_crash', `${s!.name} ran out of memory`, `Java reported OutOfMemoryError. Consider increasing Xmx (within your RAM allocation) or reducing plugins.\n${d.line || ''}`, { link: `/server/${s!.id}/startup` }), 3600_000); break;
        case 'scan': await handleScanEvent(s!.id, node.id, d); break;
        case 'runtime': await handleRuntimeEvent(s!.id, node.id, d); break;
        case 'disk_exceeded': await serverActivity(null, s!.id, 'server.disk_exceeded', d); await notifyDedup(`disk:${s!.id}`, () => notify(s!.owner_id, 'storage', `${s!.name} exceeded its disk allocation`, `Using ${(d.used / 1048576).toFixed(0)} MB of ${(d.limit / 1048576).toFixed(0)} MB. New uploads and writes are blocked until you free space.`, { link: `/server/${s!.id}/files`, email: true }), 6 * 3600_000); break;
        case 'disk_warning': await notifyDedup(`diskw:${s!.id}`, () => notify(s!.owner_id, 'storage', `${s!.name} is above 90% disk usage`, `Using ${(d.used / 1048576).toFixed(0)} MB of ${(d.limit / 1048576).toFixed(0)} MB.`, { link: `/server/${s!.id}/files` })); break;
        default: console.warn('[remote] unknown event', ev.type);
      }
    } catch (e: any) { console.error('[remote] event failed', ev.type, e.message); }
  }
  res.json({ ok: true, processed: events.length });
});
