import { ReactNode, useState } from 'react';
import { Plus, Pencil, Trash2 } from 'lucide-react';
import { useApi, useAction } from '../../lib/hooks';
import { api } from '../../lib/api';
import { Card, Confirm, Empty, ErrorBox, Field, Loading, Modal, Spinner, Switch, Table } from '../../components/ui';

export type FieldDef = { key: string; label: string; type?: 'text' | 'number' | 'textarea' | 'switch' | 'select' | 'datetime' | 'password' | 'list' | 'multiselect' | 'money'; options?: Array<{ value: any; label: string }>; hint?: ReactNode; required?: boolean; createOnly?: boolean; placeholder?: string; nullable?: boolean; span?: 2 };
export type Column = { label: string; render: (row: any) => ReactNode; className?: string };

export function FormFields({ fields, value, onChange, editing }: { fields: FieldDef[]; value: any; onChange: (v: any) => void; editing?: boolean }) {
  const set = (k: string, v: any) => onChange({ ...value, [k]: v });
  return <div className="grid gap-4 sm:grid-cols-2">{fields.filter(f => !(editing && f.createOnly)).map(f => {
    const v = value[f.key]; let input: ReactNode;
    switch (f.type) {
      case 'switch': return <div key={f.key} className="flex items-end sm:col-span-1"><Switch checked={!!v} onChange={x => set(f.key, x)} label={f.label} /></div>;
      case 'textarea': input = <textarea className="input min-h-24" value={v ?? ''} placeholder={f.placeholder} onChange={e => set(f.key, e.target.value)} />; break;
      case 'number': input = <input className="input" type="number" value={v ?? ''} placeholder={f.placeholder} onChange={e => set(f.key, e.target.value === '' ? (f.nullable ? null : '') : Number(e.target.value))} />; break;
      case 'money': input = <input className="input" type="number" step="0.01" min={0} value={v == null ? '' : v / 100} onChange={e => set(f.key, Math.round(Number(e.target.value) * 100))} />; break;
      case 'select': input = <select className="input" value={v ?? ''} onChange={e => { const o = f.options!.find(o => String(o.value) === e.target.value); set(f.key, o ? o.value : null); }}>{f.nullable && <option value="">—</option>}{f.options!.map(o => <option key={String(o.value)} value={String(o.value)}>{o.label}</option>)}</select>; break;
      case 'multiselect': input = <div className="grid max-h-48 grid-cols-2 gap-1 overflow-auto rounded-lg border border-ink-700 p-2 text-sm">{f.options!.map(o => <label key={String(o.value)} className="flex items-center gap-2"><input type="checkbox" checked={(v || []).includes(o.value)} onChange={e => set(f.key, e.target.checked ? [...(v || []), o.value] : (v || []).filter((x: any) => x !== o.value))} /><span className="truncate font-mono text-xs">{o.label}</span></label>)}</div>; break;
      case 'datetime': input = <input className="input" type="datetime-local" value={v ? String(v).slice(0, 16) : ''} onChange={e => set(f.key, e.target.value || null)} />; break;
      case 'password': input = <input className="input" type="password" autoComplete="new-password" value={v ?? ''} placeholder={f.placeholder} onChange={e => set(f.key, e.target.value)} />; break;
      case 'list': input = <input className="input font-mono" value={(v || []).join(', ')} placeholder={f.placeholder} onChange={e => set(f.key, e.target.value.split(/[\s,]+/).filter(Boolean))} />; break;
      default: input = <input className="input" value={v ?? ''} placeholder={f.placeholder} onChange={e => set(f.key, e.target.value)} />;
    }
    return <Field key={f.key} label={f.label} hint={f.hint} className={f.span === 2 || f.type === 'textarea' || f.type === 'multiselect' ? 'sm:col-span-2' : ''}>{input}</Field>;
  })}</div>;
}

/** Converts datetime-local strings to ISO and drops empty optional strings. */
export function cleanBody(fields: FieldDef[], v: any, editing: boolean) {
  const out: any = {};
  for (const f of fields) { if (editing && f.createOnly) continue; let x = v[f.key]; if (x === undefined) continue; if (f.type === 'datetime') x = x ? new Date(x).toISOString() : null; if (x === '' && f.type !== 'textarea' && f.type !== 'text') x = f.nullable ? null : undefined; if (x === '' && f.type === 'password') continue; if (x !== undefined) out[f.key] = x; }
  return out;
}

export function Crud({ title, endpoint, listKey, columns, fields, fromRow, defaults, editMethod = 'PATCH', canDelete = () => true, canEdit = () => true, deleteLabel = 'Delete', deleteNote, extraActions, headerExtra, onCreated }: {
  title: string; endpoint: string; listKey: string; columns: Column[]; fields: FieldDef[]; fromRow: (row: any) => any; defaults: any; editMethod?: 'PATCH' | 'PUT';
  canDelete?: (r: any) => boolean; canEdit?: (r: any) => boolean; deleteLabel?: string; deleteNote?: (r: any) => ReactNode; extraActions?: (r: any, reload: () => void) => ReactNode; headerExtra?: ReactNode; onCreated?: (res: any) => void;
}) {
  const { data, error, loading, reload } = useApi<any>(endpoint); const { busy, run } = useAction();
  const [ed, setEd] = useState<any>(null); const [rm, setRm] = useState<any>(null);
  const save = () => run('save', async () => { const editing = !!ed._id; const b = cleanBody(fields, ed, editing); const r = editing ? await api(editMethod, `${endpoint}/${ed._id}`, b) : await api('POST', endpoint, b); setEd(null); reload(); if (!editing) onCreated?.(r); }, 'Saved');
  return (
    <Card title={title} actions={<div className="flex gap-2">{headerExtra}<button className="btn-primary btn-sm" onClick={() => setEd({ ...defaults })}><Plus className="h-4 w-4" />New</button></div>}>
      {loading ? <Loading /> : error ? <ErrorBox error={error} onRetry={reload} /> : !data[listKey]?.length ? <Empty title={`No ${title.toLowerCase()} yet`} /> :
        <Table><thead><tr>{columns.map(c => <th key={c.label}>{c.label}</th>)}<th /></tr></thead><tbody>{data[listKey].map((r: any) => <tr key={r.id}>{columns.map(c => <td key={c.label} className={c.className}>{c.render(r)}</td>)}<td className="whitespace-nowrap text-right">{extraActions?.(r, reload)}{canEdit(r) && <button className="btn-ghost btn-sm px-1.5" title="Edit" onClick={() => setEd({ ...fromRow(r), _id: r.id })}><Pencil className="h-4 w-4" /></button>}{canDelete(r) && <button className="btn-ghost btn-sm px-1.5 text-red-400" title={deleteLabel} onClick={() => setRm(r)}><Trash2 className="h-4 w-4" /></button>}</td></tr>)}</tbody></Table>}
      <Modal open={!!ed} onClose={() => setEd(null)} wide title={ed?._id ? `Edit` : `New`} footer={<><button className="btn-secondary" onClick={() => setEd(null)}>Cancel</button><button className="btn-primary" disabled={!!busy} onClick={save}>{busy && <Spinner />}Save</button></>}>
        {ed && <FormFields fields={fields} value={ed} onChange={setEd} editing={!!ed._id} />}
      </Modal>
      <Confirm open={!!rm} onClose={() => setRm(null)} danger title={deleteLabel} confirmLabel={deleteLabel} busy={busy === 'rm'} onConfirm={() => run('rm', () => api('DELETE', `${endpoint}/${rm.id}`).then(() => { setRm(null); reload(); }), 'Done')}>{deleteNote ? deleteNote(rm) : 'This cannot be undone.'}</Confirm>
    </Card>
  );
}
