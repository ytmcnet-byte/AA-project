import fs from 'node:fs';
import path from 'node:path';

/** Recursively compute directory size (bytes allocated), without following symlinks. */
export async function dirSize(dir: string): Promise<number> {
  let total = 0; const stack = [dir];
  while (stack.length) {
    const d = stack.pop()!;
    let entries: fs.Dirent[] = [];
    try { entries = await fs.promises.readdir(d, { withFileTypes: true }); } catch { continue; }
    for (const e of entries) {
      const p = path.join(d, e.name);
      try {
        const st = await fs.promises.lstat(p);
        if (st.isSymbolicLink()) continue;
        if (st.isDirectory()) stack.push(p); else total += Math.max(st.size, st.blocks * 512 > 0 ? Math.min(st.blocks * 512, st.size + 4096) : st.size);
      } catch { /* vanished */ }
    }
  }
  return total;
}

/**
 * Application-level disk accounting. All write paths (upload, edit, extract, download-to-server,
 * restore) must reserve bytes first. Reservations are atomic within the single-threaded agent,
 * so concurrent uploads cannot jointly exceed the allocation.
 */
export class DiskAccount {
  used = 0; reserved = 0; lastScan = 0; scanning: Promise<number> | null = null;
  constructor(public dir: string, public limitBytes: number) {}
  async rescan() {
    if (!this.scanning) this.scanning = dirSize(this.dir).then(n => { this.used = n; this.lastScan = Date.now(); this.scanning = null; return n; });
    return this.scanning;
  }
  get unlimited() { return this.limitBytes <= 0; }
  available() { return this.unlimited ? Number.MAX_SAFE_INTEGER : this.limitBytes - this.used - this.reserved; }
  reserve(bytes: number) {
    if (!this.unlimited && bytes > this.available()) {
      const e: any = new Error(`Disk allocation exceeded: needs ${fmt(bytes)}, available ${fmt(Math.max(0, this.available()))} of ${fmt(this.limitBytes)}`); e.status = 507; throw e;
    }
    this.reserved += bytes; let released = false;
    return { release: (actualWritten = 0) => { if (released) return; released = true; this.reserved -= bytes; this.used += actualWritten; } };
  }
  exceeded() { return !this.unlimited && this.used > this.limitBytes; }
}
export const fmt = (b: number) => b >= 1 << 30 ? `${(b / (1 << 30)).toFixed(2)} GB` : `${(b / (1 << 20)).toFixed(1)} MB`;
