import crypto from 'node:crypto';
import type { PoolConnection } from 'mysql2/promise';
import { q, one, exec, tx, txRetry, json, parse } from '../db';
import { HttpError } from '../lib/http';
import { getSetting } from './settings';
import { createServer, getServer, setSuspension, syncSpec, nodeCapacity, deleteServer } from './servers';
import { getNode, type NodeRow } from './nodes';
import { notify, notifyAdmins } from './notify';
import { audit } from './audit';
import { registerJob, enqueue } from './jobs';
import { recommendedHeap } from '@oghost/shared';
import { dispatchWebhook } from './webhooks';
import { applyCoins, coinName, coinsEnabled } from './coins';

export const CYCLE_MONTHS: Record<string, number> = { monthly: 1, quarterly: 3, semiannual: 6, annual: 12, one_time: 0 };
export const addMonths = (d: Date, m: number) => { const x = new Date(d); const day = x.getUTCDate(); x.setUTCMonth(x.getUTCMonth() + m); if (x.getUTCDate() < day) x.setUTCDate(0); return x; };
export const money = (cents: number, cur: string) => `${cur} ${(cents / 100).toFixed(2)}`;

export async function getPlan(id: number) { const p: any = await one('SELECT p.*, pr.name AS product_name, pr.type AS product_type, pr.visible AS product_visible FROM plans p JOIN products pr ON pr.id = p.product_id WHERE p.id = ?', [id]); if (!p) throw new HttpError(404, 'Plan not found'); return p; }

export async function validateCoupon(code: string | undefined, planId: number, subtotal: number, c?: PoolConnection) {
  if (!code) return { coupon: null as any, discount: 0 };
  const cp: any = await one('SELECT * FROM coupons WHERE code = ? AND active = 1' + (c ? ' FOR UPDATE' : ''), [code.trim().toUpperCase()], c as any);
  if (!cp) throw new HttpError(422, 'Coupon code is not valid');
  if (cp.expires_at && new Date(cp.expires_at) < new Date()) throw new HttpError(422, 'Coupon has expired');
  if (cp.max_uses != null && cp.uses >= cp.max_uses) throw new HttpError(422, 'Coupon usage limit reached');
  const plans = parse<number[] | null>(cp.plan_ids, null); if (plans?.length && !plans.includes(planId)) throw new HttpError(422, 'Coupon does not apply to this plan');
  const discount = cp.type === 'percent' ? Math.floor(subtotal * Math.min(100, cp.value) / 100) : Math.min(subtotal, cp.value);
  return { coupon: cp, discount };
}

async function invoiceNumber(c: PoolConnection, id: number) { const prefix = String(await getSetting('store.invoicePrefix') || 'OGH'); const n = `${prefix}-${new Date().getUTCFullYear()}-${String(id).padStart(6, '0')}`; await exec('UPDATE invoices SET number = ? WHERE id = ?', [n, id], c); return n; }
export async function createInvoice(c: PoolConnection, data: { userId: number; orderId?: number | null; serviceId?: number | null; items: Array<{ description: string; amount_cents: number }>; discount: number; currency: string; dueAt: Date; coinTotal?: number | null }) {
  const subtotal = data.items.reduce((a, i) => a + i.amount_cents, 0); const total = Math.max(0, subtotal - data.discount);
  const coinTotal = data.coinTotal == null ? null : Math.max(0, Math.round(data.coinTotal));
  const r = await exec('INSERT INTO invoices (number, user_id, order_id, service_id, status, subtotal_cents, discount_cents, total_cents, currency, items, due_at, coin_total) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', [`TMP-${crypto.randomUUID()}`.slice(0, 32), data.userId, data.orderId ?? null, data.serviceId ?? null, 'unpaid', subtotal, data.discount, total, data.currency, json(data.items), data.dueAt, coinTotal], c);
  await invoiceNumber(c, r.insertId); return { id: r.insertId, total, coinTotal };
}

export interface CheckoutConfig { serverName: string; eggId?: number; locationId?: number; variables?: Record<string, string>; }
/** An invoice is free only when there is neither money nor coins to pay. */
const isFree = (inv: { total: number; coinTotal: number | null }) => inv.total === 0 && !inv.coinTotal;
export async function checkout(userId: number, planId: number, cfg: CheckoutConfig, couponCode?: string, payWith: 'money' | 'ogcoins' = 'money') {
  if (!(await getSetting('store.enabled'))) throw new HttpError(503, 'The store is currently disabled');
  const plan = await getPlan(planId); if (!plan.visible || !plan.product_visible) throw new HttpError(404, 'Plan is not available');
  if (!plan.egg_id && !cfg.eggId) throw new HttpError(422, 'Choose a server software');
  if (payWith === 'ogcoins') {
    if (!(await coinsEnabled())) throw new HttpError(503, 'OGCoins are disabled');
    if (plan.coin_price == null) throw new HttpError(422, `This plan cannot be bought with ${await coinName()}`);
    if (couponCode) throw new HttpError(422, `Coupons cannot be combined with ${await coinName()}`);
  } else if (plan.price_cents === 0 && plan.coin_price != null && !plan.setup_fee_cents) throw new HttpError(422, `This plan can only be bought with ${await coinName()}`);
  await pickNode(plan, cfg.locationId); // fail early if nothing can host it
  const subtotalItems = [{ description: `${plan.product_name} – ${plan.name} (${plan.billing_cycle.replace('_', ' ')})`, amount_cents: plan.price_cents }];
  if (plan.setup_fee_cents) subtotalItems.push({ description: 'Setup fee', amount_cents: plan.setup_fee_cents });
  const subtotal = subtotalItems.reduce((a, i) => a + i.amount_cents, 0);
  return txRetry(async (c) => {
    if (plan.max_per_user != null) {
      await one('SELECT id FROM users WHERE id = ? FOR UPDATE', [userId], c); // serialize concurrent checkouts of one user
      const n: any = await one("SELECT (SELECT COUNT(*) FROM services WHERE user_id = ? AND plan_id = ? AND status IN ('pending','active','suspended')) + (SELECT COUNT(*) FROM orders WHERE user_id = ? AND plan_id = ? AND kind = 'new' AND status IN ('pending','paid')) AS n", [userId, plan.id, userId, plan.id], c);
      if (Number(n.n) >= plan.max_per_user) throw new HttpError(409, `You can have at most ${plan.max_per_user} of this plan (pending orders count too)`);
    }
    if (plan.stock != null) { const u = await exec('UPDATE plans SET stock = stock - 1 WHERE id = ? AND stock > 0', [plan.id], c); if (!u.affectedRows) throw new HttpError(409, 'This plan is out of stock'); }
    const { coupon, discount } = await validateCoupon(couponCode, plan.id, subtotal, c);
    if (coupon) await exec('UPDATE coupons SET uses = uses + 1 WHERE id = ?', [coupon.id], c);
    const uuid = crypto.randomUUID();
    const o = await exec('INSERT INTO orders (uuid, user_id, plan_id, coupon_id, kind, status, amount_cents, currency, config) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)', [uuid, userId, plan.id, coupon?.id ?? null, 'new', 'pending', Math.max(0, subtotal - discount), plan.currency, json({ ...cfg, couponRecurring: !!coupon?.recurring, discount })], c);
    const inv = await createInvoice(c, { userId, orderId: o.insertId, items: subtotalItems, discount, currency: plan.currency, dueAt: new Date(Date.now() + 2 * 86400_000), coinTotal: plan.coin_price });
    return { orderId: o.insertId, orderUuid: uuid, invoiceId: inv.id, total: inv.total, coinTotal: inv.coinTotal, free: isFree(inv) };
  }).then(async r => {
    if (r.free) await markInvoicePaid(r.invoiceId, { gateway: 'free', reference: 'zero-total' });
    else if (payWith === 'ogcoins') {
      try { const p = await payInvoiceWithCoins(r.invoiceId, userId); return { ...r, paidWithCoins: true, balance: p.balance }; }
      catch (e) { await cancelUnpaidOrder(r.orderId).catch(() => {}); throw e; } // not enough coins: release stock / coupon, no dangling order
    }
    return r;
  });
}

/** Choose a node for a plan: fixed node, or the least-loaded online node in the location with capacity + a free port. */
export async function pickNode(plan: any, locationId?: number): Promise<NodeRow> {
  const loc = plan.location_id || locationId || null;
  const nodes = await q<NodeRow>(`SELECT * FROM nodes WHERE status = 'online' AND maintenance = 0 AND emergency = 0 ${plan.node_id ? 'AND id = ?' : loc ? 'AND location_id = ?' : ''}`, plan.node_id ? [plan.node_id] : loc ? [loc] : []);
  let best: NodeRow | null = null; let bestFree = -1;
  for (const n of nodes) {
    const cap = await nodeCapacity(n); const free = cap.memoryMax - cap.memory;
    const port: any = await one('SELECT id FROM allocations WHERE node_id = ? AND server_id IS NULL LIMIT 1', [n.id]);
    if (!port || free < plan.memory_mb || cap.diskMax - cap.disk < plan.disk_mb || (n.max_servers && cap.servers >= n.max_servers)) continue;
    if (free > bestFree) { best = n; bestFree = free; }
  }
  if (!best) throw new HttpError(409, 'No node currently has capacity for this plan. Please try another location or contact support.');
  return best;
}

/**
 * The ONLY way an invoice becomes paid. Callers must have verified the payment server-side
 * (gateway webhook signature / gateway API lookup / administrator approval). Idempotent.
 */
export async function markInvoicePaid(invoiceId: number, pay: { gateway: string; paymentId?: number; reference?: string; approvedBy?: number }, inTx?: (c: PoolConnection, inv: any) => Promise<void>) {
  const done = await txRetry(async (c) => {
    const inv: any = await one('SELECT * FROM invoices WHERE id = ? FOR UPDATE', [invoiceId], c); if (!inv) throw new HttpError(404, 'Invoice not found');
    if (inv.status === 'paid') { if (inTx) throw new HttpError(409, 'Invoice is already paid'); return null; } if (inv.status !== 'unpaid') throw new HttpError(409, `Invoice is ${inv.status}`);
    if (inTx) await inTx(c, inv); // e.g. the OGCoins debit: committed atomically with the invoice becoming paid
    await exec("UPDATE invoices SET status = 'paid', paid_at = NOW() WHERE id = ?", [invoiceId], c);
    if (pay.paymentId) await exec("UPDATE payments SET status = 'succeeded', approved_by = COALESCE(?, approved_by) WHERE id = ?", [pay.approvedBy ?? null, pay.paymentId], c);
    if (inv.order_id) await exec("UPDATE orders SET status = 'paid' WHERE id = ? AND status = 'pending'", [inv.order_id], c);
    return inv;
  });
  if (!done) return { alreadyPaid: true };
  await audit(null, 'billing.invoice_paid', { type: 'invoice', id: invoiceId }, { gateway: pay.gateway, reference: pay.reference, approvedBy: pay.approvedBy }, pay.approvedBy ? 'admin' : 'system');
  await notify(done.user_id, 'payment', `Payment received for invoice ${done.number}`, pay.gateway === 'ogcoins' ? `${done.coin_total} ${await coinName()} spent.` : `${money(done.total_cents, done.currency)} via ${pay.gateway}.`, { link: `/billing/invoices/${invoiceId}`, email: true });
  void dispatchWebhook('invoice.paid', { invoiceId, number: done.number, userId: done.user_id, total: done.total_cents, currency: done.currency });
  await enqueue('billing.provision', { invoiceId }, { uniqueKey: `provision:${invoiceId}`, maxAttempts: 5 });
  return { paid: true };
}

registerJob('billing.provision', async ({ invoiceId }: { invoiceId: number }) => {
  const inv: any = await one('SELECT * FROM invoices WHERE id = ?', [invoiceId]); if (!inv || inv.status !== 'paid') return;
  const order: any = inv.order_id ? await one('SELECT * FROM orders WHERE id = ?', [inv.order_id]) : null;
  if (order && order.status === 'active') return { already: true };
  if (order?.kind === 'new') return provisionNew(order);
  if (order?.kind === 'upgrade' || order?.kind === 'downgrade') return applyPlanChange(order);
  if (inv.service_id) return applyRenewal(inv.service_id);
});

async function provisionNew(order: any) {
  const plan = await getPlan(order.plan_id); const cfg = parse<any>(order.config, {});
  const months = CYCLE_MONTHS[plan.billing_cycle] ?? 1;
  let svcId = order.service_id;
  if (!svcId) {
    const s = await exec('INSERT INTO services (user_id, plan_id, status, coin_price, price_cents, currency, billing_cycle, config, next_due_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)', [order.user_id, plan.id, 'pending', plan.coin_price ?? null, cfg.couponRecurring ? order.amount_cents - (plan.setup_fee_cents || 0) : plan.price_cents, plan.currency, plan.billing_cycle, json(cfg), months ? addMonths(new Date(), months) : null]);
    svcId = s.insertId; await exec('UPDATE orders SET service_id = ? WHERE id = ?', [svcId, order.id]);
  }
  const svc: any = await one('SELECT * FROM services WHERE id = ?', [svcId]);
  if (!svc.server_id) {
    const node = await pickNode(plan, cfg.locationId); const heap = recommendedHeap(plan.memory_mb);
    const created = await createServer({ name: String(cfg.serverName || plan.name).slice(0, 100), ownerId: order.user_id, nodeId: node.id, eggId: plan.egg_id || cfg.eggId, memoryMb: plan.memory_mb, cpuPercent: plan.cpu_percent, diskMb: plan.disk_mb, databaseLimit: plan.databases, backupLimit: plan.backups, allocationLimit: plan.allocations, variables: cfg.variables || {}, xmsMb: heap.xmsMb, xmxMb: heap.xmxMb, serviceId: svcId });
    await exec('UPDATE services SET server_id = ? WHERE id = ?', [created.id, svcId]);
  }
  await exec("UPDATE services SET status = 'active' WHERE id = ?", [svcId]); await exec("UPDATE orders SET status = 'active' WHERE id = ?", [order.id]);
  await notify(order.user_id, 'system', 'Your server is being installed', `Order ${order.uuid.slice(0, 8)} is active. Installation usually takes a minute.`, { link: '/servers' });
  return { serviceId: svcId };
}

async function applyRenewal(serviceId: number) {
  const svc: any = await one('SELECT * FROM services WHERE id = ?', [serviceId]); if (!svc) return;
  const months = CYCLE_MONTHS[svc.billing_cycle] ?? 1; const base = svc.next_due_at && new Date(svc.next_due_at) > new Date() ? new Date(svc.next_due_at) : new Date();
  await exec("UPDATE services SET next_due_at = ?, status = IF(status = 'suspended', 'active', status), reminder_sent_at = NULL WHERE id = ?", [addMonths(base, months), serviceId]);
  if (svc.status === 'suspended' && svc.server_id) { const s = await getServer(svc.server_id).catch(() => null); if (s && s.suspension_reason?.startsWith('Billing:')) await setSuspension(s.id, false, null, null); }
  return { renewed: true };
}

async function applyPlanChange(order: any) {
  const plan = await getPlan(order.plan_id); const svc: any = await one('SELECT * FROM services WHERE id = ?', [order.service_id]);
  await exec('UPDATE services SET plan_id = ?, price_cents = ?, currency = ?, coin_price = ? WHERE id = ?', [plan.id, plan.price_cents, plan.currency, plan.coin_price ?? null, svc.id]);
  if (svc.server_id) {
    const s = await getServer(svc.server_id); const heap = recommendedHeap(plan.memory_mb);
    const xmx = Math.min(s.xmx_mb, plan.memory_mb) === s.xmx_mb && s.memory_mb === plan.memory_mb ? s.xmx_mb : heap.xmxMb;
    await exec('UPDATE servers SET memory_mb = ?, cpu_percent = ?, disk_mb = ?, database_limit = ?, backup_limit = ?, allocation_limit = ?, xmx_mb = ?, xms_mb = LEAST(xms_mb, ?) WHERE id = ?', [plan.memory_mb, plan.cpu_percent, plan.disk_mb, plan.databases, plan.backups, plan.allocations, xmx, xmx, s.id]);
    await syncSpec(s.id).catch(() => {});
  }
  await exec("UPDATE orders SET status = 'active' WHERE id = ?", [order.id]);
  await notify(order.user_id, 'system', `Plan changed to ${plan.name}`, 'New resource limits apply after the next server restart.', { link: `/server/${svc.server_id}` });
}

/** Upgrade / downgrade with simple proration of the remaining period. Downgrades never refund; they apply immediately. */
export async function changePlan(userId: number, serviceId: number, newPlanId: number) {
  const svc: any = await one("SELECT * FROM services WHERE id = ? AND user_id = ? AND status = 'active'", [serviceId, userId]); if (!svc) throw new HttpError(404, 'Active service not found');
  const cur = await getPlan(svc.plan_id); const next = await getPlan(newPlanId);
  if (cur.product_id !== next.product_id) throw new HttpError(422, 'You can only change to a plan of the same product');
  if (next.id === cur.id) throw new HttpError(422, 'Already on this plan');
  if (svc.server_id) { const s = await getServer(svc.server_id); const node = await getNode(s.node_id); const cap = await nodeCapacity(node); if (next.memory_mb > cur.memory_mb && cap.memory + next.memory_mb - cur.memory_mb > cap.memoryMax) throw new HttpError(409, 'The node hosting your server lacks capacity for this upgrade. Contact support to transfer the server.'); }
  const months = CYCLE_MONTHS[svc.billing_cycle] || 1; const periodMs = months * 30 * 86400_000;
  const remaining = svc.next_due_at ? Math.max(0, Math.min(1, (new Date(svc.next_due_at).getTime() - Date.now()) / periodMs)) : 0;
  const diff = Math.round((next.price_cents - svc.price_cents) * remaining);
  const kind = next.price_cents > cur.price_cents || (next.price_cents === cur.price_cents && (next.coin_price ?? 0) >= (cur.coin_price ?? 0)) ? 'upgrade' : 'downgrade';
  const curCoins = svc.coin_price ?? cur.coin_price; const coinTotal = next.coin_price != null && curCoins != null ? Math.max(0, Math.round((next.coin_price - curCoins) * remaining)) : null;
  return tx(async (c) => {
    const o = await exec('INSERT INTO orders (uuid, user_id, plan_id, service_id, kind, status, amount_cents, currency) VALUES (?, ?, ?, ?, ?, ?, ?, ?)', [crypto.randomUUID(), userId, next.id, svc.id, kind, 'pending', Math.max(0, diff), next.currency], c);
    const inv = await createInvoice(c, { userId, orderId: o.insertId, serviceId: svc.id, items: [{ description: `${kind === 'upgrade' ? 'Upgrade' : 'Downgrade'} ${cur.name} → ${next.name} (prorated ${Math.round(remaining * 100)}% of period)`, amount_cents: Math.max(0, diff) }], discount: 0, currency: next.currency, dueAt: new Date(Date.now() + 2 * 86400_000), coinTotal });
    return { orderId: o.insertId, invoiceId: inv.id, total: inv.total, coinTotal: inv.coinTotal };
  }).then(async r => { if (isFree(r)) await markInvoicePaid(r.invoiceId, { gateway: 'free', reference: 'proration' }); return r; });
}

export async function cancelService(userId: number | null, serviceId: number, immediate: boolean) {
  const svc: any = await one('SELECT * FROM services WHERE id = ?' + (userId ? ' AND user_id = ?' : ''), userId ? [serviceId, userId] : [serviceId]); if (!svc) throw new HttpError(404, 'Service not found');
  if (immediate) { await exec("UPDATE services SET status = 'cancelled', cancelled_at = NOW() WHERE id = ?", [serviceId]); if (svc.server_id) await setSuspension(svc.server_id, true, 'Billing: service cancelled', null); }
  else await exec('UPDATE services SET cancel_at_period_end = 1 WHERE id = ?', [serviceId]);
  await exec("UPDATE invoices SET status = 'cancelled' WHERE service_id = ? AND status = 'unpaid'", [serviceId]);
}

/** Renewal invoices, reminders, overdue suspension, end-of-period cancellations. Runs every 10 minutes. */
export async function billingTick() {
  const reminderDays = Number(await getSetting('store.reminderDays')) || 3; const grace = Number(await getSetting('store.graceDays')) || 3; const terminateDays = Number(await getSetting('store.terminateDays')) || 0;
  for (const svc of await q<any>("SELECT * FROM services WHERE status = 'active' AND cancel_at_period_end = 1 AND next_due_at <= NOW()")) {
    await exec("UPDATE services SET status = 'cancelled', cancelled_at = NOW() WHERE id = ?", [svc.id]); if (svc.server_id) await setSuspension(svc.server_id, true, 'Billing: service cancelled at end of period', null).catch(() => {});
    await notify(svc.user_id, 'renewal', 'Service cancelled', 'Your service reached the end of its paid period and was cancelled as requested. Files are kept until an administrator removes them.');
  }
  for (const svc of await q<any>("SELECT * FROM services WHERE status IN ('active','suspended') AND cancel_at_period_end = 0 AND billing_cycle <> 'one_time' AND next_due_at IS NOT NULL AND next_due_at <= DATE_ADD(NOW(), INTERVAL ? DAY)", [reminderDays])) {
    const r = await renewalInvoice(svc, { prepayCheck: false });
    if (!r.existing) await notify(svc.user_id, 'renewal', 'Renewal invoice created', `Your service renews on ${new Date(svc.next_due_at).toUTCString()}. Pay the invoice${r.coinTotal ? ` (or ${r.coinTotal} ${await coinName()})` : ''} to avoid suspension.${svc.auto_renew_coins && r.coinTotal ? ' Auto-renew with OGCoins is on: it is charged from your wallet 24 hours before the due date.' : ''}`, { link: '/billing', email: true });
  }
  await autoRenewWithCoins();
  for (const svc of await q<any>("SELECT * FROM services WHERE status = 'active' AND next_due_at < DATE_SUB(NOW(), INTERVAL ? DAY) AND billing_cycle <> 'one_time'", [grace])) {
    const unpaid: any = await one("SELECT id FROM invoices WHERE service_id = ? AND status = 'unpaid'", [svc.id]); if (!unpaid) continue;
    await exec("UPDATE services SET status = 'suspended' WHERE id = ?", [svc.id]);
    if (svc.server_id) await setSuspension(svc.server_id, true, 'Billing: overdue invoice', null).catch(() => {});
    await notify(svc.user_id, 'renewal', 'Service suspended for non-payment', 'Pay the overdue invoice to restore your server immediately. Your files are kept.', { link: '/billing', email: true });
  }
  if (terminateDays > 0) for (const svc of await q<any>("SELECT * FROM services WHERE status IN ('suspended','cancelled') AND server_id IS NOT NULL AND COALESCE(cancelled_at, next_due_at) < DATE_SUB(NOW(), INTERVAL ? DAY)", [terminateDays])) {
    await deleteServer(svc.server_id).then(() => exec("UPDATE services SET status = 'terminated' WHERE id = ?", [svc.id])).catch(e => notifyAdmins('admin.servers', 'system', `Termination failed for service #${svc.id}`, e.message));
  }
}

/** Open renewal invoice for a service, creating one if needed. Prepaying is capped at store.maxPrepayCycles periods ahead. */
export async function renewalInvoice(svc: any, opts: { prepayCheck: boolean }) {
  if (!CYCLE_MONTHS[svc.billing_cycle]) throw new HttpError(422, 'One-time services do not renew');
  const open: any = await one("SELECT id, total_cents, coin_total FROM invoices WHERE service_id = ? AND status = 'unpaid' AND order_id IS NULL ORDER BY id DESC LIMIT 1", [svc.id]);
  if (open) return { invoiceId: open.id as number, total: open.total_cents as number, coinTotal: open.coin_total as number | null, existing: true };
  if (opts.prepayCheck && svc.next_due_at) {
    const maxCycles = Math.max(1, Number(await getSetting('store.maxPrepayCycles')) || 6);
    if (new Date(svc.next_due_at) > addMonths(new Date(), CYCLE_MONTHS[svc.billing_cycle] * maxCycles)) throw new HttpError(422, `This service is already paid ${maxCycles} periods ahead`);
  }
  const plan = await getPlan(svc.plan_id);
  const coinTotal = svc.coin_price ?? plan.coin_price ?? null;
  const inv = await txRetry(c => createInvoice(c, { userId: svc.user_id, serviceId: svc.id, items: [{ description: `Renewal – ${plan.product_name} ${plan.name} (${svc.billing_cycle})`, amount_cents: svc.price_cents }], discount: 0, currency: svc.currency, dueAt: svc.next_due_at ? new Date(svc.next_due_at) : new Date(), coinTotal }));
  if (isFree(inv)) { await markInvoicePaid(inv.id, { gateway: 'free', reference: 'zero-total renewal' }); return { invoiceId: inv.id, total: 0, coinTotal: null, existing: false, free: true }; }
  return { invoiceId: inv.id, total: inv.total, coinTotal: inv.coinTotal, existing: false };
}

/**
 * Pay an unpaid invoice from the user's OGCoins wallet. The debit, the ledger row, the payment record and the
 * invoice becoming paid are one transaction: either everything happens or nothing does.
 */
export async function payInvoiceWithCoins(invoiceId: number, userId: number) {
  if (!(await coinsEnabled())) throw new HttpError(503, 'OGCoins are disabled');
  const pre: any = await one('SELECT * FROM invoices WHERE id = ? AND user_id = ?', [invoiceId, userId]); if (!pre) throw new HttpError(404, 'Invoice not found');
  if (pre.status !== 'unpaid') throw new HttpError(409, `Invoice is ${pre.status}`);
  if (!pre.coin_total) throw new HttpError(422, `This invoice cannot be paid with ${await coinName()}`);
  const order: any = pre.order_id ? await one('SELECT kind FROM orders WHERE id = ?', [pre.order_id]) : null;
  const type = !order ? 'renewal' : order.kind === 'new' ? 'purchase' : 'upgrade';
  let balance = 0;
  await markInvoicePaid(invoiceId, { gateway: 'ogcoins', reference: `coins:${pre.coin_total}` }, async (c, inv) => {
    if (inv.user_id !== userId || !inv.coin_total) throw new HttpError(409, 'Invoice changed, reload and try again');
    const w = await applyCoins(c, { userId, amount: -inv.coin_total, type, reference: `inv:${inv.id}`, description: `${type === 'renewal' ? 'Renewal' : type === 'purchase' ? 'Purchase' : 'Plan change'} – invoice ${inv.number}`, invoiceId: inv.id });
    if (!w) throw new HttpError(409, 'Invoice is already paid');
    balance = w.balance;
    await exec("INSERT INTO payments (invoice_id, user_id, gateway, amount_cents, currency, status, reference) VALUES (?, ?, 'ogcoins', 0, ?, 'succeeded', ?)", [inv.id, userId, inv.currency, `${inv.coin_total} coins`], c);
  });
  return { paid: true, balance, coins: pre.coin_total as number };
}

async function cancelUnpaidOrder(orderId: number) {
  await txRetry(async (c) => {
    const o: any = await one("SELECT * FROM orders WHERE id = ? AND status = 'pending' FOR UPDATE", [orderId], c); if (!o) return;
    await exec("UPDATE orders SET status = 'cancelled' WHERE id = ?", [orderId], c);
    await exec("UPDATE invoices SET status = 'cancelled' WHERE order_id = ? AND status = 'unpaid'", [orderId], c);
    await exec('UPDATE plans SET stock = stock + 1 WHERE id = ? AND stock IS NOT NULL', [o.plan_id], c);
    if (o.coupon_id) await exec('UPDATE coupons SET uses = GREATEST(uses - 1, 0) WHERE id = ?', [o.coupon_id], c);
  });
}

/** Services with auto-renew from wallet: charged once the renewal is due within 24 hours. Low balance -> one notice per day. */
export async function autoRenewWithCoins() {
  if (!(await coinsEnabled())) return;
  const rows = await q<any>(`SELECT sv.id, sv.user_id, sv.auto_renew_notified_at, i.id AS invoice_id, i.coin_total FROM services sv JOIN invoices i ON i.service_id = sv.id AND i.status = 'unpaid' AND i.order_id IS NULL
    WHERE sv.auto_renew_coins = 1 AND sv.status IN ('active','suspended') AND sv.cancel_at_period_end = 0 AND i.coin_total > 0 AND sv.next_due_at <= NOW() + INTERVAL 1 DAY`);
  const name = await coinName();
  for (const r of rows) {
    try {
      const p = await payInvoiceWithCoins(r.invoice_id, r.user_id);
      await exec('UPDATE services SET auto_renew_notified_at = NULL WHERE id = ?', [r.id]);
      await notify(r.user_id, 'renewal', 'Service renewed with OGCoins', `${p.coins} ${name} were charged automatically. Balance: ${p.balance} ${name}.`, { link: '/billing' });
    } catch (e: any) {
      if (e?.extra?.code !== 'INSUFFICIENT_COINS') { console.warn('[billing] auto-renew', r.id, e?.message); continue; }
      if (r.auto_renew_notified_at && Date.now() - new Date(r.auto_renew_notified_at).getTime() < 86400_000) continue;
      await exec('UPDATE services SET auto_renew_notified_at = NOW() WHERE id = ?', [r.id]);
      await notify(r.user_id, 'renewal', `Not enough ${name} to auto-renew`, `Renewal needs ${r.coin_total} ${name}, your balance is ${e.extra.balance}. Earn or redeem ${name}, or pay the invoice another way, to avoid suspension.`, { link: '/coins', email: true });
    }
  }
}
