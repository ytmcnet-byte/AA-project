import crypto from 'node:crypto';
import { q, one, exec } from '../db';
import { getNode, agent } from './nodes';
import { getServer } from './servers';
import { HttpError } from '../lib/http';
import { registerJob, enqueue } from './jobs';
import { notify } from './notify';

export async function backupUsage(serverId: number) {
  const r: any = await one("SELECT COUNT(*) AS c, COALESCE(SUM(size_bytes),0) AS bytes FROM backups WHERE server_id = ? AND is_safety = 0 AND status <> 'failed'", [serverId]);
  return { count: Number(r.c), bytes: Number(r.bytes) };
}

/** Creates a local backup row and queues the archive job on the node. Safety backups bypass the customer limit. */
export async function requestBackup(serverId: number, name: string, opts: { safety?: boolean; locked?: boolean; wait?: boolean } = {}) {
  const s = await getServer(serverId);
  if (!opts.safety) {
    const u = await backupUsage(serverId);
    if (s.backup_limit === 0) throw new HttpError(403, 'This server has no local backup slots');
    if (u.count >= s.backup_limit) throw new HttpError(409, `Backup limit reached (${s.backup_limit}). Delete an old backup or unlock one first.`);
  }
  const running: any = await one("SELECT id FROM backups WHERE server_id = ? AND status IN ('pending','creating')", [serverId]);
  if (running) throw new HttpError(409, 'Another backup is already running for this server');
  const uuid = crypto.randomUUID();
  const r = await exec('INSERT INTO backups (uuid, server_id, name, status, locked, is_safety) VALUES (?, ?, ?, ?, ?, ?)', [uuid, serverId, name.slice(0, 150), 'pending', opts.locked ? 1 : 0, opts.safety ? 1 : 0]);
  if (opts.wait) { await runBackup({ backupId: r.insertId }); return (await one('SELECT * FROM backups WHERE id = ?', [r.insertId]))!; }
  await enqueue('backup.create', { backupId: r.insertId }, { uniqueKey: `backup:${r.insertId}`, maxAttempts: 1 });
  return (await one('SELECT * FROM backups WHERE id = ?', [r.insertId]))!;
}

async function runBackup({ backupId }: { backupId: number }) {
  const b: any = await one('SELECT * FROM backups WHERE id = ?', [backupId]); if (!b || b.status === 'completed') return;
  const s = await getServer(b.server_id); const node = await getNode(s.node_id);
  await exec("UPDATE backups SET status = 'creating' WHERE id = ?", [backupId]);
  try {
    let maxBytes = 0;
    if (!b.is_safety && s.backup_storage_mb) { const u = await backupUsage(s.id); maxBytes = Math.max(1, s.backup_storage_mb * 1024 * 1024 - (u.bytes - Number(b.size_bytes))); }
    const r = await agent(node, 'POST', `/api/servers/${s.node_server_id}/backups`, { uuid: b.uuid, maxBytes }, { serverId: s.node_server_id, timeoutMs: 6 * 3600_000 });
    await exec("UPDATE backups SET status = 'completed', size_bytes = ?, sha256 = ?, completed_at = NOW(), error = NULL WHERE id = ?", [r.size, r.sha256, backupId]);
  } catch (e: any) {
    await exec("UPDATE backups SET status = 'failed', error = ?, completed_at = NOW() WHERE id = ?", [String(e.message).slice(0, 2000), backupId]);
    await notify(s.owner_id, 'backup', `Backup failed for ${s.name}`, String(e.message), { link: `/server/${s.id}/backups` });
    throw Object.assign(e, { noRetry: true });
  }
}
registerJob('backup.create', runBackup);

export async function deleteBackup(backupId: number, force = false) {
  const b: any = await one('SELECT * FROM backups WHERE id = ?', [backupId]); if (!b) throw new HttpError(404, 'Backup not found');
  if (b.locked && !force) throw new HttpError(409, 'Backup is locked. Unlock it before deleting.');
  if (['pending', 'creating'].includes(b.status)) throw new HttpError(409, 'Backup is still being created');
  const s = await getServer(b.server_id); const node = await getNode(s.node_id);
  await agent(node, 'DELETE', `/api/servers/${s.node_server_id}/backups/${b.uuid}`, undefined, { serverId: s.node_server_id });
  await exec('DELETE FROM backups WHERE id = ?', [backupId]);
}

export async function restoreBackup(backupId: number, truncate: boolean) {
  const b: any = await one('SELECT * FROM backups WHERE id = ?', [backupId]); if (!b || b.status !== 'completed') throw new HttpError(409, 'Backup is not complete');
  const s = await getServer(b.server_id); const node = await getNode(s.node_id);
  const st = await agent(node, 'GET', `/api/servers/${s.node_server_id}`, undefined, { serverId: s.node_server_id });
  if (!['offline', 'crashed'].includes(st.state)) throw new HttpError(409, 'Stop the server before restoring a backup');
  return agent(node, 'POST', `/api/servers/${s.node_server_id}/backups/${b.uuid}/restore`, { truncate }, { serverId: s.node_server_id, timeoutMs: 6 * 3600_000 });
}

/** Keeps the newest `keep` unlocked non-safety backups and deletes the rest (used by schedules). */
export async function pruneBackups(serverId: number, keep: number) {
  const list = await q("SELECT id FROM backups WHERE server_id = ? AND status = 'completed' AND locked = 0 AND is_safety = 0 ORDER BY created_at DESC", [serverId]);
  let n = 0; for (const b of list.slice(Math.max(0, keep))) { await deleteBackup(b.id); n++; } return n;
}
export async function cleanupSafetyBackups(serverId: number, keep = 2) {
  const list = await q("SELECT id FROM backups WHERE server_id = ? AND status = 'completed' AND is_safety = 1 ORDER BY created_at DESC", [serverId]);
  for (const b of list.slice(keep)) await deleteBackup(b.id, true).catch(() => {});
}
