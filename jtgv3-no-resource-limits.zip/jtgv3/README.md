# JTG Panel

Made by Jishnu

## Quick Automated Setup (Recommended)

Run the automated management script:

```bash
bash install.sh
```

Menu Options:
1. **Install Panel** (Installs Node.js, Docker, PM2, dependencies, builds & starts on port 6767)
2. **Update Panel**
3. **Create Admin User**
4. **Restart Panel**
5. **Exit**

---

## Manual Installation

1. Clone the repository:
   ```bash
   git clone https://github.com/JishnuTheGamer/Jtg.git
   cd Jtg
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Build the application:
   ```bash
   npm run build
   ```

4. Create an admin user:
   ```bash
   npm run createuser
   ```

5. Start the server (Port 6767):
   ```bash
   npm run start
   ```

## Development

To run the panel in development mode on port 3000:

```bash
npm run dev
```


## Rootless / no-Docker direct-process mode (OGHost User-Space)

This fork defaults new servers to **Direct Process** (`runtimeType: local`). Minecraft is launched as a regular child process; Docker is not needed. RAM is applied as JVM `-Xmx`/`-Xms`, but this is not a hard OS-level memory/CPU/disk isolation boundary.

### Java selection

The Create Server screen accepts a Java executable/alias such as `java8`, `java17`, `java21`, `java25`, or an absolute path. That command must be present on the machine that runs the server. If left as `21`, the panel looks for `java21`, then falls back to the normal Java resolution logic.

### Add a remote rootless node

1. Copy `user-space-node.mjs` to the remote machine. Node.js 18+ is required; no root and no Docker are required.
2. Choose a long random token and run:

   ```bash
   export OG_NODE_TOKEN='replace-with-a-long-random-secret'
   export OG_NODE_PORT=8787
   export OG_NODE_DATA="$HOME/og-node-data/servers"
   node user-space-node.mjs
   ```

3. Keep the agent running using your host's supported process manager (for example `pm2 start user-space-node.mjs --name og-node --interpreter node`).
4. In the panel's **Nodes** page, add the node hostname/IP, agent API port `8787`, and the same token. Keep the agent API private or put it behind HTTPS/access control; the token grants server process control.
5. Choose **Direct Process (No Docker)** when creating a server and select that node.

The agent downloads a Purpur JAR for normal Minecraft server types if no usable `server.jar` exists. Java executable names/paths must exist on the remote node. The current user-space agent includes create/start/stop/restart/status/logs/console-command operations. Full remote file-manager/SFTP/backup parity and OS-enforced resource quotas are not implemented yet; use local nodes for file operations until those endpoints are wired in. Do not expose the agent directly to the public internet without a trusted network or HTTPS proxy.


## Rootless multi-node Minecraft mode

The `Direct Process (No Docker)` runtime can register remote Node.js agents and launch Java server processes directly. The user-space agent does not enforce RAM, CPU, or disk quotas and launches the jar without `-Xmx`/`-Xms` flags by default. Actual resource availability remains controlled by the host operating system/provider. See `USERSPACE_NODE_SETUP.txt`. Remote file manager, SFTP, backups, plugin installer, and world-manager integration are not yet complete.
