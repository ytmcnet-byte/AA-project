import type { Request } from 'express';
import { one, parse } from '../db';
import { hasPerm, scopeOk, SERVER_PERMISSIONS } from './auth';
import { HttpError } from './http';
import { getServer, type ServerRow } from '../services/servers';

/** Resolve a server and check the caller's permission on it (owner, admin, or subuser with the permission). */
export async function serverAccess(req: Request, perm: string | null): Promise<ServerRow & { _perms: string[] }> {
  const u = req.user; if (!u) throw new HttpError(401, 'Authentication required');
  const s = await getServer(Number(req.params.id ?? req.params.serverId));
  if (!scopeOk(req, perm?.startsWith('control') || perm?.endsWith('.read') ? 'servers.read' : 'servers.write') && perm) throw new HttpError(403, 'API key lacks servers scope');
  let perms: string[];
  if (s.owner_id === u.id || hasPerm(u, 'admin.servers')) perms = [...SERVER_PERMISSIONS];
  else {
    const su: any = await one('SELECT permissions FROM server_subusers WHERE server_id = ? AND user_id = ?', [s.id, u.id]);
    if (!su) throw new HttpError(404, 'Server not found');
    perms = parse(su.permissions, []);
  }
  if (perm && !perms.includes(perm)) throw new HttpError(403, `Missing server permission: ${perm}`);
  if (s.state === 'deleting' && perm && !perm.endsWith('.read')) throw new HttpError(409, 'Server is being deleted');
  return Object.assign(s, { _perms: perms });
}
export function assertWritable(s: ServerRow) {
  if (s.suspended_at) throw new HttpError(403, `Server is suspended${s.suspension_reason ? `: ${s.suspension_reason}` : ''}`);
}
