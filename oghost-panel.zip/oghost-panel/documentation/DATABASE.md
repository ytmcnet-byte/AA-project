# Database

OGHOST PANEL uses MariaDB (10.6+) or MySQL (8.0+) with InnoDB and `utf8mb4`.

## Create the database

Run as a MySQL administrator (this is the only step that needs database admin rights; it does not need OS root):

```sql
CREATE DATABASE oghost CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'oghost'@'127.0.0.1' IDENTIFIED BY 'change-me';
GRANT ALL PRIVILEGES ON oghost.* TO 'oghost'@'127.0.0.1';
FLUSH PRIVILEGES;
```

Put the credentials into `.env` (`DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USER`, `DB_PASSWORD`, or `DB_SOCKET`).

## Migrations

```bash
node dist/panel.mjs migrate   # applies database/migrations/*.sql in order, recorded in the `migrations` table
node dist/panel.mjs seed      # idempotent: roles, permissions, eggs, store plans, default settings
```

| Migration | Contents |
| --- | --- |
| `001_core.sql` | roles, users, sessions, email tokens, API keys, audit logs, settings, notifications, announcements, jobs |
| `002_infrastructure.sql` | locations, nodes, node stats, eggs, servers, allocations, subusers, activity, stats, backups, schedules, database hosts, server databases |
| `003_security_drive.sql` | security scans, incidents, appeals, trusted software; Drive connections, OAuth states, backup configs, Drive backups |
| `004_store_extensions.sql` | products, plans, coupons, services, orders, invoices, payments, webhook events, plugin installs/repositories, extensions, extension storage, outgoing webhooks, tickets |
| `005_reservations.sql` | `node_id_reservations`, used to keep IDs reserved during deletion and transfers |

## Server ID allocation

Each node has its own numeric server-ID space. Allocation runs inside a transaction that locks the node's row, picks the lowest ID that is not used by a server and not held in `node_id_reservations`, and inserts the server, all in one step. A unique key on `(node_id, node_server_id)` makes duplicates impossible even if two requests race. A deleted server's ID only becomes free after the agent confirms its directory was removed. While a deletion is incomplete the server stays in the `deleting` state, its ID stays reserved, and an admin can retry or recover it. Transactions are retried automatically on deadlocks and snapshot conflicts (errno 1213/1020/1205).

## Indexing

Lookup columns (foreign keys, status/state columns, `next_run_at` for jobs and schedules, `(gateway, event_id)` for webhooks, `(gateway, gateway_payment_id)` for payments, `(node_id, port)` for allocations) are indexed in the migrations.

## Secrets at rest

Gateway secrets, SMTP password, Google client secret, node secrets and Drive refresh tokens are encrypted with AES-256-GCM using a key derived from `APP_KEY`. Back up `APP_KEY` together with the database, because without it those values cannot be decrypted.

## Backing up the panel database

```bash
mysqldump --single-transaction -u oghost -p oghost | gzip > oghost-$(date +%F).sql.gz
```

Game-server data lives on the nodes (`DATA_ROOT/nodes/<id>/servers/<id>/`) and is not in the database.
