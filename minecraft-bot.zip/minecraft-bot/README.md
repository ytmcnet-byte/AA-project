# 🤖 AI Minecraft Bot — SHIVAM_BRO2234

Groq AI se powered full Minecraft player bot.

## Setup

### 1. Server configure karo
`config.json` mein apna Aternos server host dalo:
```json
{
  "server": {
    "host": "your-server.aternos.me",
    "port": 25565,
    "version": "1.20.1"
  }
}
```

### 2. Bot chalaao
Workflow "Minecraft AI Bot" se start karo.

## Bot kya karta hai

### Autonomous mode (jab koi command nahi deta)
- ⛏️ Mining: diamond, iron, coal automatically dhundha karta hai
- 🍖 Eating: bhuk lagne par khud khata hai
- 🗺️ Exploring: nayi jagahein dhundha karta hai  
- 🏠 Building: raat ko shelter banata hai
- 🛡️ Survival: health kam ho to safe rehta hai

### Owner commands (SHIVAM_BRO2234 ke liye)
| Command | Kya karta hai |
|---------|---------------|
| `mine diamond` | Diamond ore dhundh ke khoda |
| `mine iron_ore` | Iron ore khoda |
| `craft torch` | Torch craft kiya |
| `craft wooden_pickaxe` | Wooden pickaxe banaya |
| `follow` | Tumhare peche aata hai |
| `stop follow` | Follow band kar deta hai |
| `come` | Tumhare paas aata hai |
| `stop` | Sab kuch band kar deta hai |
| `start` | Wapas autonomous mode mein |
| `inv` | Inventory dikhata hai |
| `status` | HP, food, position |
| `kha` | Khana khata hai |
| `explore` | Random direction mein ghoomta hai |
| Koi bhi sentence | AI se process hota hai |

## Config options
- `decisionInterval`: Kitne milliseconds mein AI decision lega (default: 30000 = 30 sec)
- `mineRadius`: Kitne blocks door tak mine karega
- `followDistance`: Follow mein kitne blocks door rehega
