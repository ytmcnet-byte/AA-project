# Installing OGHOST PANEL

OGHOST PANEL runs as a normal Linux user. The installer never calls `sudo` and refuses to run as root unless you pass `--allow-root`, which is not recommended. Steps that really need a host administrator, such as enabling systemd lingering, opening firewall ports or setting up kernel quotas, are printed as instructions rather than run.

## Requirements

| Component | Version / notes |
| --- | --- |
| OS | Linux, AMD64 (x86_64) or ARM64 (aarch64) |
| Node.js | 20 or newer (install under your user with nvm or the official tarball, no root needed) |
| Database | MariaDB 10.6+ or MySQL 8.0+ (local or remote) |
| Java (agents) | Any JDK/JRE the servers need: 8, 11, 16, 17, 21, 22, 25+. The agent detects installations; the installer can download Temurin into `~/java` |
| Build tools (agents, optional) | `gcc` and `make` to build `cpulimit` into `~/bin` |
| openssl (agents) | To create the agent's TLS certificate |

## Panel: installer

```bash
tar xf oghost-panel.tar.gz   # or unzip oghost-panel.zip
cd oghost-panel
bash installer/install.sh
```

The installer will:

1. Check the architecture, Node.js version and that you are not root.
2. Run `npm ci` and build the backend (`dist/panel.mjs`, `dist/agent.mjs`) and the frontend.
3. Ask for APP_URL, port and database details and write `.env` with a freshly generated `APP_KEY`.
4. Print the SQL to create the database and user. If you have a MySQL admin account it can optionally run that SQL for you.
5. Run migrations and seed data (roles, eggs, store plans, default settings).
6. Create the first Super Admin account.
7. Install a `systemd --user` unit, or fall back to `scripts/oghost.sh` (nohup) with a crontab `@reboot` entry.

Non-interactive install: export `APP_URL PORT DB_HOST DB_PORT DB_NAME DB_USER DB_PASSWORD ADMIN_EMAIL ADMIN_USERNAME ADMIN_PASSWORD` and run `bash installer/install.sh --yes`.

Options: `--agent`, `--yes`, `--no-service`, `--skip-build`, `--allow-root`, `--help`.

## Panel: manual install

```bash
npm ci
npm run build                       # backend + frontend
cp .env.example .env
node dist/panel.mjs keygen          # paste the output into APP_KEY in .env
# create the database (see DATABASE.md), then:
node dist/panel.mjs migrate
node dist/panel.mjs seed
ADMIN_EMAIL=you@example.com ADMIN_USERNAME=admin ADMIN_PASSWORD='a-long-password' node dist/panel.mjs create-admin
bash scripts/oghost.sh start panel  # or: node dist/panel.mjs serve
```

Open `APP_URL` and sign in. Then configure SMTP, Firebase (Google sign-in), payment gateways and Google Drive in **Admin → Settings**.

## Adding a node

1. In **Admin → Locations** create a location, then in **Admin → Nodes** create the node (FQDN, agent port, scheme, memory/disk totals) and add port allocations.
2. Open the node and copy the agent configuration it shows (NODE_ID, NODE_SECRET, PANEL_URL).
3. On the game host, as a normal user:

```bash
cd oghost-panel
bash installer/install.sh --agent
```

The agent installer writes `~/oghost-agent/agent.env` (see `agent.env.example`), creates a self-signed TLS certificate, can download a Temurin JRE into `~/java` and build `cpulimit` into `~/bin/cpulimit`, and starts the agent. The node turns **online** in the panel after its first heartbeat.

If the agent uses a self-signed certificate, copy `~/oghost-agent/tls/cert.pem` to the panel host and set `NODE_CA_FILE=/path/to/cert.pem` in the panel's `.env` (the launcher exports it as `NODE_EXTRA_CA_CERTS`). Without it the panel correctly refuses the connection.

## Updating

```bash
bash scripts/oghost.sh stop panel
# replace files with the new release, keep .env and .server/
npm ci && npm run build
node dist/panel.mjs migrate
bash scripts/oghost.sh start panel
```

Agents stop game servers gracefully on shutdown. Update agents the same way with `bash installer/install.sh --agent --skip-build` after copying the new `dist/`.

## Multiple Java versions (java8, java17, ...)

The agent finds every Java on the node automatically, including numbered commands such as `java8`, `java11`, `java17`, `java21`, `java-17` or `java_21`. These can be binaries, symlinks or small wrapper scripts. It looks in:
- `PATH`, `~/bin` and `~/.local/bin`
- `/usr/lib/jvm`, `/opt`, `~/java`, `~/.sdkman` and `~/.jdks`
- every entry in `JAVA_SEARCH_PATHS`

Each candidate is run with `-version` to read its real version, so the name itself does not matter.

If your commands live somewhere else, add that folder, or the command files themselves, to `agent.env`:

```
JAVA_SEARCH_PATHS=/usr/local/bin:/home/you/bin/java8:/home/you/bin/java17
```

Run `which java8 java17` to see where they are. A shell **alias** in `.bashrc` (`alias java8=...`) is not a file and cannot be detected. In that case point `JAVA_SEARCH_PATHS` at the real Java folder that the alias uses.

Restart the agent after changing this (`bash scripts/oghost.sh restart agent`). The list refreshes every 10 minutes.

Which Java a server uses:
- **Automatic (default):** the lowest installed Java that fits that server's Minecraft version and egg. For example 1.8–1.16 uses Java 8 (or 11), 1.17–1.20.4 uses 17, 1.20.5–1.21.x uses 21, and 26.x uses 25. The console shows a line like `Using Java 17 (/usr/bin/java17)`.
- **Manual:** **Server → Startup → Java** lets you pick any detected Java for that server.
