import express, { Router } from 'express';
import { razorpayWebhook, stripeWebhook, cashfreeWebhook } from '../services/gateways';

/** Payment gateway webhooks. Mounted BEFORE the JSON body parser: signatures are computed over the raw body. */
export const paymentWebhooksRouter = Router();
paymentWebhooksRouter.use(express.raw({ type: '*/*', limit: '1mb' }));
const raw = (b: unknown) => (Buffer.isBuffer(b) ? b : Buffer.from(''));
paymentWebhooksRouter.post('/razorpay', async (req, res) => { await razorpayWebhook(raw(req.body), String(req.get('x-razorpay-signature') || ''), String(req.get('x-razorpay-event-id') || '')); res.json({ ok: true }); });
paymentWebhooksRouter.post('/stripe', async (req, res) => { await stripeWebhook(raw(req.body), String(req.get('stripe-signature') || '')); res.json({ received: true }); });
paymentWebhooksRouter.post('/cashfree', async (req, res) => { await cashfreeWebhook(raw(req.body), String(req.get('x-webhook-signature') || ''), String(req.get('x-webhook-timestamp') || '')); res.json({ ok: true }); });
