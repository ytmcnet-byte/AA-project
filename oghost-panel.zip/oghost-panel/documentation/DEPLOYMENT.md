# Non-root deployment

Everything here runs as an unprivileged Linux user. OGHOST does not use Docker, Docker Compose or any container runtime.

## Layout

```
~/oghost-panel/                 panel code, .env, logs/, .server/ (panel metadata, uploads)
~/oghost-agent/agent.env        agent configuration (on each game host)
~/oghost-agent/.server/nodes/<NODE_ID>/servers/<server id>/   game server files (numeric IDs only)
~/oghost-agent/.server/nodes/<NODE_ID>/{backups,temporary,metadata}/
~/java/                         optional user-local JREs/JDKs
~/bin/cpulimit                  optional best-effort CPU throttling
```

## Running the services

### Option A: systemd --user (preferred when available)

The installer writes `~/.config/systemd/user/oghost-panel.service` (or `oghost-agent.service`) that runs `scripts/run.sh panel|agent`.

```bash
systemctl --user daemon-reload
systemctl --user enable --now oghost-panel
journalctl --user -u oghost-panel -f
```

To keep user services running after logout and across reboots, a host administrator must run this once (the installer only prints it):

```bash
loginctl enable-linger <your-user>
```

Note: this path could not be exercised in our test environment (no user D-Bus). Option B was tested.

### Option B: nohup helper (works everywhere)

```bash
bash scripts/oghost.sh start panel     # start|stop|restart|status, panel|agent
bash scripts/oghost.sh status agent
```

The helper uses `setsid` + `nohup` and pid files. Panel logs go to `<root>/logs/`, agent logs to `~/oghost-agent/logs/`. For start on boot, add a crontab entry (the installer offers to do this):

```
@reboot bash /home/<user>/oghost-panel/scripts/oghost.sh start panel
```

## Reverse proxy and TLS (panel)

Run the panel on `HOST=127.0.0.1`, `PORT=8080` and put a reverse proxy in front. WebSockets (`/socket.io/`) must be proxied.

### Caddy (automatic HTTPS)

```
panel.example.com {
    reverse_proxy 127.0.0.1:8080
}
```

### nginx

```nginx
server {
    listen 443 ssl http2;
    server_name panel.example.com;
    ssl_certificate     /etc/letsencrypt/live/panel.example.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/panel.example.com/privkey.pem;
    client_max_body_size 512m;          # file uploads
    location / {
        proxy_pass http://127.0.0.1:8080;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_read_timeout 3600s;
    }
}
```

Set `APP_URL=https://panel.example.com` and `TRUST_PROXY=loopback`. Binding ports below 1024 needs root or `CAP_NET_BIND_SERVICE`, so the proxy is usually run by the host administrator, or you can use a user-level Caddy on a high port.

## Panel ↔ agent security

- The panel calls agents over HTTPS (`AGENT_TLS_CERT` / `AGENT_TLS_KEY`). Requests carry HMAC-signed tokens (60 s lifetime, 120 s for console WebSocket tokens, unique token ID) scoped to one node and, where relevant, one server.
- Agents call the panel (heartbeat, events) with the node secret, and the panel verifies them.
- Self-signed certificates: set `NODE_CA_FILE` on the panel (trust the agent cert) and `PANEL_CA` on the agent (trust the panel cert if needed). `scripts/run.sh` exports them as `NODE_EXTRA_CA_CERTS`.
- Agents only expose a fixed API (power, files, backups, versions and so on). They never run shell commands sent by users. Startup commands are rendered into an argument vector from the egg template and validated variables, and they are run without a shell.

## Firewall

The host administrator must open:
- the panel's HTTPS port (443) on the panel host
- each agent's `AGENT_PORT` (default 8443), ideally only reachable from the panel host's IP
- the game ports listed in the node's allocations

The panel's **Allocations** view shows which ports were actually reachable from the panel's network (TCP connect test). UDP ports, such as Bedrock's, cannot be verified this way and are labelled as such.

## ARM64

The panel, the agent and Java servers run on ARM64. Bedrock Dedicated Server is only published by Mojang for x86_64 Linux, so the Bedrock egg refuses to install on ARM64 nodes instead of failing at runtime.
