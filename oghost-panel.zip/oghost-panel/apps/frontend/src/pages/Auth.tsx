import { useEffect, useState, type FormEvent, type ReactNode } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { api } from '../lib/api';
import { useAuth } from '../lib/auth';
import { googleIdToken } from '../lib/firebase';
import { ErrorBox, Logo, Notice, Spinner } from '../components/ui';
import { Footer } from '../components/Layout';

function Shell({ title, subtitle, children }: { title: string; subtitle?: ReactNode; children: ReactNode }) {
  return (
    <div className="flex min-h-full flex-col bg-[radial-gradient(ellipse_at_top,rgba(220,38,38,0.18),transparent_55%)]">
      <div className="flex flex-1 items-center justify-center px-4 py-10">
        <div className="w-full max-w-md">
          <div className="mb-6 flex flex-col items-center text-center"><Logo size={44} /><p className="mt-3 text-sm text-ink-400">Powering the Next Generation of Game Hosting.</p></div>
          <div className="card p-6 sm:p-7"><h1 className="text-lg font-bold text-white">{title}</h1>{subtitle && <p className="mt-1 text-sm text-ink-400">{subtitle}</p>}<div className="mt-5">{children}</div></div>
        </div>
      </div>
      <Footer />
    </div>
  );
}
function GoogleButton({ label = 'Continue with Google' }: { label?: string }) {
  const { config, refresh } = useAuth(); const [busy, setBusy] = useState(false); const [err, setErr] = useState<string | null>(null); const nav = useNavigate();
  if (!config?.firebase) return null;
  const go = async () => {
    setBusy(true); setErr(null);
    try { const idToken = await googleIdToken(config.firebase!); const r = await api('POST', '/api/auth/firebase', { idToken }); await refresh(); nav(r.twoFactorRequired ? '/login/2fa' : '/'); }
    catch (e: any) { if (!String(e.code || '').includes('popup-closed')) setErr(e.message); } finally { setBusy(false); }
  };
  return <><button type="button" className="btn-secondary w-full" onClick={go} disabled={busy}>{busy ? <Spinner /> : <svg className="h-4 w-4" viewBox="0 0 48 48"><path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3C33.7 32.7 29.2 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34 6.1 29.3 4 24 4 12.9 4 4 12.9 4 24s8.9 20 20 20 20-8.9 20-20c0-1.3-.1-2.4-.4-3.5z" /><path fill="#FF3D00" d="m6.3 14.7 6.6 4.8C14.7 15.1 19 12 24 12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34 6.1 29.3 4 24 4 16.3 4 9.7 8.3 6.3 14.7z" /><path fill="#4CAF50" d="M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2C29.2 35.1 26.7 36 24 36c-5.2 0-9.6-3.3-11.3-7.9l-6.5 5C9.5 39.6 16.2 44 24 44z" /><path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.8 2.2-2.2 4.2-4.1 5.6l6.2 5.2C37 39.2 44 34 44 24c0-1.3-.1-2.4-.4-3.5z" /></svg>}{label}</button>{err && <div className="mt-2"><ErrorBox error={err} /></div>}<div className="my-4 flex items-center gap-3 text-xs text-ink-400"><div className="h-px flex-1 bg-ink-700" />or<div className="h-px flex-1 bg-ink-700" /></div></>;
}

export function Login() {
  const { refresh, config } = useAuth(); const nav = useNavigate(); const [login, setLogin] = useState(''); const [password, setPassword] = useState(''); const [err, setErr] = useState<string | null>(null); const [busy, setBusy] = useState(false);
  const submit = async (e: FormEvent) => { e.preventDefault(); setBusy(true); setErr(null); try { const r = await api('POST', '/api/auth/login', { login, password }); await refresh(); nav(r.twoFactorRequired ? '/login/2fa' : '/'); } catch (e: any) { setErr(e.message); } finally { setBusy(false); } };
  return (
    <Shell title="Sign in" subtitle="Welcome back. Sign in to manage your servers.">
      <GoogleButton />
      <form onSubmit={submit} className="space-y-4">
        <div><label className="label">Email or username</label><input className="input" value={login} onChange={e => setLogin(e.target.value)} autoComplete="username" required autoFocus /></div>
        <div><div className="flex items-center justify-between"><label className="label">Password</label><Link to="/forgot-password" className="link mb-1.5 text-xs">Forgot password?</Link></div><input className="input" type="password" value={password} onChange={e => setPassword(e.target.value)} autoComplete="current-password" required /></div>
        {err && <ErrorBox error={err} />}
        <button className="btn-primary w-full" disabled={busy}>{busy && <Spinner />}Sign in</button>
      </form>
      {config?.registration && <p className="mt-5 text-center text-sm text-ink-400">No account? <Link to="/register" className="link">Create one</Link></p>}
    </Shell>
  );
}
export function TwoFactor() {
  const { refresh, logout } = useAuth(); const nav = useNavigate(); const [code, setCode] = useState(''); const [err, setErr] = useState<string | null>(null); const [busy, setBusy] = useState(false);
  const submit = async (e: FormEvent) => { e.preventDefault(); setBusy(true); setErr(null); try { await api('POST', '/api/auth/login/2fa', { code }); await refresh(); nav('/'); } catch (e: any) { setErr(e.message); } finally { setBusy(false); } };
  return (
    <Shell title="Two-factor authentication" subtitle="Enter the 6-digit code from your authenticator app, or one of your recovery codes.">
      <form onSubmit={submit} className="space-y-4">
        <input className="input text-center font-mono text-lg tracking-[0.3em]" value={code} onChange={e => setCode(e.target.value)} inputMode="numeric" autoComplete="one-time-code" autoFocus required maxLength={20} />
        {err && <ErrorBox error={err} />}
        <button className="btn-primary w-full" disabled={busy}>{busy && <Spinner />}Verify</button>
        <button type="button" className="btn-ghost w-full" onClick={async () => { await logout(); nav('/login'); }}>Cancel</button>
      </form>
    </Shell>
  );
}
export function Register() {
  const { refresh, config } = useAuth(); const nav = useNavigate(); const [f, setF] = useState({ email: '', username: '', password: '', confirm: '' }); const [err, setErr] = useState<string | null>(null); const [busy, setBusy] = useState(false);
  const submit = async (e: FormEvent) => { e.preventDefault(); if (f.password !== f.confirm) return setErr('Passwords do not match'); setBusy(true); setErr(null); try { await api('POST', '/api/auth/register', { email: f.email, username: f.username, password: f.password }); await refresh(); nav('/'); } catch (e: any) { setErr(e.message); } finally { setBusy(false); } };
  if (config && !config.registration) return <Shell title="Registration closed"><Notice kind="warn">New registrations are currently disabled by the administrator.</Notice><Link to="/login" className="btn-secondary mt-4 w-full">Back to sign in</Link></Shell>;
  return (
    <Shell title="Create your account" subtitle="Start hosting in minutes.">
      <GoogleButton label="Sign up with Google" />
      <form onSubmit={submit} className="space-y-4">
        <div><label className="label">Email</label><input className="input" type="email" value={f.email} onChange={e => setF({ ...f, email: e.target.value })} autoComplete="email" required /></div>
        <div><label className="label">Username</label><input className="input" value={f.username} onChange={e => setF({ ...f, username: e.target.value })} pattern="[a-zA-Z0-9_.\-]{3,32}" title="3-32 letters, digits, _ . -" autoComplete="username" required /></div>
        <div className="grid gap-4 sm:grid-cols-2"><div><label className="label">Password</label><input className="input" type="password" value={f.password} onChange={e => setF({ ...f, password: e.target.value })} autoComplete="new-password" minLength={10} required /></div><div><label className="label">Confirm</label><input className="input" type="password" value={f.confirm} onChange={e => setF({ ...f, confirm: e.target.value })} autoComplete="new-password" required /></div></div>
        <p className="hint">At least 10 characters with letters and numbers.</p>
        {err && <ErrorBox error={err} />}
        <button className="btn-primary w-full" disabled={busy}>{busy && <Spinner />}Create account</button>
      </form>
      <p className="mt-5 text-center text-sm text-ink-400">Already registered? <Link to="/login" className="link">Sign in</Link></p>
    </Shell>
  );
}
export function ForgotPassword() {
  const [email, setEmail] = useState(''); const [msg, setMsg] = useState<string | null>(null); const [err, setErr] = useState<string | null>(null); const [busy, setBusy] = useState(false);
  const submit = async (e: FormEvent) => { e.preventDefault(); setBusy(true); setErr(null); try { const r = await api('POST', '/api/auth/forgot-password', { email }); setMsg(r.message); } catch (e: any) { setErr(e.message); } finally { setBusy(false); } };
  return <Shell title="Reset your password" subtitle="We will email you a reset link."><form onSubmit={submit} className="space-y-4"><input className="input" type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="you@example.com" required />{msg && <Notice kind="success">{msg}</Notice>}{err && <ErrorBox error={err} />}<button className="btn-primary w-full" disabled={busy}>{busy && <Spinner />}Send reset link</button><Link to="/login" className="btn-ghost w-full">Back to sign in</Link></form></Shell>;
}
export function ResetPassword() {
  const [sp] = useSearchParams(); const nav = useNavigate(); const [p, setP] = useState(''); const [err, setErr] = useState<string | null>(null); const [busy, setBusy] = useState(false);
  const submit = async (e: FormEvent) => { e.preventDefault(); setBusy(true); setErr(null); try { await api('POST', '/api/auth/reset-password', { token: sp.get('token') || '', password: p }); nav('/login'); } catch (e: any) { setErr(e.message); } finally { setBusy(false); } };
  return <Shell title="Choose a new password"><form onSubmit={submit} className="space-y-4"><input className="input" type="password" value={p} onChange={e => setP(e.target.value)} minLength={10} autoComplete="new-password" required placeholder="New password" />{err && <ErrorBox error={err} />}<button className="btn-primary w-full" disabled={busy}>{busy && <Spinner />}Update password</button></form></Shell>;
}
export function VerifyEmail() {
  const [sp] = useSearchParams(); const { refresh, user } = useAuth(); const [state, setState] = useState<'pending' | 'ok' | string>('pending');
  useEffect(() => { api('POST', '/api/auth/verify-email', { token: sp.get('token') || '' }).then(() => { setState('ok'); refresh(); }).catch(e => setState(e.message)); }, []);
  return <Shell title="Email verification">{state === 'pending' ? <div className="flex items-center gap-2 text-sm"><Spinner /> Verifying…</div> : state === 'ok' ? <Notice kind="success">Your email address is verified.</Notice> : <ErrorBox error={state} />}<Link to={user ? '/' : '/login'} className="btn-secondary mt-4 w-full">Continue</Link></Shell>;
}
