CREATE TABLE product_categories (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  slug VARCHAR(100) NOT NULL UNIQUE,
  description TEXT NULL,
  sort INT NOT NULL DEFAULT 0,
  visible TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE products (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  category_id INT UNSIGNED NOT NULL,
  name VARCHAR(100) NOT NULL,
  slug VARCHAR(100) NOT NULL UNIQUE,
  type ENUM('minecraft','vps','game','custom','addon_storage','addon_ram','addon_cpu') NOT NULL,
  description TEXT NULL,
  visible TINYINT(1) NOT NULL DEFAULT 1,
  sort INT NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_prod_cat FOREIGN KEY (category_id) REFERENCES product_categories(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE plans (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  product_id INT UNSIGNED NOT NULL,
  name VARCHAR(100) NOT NULL,
  description TEXT NULL,
  price_cents INT UNSIGNED NOT NULL,
  currency CHAR(3) NOT NULL DEFAULT 'INR',
  billing_cycle ENUM('monthly','quarterly','semiannual','annual','one_time') NOT NULL DEFAULT 'monthly',
  setup_fee_cents INT UNSIGNED NOT NULL DEFAULT 0,
  memory_mb INT UNSIGNED NOT NULL DEFAULT 0,
  cpu_percent INT UNSIGNED NOT NULL DEFAULT 0,
  disk_mb INT UNSIGNED NOT NULL DEFAULT 0,
  `databases` INT UNSIGNED NOT NULL DEFAULT 0,
  backups INT UNSIGNED NOT NULL DEFAULT 1,
  allocations INT UNSIGNED NOT NULL DEFAULT 1,
  egg_id INT UNSIGNED NULL,
  node_id INT UNSIGNED NULL,
  location_id INT UNSIGNED NULL,
  stock INT NULL,
  visible TINYINT(1) NOT NULL DEFAULT 1,
  sort INT NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_plan_prod FOREIGN KEY (product_id) REFERENCES products(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE coupons (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  code VARCHAR(50) NOT NULL UNIQUE,
  type ENUM('percent','fixed') NOT NULL,
  value INT UNSIGNED NOT NULL,
  max_uses INT UNSIGNED NULL,
  uses INT UNSIGNED NOT NULL DEFAULT 0,
  expires_at DATETIME NULL,
  plan_ids JSON NULL,
  recurring TINYINT(1) NOT NULL DEFAULT 0,
  active TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE services (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  plan_id INT UNSIGNED NOT NULL,
  server_id INT UNSIGNED NULL,
  status ENUM('pending','active','suspended','cancelled','terminated') NOT NULL DEFAULT 'pending',
  price_cents INT UNSIGNED NOT NULL,
  currency CHAR(3) NOT NULL,
  billing_cycle VARCHAR(16) NOT NULL,
  config JSON NULL,
  next_due_at DATETIME NULL,
  cancel_at_period_end TINYINT(1) NOT NULL DEFAULT 0,
  reminder_sent_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  cancelled_at DATETIME NULL,
  INDEX idx_services_user (user_id), INDEX idx_services_due (status, next_due_at),
  CONSTRAINT fk_svc_user FOREIGN KEY (user_id) REFERENCES users(id),
  CONSTRAINT fk_svc_plan FOREIGN KEY (plan_id) REFERENCES plans(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE orders (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  uuid CHAR(36) NOT NULL UNIQUE,
  user_id INT UNSIGNED NOT NULL,
  plan_id INT UNSIGNED NOT NULL,
  service_id INT UNSIGNED NULL,
  coupon_id INT UNSIGNED NULL,
  kind ENUM('new','renewal','upgrade','downgrade') NOT NULL DEFAULT 'new',
  status ENUM('pending','paid','active','cancelled','failed','refunded') NOT NULL DEFAULT 'pending',
  amount_cents INT UNSIGNED NOT NULL,
  currency CHAR(3) NOT NULL,
  config JSON NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_orders_user (user_id), INDEX idx_orders_status (status),
  CONSTRAINT fk_ord_user FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE invoices (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  number VARCHAR(32) NOT NULL UNIQUE,
  user_id INT UNSIGNED NOT NULL,
  order_id INT UNSIGNED NULL,
  service_id INT UNSIGNED NULL,
  status ENUM('unpaid','paid','cancelled','refunded') NOT NULL DEFAULT 'unpaid',
  subtotal_cents INT UNSIGNED NOT NULL,
  discount_cents INT UNSIGNED NOT NULL DEFAULT 0,
  total_cents INT UNSIGNED NOT NULL,
  currency CHAR(3) NOT NULL,
  items JSON NOT NULL,
  due_at DATETIME NULL,
  paid_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_inv_user (user_id), INDEX idx_inv_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE payments (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  invoice_id INT UNSIGNED NOT NULL,
  user_id INT UNSIGNED NOT NULL,
  gateway VARCHAR(20) NOT NULL,
  gateway_order_id VARCHAR(191) NULL,
  gateway_payment_id VARCHAR(191) NULL,
  amount_cents INT UNSIGNED NOT NULL,
  refunded_cents INT UNSIGNED NOT NULL DEFAULT 0,
  currency CHAR(3) NOT NULL,
  status ENUM('created','pending','awaiting_approval','succeeded','failed','refunded','partially_refunded') NOT NULL DEFAULT 'created',
  reference VARCHAR(100) NULL,
  failure_reason VARCHAR(500) NULL,
  raw JSON NULL,
  approved_by INT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_gw_payment (gateway, gateway_payment_id),
  INDEX idx_pay_invoice (invoice_id), INDEX idx_pay_gworder (gateway, gateway_order_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE webhook_events (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  gateway VARCHAR(20) NOT NULL,
  event_id VARCHAR(191) NOT NULL,
  type VARCHAR(100) NULL,
  payload JSON NOT NULL,
  processed_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_wh (gateway, event_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE plugin_installs (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  server_id INT UNSIGNED NOT NULL,
  source VARCHAR(20) NOT NULL,
  project_id VARCHAR(100) NOT NULL,
  project_name VARCHAR(200) NOT NULL,
  version_id VARCHAR(100) NOT NULL,
  version_name VARCHAR(100) NOT NULL,
  file VARCHAR(200) NOT NULL,
  latest_version_id VARCHAR(100) NULL,
  latest_version_name VARCHAR(100) NULL,
  checked_at DATETIME NULL,
  installed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_pi (server_id, source, project_id),
  CONSTRAINT fk_pi_server FOREIGN KEY (server_id) REFERENCES servers(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE plugin_repositories (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  type ENUM('modrinth','hangar','spiget','github','custom') NOT NULL,
  base_url VARCHAR(300) NULL,
  download_hosts JSON NULL,
  enabled TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE extensions (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  identifier VARCHAR(64) NOT NULL UNIQUE,
  name VARCHAR(100) NOT NULL,
  version VARCHAR(32) NOT NULL,
  enabled TINYINT(1) NOT NULL DEFAULT 0,
  settings JSON NULL,
  manifest JSON NOT NULL,
  granted_permissions JSON NULL,
  installed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE extension_storage (
  extension_id INT UNSIGNED NOT NULL,
  `key` VARCHAR(150) NOT NULL,
  value JSON NOT NULL,
  PRIMARY KEY (extension_id, `key`),
  CONSTRAINT fk_es_ext FOREIGN KEY (extension_id) REFERENCES extensions(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE outgoing_webhooks (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  url VARCHAR(500) NOT NULL,
  secret_enc TEXT NOT NULL,
  events JSON NOT NULL,
  enabled TINYINT(1) NOT NULL DEFAULT 1,
  last_status VARCHAR(100) NULL,
  last_delivery_at DATETIME NULL,
  created_by INT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
