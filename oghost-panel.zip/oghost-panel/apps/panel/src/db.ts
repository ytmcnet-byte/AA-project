import fs from 'node:fs';
import path from 'node:path';
import mysql, { type Pool, type PoolConnection, type ResultSetHeader } from 'mysql2/promise';
import { config } from './config';

export const pool: Pool = mysql.createPool({ ...config.db, connectionLimit: 20, waitForConnections: true, dateStrings: false, timezone: 'Z', supportBigNumbers: true, bigNumberStrings: false, charset: 'utf8mb4',
  // JSON columns are always returned as raw JSON text and decoded by parse(). Without this, MySQL 8 (and MariaDB with
  // extended metadata) pre-decode them, which made JSON string values such as "abc" fail a second JSON.parse.
  typeCast: (field: any, next: () => unknown) => (field.type === 'JSON' || field.extendedFormat === 'json' ? field.string('utf8') : next()) });
type Exec = Pool | PoolConnection;
// All DATETIME values are UTC: the driver converts JS dates with timezone 'Z' and every session uses +00:00 for NOW().
(pool as any).pool.on('connection', (c: any) => { c.query("SET time_zone = '+00:00'"); });
export async function q<T = any>(sql: string, params: any[] = [], conn: Exec = pool): Promise<T[]> {
  const [rows] = await conn.query(sql, params); return rows as T[];
}
export async function one<T = any>(sql: string, params: any[] = [], conn: Exec = pool): Promise<T | null> { return (await q<T>(sql, params, conn))[0] ?? null; }
export async function exec(sql: string, params: any[] = [], conn: Exec = pool): Promise<ResultSetHeader> { const [r] = await conn.query(sql, params); return r as ResultSetHeader; }
export async function tx<T>(fn: (c: PoolConnection) => Promise<T>): Promise<T> {
  const c = await pool.getConnection();
  // READ COMMITTED: correctness relies on explicit row locks (SELECT ... FOR UPDATE), and every read after a lock sees committed data.
  try { await c.query('SET TRANSACTION ISOLATION LEVEL READ COMMITTED'); await c.beginTransaction(); const r = await fn(c); await c.commit(); return r; }
  catch (e) { await c.rollback().catch(() => {}); throw e; } finally { c.release(); }
}
/** Transaction retried on deadlock (1213) / snapshot-isolation conflicts (1020, MariaDB 11.8+). fn must only touch the database. */
export async function txRetry<T>(fn: (c: PoolConnection) => Promise<T>, attempts = 5): Promise<T> {
  for (let i = 1; ; i++) {
    try { return await tx(fn); }
    catch (e: any) { if (i >= attempts || ![1213, 1020, 1205].includes(e?.errno)) throw e; await new Promise(r => setTimeout(r, 20 * i + Math.random() * 50)); }
  }
}
export const json = (v: unknown) => JSON.stringify(v ?? null);
export const parse = <T = any>(v: any, d: T): T => { if (v == null) return d; if (typeof v === 'object') return v as T; try { return JSON.parse(v); } catch { return d; } };

export async function migrate(log = console.log) {
  await exec('CREATE TABLE IF NOT EXISTS migrations (name VARCHAR(191) PRIMARY KEY, ran_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB');
  const done = new Set((await q<{ name: string }>('SELECT name FROM migrations')).map(r => r.name));
  const files = fs.readdirSync(config.migrationsDir).filter(f => f.endsWith('.sql')).sort();
  for (const f of files) {
    if (done.has(f)) continue;
    const sql = fs.readFileSync(path.join(config.migrationsDir, f), 'utf8');
    const statements = sql.replace(/^\s*--.*$/gm, '').split(/;\s*(?:\n|$)/).map(s => s.trim()).filter(Boolean);
    log(`[migrate] ${f} (${statements.length} statements)`);
    for (const s of statements) await exec(s);
    await exec('INSERT INTO migrations (name) VALUES (?)', [f]);
  }
  log('[migrate] up to date');
}
