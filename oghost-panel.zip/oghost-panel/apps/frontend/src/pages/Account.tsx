import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useApi, useAction, toast } from '../lib/hooks';
import { api, del, patch, post } from '../lib/api';
import { useAuth } from '../lib/auth';
import { googleIdToken } from '../lib/firebase';
import { ago, date } from '../lib/format';
import { Badge, Card, Confirm, Field, Loading, Modal, Notice, PageHeader, Spinner, Table, Tabs, Empty } from '../components/ui';

type T = 'profile' | 'security' | 'sessions' | 'api' | 'notifications' | 'integrations';
export function Account() {
  const [sp] = useSearchParams(); const [tab, setTab] = useState<T>((sp.get('tab') as T) || (sp.get('drive') ? 'integrations' : 'profile'));
  return <><PageHeader title="Account" subtitle="Profile, security and integrations." />
    <Tabs value={tab} onChange={setTab} tabs={[{ id: 'profile', label: 'Profile' }, { id: 'security', label: 'Security' }, { id: 'sessions', label: 'Sessions' }, { id: 'api', label: 'API keys' }, { id: 'notifications', label: 'Notifications' }, { id: 'integrations', label: 'Google & Drive' }]} />
    {tab === 'profile' ? <Profile /> : tab === 'security' ? <Security /> : tab === 'sessions' ? <Sessions /> : tab === 'api' ? <ApiKeys /> : tab === 'notifications' ? <Notifications /> : <Integrations />}</>;
}
function Profile() {
  const { user, refresh } = useAuth(); const { busy, run } = useAction();
  const [p, setP] = useState({ name: user?.name || '', username: user?.username || '' }); const [email, setEmail] = useState(user?.email || ''); const [pw, setPw] = useState('');
  const avatar = (f?: File) => { if (!f) return; if (f.size > 1024 * 1024) return toast('Avatar must be under 1 MB', 'error'); const r = new FileReader(); r.onload = () => run('av', () => post('/api/account/avatar', { dataUrl: r.result }).then(refresh), 'Avatar updated'); r.readAsDataURL(f); };
  return (
    <div className="grid gap-5 lg:grid-cols-2">
      <Card title="Profile">
        <div className="mb-4 flex items-center gap-4">{user?.avatar_url ? <img src={user.avatar_url} className="h-16 w-16 rounded-full object-cover" alt="" /> : <div className="flex h-16 w-16 items-center justify-center rounded-full bg-brand-900 text-xl font-bold">{user?.username[0]?.toUpperCase()}</div>}<label className="btn-secondary btn-sm cursor-pointer">{busy === 'av' && <Spinner />}Change avatar<input type="file" accept="image/png,image/jpeg,image/webp" className="hidden" onChange={e => avatar(e.target.files?.[0])} /></label></div>
        <div className="space-y-3"><Field label="Display name"><input className="input" value={p.name} onChange={e => setP({ ...p, name: e.target.value })} /></Field><Field label="Username"><input className="input" value={p.username} onChange={e => setP({ ...p, username: e.target.value })} /></Field>
          <div className="text-xs text-ink-400">Role: <b>{user?.role_name}</b></div>
          <button className="btn-primary" disabled={!!busy} onClick={() => run('p', () => patch('/api/account/profile', { name: p.name || null, username: p.username }).then(refresh), 'Profile saved')}>Save</button></div>
      </Card>
      <Card title="Email address">
        <div className="space-y-3">{!user?.email_verified && <Notice kind="warn">Your email is not verified. <button className="link" onClick={() => run('rv', () => post('/api/auth/resend-verification'), 'Verification email sent')}>Resend link</button></Notice>}
          <Field label="Email"><input className="input" type="email" value={email} onChange={e => setEmail(e.target.value)} /></Field>
          {user?.has_password && <Field label="Current password"><input className="input" type="password" value={pw} onChange={e => setPw(e.target.value)} /></Field>}
          <button className="btn-primary" disabled={!!busy || email === user?.email} onClick={() => run('e', () => post('/api/account/email', { email, password: pw }).then(refresh), 'Email changed. Check your inbox to verify it.')}>Change email</button></div>
      </Card>
      <DangerZone />
    </div>
  );
}
function DangerZone() {
  const { user, config, refresh } = useAuth(); const { busy, run } = useAction(); const [open, setOpen] = useState(false); const [pw, setPw] = useState('');
  const go = () => run('del', async () => { const b: any = { confirm: 'DELETE' }; if (user?.has_password) b.password = pw; else b.idToken = await googleIdToken(config!.firebase!); await post('/api/account/delete', b); await refresh(); });
  return <Card title="Delete account" className="lg:col-span-2"><p className="mb-3 text-sm text-ink-400">Deletes your account. Active services must be cancelled first; servers you own are removed.</p><button className="btn-danger" onClick={() => setOpen(true)}>Delete my account</button>
    <Confirm open={open} onClose={() => setOpen(false)} title="Delete account permanently" danger phrase="DELETE" confirmLabel="Delete account" busy={!!busy} onConfirm={go}>{user?.has_password ? <Field label="Password"><input type="password" className="input" value={pw} onChange={e => setPw(e.target.value)} /></Field> : <p>You will be asked to sign in with Google again to confirm.</p>}</Confirm></Card>;
}
function Security() {
  const { user, refresh } = useAuth(); const { busy, run } = useAction();
  const [pw, setPw] = useState({ current: '', password: '', confirm: '' }); const [setup, setSetup] = useState<any>(null); const [code, setCode] = useState(''); const [codes, setCodes] = useState<string[] | null>(null); const [dis, setDis] = useState(false);
  return (
    <div className="grid gap-5 lg:grid-cols-2">
      <Card title={user?.has_password ? 'Change password' : 'Set a password'}>
        <div className="space-y-3">{user?.has_password && <Field label="Current password"><input className="input" type="password" value={pw.current} onChange={e => setPw({ ...pw, current: e.target.value })} /></Field>}
          <Field label="New password" hint="At least 10 characters with letters and numbers."><input className="input" type="password" value={pw.password} onChange={e => setPw({ ...pw, password: e.target.value })} /></Field>
          <Field label="Confirm"><input className="input" type="password" value={pw.confirm} onChange={e => setPw({ ...pw, confirm: e.target.value })} /></Field>
          <button className="btn-primary" disabled={!!busy || !pw.password || pw.password !== pw.confirm} onClick={() => run('pw', () => post('/api/account/password', { current: pw.current, password: pw.password }).then(() => { setPw({ current: '', password: '', confirm: '' }); refresh(); }), 'Password updated. Other sessions were signed out.')}>Save password</button></div>
      </Card>
      <Card title="Two-factor authentication" actions={<Badge value={user?.totp_enabled ? 'enabled' : 'disabled'} />}>
        {codes ? <div className="space-y-3"><Notice kind="success">2FA enabled. Store these one-time recovery codes somewhere safe; they are shown only once.</Notice><div className="grid grid-cols-2 gap-2 rounded-lg bg-ink-950 p-3 font-mono text-sm">{codes.map(c => <span key={c}>{c}</span>)}</div><button className="btn-secondary" onClick={() => { navigator.clipboard?.writeText(codes.join('\n')); toast('Copied', 'success'); }}>Copy codes</button><button className="btn-primary ml-2" onClick={() => setCodes(null)}>Done</button></div>
          : user?.totp_enabled ? <><p className="mb-3 text-sm text-ink-400">Your account requires an authenticator code at sign-in.</p><button className="btn-danger" onClick={() => setDis(true)}>Disable 2FA</button></>
          : setup ? <div className="space-y-3"><p className="text-sm text-ink-400">Scan with an authenticator app (Google Authenticator, Aegis, 1Password…), then enter the 6-digit code.</p><img src={setup.qr} alt="2FA QR code" className="h-44 w-44 rounded-lg bg-white p-2" /><div className="break-all font-mono text-xs text-ink-400">{setup.secret}</div><Field label="Code"><input className="input font-mono" inputMode="numeric" maxLength={6} value={code} onChange={e => setCode(e.target.value.replace(/\D/g, ''))} /></Field><button className="btn-primary" disabled={code.length !== 6 || !!busy} onClick={() => run('en', async () => { const r = await post('/api/account/2fa/enable', { code }); setCodes(r.recoveryCodes); setSetup(null); setCode(''); refresh(); })}>Enable</button></div>
          : <button className="btn-primary" disabled={!!busy} onClick={() => run('su', async () => setSetup(await post('/api/account/2fa/setup')))}>Set up 2FA</button>}
        <Modal open={dis} onClose={() => setDis(false)} title="Disable two-factor authentication" footer={<button className="btn-danger" disabled={code.length !== 6 || !!busy} onClick={() => run('d', () => post('/api/account/2fa/disable', { code }).then(() => { setDis(false); setCode(''); refresh(); }), '2FA disabled')}>Disable</button>}><Field label="Current authenticator code"><input className="input font-mono" maxLength={6} value={code} onChange={e => setCode(e.target.value.replace(/\D/g, ''))} /></Field></Modal>
      </Card>
    </div>
  );
}
function Sessions() {
  const { data, loading, reload } = useApi<any>('/api/account/sessions'); const { run } = useAction();
  if (loading || !data) return <Loading />;
  return <Card title="Active sessions" actions={<button className="btn-secondary btn-sm" onClick={() => run('all', () => del('/api/account/sessions').then(reload), 'Other sessions signed out')}>Sign out all others</button>}>
    <Table><thead><tr><th>Device</th><th>IP</th><th>Signed in</th><th>Last active</th><th /></tr></thead><tbody>{data.sessions.map((s: any) => <tr key={s.id}><td className="max-w-xs truncate text-xs" title={s.user_agent}>{s.user_agent || 'Unknown'} {s.current && <Badge value="online" label="this device" />}</td><td className="font-mono text-xs">{s.ip}</td><td>{date(s.created_at)}</td><td>{ago(s.last_seen_at)}</td><td className="text-right">{!s.current && <button className="btn-ghost btn-sm" onClick={() => run(s.id, () => del(`/api/account/sessions/${s.id}`).then(reload), 'Session revoked')}>Revoke</button>}</td></tr>)}</tbody></Table></Card>;
}
function ApiKeys() {
  const { data, loading, reload } = useApi<any>('/api/account/api-keys'); const { busy, run } = useAction();
  const [f, setF] = useState({ name: '', scopes: [] as string[], ips: '', days: '' }); const [created, setCreated] = useState<string | null>(null); const [rm, setRm] = useState<any>(null);
  if (loading || !data) return <Loading />;
  const create = () => run('c', async () => { const r = await post('/api/account/api-keys', { name: f.name, scopes: f.scopes, allowedIps: f.ips.trim() ? f.ips.split(/[\s,]+/).filter(Boolean) : undefined, expiresDays: f.days ? Number(f.days) : undefined }); setCreated(r.key); setF({ name: '', scopes: [], ips: '', days: '' }); reload(); });
  return (
    <div className="grid gap-5 lg:grid-cols-5">
      <Card title="Create key" className="lg:col-span-2"><div className="space-y-3">
        <Field label="Name"><input className="input" value={f.name} onChange={e => setF({ ...f, name: e.target.value })} /></Field>
        <Field label="Scopes"><div className="grid grid-cols-2 gap-1 text-sm">{data.scopes.map((s: string) => <label key={s} className="flex items-center gap-2"><input type="checkbox" checked={f.scopes.includes(s)} onChange={e => setF({ ...f, scopes: e.target.checked ? [...f.scopes, s] : f.scopes.filter(x => x !== s) })} /><span className="font-mono text-xs">{s}</span></label>)}</div></Field>
        <Field label="Allowed IPs" hint="Optional, comma separated. Empty = any IP."><input className="input" value={f.ips} onChange={e => setF({ ...f, ips: e.target.value })} /></Field>
        <Field label="Expires after (days)"><input className="input" type="number" min={1} value={f.days} onChange={e => setF({ ...f, days: e.target.value })} placeholder="Never" /></Field>
        <button className="btn-primary" disabled={!f.name || !f.scopes.length || !!busy} onClick={create}>Create key</button>
        <p className="hint">Use with <code>Authorization: Bearer ogh_…</code>. Keys act with your permissions, limited to the selected scopes. See <a className="link" href="/api/docs" target="_blank" rel="noreferrer">API docs</a>.</p></div></Card>
      <Card title="Your keys" className="lg:col-span-3">{!data.keys.length ? <Empty title="No API keys" /> : <Table><thead><tr><th>Name</th><th>Prefix</th><th>Scopes</th><th>Last used</th><th /></tr></thead><tbody>{data.keys.map((k: any) => { const sc = typeof k.scopes === 'string' ? JSON.parse(k.scopes) : k.scopes; return <tr key={k.id}><td>{k.name}{k.expires_at && <div className="text-xs text-ink-500">expires {date(k.expires_at)}</div>}</td><td className="font-mono text-xs">ogh_{k.prefix}_…</td><td className="text-xs">{sc.join(', ')}</td><td>{ago(k.last_used_at)}</td><td><button className="btn-ghost btn-sm" onClick={() => setRm(k)}>Delete</button></td></tr>; })}</tbody></Table>}</Card>
      <Modal open={!!created} onClose={() => setCreated(null)} title="API key created"><Notice kind="warn">Copy this key now. It will not be shown again.</Notice><div className="mt-3 break-all rounded-lg bg-ink-950 p-3 font-mono text-sm">{created}</div><button className="btn-secondary mt-3" onClick={() => { navigator.clipboard?.writeText(created!); toast('Copied', 'success'); }}>Copy</button></Modal>
      <Confirm open={!!rm} onClose={() => setRm(null)} title="Delete API key" danger onConfirm={() => run('rm', () => del(`/api/account/api-keys/${rm.id}`).then(() => { setRm(null); reload(); }), 'Key deleted')}>Applications using <b>{rm?.name}</b> will stop working immediately.</Confirm>
    </div>
  );
}
function Notifications() {
  const { data, loading, reload } = useApi<any>('/api/account/notifications'); const { run } = useAction();
  if (loading || !data) return <Loading />;
  return <Card title={`Notifications (${data.unread} unread)`} actions={<button className="btn-secondary btn-sm" onClick={() => run('r', () => post('/api/account/notifications/read', {}).then(reload))}>Mark all read</button>}>
    {!data.notifications.length ? <Empty title="No notifications" /> : <div className="divide-y divide-ink-800">{data.notifications.map((n: any) => <div key={n.id} className="flex gap-3 py-3"><span className={`mt-1.5 h-2 w-2 shrink-0 rounded-full ${n.read_at ? 'bg-ink-700' : 'bg-brand-500'}`} /><div className="min-w-0 flex-1"><div className="text-sm font-semibold text-white">{n.link ? <a className="hover:underline" href={n.link}>{n.title}</a> : n.title}</div>{n.body && <div className="whitespace-pre-wrap text-sm text-ink-400">{n.body}</div>}<div className="text-xs text-ink-500">{n.type} · {date(n.created_at)}</div></div></div>)}</div>}</Card>;
}
function Integrations() {
  const { user, config, refresh } = useAuth(); const { busy, run } = useAction(); const [sp, setSp] = useSearchParams();
  const drive = useApi<any>('/api/drive/status');
  useEffect(() => { const d = sp.get('drive'); if (d) { toast(d === 'connected' ? 'Google Drive connected' : d === 'denied' ? 'Google Drive access was denied' : `Google Drive: ${sp.get('message') || 'error'}`, d === 'connected' ? 'success' : 'error'); setSp({ tab: 'integrations' }); } }, []);
  const link = () => run('g', async () => { const idToken = await googleIdToken(config!.firebase!); await api('POST', '/api/auth/firebase', { idToken, link: true }); await refresh(); }, 'Google account linked');
  const c = drive.data?.connection;
  return (
    <div className="grid gap-5 lg:grid-cols-2">
      <Card title="Google sign-in">{!config?.firebase ? <Notice>Google sign-in is not configured by the administrator.</Notice> : user?.firebase_uid ? <><p className="mb-3 text-sm text-ink-400">Your account is linked to Google. You can sign in with the Google button.</p><button className="btn-secondary" disabled={!!busy} onClick={() => run('u', () => post('/api/account/google/unlink').then(refresh), 'Google unlinked')}>Unlink Google</button></> : <><p className="mb-3 text-sm text-ink-400">Link a Google account to sign in with one click. The Google token is verified by the server before linking.</p><button className="btn-primary" disabled={!!busy} onClick={link}>{busy === 'g' && <Spinner />}Link Google account</button></>}</Card>
      <Card title="Google Drive backups">{drive.loading ? <Loading /> : !drive.data?.configured ? <Notice>Google Drive backups are not enabled on this panel.</Notice> : <>
        {c && c.status !== 'revoked' ? <div className="space-y-3 text-sm"><div>Connected as <b>{c.google_email}</b> <Badge value={c.status} /></div>{c.last_error && <Notice kind="error">{c.last_error}</Notice>}<p className="text-ink-400">OGHOST can only access files it created (drive.file scope), stored under <span className="font-mono">OGHOST/Node-N/Server-M</span>. Administrators cannot browse your Drive. Configure schedules per server under Backups.</p><div className="flex gap-2">{c.status !== 'active' && <button className="btn-primary" onClick={() => run('rc', async () => { const r = await post('/api/drive/connect', { returnTo: '/account?tab=integrations' }); window.location.href = r.url; })}>Reconnect</button>}<button className="btn-danger" onClick={() => run('dc', () => post('/api/drive/disconnect').then(drive.reload), 'Google Drive disconnected')}>Disconnect</button></div></div>
          : <div className="space-y-3 text-sm"><p className="text-ink-400">Store server backups in your own Google Drive. OGHOST requests only the minimal <span className="font-mono">drive.file</span> scope.</p><button className="btn-primary" disabled={!!busy} onClick={() => run('cn', async () => { const r = await post('/api/drive/connect', { returnTo: '/account?tab=integrations' }); window.location.href = r.url; })}>Connect Google Drive</button></div>}</>}</Card>
    </div>
  );
}
