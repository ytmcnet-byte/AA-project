import { StrictMode, type ReactNode } from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter, Navigate, Route, Routes, useLocation } from 'react-router-dom';
import './index.css';
import { AuthProvider, useAuth, isAdmin } from './lib/auth';
import { Layout } from './components/Layout';
import { Loading, Toaster, Empty } from './components/ui';
import { Login, TwoFactor, Register, ForgotPassword, ResetPassword, VerifyEmail } from './pages/Auth';
import { Dashboard, ServerList } from './pages/Dashboard';
import { Store } from './pages/Store';
import { Billing, InvoicePage } from './pages/Billing';
import { Tickets, TicketDetail } from './pages/Tickets';
import { Account } from './pages/Account';
import { CoinsPage } from './pages/Coins';
import { CoinsAdmin } from './pages/admin/Coins';
import { ServerLayout } from './pages/server/ServerLayout';
import { ConsoleTab } from './pages/server/Console';
import { FilesTab } from './pages/server/Files';
import { StartupTab, VersionTab, PluginsTab, BackupsTab, SchedulesTab, DatabasesTab, NetworkTab, UsersTab, ActivityTab, SettingsTab, SecurityTab } from './pages/server/Manage';
import { ServerExtensionPage } from './pages/server/ExtensionPage';
import { AdminOverview } from './pages/admin/Overview';
import { SecurityCenter } from './pages/admin/Security';
import { ServersAdmin, ServerCreateAdmin, ServerDetailAdmin } from './pages/admin/Servers';
import { NodesAdmin, NodeDetailAdmin } from './pages/admin/Nodes';
import { EggsAdmin } from './pages/admin/Eggs';
import { UsersAdmin, UserDetailAdmin } from './pages/admin/Users';
import { OrdersAdmin } from './pages/admin/Orders';
import { SettingsAdmin } from './pages/admin/Settings';
import { ExtensionsAdmin, AdminExtensionPage } from './pages/admin/Extensions';
import { LocationsAdmin, DatabaseHostsAdmin, PluginReposAdmin, AnnouncementsAdmin, RolesAdmin, StoreAdmin, WebhooksAdmin, AuditAdmin, JobsAdmin, DriveAdmin } from './pages/admin/Simple';

function Protected({ children }: { children: ReactNode }) {
  const { user, loading, twoFactorPending } = useAuth(); const loc = useLocation();
  if (loading) return <div className="flex min-h-screen items-center justify-center"><Loading /></div>;
  if (twoFactorPending) return <Navigate to="/login/2fa" replace />;
  if (!user) return <Navigate to={`/login?next=${encodeURIComponent(loc.pathname + loc.search)}`} replace />;
  return <Layout>{children}</Layout>;
}
function AdminOnly({ children }: { children: ReactNode }) { const { user } = useAuth(); return isAdmin(user) ? <>{children}</> : <Empty title="You do not have access to this page" />; }
function GuestOnly({ children }: { children: ReactNode }) { const { user, loading } = useAuth(); if (loading) return <div className="flex min-h-screen items-center justify-center"><Loading /></div>; return user ? <Navigate to="/" replace /> : <>{children}</>; }

const admin: Array<[string, ReactNode]> = [
  ['', <AdminOverview />], ['security', <SecurityCenter />], ['servers', <ServersAdmin />], ['servers/new', <ServerCreateAdmin />], ['servers/:id', <ServerDetailAdmin />],
  ['nodes', <NodesAdmin />], ['nodes/:id', <NodeDetailAdmin />], ['locations', <LocationsAdmin />], ['eggs', <EggsAdmin />], ['users', <UsersAdmin />], ['users/:id', <UserDetailAdmin />],
  ['roles', <RolesAdmin />], ['store', <StoreAdmin />], ['orders', <OrdersAdmin />], ['coins', <CoinsAdmin />], ['tickets', <Tickets admin />], ['tickets/:id', <TicketDetail admin />], ['databases', <DatabaseHostsAdmin />],
  ['plugins', <PluginReposAdmin />], ['extensions', <ExtensionsAdmin />], ['extensions/:identifier/:pageId', <AdminExtensionPage />], ['announcements', <AnnouncementsAdmin />], ['webhooks', <WebhooksAdmin />],
  ['drive', <DriveAdmin />], ['audit', <AuditAdmin />], ['jobs', <JobsAdmin />], ['settings', <SettingsAdmin />],
];

function App() {
  return <Routes>
    <Route path="/login" element={<GuestOnly><Login /></GuestOnly>} />
    <Route path="/login/2fa" element={<TwoFactor />} />
    <Route path="/register" element={<GuestOnly><Register /></GuestOnly>} />
    <Route path="/forgot-password" element={<ForgotPassword />} />
    <Route path="/reset-password" element={<ResetPassword />} />
    <Route path="/verify-email" element={<VerifyEmail />} />
    <Route path="/" element={<Protected><Dashboard /></Protected>} />
    <Route path="/servers" element={<Protected><ServerList /></Protected>} />
    <Route path="/store" element={<Protected><Store /></Protected>} />
    <Route path="/billing" element={<Protected><Billing /></Protected>} />
    <Route path="/billing/invoices/:id" element={<Protected><InvoicePage /></Protected>} />
    <Route path="/coins" element={<Protected><CoinsPage /></Protected>} />
    <Route path="/tickets" element={<Protected><Tickets /></Protected>} />
    <Route path="/tickets/:id" element={<Protected><TicketDetail /></Protected>} />
    <Route path="/account" element={<Protected><Account /></Protected>} />
    <Route path="/server/:id" element={<Protected><ServerLayout /></Protected>}>
      <Route index element={<ConsoleTab />} /><Route path="files" element={<FilesTab />} /><Route path="startup" element={<StartupTab />} /><Route path="version" element={<VersionTab />} />
      <Route path="plugins" element={<PluginsTab />} /><Route path="backups" element={<BackupsTab />} /><Route path="schedules" element={<SchedulesTab />} /><Route path="databases" element={<DatabasesTab />} />
      <Route path="network" element={<NetworkTab />} /><Route path="users" element={<UsersTab />} /><Route path="activity" element={<ActivityTab />} /><Route path="security" element={<SecurityTab />} />
      <Route path="settings" element={<SettingsTab />} /><Route path="ext/:identifier/:pageId" element={<ServerExtensionPage />} />
    </Route>
    {admin.map(([p, el]) => <Route key={p} path={`/admin${p ? '/' + p : ''}`} element={<Protected><AdminOnly>{el}</AdminOnly></Protected>} />)}
    <Route path="*" element={<Protected><Empty title="Page not found" /></Protected>} />
  </Routes>;
}

createRoot(document.getElementById('root')!).render(<StrictMode><BrowserRouter><AuthProvider><App /><Toaster /></AuthProvider></BrowserRouter></StrictMode>);
