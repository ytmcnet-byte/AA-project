import fs from 'node:fs';
import os from 'node:os';
import { execFile } from 'node:child_process';
import { config } from './config';

let lastCpu: { idle: number; total: number } | null = null;
export function cpuUsage(): number {
  const l = fs.readFileSync('/proc/stat', 'utf8').split('\n')[0].trim().split(/\s+/).slice(1).map(Number);
  const idle = l[3] + (l[4] || 0); const total = l.reduce((a, b) => a + b, 0);
  const prev = lastCpu; lastCpu = { idle, total };
  if (!prev || total === prev.total) return 0;
  return Math.round((1 - (idle - prev.idle) / (total - prev.total)) * 1000) / 10;
}
export function memInfo() {
  const t = fs.readFileSync('/proc/meminfo', 'utf8');
  const g = (k: string) => Number(t.match(new RegExp(`^${k}:\\s+(\\d+)`, 'm'))?.[1] || 0) * 1024;
  return { total: g('MemTotal'), free: g('MemAvailable') };
}
export function netTotals() {
  let rx = 0, tx = 0;
  for (const line of fs.readFileSync('/proc/net/dev', 'utf8').split('\n').slice(2)) {
    const [iface, rest] = line.split(':'); if (!rest || iface.trim() === 'lo') continue;
    const c = rest.trim().split(/\s+/).map(Number); rx += c[0]; tx += c[8];
  }
  return { rxBytes: rx, txBytes: tx };
}
export function diskInfo(dir = config.dataRoot) {
  const s = fs.statfsSync(dir);
  return { total: s.blocks * s.bsize, free: s.bavail * s.bsize };
}

/** Report whether real kernel filesystem quotas are available for the data root. */
export function quotaSupport(dir = config.dataRoot): Promise<{ fsType: string; quotaSupport: string }> {
  return new Promise((res) => execFile('findmnt', ['-n', '-o', 'FSTYPE,OPTIONS', '--target', dir], { timeout: 4000 }, (err, out) => {
    if (err) return res({ fsType: 'unknown', quotaSupport: 'unknown: findmnt unavailable; application-level enforcement only' });
    const [fsType, opts = ''] = out.trim().split(/\s+/);
    if (/^nfs/.test(fsType)) return res({ fsType, quotaSupport: 'unavailable: NFS mount; quotas are controlled by the NFS server. Application-level enforcement only.' });
    if (/(prjquota|pquota|usrquota|grpquota|quota)/.test(opts)) return res({ fsType, quotaSupport: `available: ${fsType} mounted with quota options (requires host-admin QUOTA_HOOK to apply)` + (config.quotaHook ? ' — QUOTA_HOOK configured' : '') });
    res({ fsType, quotaSupport: `unavailable: ${fsType} mounted without quota options. Application-level enforcement only (not a hard limit).` });
  }));
}
export const systemBasics = () => ({ arch: os.arch(), platform: `${os.type()} ${os.release()}`, uptime: os.uptime(), cores: os.cpus().length, load: os.loadavg() });
