-- OGCoins: panel currency. Balance lives on users (single row lock = atomic debit/credit);
-- every change is recorded in coin_transactions (append-only ledger, idempotent via (type, reference)).

ALTER TABLE users
  ADD COLUMN coin_balance BIGINT NOT NULL DEFAULT 0,
  ADD COLUMN discord_id VARCHAR(32) NULL,
  ADD COLUMN discord_username VARCHAR(100) NULL,
  ADD COLUMN discord_linked_at DATETIME NULL,
  ADD UNIQUE KEY uq_users_discord (discord_id),
  ADD CONSTRAINT chk_users_coins CHECK (coin_balance >= 0);

CREATE TABLE coin_transactions (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  amount BIGINT NOT NULL,
  balance_after BIGINT NOT NULL,
  type ENUM('linkvertise','redeem','discord','admin','purchase','renewal','upgrade','refund') NOT NULL,
  reference VARCHAR(191) NULL,
  description VARCHAR(255) NOT NULL,
  actor_id INT UNSIGNED NULL,
  invoice_id INT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_coin_ref (type, reference),
  INDEX idx_coin_user (user_id, id),
  INDEX idx_coin_type_time (type, created_at),
  CONSTRAINT fk_coin_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE coin_codes (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  code VARCHAR(40) NOT NULL UNIQUE,
  coins INT UNSIGNED NOT NULL,
  max_uses INT UNSIGNED NOT NULL DEFAULT 1,
  uses INT UNSIGNED NOT NULL DEFAULT 0,
  expires_at DATETIME NULL,
  note VARCHAR(191) NULL,
  active TINYINT(1) NOT NULL DEFAULT 1,
  created_by INT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE coin_code_redemptions (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  code_id INT UNSIGNED NOT NULL,
  user_id INT UNSIGNED NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_code_user (code_id, user_id),
  CONSTRAINT fk_ccr_code FOREIGN KEY (code_id) REFERENCES coin_codes(id) ON DELETE CASCADE,
  CONSTRAINT fk_ccr_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE linkvertise_claims (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  token_hash CHAR(64) NOT NULL UNIQUE,
  user_id INT UNSIGNED NOT NULL,
  coins INT UNSIGNED NOT NULL,
  status ENUM('pending','completed','failed','expired') NOT NULL DEFAULT 'pending',
  ip VARCHAR(64) NULL,
  lv_hash CHAR(64) NULL UNIQUE,
  failure VARCHAR(191) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  completed_at DATETIME NULL,
  INDEX idx_lv_user (user_id, status, created_at),
  INDEX idx_lv_ip (ip, created_at),
  CONSTRAINT fk_lv_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE oauth_states (
  state_hash CHAR(64) PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  provider VARCHAR(20) NOT NULL,
  expires_at DATETIME NOT NULL,
  INDEX idx_oauth_states_exp (expires_at),
  CONSTRAINT fk_oauth_states_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Coin prices. NULL = cannot be bought / renewed with OGCoins.
ALTER TABLE plans
  ADD COLUMN coin_price INT UNSIGNED NULL,
  ADD COLUMN max_per_user INT UNSIGNED NULL;

ALTER TABLE services
  ADD COLUMN coin_price INT UNSIGNED NULL,
  ADD COLUMN auto_renew_coins TINYINT(1) NOT NULL DEFAULT 0,
  ADD COLUMN auto_renew_notified_at DATETIME NULL;

ALTER TABLE invoices
  ADD COLUMN coin_total INT UNSIGNED NULL;
