// Shared helpers for end-to-end tests. These run against a live panel + node agent:
//   PANEL_URL (default http://127.0.0.1:8080), E2E_ADMIN / E2E_PASSWORD, E2E_NODE_ID (default 1)
// They create servers named "e2e-*" with the Custom JAR egg (no download) and remove them afterwards.
import fs from 'node:fs';
import path from 'node:path';
import mysql from 'mysql2/promise';
import { client, waitFor, sleep } from './client.mjs';
export { client, waitFor, sleep };
export const PANEL = process.env.PANEL_URL || 'http://127.0.0.1:8080';
export const NODE = Number(process.env.E2E_NODE_ID || 1);
const root = path.resolve(import.meta.dirname, '../..');
export async function panelUp() { try { return (await fetch(PANEL + '/healthz')).ok; } catch { return false; } }
export const skip = (await panelUp()) ? false : `panel not reachable at ${PANEL} (start it to run e2e tests)`;
export async function admin() { const c = client(PANEL); await c.login(process.env.E2E_ADMIN || 'admin', process.env.E2E_PASSWORD || 'Admin12345pass'); return c; }
export function envFile() {
  const f = process.env.OGHOST_ENV_FILE || path.join(root, '.env'); const o = {};
  if (fs.existsSync(f)) for (const l of fs.readFileSync(f, 'utf8').split('\n')) { const m = l.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)$/); if (m) o[m[1]] = m[2].replace(/^["']|["']$/g, ''); }
  return o;
}
export async function db() { const e = envFile(); return mysql.createConnection({ host: e.DB_HOST || '127.0.0.1', port: Number(e.DB_PORT || 3306), user: e.DB_USER, password: e.DB_PASSWORD, database: e.DB_NAME }); }
export async function customJarEgg(c) { const { eggs } = await c.get('/api/admin/eggs'); const e = eggs.find(x => x.slug === 'custom-jar' || /custom jar/i.test(x.name)); if (!e) throw new Error('Custom JAR egg not found'); return e.id; }
export async function mkServer(c, name, extra = {}) {
  return c.post('/api/admin/servers', { name, ownerId: 1, nodeId: NODE, eggId: await customJarEgg(c), memoryMb: 256, cpuPercent: 50, diskMb: 256, skipInstall: true, ...extra });
}
export async function rmServer(c, s) {
  await c.call('DELETE', `/api/admin/servers/${s.id}`, { confirm: `${s.nodeId ?? NODE}/${s.nodeServerId}` }, { allowError: true });
  await waitFor(async () => (await c.get(`/api/admin/servers/${s.id}`, { allowError: true })).status === 404, { timeout: 30000, label: `server ${s.id} deleted` }).catch(() => {});
}
