import fs from 'node:fs';
import { execFileSync } from 'node:child_process';

let CLK = 100, PAGE = 4096;
try { CLK = Number(execFileSync('getconf', ['CLK_TCK']).toString().trim()) || 100; PAGE = Number(execFileSync('getconf', ['PAGESIZE']).toString().trim()) || 4096; } catch { /* defaults */ }

export interface ProcInfo { pid: number; ppid: number; comm: string; ticks: number; rss: number; uid: number; }
export function readProc(pid: number): ProcInfo | null {
  try {
    const stat = fs.readFileSync(`/proc/${pid}/stat`, 'utf8');
    const close = stat.lastIndexOf(')'); const comm = stat.slice(stat.indexOf('(') + 1, close);
    const f = stat.slice(close + 2).split(' ');
    const ppid = Number(f[1]); const ticks = Number(f[11]) + Number(f[12]);
    const rss = Number(f[21]) * PAGE;
    const uidLine = fs.readFileSync(`/proc/${pid}/status`, 'utf8').match(/^Uid:\s+(\d+)/m);
    return { pid, ppid, comm, ticks, rss, uid: uidLine ? Number(uidLine[1]) : -1 };
  } catch { return null; }
}
export function allPids(): number[] { return fs.readdirSync('/proc').filter(n => /^\d+$/.test(n)).map(Number); }

/** Returns the process and all of its descendants (only these PIDs are ever acted on). */
export function processTree(root: number): ProcInfo[] {
  const infos = allPids().map(readProc).filter(Boolean) as ProcInfo[];
  const byParent = new Map<number, ProcInfo[]>();
  for (const p of infos) { const l = byParent.get(p.ppid) || []; l.push(p); byParent.set(p.ppid, l); }
  const out: ProcInfo[] = []; const rootInfo = infos.find(p => p.pid === root); if (!rootInfo) return out;
  const stack = [rootInfo];
  while (stack.length) { const p = stack.pop()!; out.push(p); for (const c of byParent.get(p.pid) || []) stack.push(c); }
  return out;
}
export const cmdline = (pid: number) => { try { return fs.readFileSync(`/proc/${pid}/cmdline`, 'utf8').split('\0').filter(Boolean).join(' '); } catch { return ''; } };
export const cwdOf = (pid: number) => { try { return fs.readlinkSync(`/proc/${pid}/cwd`); } catch { return ''; } };
export const exeOf = (pid: number) => { try { return fs.readlinkSync(`/proc/${pid}/exe`); } catch { return ''; } };

export class CpuSampler {
  private last = new Map<number, { ticks: number; at: number }>();
  /** CPU % where 100 = one full core. */
  sample(key: number, tree: ProcInfo[]) {
    const ticks = tree.reduce((s, p) => s + p.ticks, 0); const now = Date.now();
    const prev = this.last.get(key); this.last.set(key, { ticks, at: now });
    if (!prev || now <= prev.at || ticks < prev.ticks) return 0;
    return Math.round(((ticks - prev.ticks) / CLK) / ((now - prev.at) / 1000) * 1000) / 10;
  }
  reset(key: number) { this.last.delete(key); }
}

/** Socket inodes owned by a process, used to attribute TCP connections without root. */
export function socketInodes(pid: number): Set<string> {
  const s = new Set<string>();
  try { for (const fd of fs.readdirSync(`/proc/${pid}/fd`)) { try { const l = fs.readlinkSync(`/proc/${pid}/fd/${fd}`); const m = l.match(/^socket:\[(\d+)\]$/); if (m) s.add(m[1]); } catch { /* */ } } } catch { /* */ }
  return s;
}
export interface TcpConn { local: string; remoteIp: string; remotePort: number; state: string; inode: string; }
export function tcpConnections(): TcpConn[] {
  const out: TcpConn[] = [];
  for (const f of ['/proc/net/tcp', '/proc/net/tcp6']) {
    try {
      for (const line of fs.readFileSync(f, 'utf8').split('\n').slice(1)) {
        const c = line.trim().split(/\s+/); if (c.length < 10) continue;
        const [rip, rport] = c[2].split(':');
        let ip = '';
        if (rip.length === 8) ip = [3, 2, 1, 0].map(i => parseInt(rip.slice(i * 2, i * 2 + 2), 16)).join('.');
        else ip = rip.match(/.{8}/g)!.map(g => g.match(/../g)!.reverse().join('')).join('').match(/.{4}/g)!.join(':');
        out.push({ local: c[1], remoteIp: ip, remotePort: parseInt(rport, 16), state: c[3], inode: c[9] });
      }
    } catch { /* */ }
  }
  return out;
}
