#!/usr/bin/env bash
# Development helper: rebuild and restart the panel plus local test agents (non-root).
set -e
cd "$(dirname "$0")/.."
node scripts/build.mjs >/dev/null
pkill -f "dist/panel.mjs serve" || true; pkill -f "dist/agent.mjs" || true
# agents stop game servers gracefully first; wait for them to exit
for i in $(seq 1 90); do pgrep -f "dist/(agent|panel).mjs" >/dev/null || break; sleep 1; done
mkdir -p logs
(set -m; nohup node dist/panel.mjs serve >> logs/panel.log 2>&1 &)
for f in ${AGENT_ENVS:-/tmp/oge/agent1.env /tmp/oge/agent2.env}; do n=$(basename "$f" .env); (set -m; AGENT_ENV_FILE="$f" nohup node dist/agent.mjs >> "logs/$n.log" 2>&1 &); done
sleep 3; curl -sf localhost:${PORT:-8080}/healthz && echo
