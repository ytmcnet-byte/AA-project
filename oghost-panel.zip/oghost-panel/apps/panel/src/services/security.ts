import { q, one, exec, json } from '../db';
import { getServer, setSuspension, syncSpec } from './servers';
import { getNode, agent } from './nodes';
import { notify, notifyAdmins } from './notify';
import { getSetting } from './settings';
import { audit } from './audit';
import { dispatchWebhook } from './webhooks';

export async function trustedHashes(): Promise<string[]> { return (await q<{ sha256: string }>('SELECT sha256 FROM trusted_software')).map(r => r.sha256); }

export async function pushTrustedToNodes() {
  const hashes = await trustedHashes();
  for (const n of await q<any>("SELECT * FROM nodes WHERE status = 'online'")) await agent(n, 'PUT', '/api/security/trusted', { hashes }).catch(() => {});
}

async function incident(serverId: number | null, nodeId: number | null, severity: 'low' | 'medium' | 'high', category: string, rule: string, evidence: unknown, action: string | null) {
  const r = await exec('INSERT INTO security_incidents (server_id, node_id, severity, category, rule, evidence, action_taken) VALUES (?, ?, ?, ?, ?, ?, ?)', [serverId, nodeId, severity, category, rule.slice(0, 100), json(evidence), action]);
  void dispatchWebhook('security.incident', { incidentId: r.insertId, serverId, nodeId, severity, category, rule, action });
  return r.insertId;
}

/** High-risk response: stop + suspend ONLY the affected server for N hours, block execution, notify, record evidence. */
export async function highRisk(serverId: number, nodeId: number, category: string, rule: string, evidence: unknown) {
  const hours = Number(await getSetting('security.autoSuspendHours')) || 48;
  const s = await getServer(serverId);
  const id = await incident(serverId, nodeId, 'high', category, rule, evidence, `Server stopped and suspended for ${hours}h; uploads and execution blocked`);
  await exec("UPDATE servers SET security_level = 'high_risk', security_blocked = 1 WHERE id = ?", [serverId]);
  await setSuspension(serverId, true, `Security: ${category} detected (incident #${id}). Automatic ${hours}h suspension pending review.`, hours);
  const node = await getNode(nodeId); await agent(node, 'POST', `/api/servers/${s.node_server_id}/power`, { action: 'kill' }, { serverId: s.node_server_id }).catch(() => {});
  await notifyAdmins('admin.security', 'security', `HIGH RISK: ${category} on server #${serverId}`, `Server "${s.name}" (node ${nodeId}, ID ${s.node_server_id}) was suspended for ${hours} hours. Rule: ${rule}.`, { link: `/admin/security?incident=${id}`, email: true });
  await notify(s.owner_id, 'security', `Server "${s.name}" suspended by security system`, `Prohibited software (${category}) was detected. The server is suspended for ${hours} hours pending administrator review. Your files were not deleted. You can submit an appeal from the server page.`, { link: `/server/${serverId}`, email: true });
  await audit(null, 'security.auto_suspend', { type: 'server', id: serverId }, { category, rule, incident: id, hours }, 'system');
  return id;
}

export async function handleScanEvent(serverId: number, nodeId: number, data: { phase: string; results: any[] }) {
  const s = await getServer(serverId);
  let worst: 'safe' | 'suspicious' | 'high_risk' = 'safe'; const pending: any[] = [];
  for (const r of data.results) {
    const approved = await one('SELECT id FROM trusted_software WHERE sha256 = ?', [r.sha256]);
    const level = approved ? 'safe' : r.level;
    await exec('INSERT INTO security_scans (server_id, file, mode, phase, level, sha256, size_bytes, reason, minecraft, findings, review_status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
      [serverId, String(r.file).slice(0, 500), r.mode, data.phase, level, r.sha256, r.size || 0, String(r.reason || '').slice(0, 500), json(r.minecraft), json(r.findings), level === 'suspicious' ? 'pending' : 'none']);
    if (level === 'high_risk') worst = 'high_risk'; else if (level === 'suspicious' && worst === 'safe') worst = 'suspicious';
    if (level !== 'safe') pending.push(r);
  }
  if (worst === 'high_risk') {
    const r = pending.find(p => p.level === 'high_risk');
    const cat = r.findings?.find((f: any) => f.severity === 'high')?.category || 'prohibited-software';
    await highRisk(serverId, nodeId, cat, r.findings?.find((f: any) => f.severity === 'high')?.rule || 'signature', { file: r.file, sha256: r.sha256, reason: r.reason, findings: r.findings?.slice(0, 20), phase: data.phase });
  } else if (worst === 'suspicious') {
    const block = await getSetting('security.blockSuspicious');
    await exec('UPDATE servers SET security_level = ?, security_blocked = ? WHERE id = ?', ['suspicious', block ? 1 : 0, serverId]);
    const id = await incident(serverId, nodeId, 'medium', 'suspicious-jar', 'unverified-software', { files: pending.map(p => ({ file: p.file, sha256: p.sha256, reason: p.reason, findings: p.findings?.slice(0, 10) })), phase: data.phase }, block ? 'Execution blocked pending review' : 'Alert only');
    await notifyAdmins('admin.security', 'security', `Suspicious software on server #${serverId}`, `${pending.map(p => p.file).join(', ')}: ${pending[0].reason}`, { link: `/admin/security?incident=${id}` });
    await notify(s.owner_id, 'security', `Verification required for "${s.name}"`, `The security scanner could not verify: ${pending.map(p => p.file).join(', ')}. ${block ? 'Starting is blocked until an administrator reviews it (usually quick for legitimate custom software).' : ''} You can add details via an appeal on the server page.`, { link: `/server/${serverId}` });
    if (block) await syncSpec(serverId).catch(() => {});
  } else {
    const stillPending: any = await one("SELECT COUNT(*) AS c FROM security_scans WHERE server_id = ? AND review_status = 'pending'", [serverId]);
    const newLevel = 'safe';
    if (s.security_blocked && !s.suspended_at && data.phase === 'manual') {
      // All current files are clean (e.g. the customer removed the flagged file): unblock and resolve pending reviews.
      await exec("UPDATE security_scans SET review_status = 'approved' WHERE server_id = ? AND review_status = 'pending'", [serverId]);
      await exec("UPDATE servers SET security_blocked = 0, security_level = 'safe' WHERE id = ?", [serverId]); await syncSpec(serverId).catch(() => {});
    } else if (!s.security_blocked && !Number(stillPending.c)) await exec('UPDATE servers SET security_level = ? WHERE id = ?', [newLevel, serverId]);
  }
}

export async function handleRuntimeEvent(serverId: number, nodeId: number, d: { severity: 'low' | 'medium' | 'high'; category: string; rule: string; detail: unknown }) {
  if (d.severity === 'high') return highRisk(serverId, nodeId, d.category, d.rule, d.detail);
  const id = await incident(serverId, nodeId, d.severity, d.category, d.rule, d.detail, 'Alert recorded');
  if (d.severity === 'medium') await notifyAdmins('admin.security', 'security', `${d.category} alert on server #${serverId}`, `Rule ${d.rule}. Review evidence in the Security Center.`, { link: `/admin/security?incident=${id}` });
  return id;
}

/** Releases automatic suspensions whose time elapsed (unless an administrator extended them). */
export async function releaseExpiredSuspensions() {
  const rows = await q<{ id: number; name: string; owner_id: number }>('SELECT id, name, owner_id FROM servers WHERE suspended_at IS NOT NULL AND suspended_until IS NOT NULL AND suspended_until <= NOW()');
  for (const r of rows) {
    await exec("UPDATE servers SET security_blocked = 0, security_level = 'unscanned' WHERE id = ?", [r.id]);
    await setSuspension(r.id, false, null, null);
    await exec("UPDATE security_incidents SET action_taken = CONCAT(COALESCE(action_taken,''), ' | Suspension auto-released') WHERE server_id = ? AND status = 'open' AND severity = 'high'", [r.id]);
    await notify(r.owner_id, 'security', `Suspension lifted for "${r.name}"`, 'The temporary suspension expired. Files are scanned again before the next start; remove any prohibited software first.', { link: `/server/${r.id}` });
    await audit(null, 'security.auto_release', { type: 'server', id: r.id }, {}, 'system');
  }
  return rows.length;
}
