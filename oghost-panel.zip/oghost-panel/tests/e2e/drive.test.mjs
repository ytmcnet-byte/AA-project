// Google Drive backups against a local Google mock (no real Google account needed).
// Requires the panel to be started with:
//   GOOGLE_OAUTH_BASE=http://127.0.0.1:$E2E_DRIVE_MOCK_PORT GOOGLE_DRIVE_API_BASE=http://127.0.0.1:$E2E_DRIVE_MOCK_PORT
// and E2E_DRIVE_MOCK_PORT set for the test run.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { skip as noPanel, admin, mkServer, rmServer, waitFor, PANEL } from './common.mjs';
import { startGoogleMock } from '../mocks/google-mock.mjs';
const PORT = Number(process.env.E2E_DRIVE_MOCK_PORT || 0);
const skip = noPanel || (!PORT && 'set E2E_DRIVE_MOCK_PORT and start the panel with GOOGLE_*_BASE pointing at the mock');
const bin = { headers: { 'content-type': 'application/octet-stream' } };

test('Drive: OAuth connect, folder layout, retention, failure keeps previous, restore with safety backup', { skip, timeout: 240_000 }, async () => {
  const mock = await startGoogleMock(PORT); const c = await admin(); let s;
  const prev = await c.get('/api/admin/settings').catch(() => null);
  try {
    await c.put('/api/admin/settings', { 'google.clientId': 'e2e-client.apps.googleusercontent.com', 'google.clientSecret': 'e2e-secret', 'drive.enabled': true });
    s = await mkServer(c, 'e2e drive');
    const F = `/api/servers/${s.id}/files`;
    await c.post(`${F}/write?path=world/level.dat`, Buffer.from('version-1'), bin);

    // OAuth: state is single-use and bound to the user; tokens never reach the browser
    const { url } = await c.post('/api/drive/connect', { returnTo: `/server/${s.id}/backups` });
    const au = new URL(url); assert.equal(au.searchParams.get('scope').split(' ').filter(x => x.includes('drive')).join(), 'https://www.googleapis.com/auth/drive.file', 'minimum Drive scope only');
    assert.equal(au.searchParams.get('code_challenge_method'), 'S256');
    const state = au.searchParams.get('state');
    const bad = await c.call('GET', `/api/drive/callback?state=forged&code=x`, undefined, { allowError: true });
    assert.match(String(bad.data), /drive=error/);
    const cb = await fetch(`${PANEL}/api/drive/callback?state=${state}&code=authcode`, { headers: { cookie: c.cookie }, redirect: 'manual' });
    assert.match(cb.headers.get('location') || '', /drive=connected/);
    const replay = await fetch(`${PANEL}/api/drive/callback?state=${state}&code=authcode`, { headers: { cookie: c.cookie }, redirect: 'manual' });
    assert.match(replay.headers.get('location') || '', /drive=error/, 'state cannot be reused');
    const status = await c.get('/api/drive/status'); assert.equal(status.connection.status, 'connected');
    assert.ok(!/mock-refresh|ya29\./.test(JSON.stringify(status)), 'no tokens in API responses');

    await c.put(`/api/drive/servers/${s.id}`, { enabled: false, retention: 2, intervalMinutes: 60 });
    const backups = async () => (await c.get(`/api/drive/servers/${s.id}`)).backups;
    const run = async () => {
      const before = Math.max(0, ...(await backups()).map(b => b.id)); await c.post(`/api/drive/servers/${s.id}/run`);
      return waitFor(async () => { const d = await c.get(`/api/drive/servers/${s.id}`); const b = d.backups[0]; return !d.config.running && b && b.id > before && b.status !== 'uploading' && b; }, { timeout: 60000, label: 'drive backup' });
    };
    const zips = () => [...mock.state.files.values()].filter(f => f.mimeType === 'application/zip');
    for (let i = 0; i < 3; i++) { const b = await run(); assert.equal(b.status, 'completed', JSON.stringify(b)); assert.equal(b.verified, 1); }
    assert.equal(zips().length, 2, 'retention 2: oldest verified backup deleted after the new one was verified');
    const z = zips()[0]; const parent = mock.state.files.get(z.parents[0]); const node = mock.state.files.get(parent.parents[0]); const rootF = mock.state.files.get(node.parents[0]);
    assert.deepEqual([rootF.name, node.name, parent.name], ['OGHOST', `Node-${s.nodeId ?? 1}`, `Server-${s.nodeServerId}`]);

    const keep = zips().map(f => f.id).sort();
    for (const mode of ['quota', 'badmd5']) {
      await fetch(`http://127.0.0.1:${PORT}/__mock/mode`, { method: 'POST', body: JSON.stringify({ mode }) });
      const b = await run(); assert.equal(b.status, 'failed', `${mode} -> ${b.status}`);
      assert.deepEqual(zips().map(f => f.id).sort(), keep, `${mode}: previous backups untouched and no unverified file left`);
    }
    await fetch(`http://127.0.0.1:${PORT}/__mock/mode`, { method: 'POST', body: JSON.stringify({ mode: 'ok' }) });
    assert.match((await c.get(`/api/drive/servers/${s.id}`)).config.lastError, /verify|quota|full/i);

    // restore the newest completed backup; a local safety backup is taken first
    await c.post(`${F}/write?path=world/level.dat`, Buffer.from('broken'), bin);
    const latest = (await backups()).find(b => b.status === 'completed');
    await c.post(`/api/drive/servers/${s.id}/restore/${latest.id}`, { confirm: true });
    assert.equal(await c.get(`${F}/contents?path=world/level.dat`), 'version-1');
    const local = await c.get(`/api/servers/${s.id}/backups`);
    assert.ok((local.backups || local).some(b => b.is_safety && b.status === 'completed'), 'safety backup created');

    const adm = await c.get('/api/admin/drive'); assert.ok(!JSON.stringify(adm).includes('.zip'), 'admin stats do not list customer Drive files');
    await c.post('/api/drive/disconnect'); assert.equal(mock.state.revoked.length, 1, 'refresh token revoked at Google on disconnect');
  } finally {
    if (s) await rmServer(c, s);
    await c.put('/api/admin/settings', { 'drive.enabled': prev?.values?.['drive.enabled'] ?? false }).catch(() => {});
    await mock.close();
  }
});
