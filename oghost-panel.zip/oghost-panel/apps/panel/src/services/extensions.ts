import fs from 'node:fs';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import express, { Router, type Request, type Response, type NextFunction } from 'express';
import yauzl from 'yauzl';
import { validateManifest, type ExtensionManifest, type ExtensionContext, type ExtRouter, type Extension } from '@oghost/extension-sdk';
import { q, one, exec, json, parse } from '../db';
import { config } from '../config';
import { HttpError } from '../lib/http';
import { hasPerm } from '../lib/auth';
import { onPanelEvent } from './webhooks';
import { notify } from './notify';
import { encryptSecret, decryptSecret, safeResolve } from '@oghost/shared';

interface Loaded { manifest: ExtensionManifest; dbId: number; router: Router; adminRouter: Router; listeners: Array<() => void>; instance?: Extension; error?: string }
const loaded = new Map<string, Loaded>();

export const readManifest = (dir: string): ExtensionManifest => {
  const f = path.join(dir, 'extension.json'); if (!fs.existsSync(f)) throw new HttpError(422, 'extension.json not found');
  const m = JSON.parse(fs.readFileSync(f, 'utf8')); const errs = validateManifest(m); if (errs.length) throw new HttpError(422, `Invalid manifest: ${errs.join('; ')}`); return m;
};
/** Sync the extensions directory with the database (new folders become installed-but-disabled). */
export async function discoverExtensions() {
  fs.mkdirSync(config.extensionsDir, { recursive: true });
  const found: Array<{ identifier: string; error?: string }> = [];
  for (const d of fs.readdirSync(config.extensionsDir, { withFileTypes: true })) {
    if (!d.isDirectory()) continue;
    try {
      const m = readManifest(path.join(config.extensionsDir, d.name)); if (m.identifier !== d.name) throw new Error(`folder name must equal identifier (${m.identifier})`);
      await exec('INSERT INTO extensions (identifier, name, version, manifest) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE name = VALUES(name), version = VALUES(version), manifest = VALUES(manifest)', [m.identifier, m.name, m.version, json(m)]);
      found.push({ identifier: m.identifier });
    } catch (e: any) { found.push({ identifier: d.name, error: e.message }); }
  }
  return found;
}

function wrapRouter(r: Router): ExtRouter {
  const w = (m: 'get' | 'post' | 'put' | 'patch' | 'delete') => (p: string, h: any) => { if (!p.startsWith('/')) throw new Error('route paths must start with /'); r[m](p, async (req: Request, res: Response, next: NextFunction) => { try { await h(req, res); } catch (e) { next(e); } }); };
  return { get: w('get'), post: w('post'), put: w('put'), patch: w('patch'), delete: w('delete') };
}
function guard(m: ExtensionManifest, perm: string) { if (!m.permissions.includes(perm as any)) throw new Error(`Extension ${m.identifier} lacks permission "${perm}"`); }

async function load(row: any) {
  const m = parse<ExtensionManifest>(row.manifest, {} as any); const dir = path.join(config.extensionsDir, m.identifier);
  const granted = parse<string[]>(row.granted_permissions, []);
  const eff: ExtensionManifest = { ...m, permissions: m.permissions.filter(p => granted.includes(p)) };
  const L: Loaded = { manifest: eff, dbId: row.id, router: Router(), adminRouter: Router(), listeners: [] };
  L.router.use(express.json({ limit: '1mb' })); L.adminRouter.use(express.json({ limit: '1mb' }));
  const settingsDefs = new Map((m.settings || []).map(s => [s.key, s]));
  const ctx: ExtensionContext = {
    manifest: eff, log: (...a) => console.log(`[ext:${m.identifier}]`, ...a),
    router: wrapRouter(L.router), adminRouter: wrapRouter(L.adminRouter),
    storage: {
      get: async (k) => { guard(eff, 'storage'); const r: any = await one('SELECT value FROM extension_storage WHERE extension_id = ? AND `key` = ?', [row.id, k]); return r ? parse(r.value, null) : null; },
      set: async (k, v) => { guard(eff, 'storage'); if (k.length > 150) throw new Error('key too long'); const size = JSON.stringify(v ?? null).length; if (size > 1_000_000) throw new Error('value too large (1 MB max)'); await exec('INSERT INTO extension_storage (extension_id, `key`, value) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE value = VALUES(value)', [row.id, k, json(v)]); },
      delete: async (k) => { guard(eff, 'storage'); await exec('DELETE FROM extension_storage WHERE extension_id = ? AND `key` = ?', [row.id, k]); },
      list: async (prefix = '') => { guard(eff, 'storage'); return (await q<any>('SELECT `key` FROM extension_storage WHERE extension_id = ? AND `key` LIKE ? ORDER BY `key` LIMIT 1000', [row.id, `${prefix.replace(/[%_]/g, '\\$&')}%`])).map(r => r.key); },
    },
    settings: { get: async (k: string) => { guard(eff, 'settings'); const r: any = await one('SELECT settings FROM extensions WHERE id = ?', [row.id]); const s = parse<any>(r?.settings, {}); const def = settingsDefs.get(k); let v = s[k] ?? def?.default; if (def?.type === 'secret' && v && typeof v === 'object' && v.enc) v = decryptSecret(v.enc, config.appKey); return v as any; } },
    events: { on: (ev, h) => { guard(eff, 'events'); L.listeners.push(onPanelEvent((e, d) => (e === ev ? h(d) : undefined))); } },
    notifications: { notifyUser: async (uid, title, b, link) => { guard(eff, 'notifications'); await notify(uid, 'system', `[${m.name}] ${title}`.slice(0, 200), b.slice(0, 2000), { link }); } },
    servers: {
      get: async (id) => { guard(eff, 'servers:read'); const s: any = await one('SELECT id, name, owner_id, node_id, node_server_id, state FROM servers WHERE id = ?', [id]); return s ? { id: s.id, name: s.name, ownerId: s.owner_id, nodeId: s.node_id, nodeServerId: s.node_server_id, state: s.state } : null; },
      listForUser: async (uid) => { guard(eff, 'servers:read'); return q('SELECT s.id, s.name, s.state FROM servers s LEFT JOIN server_subusers su ON su.server_id = s.id AND su.user_id = ? WHERE s.owner_id = ? OR su.id IS NOT NULL', [uid, uid]); },
    },
    users: { get: async (id) => { guard(eff, 'users:read'); return one('SELECT id, email, username FROM users WHERE id = ?', [id]); } },
  };
  if (m.server) {
    if (!eff.permissions.includes('routes') && !eff.permissions.includes('events')) { /* allowed: storage-only background code */ }
    const file = safeResolve(dir, m.server);
    try { const mod = await import(`${pathToFileURL(file).href}?v=${Date.now()}`); const ext: Extension = mod.default || mod; if (typeof ext.register !== 'function') throw new Error('server module must export register(ctx)'); await ext.register(ctx); L.instance = ext; }
    catch (e: any) { L.error = e.message; console.error(`[ext:${m.identifier}] failed to load:`, e.message); for (const off of L.listeners) off(); L.listeners = []; }
  }
  loaded.set(m.identifier, L);
}
export async function unload(identifier: string) { const L = loaded.get(identifier); if (!L) return; for (const off of L.listeners) off(); try { await L.instance?.unregister?.(); } catch { /* ignore */ } loaded.delete(identifier); }
export async function loadEnabledExtensions() {
  await discoverExtensions().catch(e => console.error('[ext] discovery failed', e.message));
  for (const row of await q<any>('SELECT * FROM extensions WHERE enabled = 1')) { if (!fs.existsSync(path.join(config.extensionsDir, row.identifier))) { await exec('UPDATE extensions SET enabled = 0 WHERE id = ?', [row.id]); continue; } await load(row); }
}
export async function setEnabled(id: number, enabled: boolean, grant: string[]) {
  const row: any = await one('SELECT * FROM extensions WHERE id = ?', [id]); if (!row) throw new HttpError(404, 'Extension not found'); const m = parse<ExtensionManifest>(row.manifest, {} as any);
  if (enabled) { const missing = m.permissions.filter(p => !grant.includes(p)); if (missing.length) throw new HttpError(422, `Grant all requested permissions to enable: ${missing.join(', ')}`); }
  await exec('UPDATE extensions SET enabled = ?, granted_permissions = ? WHERE id = ?', [enabled ? 1 : 0, json(enabled ? m.permissions : []), id]);
  await unload(row.identifier); if (enabled) await load({ ...row, granted_permissions: json(m.permissions) });
  return { ok: true, error: loaded.get(row.identifier)?.error };
}
export const extensionStatus = (identifier: string) => { const L = loaded.get(identifier); return L ? { loaded: true, error: L.error || null } : { loaded: false, error: null }; };
export async function updateExtensionSettings(id: number, values: Record<string, unknown>) {
  const row: any = await one('SELECT * FROM extensions WHERE id = ?', [id]); if (!row) throw new HttpError(404, 'Extension not found'); const m = parse<ExtensionManifest>(row.manifest, {} as any);
  const cur = parse<any>(row.settings, {});
  for (const [k, v] of Object.entries(values)) { const def = (m.settings || []).find(s => s.key === k); if (!def) throw new HttpError(422, `Unknown setting ${k}`);
    if (def.type === 'number' && typeof v !== 'number') throw new HttpError(422, `${k} must be a number`); if (def.type === 'boolean' && typeof v !== 'boolean') throw new HttpError(422, `${k} must be a boolean`);
    cur[k] = def.type === 'secret' ? (v ? { enc: encryptSecret(String(v), config.appKey) } : cur[k]) : v; }
  await exec('UPDATE extensions SET settings = ? WHERE id = ?', [json(cur), id]);
}

/** Install from a .zip (must contain extension.json at its root or in a single top-level folder). Never executes code during install. */
export async function installFromZip(file: string, replace: boolean) {
  const entries: Array<{ name: string; size: number }> = [];
  const zip = await new Promise<yauzl.ZipFile>((res, rej) => yauzl.open(file, { lazyEntries: true }, (e, z) => (e ? rej(e) : res(z!))));
  await new Promise<void>((res, rej) => { zip.on('entry', (en: yauzl.Entry) => { entries.push({ name: en.fileName, size: en.uncompressedSize }); zip.readEntry(); }); zip.on('end', () => res()); zip.on('error', rej); zip.readEntry(); });
  zip.close();
  if (entries.length > 2000) throw new HttpError(422, 'Too many files'); if (entries.reduce((a, e) => a + e.size, 0) > 50 * 1024 * 1024) throw new HttpError(422, 'Extension is larger than 50 MB uncompressed');
  const top = entries.find(e => /^[^/]+\/extension\.json$/.test(e.name)) ? entries.find(e => /^[^/]+\/extension\.json$/.test(e.name))!.name.split('/')[0] + '/' : '';
  if (!top && !entries.some(e => e.name === 'extension.json')) throw new HttpError(422, 'extension.json not found in archive');
  const tmp = fs.mkdtempSync(path.join(config.extensionsDir, '.install-'));
  try {
    const z2 = await new Promise<yauzl.ZipFile>((res, rej) => yauzl.open(file, { lazyEntries: true }, (e, z) => (e ? rej(e) : res(z!))));
    await new Promise<void>((res, rej) => {
      z2.on('entry', (en: yauzl.Entry) => {
        if (!en.fileName.startsWith(top) || en.fileName === top) return z2.readEntry();
        const rel = en.fileName.slice(top.length); let dest: string; try { dest = safeResolve(tmp, rel); } catch { return rej(new HttpError(422, `Unsafe path in archive: ${en.fileName}`)); }
        const mode = (en.externalFileAttributes >>> 16) & 0o170000; if (mode === 0o120000) return rej(new HttpError(422, 'Symlinks are not allowed in extensions'));
        if (/\/$/.test(en.fileName)) { fs.mkdirSync(dest, { recursive: true }); return z2.readEntry(); }
        fs.mkdirSync(path.dirname(dest), { recursive: true });
        z2.openReadStream(en, (e, s) => { if (e || !s) return rej(e); s.pipe(fs.createWriteStream(dest, { mode: 0o640 })).on('finish', () => z2.readEntry()).on('error', rej); });
      });
      z2.on('end', () => res()); z2.on('error', rej); z2.readEntry();
    });
    const m = readManifest(tmp); const target = path.join(config.extensionsDir, m.identifier);
    if (fs.existsSync(target)) { if (!replace) throw new HttpError(409, `Extension ${m.identifier} is already installed (use replace to update)`); await unload(m.identifier); fs.rmSync(target, { recursive: true, force: true }); }
    fs.renameSync(tmp, target);
    await exec('INSERT INTO extensions (identifier, name, version, manifest, enabled) VALUES (?, ?, ?, ?, 0) ON DUPLICATE KEY UPDATE name = VALUES(name), version = VALUES(version), manifest = VALUES(manifest), enabled = 0, granted_permissions = NULL', [m.identifier, m.name, m.version, json(m)]);
    return m;
  } finally { fs.rmSync(tmp, { recursive: true, force: true }); }
}
export async function uninstall(id: number, keepData: boolean) {
  const row: any = await one('SELECT * FROM extensions WHERE id = ?', [id]); if (!row) throw new HttpError(404, 'Extension not found');
  await unload(row.identifier); fs.rmSync(path.join(config.extensionsDir, row.identifier), { recursive: true, force: true });
  if (keepData) await exec('UPDATE extensions SET enabled = 0 WHERE id = ?', [id]); else await exec('DELETE FROM extensions WHERE id = ?', [id]);
}

/** Express mount: /api/extensions/:identifier/... (user) and /api/extensions/:identifier/admin/... (admin.extensions). */
export const extensionsMount = Router();
extensionsMount.get('/', async (req, res) => {
  if (!req.user) throw new HttpError(401, 'Authentication required');
  const out = [...loaded.values()].filter(L => !L.error).map(L => ({ identifier: L.manifest.identifier, name: L.manifest.name, version: L.manifest.version, ui: (L.manifest.permissions.includes('ui') ? L.manifest.ui || [] : []).filter(p => p.area !== 'admin' || hasPerm(req.user, 'admin.extensions')) }));
  res.json({ extensions: out });
});
extensionsMount.use('/:identifier', (req, res, next) => {
  if (!req.user) return next(new HttpError(401, 'Authentication required'));
  const L = loaded.get(req.params.identifier as string); if (!L || L.error) return next(new HttpError(404, 'Extension not found or disabled'));
  if (req.path.startsWith('/admin')) { if (!hasPerm(req.user, 'admin.extensions')) return next(new HttpError(403, 'Admin only')); req.url = req.url.replace(/^\/admin/, '') || '/'; return L.adminRouter(req, res, next); }
  if (!L.manifest.permissions.includes('routes')) return next(new HttpError(404, 'Extension has no routes'));
  return L.router(req, res, next);
});
/** Static UI files: /extensions-ui/:identifier/<file> — served with a strict CSP; the SPA embeds them in a sandboxed iframe. */
export const extensionsUi = Router();
/** Bridge script for extension UIs: the iframe has an opaque origin (CSP sandbox), so API calls are relayed by the panel SPA
 * via postMessage and are restricted to /api/extensions/<identifier>/... */
const BRIDGE = `(function(){var n=0,p={};window.addEventListener('message',function(e){var d=e.data||{};if(d.type==='oghost:response'&&p[d.id]){p[d.id](d);delete p[d.id];}});
window.OGHOST={request:function(method,path,body){return new Promise(function(res,rej){var id=++n;p[id]=function(d){d.ok?res(d.data):rej(new Error(d.error||'Request failed'))};parent.postMessage({type:'oghost:request',id:id,method:method,path:path,body:body},'*');});},
context:new Promise(function(res){window.addEventListener('message',function(e){if((e.data||{}).type==='oghost:context')res(e.data.context);});parent.postMessage({type:'oghost:ready'},'*');})};})();`;
extensionsUi.get('/_sdk/bridge.js', (_req, res) => { res.type('application/javascript').send(BRIDGE); });
extensionsUi.get('/:identifier/{*file}', (req, res, next) => {
  const L = loaded.get(req.params.identifier as string); if (!L || L.error || !L.manifest.permissions.includes('ui')) return next(new HttpError(404, 'Not found'));
  const rel = ([] as string[]).concat((req.params as any).file || []).join('/'); let f: string;
  try { f = safeResolve(path.join(config.extensionsDir, L.manifest.identifier, 'ui'), rel); } catch { return next(new HttpError(400, 'Bad path')); }
  if (!fs.existsSync(f) || !fs.statSync(f).isFile()) return next(new HttpError(404, 'Not found'));
  res.setHeader('Content-Security-Policy', "sandbox allow-scripts allow-forms; default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'none'; frame-ancestors 'self'");
  res.setHeader('X-Content-Type-Options', 'nosniff'); res.sendFile(f);
});
