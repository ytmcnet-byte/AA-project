import { useEffect, useRef, useState } from 'react';
import { Terminal } from '@xterm/xterm';
import { FitAddon } from '@xterm/addon-fit';
import { SearchAddon } from '@xterm/addon-search';
import '@xterm/xterm/css/xterm.css';
import { Cpu, MemoryStick, HardDrive, Clock, Search } from 'lucide-react';
import { socket } from '../../lib/socket';
import { bytes, dur, pct } from '../../lib/format';
import { Bar, Notice, Stat } from '../../components/ui';
import { useServer } from './ServerLayout';

interface Stats { cpu: number; memory: number; disk: number; diskLimit: number; state: string; processes?: number; startedAt?: number }

export function ConsoleTab() {
  const { server, id, setState, can } = useServer();
  const box = useRef<HTMLDivElement>(null); const term = useRef<Terminal | null>(null); const search = useRef<SearchAddon | null>(null);
  const [conn, setConn] = useState<'connecting' | 'connected' | 'disconnected'>('connecting'); const [err, setErr] = useState<string | null>(null);
  const [stats, setStats] = useState<Stats | null>(null); const [cpulimit, setCpulimit] = useState<boolean | null>(null); const [lastExit, setLastExit] = useState<any>(null);
  const [cmd, setCmd] = useState(''); const hist = useRef<string[]>(JSON.parse(localStorage.getItem(`oghost:hist:${id}`) || '[]')); const hi = useRef(-1);
  const [q, setQ] = useState('');

  useEffect(() => {
    const t = new Terminal({ convertEol: true, disableStdin: true, fontSize: 13, fontFamily: 'JetBrains Mono, ui-monospace, Menlo, monospace', scrollback: 5000, theme: { background: '#09090b', foreground: '#e4e4e7', cursor: '#09090b', selectionBackground: '#7f1d1d' } });
    const fit = new FitAddon(); const sa = new SearchAddon(); t.loadAddon(fit); t.loadAddon(sa); t.open(box.current!); fit.fit(); term.current = t; search.current = sa;
    const ro = new ResizeObserver(() => { try { fit.fit(); } catch { /* */ } }); ro.observe(box.current!);
    const s = socket();
    const mine = (m: any) => m?.serverId === id;
    const subscribe = () => { setConn('connecting'); s.emit('subscribe', id, (r: any) => { if (r?.error) { setErr(r.error); setConn('disconnected'); } else { setErr(null); } }); };
    const onConsole = (m: any) => { if (mine(m)) t.writeln(String(m.data)); };
    const onBacklog = (m: any) => { if (mine(m)) { t.clear(); t.reset(); for (const l of m.data as string[]) t.writeln(l); } };
    const onStatus = (m: any) => { if (!mine(m)) return; const d = m.data; setState(d.state); setCpulimit(d.cpulimitActive); setLastExit(d.lastExit); if (d.stats) setStats({ ...d.stats, disk: d.disk?.used ?? 0, diskLimit: d.disk?.limit ?? 0, state: d.state }); };
    const onStats = (m: any) => { if (mine(m)) { setStats(m.data); setState(m.data.state); } };
    const onState = (m: any) => { if (mine(m) && m.data?.state) setState(m.data.state); };
    const onUp = (m: any) => { if (!mine(m)) return; setConn(m.connected ? 'connected' : 'disconnected'); if (!m.connected && m.error) setErr(`Node connection: ${m.error}`); else if (m.connected) setErr(null); };
    s.on('console', onConsole); s.on('backlog', onBacklog); s.on('status', onStatus); s.on('stats', onStats); s.on('state', onState); s.on('upstream', onUp);
    s.on('connect', subscribe); s.on('disconnect', () => setConn('disconnected'));
    if (s.connected) subscribe();
    return () => { s.emit('unsubscribe', id); s.off('console', onConsole); s.off('backlog', onBacklog); s.off('status', onStatus); s.off('stats', onStats); s.off('state', onState); s.off('upstream', onUp); s.off('connect', subscribe); ro.disconnect(); t.dispose(); };
  }, [id]);

  const send = () => {
    const c = cmd.trim(); if (!c) return;
    socket().emit('command', { serverId: id, command: c }, (r: any) => { if (r?.error) term.current?.writeln(`\x1b[31m[OGHOST] ${r.error}\x1b[0m`); });
    hist.current = [c, ...hist.current.filter(x => x !== c)].slice(0, 100); localStorage.setItem(`oghost:hist:${id}`, JSON.stringify(hist.current)); hi.current = -1; setCmd('');
  };
  const key = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') send();
    else if (e.key === 'ArrowUp') { e.preventDefault(); if (hi.current < hist.current.length - 1) { hi.current++; setCmd(hist.current[hi.current]); } }
    else if (e.key === 'ArrowDown') { e.preventDefault(); if (hi.current > 0) { hi.current--; setCmd(hist.current[hi.current]); } else { hi.current = -1; setCmd(''); } }
  };
  const lim = server.limits; const running = stats && ['running', 'starting'].includes(stats.state);
  const cpuMax = lim.cpuPercent || 100 * (navigator.hardwareConcurrency || 1);
  return (
    <div className="grid gap-5 xl:grid-cols-4">
      <div className="xl:col-span-3">
        {err && <Notice kind="error" className="mb-3">{err}</Notice>}
        {lastExit && stats?.state === 'crashed' && <Notice kind="error" className="mb-3">The server crashed (exit code {lastExit.code ?? '—'}{lastExit.signal ? `, signal ${lastExit.signal}` : ''}). Check the console output above for the cause.</Notice>}
        <div className="overflow-hidden rounded-xl border border-ink-800 bg-[#09090b]">
          <div className="flex items-center justify-between border-b border-ink-800 px-3 py-1.5 text-xs text-ink-400"><span className="flex items-center gap-2"><span className={`h-2 w-2 rounded-full ${conn === 'connected' ? 'bg-emerald-500' : conn === 'connecting' ? 'bg-amber-500' : 'bg-red-500'}`} />{conn === 'connected' ? 'Live console' : conn === 'connecting' ? 'Connecting…' : 'Disconnected — reconnecting automatically'}</span>
            <span className="flex items-center gap-1"><Search className="h-3.5 w-3.5" /><input className="w-28 bg-transparent outline-none placeholder:text-ink-600 sm:w-40" placeholder="Search output" value={q} onChange={e => { setQ(e.target.value); if (e.target.value) search.current?.findNext(e.target.value); }} onKeyDown={e => { if (e.key === 'Enter' && q) search.current?.findNext(q); }} /></span></div>
          <div ref={box} className="h-[52vh] min-h-72 px-2 py-1" />
          {can('control.console') && <div className="flex items-center border-t border-ink-800"><span className="pl-3 font-mono text-brand-500">&gt;</span><input className="flex-1 bg-transparent px-2 py-2.5 font-mono text-sm text-zinc-100 outline-none placeholder:text-ink-600" placeholder={running ? 'Type a command… (↑/↓ history)' : 'Server is not running'} disabled={!running || !!server.suspended} value={cmd} onChange={e => setCmd(e.target.value)} onKeyDown={key} maxLength={1000} /></div>}
        </div>
        <p className="hint mt-2">Commands are written to the game server's console input only; they are never run in a system shell.</p>
      </div>
      <div className="grid content-start gap-3 sm:grid-cols-2 xl:grid-cols-1">
        <Stat label="CPU" icon={<Cpu className="h-4 w-4" />} value={running ? pct(stats!.cpu) : '—'} sub={<>{lim.cpuPercent ? `limit ${lim.cpuPercent}%` : 'no limit'}{cpulimit != null && lim.cpuPercent ? <span className="block">{cpulimit ? 'cpulimit active (best-effort)' : 'cpulimit not active on node'}</span> : null}<Bar value={stats?.cpu || 0} max={cpuMax} className="mt-1" /></>} />
        <Stat label="Memory" icon={<MemoryStick className="h-4 w-4" />} value={running ? bytes(stats!.memory) : '—'} sub={<>of {lim.memoryMb ? bytes(lim.memoryMb * 1048576) : 'unlimited'} (RSS of process tree)<Bar value={stats?.memory || 0} max={(lim.memoryMb || 1) * 1048576} className="mt-1" /></>} />
        <Stat label="Disk" icon={<HardDrive className="h-4 w-4" />} value={stats ? bytes(stats.disk) : '—'} sub={<>of {lim.diskMb ? bytes(lim.diskMb * 1048576) : 'unlimited'} (measured by the node)<Bar value={stats?.disk || 0} max={(lim.diskMb || 1) * 1048576} className="mt-1" /></>} />
        <Stat label="Uptime" icon={<Clock className="h-4 w-4" />} value={running && stats?.startedAt ? dur((Date.now() - stats.startedAt) / 1000) : '—'} sub={stats?.processes ? `${stats.processes} process${stats.processes === 1 ? '' : 'es'}` : undefined} />
      </div>
    </div>
  );
}
