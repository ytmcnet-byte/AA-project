export const bytes = (n: number | null | undefined, d = 1) => { if (n == null || isNaN(n)) return '—'; const u = ['B', 'KB', 'MB', 'GB', 'TB']; let i = 0; let v = Number(n); while (v >= 1024 && i < u.length - 1) { v /= 1024; i++; } return `${v.toFixed(i ? d : 0)} ${u[i]}`; };
export const mb = (n: number | null | undefined) => (n == null ? '—' : n === 0 ? 'Unlimited' : n >= 1024 ? `${(n / 1024).toFixed(n % 1024 ? 1 : 0)} GB` : `${n} MB`);
export const date = (s: string | number | Date | null | undefined) => (s ? new Date(s).toLocaleString() : '—');
export const day = (s: string | number | Date | null | undefined) => (s ? new Date(s).toLocaleDateString() : '—');
export const ago = (s: string | number | Date | null | undefined) => { if (!s) return 'never'; const t = (Date.now() - new Date(s).getTime()) / 1000; if (t < 0) return 'in ' + dur(-t); if (t < 60) return `${Math.floor(t)}s ago`; if (t < 3600) return `${Math.floor(t / 60)}m ago`; if (t < 86400) return `${Math.floor(t / 3600)}h ago`; return `${Math.floor(t / 86400)}d ago`; };
export const dur = (sec: number) => { sec = Math.max(0, Math.floor(sec)); const d = Math.floor(sec / 86400), h = Math.floor((sec % 86400) / 3600), m = Math.floor((sec % 3600) / 60), s = sec % 60; return d ? `${d}d ${h}h` : h ? `${h}h ${m}m` : m ? `${m}m ${s}s` : `${s}s`; };
export const money = (cents: number, cur = 'INR') => { try { return new Intl.NumberFormat(undefined, { style: 'currency', currency: cur }).format((cents || 0) / 100); } catch { return `${((cents || 0) / 100).toFixed(2)} ${cur}`; } };
export const pct = (v: number | null | undefined) => (v == null ? '—' : `${Number(v).toFixed(1)}%`);
export const cls = (...a: Array<string | false | null | undefined>) => a.filter(Boolean).join(' ');
