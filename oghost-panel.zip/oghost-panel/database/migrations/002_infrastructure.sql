CREATE TABLE locations (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  short VARCHAR(32) NOT NULL UNIQUE,
  name VARCHAR(100) NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE nodes (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  location_id INT UNSIGNED NOT NULL,
  fqdn VARCHAR(255) NOT NULL,
  scheme ENUM('http','https') NOT NULL DEFAULT 'https',
  port INT UNSIGNED NOT NULL DEFAULT 8443,
  public_ip VARCHAR(64) NOT NULL,
  secret_enc TEXT NOT NULL,
  memory_mb INT UNSIGNED NOT NULL,
  memory_overalloc INT NOT NULL DEFAULT 0,
  disk_mb INT UNSIGNED NOT NULL,
  disk_overalloc INT NOT NULL DEFAULT 0,
  cpu_percent INT UNSIGNED NOT NULL DEFAULT 0,
  max_servers INT UNSIGNED NOT NULL DEFAULT 0,
  maintenance TINYINT(1) NOT NULL DEFAULT 0,
  emergency TINYINT(1) NOT NULL DEFAULT 0,
  status ENUM('unknown','online','offline') NOT NULL DEFAULT 'unknown',
  arch VARCHAR(16) NULL,
  last_heartbeat_at DATETIME NULL,
  heartbeat JSON NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_nodes_location (location_id),
  CONSTRAINT fk_nodes_loc FOREIGN KEY (location_id) REFERENCES locations(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE node_stats (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  node_id INT UNSIGNED NOT NULL,
  cpu FLOAT NOT NULL, mem_used BIGINT NOT NULL, mem_total BIGINT NOT NULL, disk_used BIGINT NOT NULL, disk_total BIGINT NOT NULL, rx BIGINT NOT NULL, tx BIGINT NOT NULL,
  at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_ns (node_id, at)
) ENGINE=InnoDB;

CREATE TABLE eggs (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  slug VARCHAR(64) NOT NULL UNIQUE,
  name VARCHAR(100) NOT NULL,
  category VARCHAR(32) NOT NULL,
  definition JSON NOT NULL,
  is_builtin TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE servers (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  uuid CHAR(36) NOT NULL UNIQUE,
  node_id INT UNSIGNED NOT NULL,
  node_server_id INT UNSIGNED NOT NULL,
  owner_id INT UNSIGNED NOT NULL,
  name VARCHAR(100) NOT NULL,
  description TEXT NULL,
  egg_id INT UNSIGNED NOT NULL,
  state VARCHAR(20) NOT NULL DEFAULT 'installing',
  status_detail VARCHAR(255) NULL,
  memory_mb INT UNSIGNED NOT NULL,
  cpu_percent INT UNSIGNED NOT NULL DEFAULT 0,
  disk_mb INT UNSIGNED NOT NULL,
  swap_mb INT UNSIGNED NOT NULL DEFAULT 0,
  xms_mb INT UNSIGNED NOT NULL,
  xmx_mb INT UNSIGNED NOT NULL,
  java_path VARCHAR(500) NULL,
  startup VARCHAR(1000) NOT NULL,
  variables JSON NOT NULL,
  database_limit INT UNSIGNED NOT NULL DEFAULT 0,
  allocation_limit INT UNSIGNED NOT NULL DEFAULT 1,
  backup_limit INT UNSIGNED NOT NULL DEFAULT 3,
  backup_storage_mb INT UNSIGNED NOT NULL DEFAULT 0,
  max_upload_mb INT UNSIGNED NOT NULL DEFAULT 1024,
  auto_restart TINYINT(1) NOT NULL DEFAULT 1,
  suspended_at DATETIME NULL,
  suspended_until DATETIME NULL,
  suspension_reason VARCHAR(500) NULL,
  security_level VARCHAR(16) NOT NULL DEFAULT 'unscanned',
  security_blocked TINYINT(1) NOT NULL DEFAULT 0,
  installed_version VARCHAR(64) NULL,
  installed_build VARCHAR(64) NULL,
  installed_at DATETIME NULL,
  deleting_at DATETIME NULL,
  service_id INT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_node_server (node_id, node_server_id),
  INDEX idx_servers_owner (owner_id), INDEX idx_servers_state (state),
  CONSTRAINT fk_servers_node FOREIGN KEY (node_id) REFERENCES nodes(id),
  CONSTRAINT fk_servers_owner FOREIGN KEY (owner_id) REFERENCES users(id),
  CONSTRAINT fk_servers_egg FOREIGN KEY (egg_id) REFERENCES eggs(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE allocations (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  node_id INT UNSIGNED NOT NULL,
  ip VARCHAR(64) NOT NULL,
  port INT UNSIGNED NOT NULL,
  protocol ENUM('tcp','udp','tcp+udp') NOT NULL DEFAULT 'tcp+udp',
  alias VARCHAR(255) NULL,
  notes VARCHAR(255) NULL,
  server_id INT UNSIGNED NULL,
  is_primary TINYINT(1) NOT NULL DEFAULT 0,
  reachable ENUM('unknown','reachable','unreachable') NOT NULL DEFAULT 'unknown',
  checked_at DATETIME NULL,
  UNIQUE KEY uq_alloc (node_id, ip, port),
  INDEX idx_alloc_server (server_id),
  CONSTRAINT fk_alloc_node FOREIGN KEY (node_id) REFERENCES nodes(id) ON DELETE CASCADE,
  CONSTRAINT fk_alloc_server FOREIGN KEY (server_id) REFERENCES servers(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE server_subusers (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  server_id INT UNSIGNED NOT NULL,
  user_id INT UNSIGNED NOT NULL,
  permissions JSON NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_subuser (server_id, user_id),
  CONSTRAINT fk_su_server FOREIGN KEY (server_id) REFERENCES servers(id) ON DELETE CASCADE,
  CONSTRAINT fk_su_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE server_activity (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  server_id INT UNSIGNED NOT NULL,
  user_id INT UNSIGNED NULL,
  event VARCHAR(100) NOT NULL,
  metadata JSON NULL,
  ip VARCHAR(64) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_sa (server_id, created_at),
  CONSTRAINT fk_sa_server FOREIGN KEY (server_id) REFERENCES servers(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE server_stats (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  server_id INT UNSIGNED NOT NULL,
  cpu FLOAT NOT NULL, memory BIGINT NOT NULL, disk BIGINT NOT NULL,
  at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_ss (server_id, at)
) ENGINE=InnoDB;

CREATE TABLE backups (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  uuid CHAR(36) NOT NULL UNIQUE,
  server_id INT UNSIGNED NOT NULL,
  name VARCHAR(150) NOT NULL,
  status ENUM('pending','creating','completed','failed') NOT NULL DEFAULT 'pending',
  size_bytes BIGINT UNSIGNED NOT NULL DEFAULT 0,
  sha256 CHAR(64) NULL,
  error TEXT NULL,
  locked TINYINT(1) NOT NULL DEFAULT 0,
  is_safety TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  completed_at DATETIME NULL,
  INDEX idx_backups_server (server_id, status),
  CONSTRAINT fk_backups_server FOREIGN KEY (server_id) REFERENCES servers(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE schedules (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  server_id INT UNSIGNED NOT NULL,
  name VARCHAR(100) NOT NULL,
  cron VARCHAR(100) NULL,
  run_once_at DATETIME NULL,
  timezone VARCHAR(64) NOT NULL DEFAULT 'UTC',
  enabled TINYINT(1) NOT NULL DEFAULT 1,
  only_when_online TINYINT(1) NOT NULL DEFAULT 0,
  notify_on_failure TINYINT(1) NOT NULL DEFAULT 1,
  is_processing TINYINT(1) NOT NULL DEFAULT 0,
  last_run_at DATETIME NULL,
  next_run_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_sched_next (enabled, next_run_at),
  CONSTRAINT fk_sched_server FOREIGN KEY (server_id) REFERENCES servers(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE schedule_tasks (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  schedule_id INT UNSIGNED NOT NULL,
  sequence INT UNSIGNED NOT NULL,
  action ENUM('start','stop','restart','kill','command','backup','delete_old_backups','notify') NOT NULL,
  payload VARCHAR(1000) NULL,
  delay_seconds INT UNSIGNED NOT NULL DEFAULT 0,
  continue_on_failure TINYINT(1) NOT NULL DEFAULT 0,
  CONSTRAINT fk_st_sched FOREIGN KEY (schedule_id) REFERENCES schedules(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE schedule_runs (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  schedule_id INT UNSIGNED NOT NULL,
  status ENUM('running','success','failed') NOT NULL,
  output JSON NULL,
  started_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  finished_at DATETIME NULL,
  INDEX idx_sr (schedule_id, started_at),
  CONSTRAINT fk_sr_sched FOREIGN KEY (schedule_id) REFERENCES schedules(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE database_hosts (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  host VARCHAR(255) NOT NULL,
  port INT UNSIGNED NOT NULL DEFAULT 3306,
  public_host VARCHAR(255) NULL,
  username VARCHAR(100) NOT NULL,
  password_enc TEXT NOT NULL,
  node_id INT UNSIGNED NULL,
  max_databases INT UNSIGNED NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE server_databases (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  server_id INT UNSIGNED NOT NULL,
  host_id INT UNSIGNED NOT NULL,
  database_name VARCHAR(64) NOT NULL,
  username VARCHAR(32) NOT NULL,
  password_enc TEXT NOT NULL,
  remote VARCHAR(64) NOT NULL DEFAULT '%',
  max_connections INT UNSIGNED NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_db (host_id, database_name),
  CONSTRAINT fk_sd_server FOREIGN KEY (server_id) REFERENCES servers(id) ON DELETE CASCADE,
  CONSTRAINT fk_sd_host FOREIGN KEY (host_id) REFERENCES database_hosts(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
