import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from 'react';
import { api, setCsrf } from './api';

export interface User { id: number; uuid: string; email: string; username: string; name: string | null; avatar_url: string | null; role_slug: string; role_name: string; permissions: string[]; email_verified: boolean; totp_enabled: boolean; firebase_uid: string | null; has_password: boolean }
export interface PublicConfig { name: string; registration: boolean; requireEmailVerification: boolean; storeEnabled: boolean; currency: string; coins: { enabled: boolean; name: string }; firebase: { apiKey: string; authDomain: string; projectId: string; appId: string } | null; announcements: Array<{ id: number; title: string; body: string; level: string }> }
interface Ctx { user: User | null; config: PublicConfig | null; twoFactorPending: boolean; loading: boolean; refresh: () => Promise<void>; logout: () => Promise<void> }
const AuthContext = createContext<Ctx>(null as any);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<{ user: User | null; config: PublicConfig | null; twoFactorPending: boolean; loading: boolean }>({ user: null, config: null, twoFactorPending: false, loading: true });
  const refresh = useCallback(async () => {
    try { const me = await api('GET', '/api/auth/me'); setCsrf(me.csrf); setState({ user: me.user, config: me.config, twoFactorPending: me.twoFactorPending, loading: false }); }
    catch { setState(s => ({ ...s, loading: false })); }
  }, []);
  const logout = useCallback(async () => { await api('POST', '/api/auth/logout').catch(() => {}); setCsrf(null); await refresh(); }, [refresh]);
  useEffect(() => { refresh(); const h = () => refresh(); window.addEventListener('oghost:unauthorized', h); return () => window.removeEventListener('oghost:unauthorized', h); }, [refresh]);
  return <AuthContext.Provider value={{ ...state, refresh, logout }}>{children}</AuthContext.Provider>;
}
export const useAuth = () => useContext(AuthContext);
export const hasPerm = (u: User | null | undefined, perm: string) => {
  if (!u) return false; const P = u.permissions; if (P.includes('*') || P.includes(perm)) return true;
  const parts = perm.split('.'); for (let i = parts.length - 1; i >= 1; i--) { const pre = parts.slice(0, i).join('.'); if ((i >= 2 && P.includes(pre)) || P.includes(pre + '.*')) return true; }
  return false;
};
export const isAdmin = (u: User | null | undefined) => !!u && (u.permissions.includes('*') || u.permissions.some(p => p.startsWith('admin')));
