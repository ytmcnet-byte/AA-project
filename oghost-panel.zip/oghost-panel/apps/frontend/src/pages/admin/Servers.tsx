import { useEffect, useMemo, useState } from 'react';
import { Link, useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { Download, Plus, Search, Upload } from 'lucide-react';
import { useApi, useAction, toast } from '../../lib/hooks';
import { api, upload } from '../../lib/api';
import { date, mb } from '../../lib/format';
import { Badge, Card, Confirm, Empty, ErrorBox, Field, Loading, Modal, Notice, PageHeader, Pager, Spinner, Switch, Table, Tabs } from '../../components/ui';

export function ServersAdmin() {
  const [sp, setSp] = useSearchParams(); const nav = useNavigate(); const [page, setPage] = useState(1);
  const f = { search: sp.get('search') || '', node: sp.get('node') || '', state: sp.get('state') || '', suspended: sp.get('suspended') || '', owner: sp.get('owner') || '' };
  const setF = (k: string, v: string) => { const n = new URLSearchParams(sp); v ? n.set(k, v) : n.delete(k); setSp(n, { replace: true }); setPage(1); };
  const qs = new URLSearchParams({ page: String(page), per_page: '25', ...Object.fromEntries(Object.entries(f).filter(([, v]) => v)) }).toString();
  const { data, error, loading, reload } = useApi<any>(`/api/admin/servers?${qs}`, [], 10000); const nodes = useApi<any>('/api/admin/nodes');
  return <><PageHeader title="Servers" subtitle="Folders on each node are named by numeric ID only (.server/nodes/<node>/servers/<id>), so servers can share display names." actions={<Link className="btn-primary" to="/admin/servers/new"><Plus className="h-4 w-4" />New server</Link>} />
    <Card title={<div className="flex flex-wrap gap-2"><div className="relative"><Search className="absolute left-3 top-2.5 h-4 w-4 text-ink-500" /><input className="input w-64 pl-9" placeholder="Name, UUID, owner email, ID" value={f.search} onChange={e => setF('search', e.target.value)} /></div>
      <select className="input w-40" value={f.node} onChange={e => setF('node', e.target.value)}><option value="">All nodes</option>{nodes.data?.nodes?.map((n: any) => <option key={n.id} value={n.id}>{n.name}</option>)}</select>
      <select className="input w-40" value={f.state} onChange={e => setF('state', e.target.value)}><option value="">Any state</option>{['running', 'starting', 'stopping', 'offline', 'stopped', 'crashed', 'installing', 'install_failed', 'transferring', 'deleting'].map(s => <option key={s}>{s}</option>)}</select>
      <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={f.suspended === '1'} onChange={e => setF('suspended', e.target.checked ? '1' : '')} />Suspended only</label></div>}>
      {loading ? <Loading /> : error ? <ErrorBox error={error} onRetry={reload} /> : !data.servers.length ? <Empty title="No servers match" /> :
        <Table><thead><tr><th>ID</th><th>Server</th><th>Node / folder</th><th>Owner</th><th>Software</th><th>Resources</th><th>Address</th><th>State</th></tr></thead><tbody>{data.servers.map((s: any) => <tr key={s.id} className="cursor-pointer hover:bg-ink-800/50" onClick={() => nav(`/admin/servers/${s.id}`)}>
          <td>{s.id}</td><td className="font-semibold">{s.name}</td><td className="text-xs">{s.node_name}<div className="font-mono text-ink-400">{s.node_id}/{s.node_server_id}</div></td><td className="text-xs">{s.owner_username}<div className="text-ink-400">{s.owner_email}</div></td><td className="text-xs">{s.egg_name}</td>
          <td className="text-xs">{mb(s.memory_mb)} · {s.cpu_percent ? `${s.cpu_percent}%` : '∞'} CPU · {mb(s.disk_mb)}</td><td className="font-mono text-xs">{s.address || '—'}</td>
          <td><Badge value={s.state} />{s.suspended_at && <Badge value="suspended" className="ml-1" />}{s.security_blocked ? <Badge value="high_risk" label="blocked" className="ml-1" /> : null}</td></tr>)}</tbody></Table>}
      <Pager page={page} setPage={setPage} hasMore={page * 25 < (data?.total || 0)} />
    </Card></>;
}

function useOwnerSearch() {
  const [q, setQ] = useState(''); const { data } = useApi<any>(q.length >= 2 ? `/api/admin/users?per_page=10&search=${encodeURIComponent(q)}` : null, [q]);
  return { q, setQ, users: data?.users || [] };
}
function OwnerPicker({ value, onChange }: { value: any; onChange: (u: any) => void }) {
  const o = useOwnerSearch();
  return <div className="relative">{value ? <div className="input flex items-center justify-between"><span>{value.username} <span className="text-xs text-ink-400">{value.email}</span></span><button className="text-xs text-brand-400" onClick={() => onChange(null)}>Change</button></div> :
    <><input className="input" placeholder="Search user by email or username" value={o.q} onChange={e => o.setQ(e.target.value)} />{o.users.length > 0 && <div className="absolute z-20 mt-1 w-full rounded-lg border border-ink-700 bg-ink-900 shadow-xl">{o.users.map((u: any) => <button key={u.id} className="block w-full px-3 py-2 text-left text-sm hover:bg-ink-800" onClick={() => { onChange(u); o.setQ(''); }}>{u.username} <span className="text-xs text-ink-400">{u.email} · #{u.id}</span></button>)}</div>}</>}</div>;
}

export function ServerCreateAdmin() {
  const nav = useNavigate(); const nodes = useApi<any>('/api/admin/nodes'); const eggs = useApi<any>('/api/admin/eggs'); const { busy, run } = useAction();
  const [owner, setOwner] = useState<any>(null);
  const [f, setF] = useState<any>({ name: '', description: '', nodeId: '', eggId: '', memoryMb: 2048, cpuPercent: 100, diskMb: 5120, swapMb: 0, allocationId: '', additionalAllocations: 0, databaseLimit: 1, allocationLimit: 1, backupLimit: 2, backupStorageMb: 0, javaPath: '', xmsMb: '', xmxMb: '', startup: '', skipInstall: false, autoRestart: true, variables: {} as Record<string, string> });
  const set = (k: string, v: any) => setF((p: any) => ({ ...p, [k]: v }));
  const allocs = useApi<any>(f.nodeId ? `/api/admin/nodes/${f.nodeId}/allocations` : null, [f.nodeId]);
  const java = useApi<any>(f.nodeId ? `/api/admin/nodes/${f.nodeId}/java` : null, [f.nodeId]);
  const egg = useMemo(() => eggs.data?.eggs?.find((e: any) => e.id === Number(f.eggId)), [eggs.data, f.eggId]);
  useEffect(() => { if (egg) setF((p: any) => ({ ...p, variables: Object.fromEntries((egg.definition.variables || []).map((v: any) => [v.key, v.default])), startup: '' })); }, [egg]);
  const free = (allocs.data?.allocations || []).filter((a: any) => !a.server_id);
  const isJava = egg?.definition?.runtime === 'java';
  const heapWarn = isJava && f.xmxMb && Number(f.xmxMb) > f.memoryMb ? 'Xmx cannot exceed the assigned RAM.' : null;
  const submit = () => run('c', async () => {
    const b: any = { ...f, ownerId: owner?.id, nodeId: Number(f.nodeId), eggId: Number(f.eggId), allocationId: f.allocationId ? Number(f.allocationId) : undefined, javaPath: f.javaPath || null, xmsMb: f.xmsMb ? Number(f.xmsMb) : undefined, xmxMb: f.xmxMb ? Number(f.xmxMb) : undefined, startup: f.startup || undefined, description: f.description || undefined };
    const r = await api('POST', '/api/admin/servers', b); nav(`/admin/servers/${r.id}`); return r;
  }, 'Server created');
  const num = (k: string, label: string, hint?: string) => <Field label={label} hint={hint}><input className="input" type="number" value={f[k]} onChange={e => set(k, e.target.value === '' ? '' : Number(e.target.value))} /></Field>;
  return <><PageHeader title="New server" subtitle="The node allocates the next free numeric ID atomically; reserved IDs from unfinished deletions are never reused." />
    <div className="grid gap-6 lg:grid-cols-2">
      <Card title="Basics"><div className="grid gap-4">
        <Field label="Name" hint="Display name only; duplicates are allowed"><input className="input" value={f.name} onChange={e => set('name', e.target.value)} /></Field>
        <Field label="Description"><textarea className="input" value={f.description} onChange={e => set('description', e.target.value)} /></Field>
        <Field label="Owner"><OwnerPicker value={owner} onChange={setOwner} /></Field>
        <Field label="Node"><select className="input" value={f.nodeId} onChange={e => { set('nodeId', e.target.value); set('allocationId', ''); }}><option value="">Select…</option>{nodes.data?.nodes?.map((n: any) => <option key={n.id} value={n.id} disabled={n.status !== 'online' || n.maintenance}>{n.name} ({n.status}{n.maintenance ? ', maintenance' : ''}) — {mb(n.capacity.memoryMax - n.capacity.memory)} RAM free</option>)}</select></Field>
        <Field label="Primary allocation" hint={f.nodeId && !free.length ? 'No free allocations on this node. Add ports under Nodes.' : 'Leave empty to pick the first free port'}><select className="input" value={f.allocationId} onChange={e => set('allocationId', e.target.value)}><option value="">Automatic</option>{free.map((a: any) => <option key={a.id} value={a.id}>{a.ip}:{a.port}{a.alias ? ` (${a.alias})` : ''} — {a.reachable}</option>)}</select></Field>
        {num('additionalAllocations', 'Additional ports to assign')}
      </div></Card>
      <Card title="Software"><div className="grid gap-4">
        <Field label="Egg"><select className="input" value={f.eggId} onChange={e => set('eggId', e.target.value)}><option value="">Select…</option>{eggs.data?.eggs?.map((e: any) => <option key={e.id} value={e.id}>{e.name} ({e.category})</option>)}</select></Field>
        {egg?.definition?.notes && <Notice>{egg.definition.notes}</Notice>}
        {(egg?.definition?.variables || []).map((v: any) => <Field key={v.key} label={`${v.name} (${v.key})`} hint={v.description}><input className="input font-mono" value={f.variables[v.key] ?? ''} onChange={e => set('variables', { ...f.variables, [v.key]: e.target.value })} /></Field>)}
        {isJava && <Field label="Java runtime" hint={egg.definition.javaMin ? `This software needs Java ${egg.definition.javaMin}${egg.definition.javaMax ? `–${egg.definition.javaMax}` : '+'}. Automatic picks a matching install on the node.` : undefined}>
          <select className="input" value={f.javaPath} onChange={e => set('javaPath', e.target.value)}><option value="">Automatic</option>{java.data?.java?.map((j: any) => <option key={j.path} value={j.path}>Java {j.major} ({j.version}, {j.vendor}) — {j.path}</option>)}</select>{java.error && <div className="mt-1 text-xs text-red-300">{java.error}</div>}</Field>}
        <Field label="Startup override" hint="Leave empty to use the egg's startup command"><input className="input font-mono text-xs" placeholder={egg?.definition?.startup} value={f.startup} onChange={e => set('startup', e.target.value)} /></Field>
        <Switch checked={f.skipInstall} onChange={v => set('skipInstall', v)} label="Skip installation (upload files yourself)" />
        <Switch checked={f.autoRestart} onChange={v => set('autoRestart', v)} label="Restart automatically after a crash" />
      </div></Card>
      <Card title="Resources" className="lg:col-span-2"><div className="grid gap-4 sm:grid-cols-3 lg:grid-cols-4">
        {num('memoryMb', 'RAM (MB)')}{num('cpuPercent', 'CPU %', '100 = one core, 0 = unlimited. Enforced with cpulimit (best effort).')}{num('diskMb', 'Disk (MB)', 'Enforced by the agent on every write; not a kernel quota.')}{num('swapMb', 'Swap (MB)')}
        {isJava && <>{num('xmsMb', 'Xms (MB)', 'Empty = recommended')}{num('xmxMb', 'Xmx (MB)', 'Empty = recommended (leaves room for JVM overhead)')}</>}
        {num('databaseLimit', 'Databases')}{num('allocationLimit', 'Port limit')}{num('backupLimit', 'Backups')}{num('backupStorageMb', 'Backup storage (MB, 0 = disk size)')}
      </div>{heapWarn && <Notice kind="error" className="mt-3">{heapWarn}</Notice>}</Card>
    </div>
    <div className="mt-6 flex justify-end gap-2"><Link className="btn-secondary" to="/admin/servers">Cancel</Link><button className="btn-primary" disabled={!!busy || !owner || !f.nodeId || !f.eggId || !f.name || !!heapWarn} onClick={submit}>{busy && <Spinner />}Create server</button></div>
  </>;
}

export function ServerDetailAdmin() {
  const { id } = useParams(); const nav = useNavigate();
  const { data, error, loading, reload } = useApi<any>(`/api/admin/servers/${id}`, [], 8000); const [tab, setTab] = useState<'build' | 'network' | 'actions' | 'security'>('build');
  if (loading) return <Loading />; if (error) return <ErrorBox error={error} onRetry={reload} />;
  const s = data.server;
  return <><PageHeader title={<>{s.name} <Badge value={s.state} className="ml-2 align-middle" />{s.suspended_at && <Badge value="suspended" className="ml-1 align-middle" />}</>}
      subtitle={<>Server #{s.id} · node {data.node.name} ({data.node.status}) · folder <span className="font-mono">.server/nodes/{s.node_id}/servers/{s.node_server_id}</span> · owner <Link className="link" to={`/admin/users/${data.owner?.id}`}>{data.owner?.email}</Link></>}
      actions={<><Link className="btn-secondary" to={`/server/${s.id}`}>Open server panel</Link></>} />
    {s.suspended_at && <Notice kind="error" className="mb-4">Suspended {date(s.suspended_at)}{s.suspended_until ? ` until ${date(s.suspended_until)}` : ''}: {s.suspension_reason}</Notice>}
    {s.state === 'deleting' && <Notice kind="warn" className="mb-4">Deletion has not completed (the node may be offline). The ID stays reserved until it finishes. You can recover the server or retry deletion.</Notice>}
    {data.live?.error && <Notice kind="warn" className="mb-4">Node did not answer: {data.live.error}</Notice>}
    <Tabs value={tab} onChange={setTab} tabs={[{ id: 'build', label: 'Build & startup' }, { id: 'network', label: 'Allocations' }, { id: 'actions', label: 'Actions' }, { id: 'security', label: `Security (${data.incidents.length})` }]} />
    {tab === 'build' && <BuildForm s={s} reload={reload} />}
    {tab === 'network' && <AllocAdmin s={s} allocations={data.allocations} reload={reload} />}
    {tab === 'actions' && <ActionsAdmin s={s} reload={reload} onDeleted={() => nav('/admin/servers')} />}
    {tab === 'security' && <Card title="Incidents">{!data.incidents.length ? <Empty title="No incidents" /> : <Table><thead><tr><th>When</th><th>Severity</th><th>Category</th><th>Rule</th><th>Status</th></tr></thead><tbody>{data.incidents.map((i: any) => <tr key={i.id}><td className="text-xs">{date(i.created_at)}</td><td><Badge value={i.severity === 'high' ? 'high_risk' : 'suspicious'} label={i.severity} /></td><td>{i.category}</td><td className="font-mono text-xs">{i.rule}</td><td>{i.status}</td></tr>)}</tbody></Table>}<div className="mt-3"><Link className="link text-sm" to={`/admin/security?server=${s.id}`}>Open in OGHOST Security Center</Link></div></Card>}
  </>;
}

function BuildForm({ s, reload }: { s: any; reload: () => void }) {
  const eggs = useApi<any>('/api/admin/eggs'); const java = useApi<any>(`/api/admin/nodes/${s.node_id}/java`); const { busy, run } = useAction();
  const init = () => ({ name: s.name, description: s.description || '', memoryMb: s.memory_mb, cpuPercent: s.cpu_percent, diskMb: s.disk_mb, swapMb: s.swap_mb, xmsMb: s.xms_mb, xmxMb: s.xmx_mb, databaseLimit: s.database_limit, allocationLimit: s.allocation_limit, backupLimit: s.backup_limit, backupStorageMb: s.backup_storage_mb, maxUploadMb: s.max_upload_mb, startup: s.startup || '', eggId: s.egg_id, javaPath: s.java_path || '', autoRestart: !!s.auto_restart, variables: { ...s.variables } });
  const [f, setF] = useState<any>(init); useEffect(() => setF(init()), [s.id]); // eslint-disable-line
  const set = (k: string, v: any) => setF((p: any) => ({ ...p, [k]: v }));
  const egg = eggs.data?.eggs?.find((e: any) => e.id === Number(f.eggId));
  const num = (k: string, label: string, hint?: string) => <Field label={label} hint={hint}><input className="input" type="number" value={f[k] ?? ''} onChange={e => set(k, Number(e.target.value))} /></Field>;
  const save = () => run('s', async () => { const r = await api('PATCH', `/api/admin/servers/${s.id}`, { ...f, description: f.description || null, startup: f.startup || undefined, javaPath: f.javaPath || null }); if (r.syncWarning) toast(`Saved, but the node was not updated: ${r.syncWarning}`, 'error'); else if (r.note) toast(r.note, 'info'); reload(); return r; }, 'Saved');
  return <div className="grid gap-6 lg:grid-cols-2">
    <Card title="Details & limits"><div className="grid gap-4 sm:grid-cols-2">
      <Field label="Name" className="sm:col-span-2"><input className="input" value={f.name} onChange={e => set('name', e.target.value)} /></Field>
      <Field label="Description" className="sm:col-span-2"><textarea className="input" value={f.description} onChange={e => set('description', e.target.value)} /></Field>
      {num('memoryMb', 'RAM (MB)')}{num('cpuPercent', 'CPU % (0 = unlimited)')}{num('diskMb', 'Disk (MB)')}{num('swapMb', 'Swap (MB)')}
      {num('xmsMb', 'Xms (MB)')}{num('xmxMb', 'Xmx (MB)', 'Must not exceed RAM')}{num('databaseLimit', 'Databases')}{num('allocationLimit', 'Port limit')}{num('backupLimit', 'Backups')}{num('backupStorageMb', 'Backup storage (MB)')}{num('maxUploadMb', 'Max upload (MB)')}
    </div></Card>
    <Card title="Software & startup"><div className="grid gap-4">
      <Field label="Egg" hint="Changing the egg does not reinstall. Use the version changer or reinstall afterwards."><select className="input" value={f.eggId} onChange={e => set('eggId', Number(e.target.value))}>{eggs.data?.eggs?.map((e: any) => <option key={e.id} value={e.id}>{e.name}</option>)}</select></Field>
      <Field label="Java runtime"><select className="input" value={f.javaPath} onChange={e => set('javaPath', e.target.value)}><option value="">Automatic</option>{java.data?.java?.map((j: any) => <option key={j.path} value={j.path}>Java {j.major} — {j.path}</option>)}</select></Field>
      <Field label="Startup command" hint={<>Empty = egg default: <span className="font-mono">{egg?.definition?.startup}</span></>}><textarea className="input font-mono text-xs" value={f.startup} onChange={e => set('startup', e.target.value)} /></Field>
      {(egg?.definition?.variables || []).map((v: any) => <Field key={v.key} label={`${v.name} (${v.key})`} hint={v.userEditable ? 'Editable by the customer' : 'Admin only'}><input className="input font-mono" value={f.variables[v.key] ?? ''} onChange={e => set('variables', { ...f.variables, [v.key]: e.target.value })} /></Field>)}
      <Switch checked={f.autoRestart} onChange={v => set('autoRestart', v)} label="Auto-restart after crash" />
    </div></Card>
    <div className="flex justify-end lg:col-span-2"><button className="btn-primary" disabled={!!busy} onClick={save}>{busy && <Spinner />}Save changes</button></div>
  </div>;
}

function AllocAdmin({ s, allocations, reload }: { s: any; allocations: any[]; reload: () => void }) {
  const all = useApi<any>(`/api/admin/nodes/${s.node_id}/allocations`); const { run } = useAction(); const [pick, setPick] = useState('');
  const free = (all.data?.allocations || []).filter((a: any) => !a.server_id);
  const add = (primary: boolean, aid: number) => run('a', () => api('POST', `/api/admin/servers/${s.id}/allocations`, { allocationId: aid, primary }).then(() => { reload(); all.reload(); setPick(''); }), 'Allocation updated');
  return <Card title="Allocations" actions={<div className="flex gap-2"><select className="input w-56" value={pick} onChange={e => setPick(e.target.value)}><option value="">Add a free port…</option>{free.map((a: any) => <option key={a.id} value={a.id}>{a.ip}:{a.port}</option>)}</select><button className="btn-primary btn-sm" disabled={!pick} onClick={() => add(false, Number(pick))}>Assign</button></div>}>
    <Notice className="mb-3">“Reachable” means a TCP connection from the panel succeeded. Run a check from the node page; UDP (e.g. Bedrock) cannot be verified this way.</Notice>
    <Table><thead><tr><th>Address</th><th>Alias</th><th>Protocol</th><th>Reachability</th><th /></tr></thead><tbody>{allocations.map(a => <tr key={a.id}><td className="font-mono">{a.ip}:{a.port}{a.is_primary ? <span className="ml-2 badge border-brand-700 text-brand-400">primary</span> : null}</td><td>{a.alias || '—'}</td><td>{a.protocol}</td><td><Badge value={a.reachable} /> <span className="text-xs text-ink-400">{a.checked_at ? date(a.checked_at) : 'never checked'}</span></td>
      <td className="whitespace-nowrap text-right">{!a.is_primary && <><button className="btn-ghost btn-sm" onClick={() => add(true, a.id)}>Make primary</button><button className="btn-ghost btn-sm text-red-400" onClick={() => run('r', () => api('DELETE', `/api/admin/servers/${s.id}/allocations/${a.id}`).then(() => { reload(); all.reload(); }), 'Removed')}>Remove</button></>}</td></tr>)}</tbody></Table>
  </Card>;
}

function ActionsAdmin({ s, reload, onDeleted }: { s: any; reload: () => void; onDeleted: () => void }) {
  const { busy, run } = useAction(); const nodes = useApi<any>('/api/admin/nodes'); const [m, setM] = useState<string | null>(null);
  const [susp, setSusp] = useState({ reason: '', hours: '' }); const [tr, setTr] = useState<any>({ nodeId: '', allocationId: '' }); const [cl, setCl] = useState<any>({ nodeId: String(s.node_id), name: `${s.name} (copy)` });
  const [imp, setImp] = useState<File | null>(null); const [pct, setPct] = useState(0);
  const tAllocs = useApi<any>(tr.nodeId ? `/api/admin/nodes/${tr.nodeId}/allocations` : null, [tr.nodeId]);
  const pw = (a: string) => run(a, () => api('POST', `/api/admin/servers/${s.id}/power`, { action: a }).then(reload), `Sent ${a}`);
  const stopped = ['offline', 'stopped', 'install_failed', 'crashed'].includes(s.state);
  const close = () => setM(null);
  return <div className="grid gap-6 lg:grid-cols-2">
    <Card title="Power"><div className="flex flex-wrap gap-2">{['start', 'restart', 'stop', 'kill'].map(a => <button key={a} className={a === 'kill' ? 'btn-danger' : 'btn-secondary'} disabled={!!busy} onClick={() => pw(a)}>{busy === a && <Spinner />}{a[0].toUpperCase() + a.slice(1)}</button>)}</div></Card>
    <Card title="Suspension"><div className="flex flex-wrap gap-2">{s.suspended_at ? <button className="btn-primary" onClick={() => run('u', () => api('POST', `/api/admin/servers/${s.id}/unsuspend`).then((r: any) => { if (r.securityBlocked) toast('Unsuspended, but the server is still blocked by the Security Center.', 'info'); reload(); }), 'Unsuspended')}>Unsuspend</button> : <button className="btn-secondary" onClick={() => setM('suspend')}>Suspend…</button>}</div></Card>
    <Card title="Move & copy"><div className="flex flex-wrap gap-2"><button className="btn-secondary" onClick={() => setM('transfer')}>Transfer to another node…</button><button className="btn-secondary" disabled={!stopped} title={stopped ? '' : 'Stop the server first'} onClick={() => setM('clone')}>Clone…</button></div><p className="mt-2 text-xs text-ink-400">Transfers and clones run as background jobs; progress is visible under Jobs.</p></Card>
    <Card title="Import / export"><div className="flex flex-wrap gap-2"><a className="btn-secondary" href={`/api/admin/servers/${s.id}/export`}><Download className="h-4 w-4" />Files (.zip)</a><a className="btn-secondary" href={`/api/admin/servers/${s.id}/export-config`}><Download className="h-4 w-4" />Configuration (.json)</a><button className="btn-secondary" disabled={!stopped} onClick={() => setM('import')}><Upload className="h-4 w-4" />Import .zip…</button></div></Card>
    <Card title="Danger zone" className="lg:col-span-2"><div className="flex flex-wrap gap-2"><button className="btn-secondary" onClick={() => setM('reinstall')}>Reinstall</button>{s.state === 'deleting' && <button className="btn-secondary" onClick={() => run('rc', () => api('POST', `/api/admin/servers/${s.id}/recover`).then(reload), 'Recovered')}>Recover</button>}<button className="btn-danger" onClick={() => setM('delete')}>Delete server</button></div></Card>

    <Modal open={m === 'suspend'} onClose={close} title="Suspend server" footer={<><button className="btn-secondary" onClick={close}>Cancel</button><button className="btn-danger" disabled={!!busy} onClick={() => run('s', () => api('POST', `/api/admin/servers/${s.id}/suspend`, { reason: susp.reason || undefined, hours: susp.hours ? Number(susp.hours) : null }).then(() => { close(); reload(); }), 'Suspended')}>Suspend</button></>}>
      <div className="grid gap-4"><Field label="Reason (shown to the owner)"><input className="input" value={susp.reason} onChange={e => setSusp({ ...susp, reason: e.target.value })} /></Field><Field label="Duration in hours" hint="Empty = until manually unsuspended"><input className="input" type="number" value={susp.hours} onChange={e => setSusp({ ...susp, hours: e.target.value })} /></Field></div></Modal>
    <Modal open={m === 'transfer'} onClose={close} title="Transfer server" footer={<><button className="btn-secondary" onClick={close}>Cancel</button><button className="btn-primary" disabled={!tr.nodeId || !!busy} onClick={() => run('t', () => api('POST', `/api/admin/servers/${s.id}/transfer`, { nodeId: Number(tr.nodeId), allocationId: tr.allocationId ? Number(tr.allocationId) : undefined }).then((r: any) => { close(); reload(); toast(`Transfer queued as job #${r.jobId}`, 'success'); }))}>Start transfer</button></>}>
      <Notice className="mb-3">The server is stopped, archived, copied to the target node under a new numeric ID, verified, and only then removed from the source.</Notice>
      <div className="grid gap-4"><Field label="Target node"><select className="input" value={tr.nodeId} onChange={e => setTr({ nodeId: e.target.value, allocationId: '' })}><option value="">Select…</option>{nodes.data?.nodes?.filter((n: any) => n.id !== s.node_id).map((n: any) => <option key={n.id} value={n.id} disabled={n.status !== 'online'}>{n.name} ({n.status})</option>)}</select></Field>
        <Field label="Primary allocation on target"><select className="input" value={tr.allocationId} onChange={e => setTr({ ...tr, allocationId: e.target.value })}><option value="">Automatic</option>{(tAllocs.data?.allocations || []).filter((a: any) => !a.server_id).map((a: any) => <option key={a.id} value={a.id}>{a.ip}:{a.port}</option>)}</select></Field></div></Modal>
    <Modal open={m === 'clone'} onClose={close} title="Clone server" footer={<><button className="btn-secondary" onClick={close}>Cancel</button><button className="btn-primary" disabled={!!busy} onClick={() => run('c', () => api('POST', `/api/admin/servers/${s.id}/clone`, { nodeId: Number(cl.nodeId), name: cl.name }).then((r: any) => { close(); toast(`Clone queued as job #${r.jobId}`, 'success'); }))}>Clone</button></>}>
      <div className="grid gap-4"><Field label="Name"><input className="input" value={cl.name} onChange={e => setCl({ ...cl, name: e.target.value })} /></Field><Field label="Node"><select className="input" value={cl.nodeId} onChange={e => setCl({ ...cl, nodeId: e.target.value })}>{nodes.data?.nodes?.map((n: any) => <option key={n.id} value={n.id}>{n.name}</option>)}</select></Field></div></Modal>
    <Modal open={m === 'import'} onClose={close} title="Import files" footer={<><button className="btn-secondary" onClick={close}>Cancel</button><button className="btn-danger" disabled={!imp || !!busy} onClick={() => run('i', () => upload(`/api/admin/servers/${s.id}/import`, imp!, setPct).then(() => { close(); setImp(null); reload(); }), 'Imported')}>{busy === 'i' && <Spinner />}Replace files</button></>}>
      <Notice kind="warn" className="mb-3">This replaces the server's current files with the archive contents. Paths escaping the server folder are rejected, and the extracted size is checked against the disk limit.</Notice>
      <input type="file" accept=".zip" onChange={e => setImp(e.target.files?.[0] || null)} />{busy === 'i' && <div className="mt-2 text-sm">Uploading {pct}%</div>}</Modal>
    <Confirm open={m === 'reinstall'} onClose={close} danger title="Reinstall server" phrase="REINSTALL" confirmLabel="Reinstall" busy={busy === 'ri'} onConfirm={() => run('ri', () => api('POST', `/api/admin/servers/${s.id}/reinstall`).then(() => { close(); reload(); }), 'Reinstall started')}>Runs the egg installer again. Existing files may be overwritten.</Confirm>
    <Confirm open={m === 'delete'} onClose={close} danger title="Delete server" phrase={`${s.node_id}/${s.node_server_id}`} confirmLabel="Delete permanently" busy={busy === 'd'} onConfirm={() => run('d', async () => { try { const r = await api('DELETE', `/api/admin/servers/${s.id}`, { confirm: `${s.node_id}/${s.node_server_id}` }); close(); onDeleted(); return r; } catch (e) { close(); reload(); throw e; } }, 'Server deleted')}>
      Stops the server and deletes its folder, backups on the node and databases. Type the node/ID identifier to confirm (names are not unique). The numeric ID becomes reusable only after deletion completes.
    </Confirm>
  </div>;
}
