import crypto from 'node:crypto';
import { BUILTIN_EGGS } from '@oghost/shared';
import { q, one, exec, json } from './db';
import { ADMIN_PERMISSIONS, hashPassword, passwordPolicy } from './lib/auth';

/** Idempotent seed: system roles, built-in eggs, example store plans, default location and plugin repositories. Never overwrites admin edits. */
export async function seed(log = console.log) {
  const roles: Array<[string, string, string[]]> = [
    ['super_admin', 'Super Admin', ['*']],
    ['admin', 'Admin', ADMIN_PERMISSIONS.filter(p => p !== 'admin.roles')],
    ['staff', 'Staff', ['admin.overview', 'admin.servers', 'admin.nodes', 'admin.tickets', 'admin.users.read', 'admin.security', 'admin.orders']],
    ['support', 'Support', ['admin.overview', 'admin.tickets', 'admin.users.read']],
    ['customer', 'Customer', []],
  ];
  for (const [slug, name, perms] of roles) {
    const r = await exec('INSERT IGNORE INTO roles (slug, name, permissions, is_system) VALUES (?, ?, ?, 1)', [slug, name, json(perms)]);
    if (r.affectedRows) log(`[seed] role ${slug}`);
  }
  for (const egg of BUILTIN_EGGS) {
    const ex = await one<any>('SELECT id, is_builtin FROM eggs WHERE slug = ?', [egg.slug]);
    if (!ex) { await exec('INSERT INTO eggs (slug, name, category, definition, is_builtin) VALUES (?, ?, ?, ?, 1)', [egg.slug, egg.name, egg.category, json(egg)]); log(`[seed] egg ${egg.slug}`); }
  }
  if (!(await one('SELECT id FROM locations LIMIT 1'))) { await exec("INSERT INTO locations (short, name) VALUES ('default', 'Default location')"); log('[seed] location default'); }
  const repos: Array<[string, string, string]> = [['Modrinth', 'modrinth', 'https://api.modrinth.com'], ['Hangar (PaperMC)', 'hangar', 'https://hangar.papermc.io'], ['SpigotMC (via Spiget)', 'spiget', 'https://api.spiget.org'], ['GitHub Releases', 'github', 'https://api.github.com']];
  if (!(await one('SELECT id FROM plugin_repositories LIMIT 1'))) for (const [n, t, u] of repos) await exec('INSERT INTO plugin_repositories (name, type, base_url, download_hosts, enabled) VALUES (?, ?, ?, ?, 1)', [n, t, u, json([])]);
  if (!(await one('SELECT id FROM product_categories LIMIT 1'))) {
    const c = await exec("INSERT INTO product_categories (name, slug, description, sort) VALUES ('Minecraft Hosting', 'minecraft', 'Java & Bedrock Minecraft servers', 0)");
    const egg = await one<any>("SELECT id FROM eggs WHERE slug = 'paper'");
    const p = await exec("INSERT INTO products (category_id, name, slug, type, description) VALUES (?, 'Minecraft Server', 'minecraft-server', 'minecraft', 'Example plans. Edit prices and resources in Admin > Store.')", [c.insertId]);
    const plans: Array<[string, number, number, number, number]> = [['STARTER', 14900, 2048, 100, 5120], ['PRO', 29900, 4096, 200, 15360], ['ULTIMATE', 59900, 8192, 400, 30720]];
    let i = 0; for (const [n, price, ram, cpu, disk] of plans) await exec('INSERT INTO plans (product_id, name, description, price_cents, currency, billing_cycle, memory_mb, cpu_percent, disk_mb, `databases`, backups, allocations, egg_id, sort) VALUES (?, ?, ?, ?, \'INR\', \'monthly\', ?, ?, ?, ?, ?, ?, ?, ?)', [p.insertId, n, `${ram / 1024} GB RAM, ${cpu / 100} CPU core${cpu > 100 ? 's' : ''}, ${disk / 1024} GB disk`, price, ram, cpu, disk, i + 1, i + 2, i + 1, egg?.id ?? null, i++]);
    log('[seed] store plans STARTER / PRO / ULTIMATE (example prices)');
  }
}

export async function createAdmin(email: string, username: string, password: string) {
  passwordPolicy(password);
  const role = await one<any>("SELECT id FROM roles WHERE slug = 'super_admin'"); if (!role) throw new Error('Run seed first');
  const ex = await one<any>('SELECT id FROM users WHERE email = ? OR username = ?', [email, username]);
  if (ex) { await exec('UPDATE users SET role_id = ?, password_hash = ?, suspended = 0, email_verified_at = COALESCE(email_verified_at, NOW()) WHERE id = ?', [role.id, await hashPassword(password), ex.id]); return ex.id as number; }
  const r = await exec('INSERT INTO users (uuid, email, username, name, password_hash, role_id, email_verified_at) VALUES (?, ?, ?, ?, ?, ?, NOW())', [crypto.randomUUID(), email, username, username, await hashPassword(password), role.id]);
  return r.insertId;
}
export const countUsers = async () => (await q<any>('SELECT COUNT(*) n FROM users'))[0].n as number;
