# Security model and limitations

This document explains what OGHOST PANEL enforces and what it cannot enforce without help from the host. The panel does not claim stronger isolation than the host provides.

## What is enforced

- **No root, no shell for customers.** Customers and subusers act only through the panel API. Agents expose a fixed API and never run arbitrary commands. Startup commands are rendered from egg templates into an argument vector, variables are validated (shell metacharacters rejected), and processes are spawned without a shell.
- **Agents refuse to start game servers as root.** If an agent is started as root without `RUN_AS_UID_BASE`, it refuses to start servers. With `RUN_AS_UID_BASE` set, each server runs as uid/gid `RUN_AS_UID_BASE + serverId`. Running as root is not the recommended mode.
- **Path safety.** Every file operation is resolved under the server's root. Each path component is checked with `lstat`, and traversal (`..`), absolute paths, symlinks pointing outside the root, and dangling symlinks are rejected. Symlinks inside uploaded archives are skipped during extraction.
- **Disk accounting on the node.** The agent reserves space before each write (upload, editor save, extraction, download, plugin install) and refuses writes that would exceed the server's allocation. Usage is measured on the node (symlink targets are not counted). Client-side sizes are never trusted.
- **Authentication.** Passwords are hashed with bcrypt. Sessions are stored server-side with revocation. TOTP 2FA comes with recovery codes. API keys are hashed. Google sign-in requires an ID token verified on the backend with Firebase Admin, and a browser response alone is never trusted. Login, password-reset and mail endpoints are rate-limited.
- **Node communication.** TLS plus short-lived HMAC tokens scoped to a node, and to a server where relevant (see DEPLOYMENT.md).
- **Secrets at rest.** AES-256-GCM encryption with a key derived from `APP_KEY`. Secrets are never returned to the frontend (settings show only whether a value is set).
- **Payments.** An order is only marked paid after a signature-verified webhook (with replay protection and an amount check) or an admin approval. Redirects and screenshots are never trusted.
- **Database credentials.** Customers get credentials for their own database user only. Database-host admin credentials stay encrypted on the panel.

## Limitations (please read)

### Same-Unix-user isolation in non-root mode

In the recommended non-root mode, all game servers on a node run as the same Unix user as the agent. The panel API stops customers from reaching other servers' files, but a malicious plugin or JAR running inside a server process has that user's filesystem permissions and could read or modify other servers' directories on the same node. Kernel-level separation needs one of:
- a host administrator running the agent as root with `RUN_AS_UID_BASE` (separate uid per server), or
- one node per customer or trust group.

The OGHOST Security Center (static JAR scanning) reduces this risk, but it is not a sandbox.

### Disk limits are application-level, not kernel quotas

Application-level storage enforcement is not a substitute for kernel filesystem quotas. The agent blocks writes made through the panel and checks running servers every `DISK_SCAN_SECONDS`. When a running server exceeds its limit, the agent warns, or stops it if `DISK_EXCEEDED_ACTION=stop`. A running server process can still write past its limit between scans, because nothing in the kernel stops it.

**Optional host-admin quota integration:** set `QUOTA_HOOK=/path/to/hook` in `agent.env`. The agent calls it without a shell and with fixed arguments:

```
<hook> set   <serverId> <serverDir> <diskMb>     # on create and whenever diskMb changes
<hook> clear <serverId> <serverDir>              # on delete
```

Exit code `0` means the quota was applied. The server's status then reports `kernelQuota: true`. Any other exit code is logged and the server keeps relying on application-level enforcement. A hook usually wraps `setquota` (project quotas on XFS/ext4), `btrfs qgroup` or `zfs set quota=`. Setting it up requires a host administrator, typically through a narrowly scoped sudoers rule for that one script.

### CPU limits are best-effort

The CPU limit uses `cpulimit` (at `CPULIMIT_PATH`, default `~/bin/cpulimit`), which throttles a process by sending SIGSTOP/SIGCONT. This is best-effort process throttling, not hard kernel-level CPU isolation. Short bursts above the limit are possible, and child processes may not be covered. If `cpulimit` is missing, the panel shows the CPU limit as not enforced. Hard limits need cgroups, which a host administrator has to delegate.

### Memory

The JVM heap (`-Xmx`) is validated so it can never exceed the assigned RAM, and the panel warns when it leaves too little room for off-heap memory. The agent measures and reports the real resident memory (RSS) of each server's process tree, but it does not enforce a hard memory cap. Native (non-Java) servers such as Bedrock or PocketMine-MP have no heap flag at all. Hard memory limits need a cgroup set up by the host administrator.

### Extensions are full trust

Extension server code runs inside the panel process. The permissions in the manifest limit which SDK APIs an extension receives, but they are not a security sandbox. Only install extensions you trust (see EXTENSIONS.md). Extension UI pages run in sandboxed iframes.

### Reachability checks

Port reachability is tested by connecting from the panel's network to the node's public IP. If the panel shares a LAN with the node, a port can look reachable even when the internet can't reach it. UDP cannot be verified with a TCP connect test.

## OGHOST Security Center (anti-abuse)

- Uploaded and installed JARs are scanned statically: the zip structure, nested JARs, class constant pools, known-good hashes and signatures of miners, reverse shells, tunnels and droppers. JARs are never executed for testing.
- **SAFE**: allowed. **SUSPICIOUS**: allowed or held for review depending on `security.blockSuspicious`. An unfamiliar JAR with no Minecraft strings is SUSPICIOUS, never HIGH RISK on that basis alone. **HIGH RISK**: that server is stopped, suspended for `security.autoSuspendHours` (default 48), and the file is blocked. An incident is recorded with evidence (hashes and matched rules), and admins and the owner are notified.
- Only the affected server is suspended. The VPS and unrelated customer processes are never touched, and customer files are never deleted automatically. Admins can release, extend or mark the software as trusted, and customers can file an appeal.

## Reporting vulnerabilities

Email the operator of your OGHOST installation. Do not open public issues for vulnerabilities.
