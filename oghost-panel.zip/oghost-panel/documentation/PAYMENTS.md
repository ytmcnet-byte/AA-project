# Payments

Configure gateways in **Admin → Settings → Payments**. Secrets are stored encrypted. Leaving a secret field empty when saving keeps the existing value.

**An invoice is only marked paid after server-side verification:** a signature-verified webhook whose amount matches the invoice, a server-side API check with the gateway, or an administrator's approval. Browser redirects, client callbacks and screenshots are never trusted on their own.

## Webhook URLs

| Gateway | URL | Events handled |
| --- | --- | --- |
| Razorpay | `<APP_URL>/api/webhooks/razorpay` | `payment.captured`, `order.paid`, `payment.failed`, `refund.processed` |
| Stripe | `<APP_URL>/api/webhooks/stripe` | `checkout.session.completed`, `checkout.session.async_payment_succeeded`, `checkout.session.async_payment_failed`, `checkout.session.expired`, `charge.refunded` |
| Cashfree | `<APP_URL>/api/webhooks/cashfree` | `PAYMENT_SUCCESS_WEBHOOK`, `PAYMENT_FAILED_WEBHOOK` |

## Verification per gateway

- **Razorpay:** HMAC-SHA256 of the raw body with the webhook secret (`x-razorpay-signature`). Events are deduplicated by `x-razorpay-event-id`. The paid amount must equal the invoice total. The checkout callback signature is also checked, and the payment is fetched from the Razorpay API (captured if only authorized) before marking paid.
- **Stripe:** `Stripe-Signature` v1 HMAC with a 300-second timestamp tolerance (stale events are rejected). The checkout session is matched to the payment, and `amount_total` must match.
- **Cashfree:** `x-webhook-signature` (HMAC-SHA256 of timestamp + raw body, base64) with `x-webhook-timestamp`. The order and amount must match.
- **Replay protection:** every webhook event is recorded in `webhook_events`. Events that were already processed are acknowledged without being applied again. An event that failed halfway can be retried by the gateway.

## UPI and manual payments

UPI shows a `upi://pay` link and QR code with the invoice amount and a reference (`tr=OGH<paymentId>`). The customer then submits the UTR or bank reference. This only puts the payment into **awaiting approval**. An administrator checks the bank statement and approves or rejects it in **Admin → Orders & Payments**. References are checked for duplicates.

## After payment

`markInvoicePaid` runs in a transaction (invoice, payment and order), then queues provisioning. The server is created on a node with free capacity in the plan's location. Renewals extend the service. Overdue services are suspended after `store.graceDays` and terminated after `store.terminateDays`, with reminder emails `store.reminderDays` before the due date.

## OGCoins

Plans can also have a coin price. Customers can pay at checkout, on any renewal invoice, or with auto-renew from their OGCoins wallet.
- A coin payment is recorded as a `payments` row with gateway `ogcoins` and amount 0, so money revenue reports do not include it.
- Coupons apply only to money payments.
- Coin purchases are not refunded automatically. Adjust the wallet by hand if needed.

See [COINS.md](COINS.md).

## Plans (seeded)

| Plan | RAM | CPU | Disk |
| --- | --- | --- | --- |
| STARTER | 2 GB | 1 core | 5 GB |
| PRO | 4 GB | 2 cores | 15 GB |
| ULTIMATE | 8 GB | 4 cores | 30 GB |

Prices, billing cycles and limits can be edited in **Admin → Store**.

## Testing

`tests/e2e/payments.test.mjs` sends signed Razorpay and Stripe webhooks to a running panel. It covers valid payments, amount mismatches, forged signatures, replays and stale timestamps. Real gateway accounts were not available during development, so before going live, run a test-mode payment with each gateway you enable.
