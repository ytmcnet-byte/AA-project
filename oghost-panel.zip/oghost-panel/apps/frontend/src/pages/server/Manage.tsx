import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { AlertTriangle, CheckCircle2, Download, Lock, Unlock, Play, Trash2, RefreshCw, Plus, Star, Eye, EyeOff, Copy } from 'lucide-react';
import { useApi, useAction, toast } from '../../lib/hooks';
import { del, get, patch, post, put } from '../../lib/api';
import { useAuth } from '../../lib/auth';
import { ago, bytes, date, cls } from '../../lib/format';
import { Badge, Card, Confirm, Empty, ErrorBox, Field, Loading, Modal, Notice, Spinner, Switch, Table, Pager } from '../../components/ui';
import { useServer } from './ServerLayout';

const copy = (t: string) => { navigator.clipboard?.writeText(t); toast('Copied', 'success'); };
async function waitJob(serverId: number, jobId: number, onTick?: (j: any) => void) {
  for (;;) { const { job } = await get(`/api/servers/${serverId}/jobs/${jobId}`); onTick?.(job); if (job.status === 'done') return job; if (job.status === 'failed') throw new Error(job.last_error || 'Job failed'); await new Promise(r => setTimeout(r, 2000)); }
}

// ---------------- Startup
export function StartupTab() {
  const { id, can, reload: reloadServer } = useServer(); const { data, error, loading, reload } = useApi<any>(`/api/servers/${id}/startup`); const { busy, run } = useAction();
  const [vars, setVars] = useState<Record<string, string>>({}); const [heap, setHeap] = useState({ xms: 0, xmx: 0 }); const [java, setJava] = useState(''); const [startup, setStartup] = useState(''); const [warn, setWarn] = useState<string[]>([]);
  useEffect(() => { if (data) { setVars(Object.fromEntries(data.variables.map((v: any) => [v.key, v.value]))); setHeap({ xms: data.xmsMb, xmx: data.xmxMb }); setJava(data.javaPath || ''); setStartup(data.startup); } }, [data]);
  if (loading) return <Loading />; if (error) return <ErrorBox error={error} />;
  const w = can('startup.update'); const isJava = data.runtime === 'java';
  const heapErr = isJava ? (heap.xmx > data.memoryMb && data.memoryMb ? `Xmx cannot exceed the server RAM (${data.memoryMb} MB)` : heap.xms > heap.xmx ? 'Xms cannot be larger than Xmx' : heap.xmx < 128 || heap.xms < 64 ? 'Xms must be at least 64 MB and Xmx at least 128 MB' : null) : null;
  const save = () => run('save', async () => {
    const changed = Object.fromEntries(Object.entries(vars).filter(([k, v]) => data.variables.find((x: any) => x.key === k)?.value !== v));
    const r = await patch(`/api/servers/${id}/startup`, { variables: changed, ...(isJava ? { xmsMb: heap.xms, xmxMb: heap.xmx, javaPath: java || null } : {}), ...(data.editableStartup && startup !== data.startup ? { startup } : {}) });
    setWarn(r.warnings || []); reload(); reloadServer();
  }, 'Saved. Changes apply on the next start.');
  return (
    <div className="space-y-5">
      {[...data.warnings, ...warn].map((m: string, i: number) => <Notice key={i} kind="warn">{m}</Notice>)}
      <Card title="Startup command">
        {data.editableStartup ? <Field label="Template (administrators only)" hint="Tokens: {{JAVA}} {{XMS}} {{XMX}} {{SERVER_JAR}} {{PORT}} {{JVM_FLAGS}} and variable keys. The command is executed directly, never via a shell."><textarea className="input min-h-20 font-mono text-xs" value={startup} onChange={e => setStartup(e.target.value)} /></Field> : null}
        <div className="mt-3"><div className="label">Resolved command</div><div className="break-all rounded-lg bg-ink-950 p-3 font-mono text-xs text-zinc-300">{data.preview}</div></div>
      </Card>
      {isJava && <Card title="Java & memory">
        <div className="grid gap-4 md:grid-cols-3">
          <Field label="Java runtime" hint={data.requiredJava ? `This version needs Java ${data.requiredJava}+.` : 'Detected on the node.'}><select className="input" disabled={!can('startup.java') && !w} value={java} onChange={e => setJava(e.target.value)}><option value="">Automatic (newest compatible)</option>{data.java.map((j: any) => <option key={j.path} value={j.path} disabled={!!data.requiredJava && j.major < data.requiredJava}>Java {j.major} ({j.version}{j.vendor ? `, ${j.vendor}` : ''}) — {j.path}</option>)}</select></Field>
          <Field label="Xms (initial heap, MB)"><input className="input" type="number" min={64} value={heap.xms} disabled={!w} onChange={e => setHeap({ ...heap, xms: Number(e.target.value) })} /></Field>
          <Field label="Xmx (max heap, MB)" hint={`Server RAM: ${data.memoryMb ? `${data.memoryMb} MB` : 'unlimited'}`}><input className="input" type="number" min={128} max={data.memoryMb || undefined} value={heap.xmx} disabled={!w} onChange={e => setHeap({ ...heap, xmx: Number(e.target.value) })} /></Field>
        </div>
        {heapErr && <Notice kind="error" className="mt-3">{heapErr}</Notice>}
        {!data.java.length && <Notice kind="warn" className="mt-3">No Java installation was detected on this node. Ask an administrator to install Java (no fixed path is assumed; the node searches JAVA_HOME, PATH, /usr/lib/jvm and ~/.oghost/java).</Notice>}
      </Card>}
      <Card title="Variables">
        <div className="grid gap-4 md:grid-cols-2">{data.variables.map((v: any) => <Field key={v.key} label={<>{v.name} <span className="font-mono text-[10px] text-ink-500">{v.key}</span></>} hint={<>{v.description}{!v.userEditable && ' (admin only)'}{v.rules && <span className="block font-mono text-[10px]">rules: {v.rules}</span>}</>}><input className="input font-mono" value={vars[v.key] ?? ''} disabled={!w || (!v.userEditable && !data.editableStartup)} onChange={e => setVars({ ...vars, [v.key]: e.target.value })} /></Field>)}</div>
      </Card>
      {w && <div className="flex justify-end"><button className="btn-primary" disabled={!!busy || !!heapErr} onClick={save}>{busy && <Spinner />}Save startup settings</button></div>}
    </div>
  );
}

// ---------------- Version changer
export function VersionTab() {
  const { id, state, reload: reloadServer, server } = useServer(); const [installer, setInstaller] = useState<string | null>(null);
  const { data, error, loading } = useApi<any>(`/api/servers/${id}/versions${installer ? `?installer=${installer}` : ''}`, [installer]);
  const rb = useApi<any>(`/api/servers/${id}/version/rollbacks`); const { busy, run } = useAction();
  const [ver, setVer] = useState(''); const [builds, setBuilds] = useState<any[] | null>(null); const [build, setBuild] = useState(''); const [backup, setBackup] = useState(true); const [eggId, setEggId] = useState<number | null>(null); const [showAll, setShowAll] = useState(false);
  const [confirm, setConfirm] = useState(false); const [job, setJob] = useState<any>(null); const [rbConfirm, setRbConfirm] = useState<string | null>(null);
  useEffect(() => { setBuilds(null); setBuild(''); if (!ver) return; get(`/api/servers/${id}/versions?version=${encodeURIComponent(ver)}${installer ? `&installer=${installer}` : ''}`).then(r => setBuilds(r.builds)).catch(e => toast(e.message, 'error')); }, [ver, installer]);
  if (loading && !data) return <Loading />; if (error) return <ErrorBox error={error} />;
  const stopped = ['offline', 'crashed', 'install_failed'].includes(state);
  const versions = (data.versions || []).filter((v: any) => showAll || v.stable);
  const start = () => run('go', async () => { setConfirm(false); const r = await post(`/api/servers/${id}/version`, { version: ver, build: build || undefined, eggId: eggId || undefined, backup, confirm: true }); setJob({ status: 'queued' }); await waitJob(id, r.jobId, setJob); toast('Version changed', 'success'); reloadServer(); rb.reload(); });
  return (
    <div className="grid gap-5 lg:grid-cols-3">
      <Card title="Change version" className="lg:col-span-2">
        <div className="mb-4 text-sm text-ink-400">Current: <b className="text-white">{server.egg.name} {data.current.version || 'unknown'}{data.current.build ? ` build ${data.current.build}` : ''}</b></div>
        {!stopped && <Notice kind="warn" className="mb-4">Stop the server before changing version.</Notice>}
        {server.egg.installer === 'custom' ? <Notice>Custom JAR servers have no version list. Upload a new JAR in Files.</Notice> : <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Server software" hint="Only compatible software of the same category is listed."><select className="input" value={eggId ?? server.egg.id} onChange={e => { const sw = data.softwares.find((x: any) => x.id === Number(e.target.value)); setEggId(Number(e.target.value)); setInstaller(sw.installer); setVer(''); }}>{data.softwares.map((s: any) => <option key={s.id} value={s.id}>{s.name}</option>)}</select></Field>
          <Field label="Version" hint={<label className="flex items-center gap-1"><input type="checkbox" checked={showAll} onChange={e => setShowAll(e.target.checked)} />show snapshots / pre-releases</label>}><select className="input" value={ver} onChange={e => setVer(e.target.value)}><option value="">Select…</option>{versions.map((v: any) => <option key={v.id} value={v.id}>{v.id}{v.java ? ` (Java ${v.java}+)` : ''}{!v.stable ? ' — unstable' : ''}</option>)}</select></Field>
          {builds && builds.length > 0 && <Field label="Build"><select className="input" value={build} onChange={e => setBuild(e.target.value)}><option value="">Latest</option>{builds.map((b: any) => <option key={b.id} value={b.id}>{b.id}{b.channel ? ` (${b.channel})` : ''}{b.time ? ` — ${new Date(b.time).toLocaleDateString()}` : ''}</option>)}</select></Field>}
          <div className="sm:col-span-2"><Switch checked={backup} onChange={setBackup} label="Create a full backup first (recommended)" /></div>
          <p className="hint sm:col-span-2">Version files are downloaded from the official project APIs. Before replacing, the current server JAR and libraries are saved as a rollback point. Worlds are not converted automatically; downgrading a world can corrupt it.</p>
          <div className="sm:col-span-2"><button className="btn-primary" disabled={!ver || !stopped || !!busy} onClick={() => setConfirm(true)}>{busy && <Spinner />}Change version</button></div>
        </div>}
        {job && <div className="mt-4 rounded-lg border border-ink-700 bg-ink-850 p-3 text-sm">Job status: <Badge value={job.status} />{job.status === 'failed' && <div className="mt-1 text-red-400">{job.last_error}</div>}{job.status === 'running' && <span className="ml-2 inline-flex items-center gap-1 text-ink-400"><Spinner />Downloading and installing…</span>}</div>}
      </Card>
      <Card title="Rollback points">
        {rb.loading ? <Loading /> : !rb.data?.points?.length ? <Empty title="No rollback points yet" /> : <div className="space-y-2">{[...rb.data.points].reverse().map((p: any) => <div key={p.id} className="flex items-center justify-between gap-2 rounded-lg border border-ink-800 p-2 text-sm"><div><div className="font-semibold">{p.egg || 'previous'} {p.version || p.variables?.MC_VERSION || ''}</div><div className="text-xs text-ink-500">{date(p.at)}</div></div><button className="btn-secondary btn-sm" disabled={!stopped} onClick={() => setRbConfirm(p.id)}>Restore</button></div>)}</div>}
      </Card>
      <Confirm open={confirm} onClose={() => setConfirm(false)} title="Change server version" confirmLabel="Change version" onConfirm={start}>Switch to <b>{ver}</b>{build ? ` build ${build}` : ''}? {backup ? 'A backup is taken first.' : 'No backup will be taken.'}</Confirm>
      <Confirm open={!!rbConfirm} onClose={() => setRbConfirm(null)} title="Roll back version" confirmLabel="Roll back" busy={busy === 'rb'} onConfirm={() => run('rb', () => post(`/api/servers/${id}/version/rollback`, { rollbackId: rbConfirm }).then(() => { setRbConfirm(null); reloadServer(); rb.reload(); }), 'Rolled back')}>Restore the server software files from this rollback point. World data is not touched.</Confirm>
    </div>
  );
}

// ---------------- Plugins
export function PluginsTab() {
  const { id, can } = useServer(); const sources = useApi<any>(`/api/servers/${id}/plugins/sources`); const installed = useApi<any>(`/api/servers/${id}/plugins`); const { busy, run } = useAction();
  const [src, setSrc] = useState('modrinth'); const [q, setQ] = useState(''); const [res, setRes] = useState<any>(null); const [pick, setPick] = useState<any>(null); const [vers, setVers] = useState<any[] | null>(null); const [updates, setUpdates] = useState<any[] | null>(null); const [rm, setRm] = useState<string | null>(null); const [result, setResult] = useState<any>(null);
  const search = () => run('s', async () => setRes(await get(`/api/servers/${id}/plugins/search?source=${encodeURIComponent(src)}&q=${encodeURIComponent(q)}`)));
  useEffect(() => { if (sources.data && !sources.data.sources.some((s: any) => s.id === src)) setSrc(sources.data.sources[0]?.id || 'modrinth'); }, [sources.data]);
  const choose = (p: any) => { setPick(p); setVers(null); get(`/api/servers/${id}/plugins/versions?source=${encodeURIComponent(p.source || src)}&project=${encodeURIComponent(p.id)}`).then(r => setVers(r.versions)).catch(e => { toast(e.message, 'error'); setVers([]); }); };
  const install = (v: any) => run('i', async () => { const r = await post(`/api/servers/${id}/plugins/install`, { source: pick.source || src, project: pick.id, projectName: pick.name, version: v.id }); setPick(null); setResult(r); installed.reload(); });
  const m = can('plugin.manage');
  return (
    <div className="space-y-5">
      <Card title="Installed" actions={<button className="btn-secondary btn-sm" disabled={busy === 'u'} onClick={() => run('u', async () => setUpdates((await post(`/api/servers/${id}/plugins/check-updates`)).updates))}>{busy === 'u' ? <Spinner /> : <RefreshCw className="h-4 w-4" />}Check updates</button>}>
        {installed.loading ? <Loading /> : installed.error ? <ErrorBox error={installed.error} /> : !installed.data.plugins.length ? <Empty title="No plugins or mods installed" /> :
          <Table><thead><tr><th>Name</th><th>Version</th><th>Type</th><th>File</th><th>Size</th><th /></tr></thead><tbody>{installed.data.plugins.map((p: any) => { const tr = installed.data.tracked.find((t: any) => t.file === p.file); const up = tr ? updates?.find((u: any) => u.project === tr.project_id) : null; return <tr key={p.file}><td className="font-semibold">{p.name}{p.missingDependencies?.length > 0 && <div className="text-xs text-amber-400">Missing: {p.missingDependencies.join(', ')}</div>}{tr && <div className="text-xs text-ink-500">from {tr.source}</div>}</td><td>{p.version}{up?.update && <div className="text-xs text-emerald-400">Update available: {up.latest}</div>}{up?.error && <div className="text-xs text-red-400">{up.error}</div>}</td><td>{p.kind}</td><td className="font-mono text-xs">{p.file}</td><td>{bytes(p.size)}</td><td className="text-right">{m && <button className="btn-ghost btn-sm text-red-400" onClick={() => setRm(p.file)}><Trash2 className="h-4 w-4" /></button>}</td></tr>; })}</tbody></Table>}
        {updates && !updates.length && <p className="hint mt-2">No tracked plugins to check (only plugins installed through this panel can be checked).</p>}
      </Card>
      {m && <Card title="Install from repository">
        <div className="flex flex-wrap gap-2"><select className="input w-auto" value={src} onChange={e => { setSrc(e.target.value); setRes(null); }}>{sources.data?.sources.map((s: any) => <option key={s.id} value={s.id}>{s.name}</option>)}</select><input className="input min-w-48 flex-1" placeholder="Search plugins and mods…" value={q} onChange={e => setQ(e.target.value)} onKeyDown={e => e.key === 'Enter' && search()} /><button className="btn-primary" disabled={busy === 's'} onClick={search}>{busy === 's' && <Spinner />}Search</button></div>
        <p className="hint mt-2">Downloads are verified (hash where the source provides one) and statically scanned by the Security Center. Files are never executed during installation.{res && <> Installing into <span className="font-mono">{res.folder}/</span>.</>}</p>
        {res && (res.results.length ? <div className="mt-4 grid gap-3 md:grid-cols-2">{res.results.map((p: any) => <button key={p.id} onClick={() => choose(p)} className="flex gap-3 rounded-lg border border-ink-800 p-3 text-left hover:border-brand-800 hover:bg-ink-850">{p.icon ? <img src={p.icon} alt="" className="h-10 w-10 shrink-0 rounded" loading="lazy" referrerPolicy="no-referrer" /> : <div className="h-10 w-10 shrink-0 rounded bg-ink-800" />}<div className="min-w-0"><div className="truncate font-semibold text-white">{p.name}</div><div className="text-xs text-ink-500">by {p.author} · {Intl.NumberFormat(undefined, { notation: 'compact' }).format(p.downloads)} downloads</div><div className="line-clamp-2 text-xs text-ink-400">{p.description}</div></div></button>)}</div> : <Empty title="No results" />)}
      </Card>}
      <Modal open={!!pick} onClose={() => setPick(null)} title={pick?.name || ''} wide>
        {!vers ? <Loading /> : !vers.length ? <Empty title="No versions found for this server software" /> : <Table><thead><tr><th>Version</th><th>Game versions</th><th>Loaders</th><th>Date</th><th /></tr></thead><tbody>{vers.slice(0, 30).map(v => <tr key={v.id}><td className="font-semibold">{v.name}</td><td className="max-w-48 truncate text-xs">{v.gameVersions?.slice(0, 6).join(', ')}</td><td className="text-xs">{v.loaders?.join(', ')}</td><td className="text-xs">{v.date ? new Date(v.date).toLocaleDateString() : ''}</td><td className="text-right">{v.downloadable ? <button className="btn-primary btn-sm" disabled={!!busy} onClick={() => install(v)}>{busy === 'i' ? <Spinner /> : <Download className="h-4 w-4" />}Install</button> : <span className="text-xs text-ink-500">external / premium</span>}</td></tr>)}</tbody></Table>}
        {pick?.url && <a className="link mt-3 inline-block text-sm" href={pick.url} target="_blank" rel="noreferrer">View project page</a>}
      </Modal>
      <Modal open={!!result} onClose={() => setResult(null)} title="Installation result">
        {result && <div className="space-y-2 text-sm">{result.installed.map((i: any) => <div key={i.file} className="rounded-lg border border-ink-800 p-2"><div className="flex items-center gap-2 font-semibold"><CheckCircle2 className="h-4 w-4 text-emerald-400" />{i.name} {i.version}</div><div className="font-mono text-xs text-ink-400">{i.file}</div>{i.scan && <div className="mt-1 text-xs">Security scan: <Badge value={i.scan.level} label={String(i.scan.level || '').replace('_', ' ').toUpperCase()} /> {i.scan.reason}</div>}</div>)}
          {result.skipped.map((s: any) => <Notice key={s.project} kind="warn">{s.name || s.project}: {s.reason}</Notice>)}{result.restartRequired && <Notice>Restart the server to load new plugins.</Notice>}</div>}
      </Modal>
      <Confirm open={!!rm} onClose={() => setRm(null)} danger title="Remove plugin" confirmLabel="Remove" onConfirm={() => run('rm', () => post(`/api/servers/${id}/plugins/delete`, { file: rm }).then(() => { setRm(null); installed.reload(); }), 'Removed')}>Delete <span className="font-mono">{rm}</span>? Its configuration folder is kept.</Confirm>
    </div>
  );
}

// ---------------- Backups (+ Google Drive)
export function BackupsTab() {
  const { id, can, server } = useServer(); const { data, error, loading, reload } = useApi<any>(`/api/servers/${id}/backups`, [], 5000); const { busy, run } = useAction();
  const [name, setName] = useState(''); const [restore, setRestore] = useState<any>(null); const [truncate, setTruncate] = useState(false); const [rm, setRm] = useState<any>(null);
  if (loading && !data) return <Loading />; if (error) return <ErrorBox error={error} />;
  const full = data.limit > 0 && data.usage.count >= data.limit;
  return (
    <div className="space-y-5">
      <Card title={`Local backups (${data.usage.count}/${data.limit || 0})`} actions={can('backup.create') && <div className="flex gap-2"><input className="input h-8 w-44 py-1 text-xs" placeholder="Backup name (optional)" value={name} onChange={e => setName(e.target.value)} /><button className="btn-primary btn-sm" disabled={full || !!busy || server.suspended} onClick={() => run('c', () => post(`/api/servers/${id}/backups`, { name: name || undefined }).then(() => { setName(''); reload(); }), 'Backup started')}>{busy === 'c' ? <Spinner /> : <Plus className="h-4 w-4" />}Create</button></div>}>
        {full && <Notice kind="warn" className="mb-3">Backup limit reached. Delete an unlocked backup or use Google Drive backups.</Notice>}
        <p className="hint mb-3">Using {bytes(data.usage.bytes)}{data.storageMb ? ` of ${bytes(data.storageMb * 1048576)}` : ''}. Local backups live on the node and are not a substitute for off-site storage.</p>
        {!data.backups.length ? <Empty title="No backups yet" /> : <Table><thead><tr><th>Name</th><th>Status</th><th>Size</th><th>Created</th><th /></tr></thead><tbody>{data.backups.map((b: any) => <tr key={b.id}><td><div className="flex items-center gap-1 font-semibold">{!!b.locked && <Lock className="h-3.5 w-3.5 text-amber-400" />}{b.name}</div>{!!b.is_safety && <div className="text-xs text-ink-500">automatic safety backup</div>}{b.error && <div className="text-xs text-red-400">{b.error}</div>}</td><td><Badge value={b.status} /></td><td>{b.size_bytes ? bytes(b.size_bytes) : '—'}</td><td>{date(b.created_at)}</td>
          <td className="whitespace-nowrap text-right">{b.status === 'completed' && <>{can('backup.download') && <a className="btn-ghost btn-sm px-1.5" title="Download" href={`/api/servers/${id}/backups/${b.id}/download`}><Download className="h-4 w-4" /></a>}{can('backup.restore') && <button className="btn-ghost btn-sm" onClick={() => setRestore(b)}>Restore</button>}</>}{can('backup.create') && <button className="btn-ghost btn-sm px-1.5" title={b.locked ? 'Unlock' : 'Lock (prevents deletion)'} onClick={() => run('l', () => post(`/api/servers/${id}/backups/${b.id}/lock`).then(reload))}>{b.locked ? <Unlock className="h-4 w-4" /> : <Lock className="h-4 w-4" />}</button>}{can('backup.delete') && !b.locked && <button className="btn-ghost btn-sm px-1.5 text-red-400" onClick={() => setRm(b)}><Trash2 className="h-4 w-4" /></button>}</td></tr>)}</tbody></Table>}
      </Card>
      <DriveBackups />
      <Confirm open={!!restore} onClose={() => setRestore(null)} danger title="Restore backup" confirmLabel="Restore" busy={busy === 'r'} onConfirm={() => run('r', () => post(`/api/servers/${id}/backups/${restore.id}/restore`, { truncate, confirm: true }).then(() => { setRestore(null); reload(); }), 'Restore completed')}><p>Restore <b>{restore?.name}</b>? The server must be stopped.</p><label className="flex items-center gap-2"><input type="checkbox" checked={truncate} onChange={e => setTruncate(e.target.checked)} />Delete all current files before restoring</label></Confirm>
      <Confirm open={!!rm} onClose={() => setRm(null)} danger title="Delete backup" confirmLabel="Delete" onConfirm={() => run('d', () => del(`/api/servers/${id}/backups/${rm.id}`).then(() => { setRm(null); reload(); }), 'Backup deleted')}>Delete <b>{rm?.name}</b> permanently?</Confirm>
    </div>
  );
}
function DriveBackups() {
  const { id, can } = useServer(); const status = useApi<any>('/api/drive/status'); const { data, error, loading, reload } = useApi<any>(`/api/drive/servers/${id}`, [], 10000); const { busy, run } = useAction();
  const [cfg, setCfg] = useState<any>(null); const [restore, setRestore] = useState<any>(null);
  useEffect(() => { if (data && !cfg) setCfg(data.config); }, [data]);
  if (status.loading || loading) return <Card title="Google Drive backups"><Loading /></Card>;
  if (!status.data?.configured) return <Card title="Google Drive backups"><Notice>Google Drive backups are not enabled on this panel.</Notice></Card>;
  if (error) return <Card title="Google Drive backups"><ErrorBox error={error} /></Card>;
  const c = data.config; const conn = data.ownerConnection;
  return (
    <Card title="Google Drive backups" actions={data.isOwner && conn?.status === 'active' && <button className="btn-secondary btn-sm" disabled={!!busy || c.running} onClick={() => run('run', () => post(`/api/drive/servers/${id}/run`).then(reload), 'Drive backup queued')}>{c.running ? <Spinner /> : <Play className="h-4 w-4" />}Back up now</button>}>
      {!data.isOwner ? <Notice>Only the server owner can configure backups to their personal Google Drive.</Notice>
        : !conn || conn.status === 'revoked' ? <div className="text-sm"><p className="mb-3 text-ink-400">Connect your Google Drive to keep off-site backups. OGHOST requests only the drive.file scope and stores archives in <span className="font-mono">OGHOST/Node-{'{N}'}/Server-{'{M}'}</span>.</p><button className="btn-primary" onClick={() => run('cn', async () => { const r = await post('/api/drive/connect', { returnTo: `/server/${id}/backups` }); window.location.href = r.url; })}>Connect Google Drive</button></div>
        : <>
          {conn.status !== 'active' && <Notice kind="warn" className="mb-3">Your Drive connection needs attention ({conn.status}). Reconnect it from Account → Google &amp; Drive.</Notice>}
          {c.lastError && <Notice kind="error" className="mb-3">Last error: {c.lastError}{c.failuresInRow > 1 ? ` (${c.failuresInRow} failures in a row)` : ''}</Notice>}
          {cfg && <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <div className="flex items-end"><Switch checked={cfg.enabled} onChange={v => setCfg({ ...cfg, enabled: v })} label="Automatic backups" /></div>
            <Field label="Interval"><select className="input" value={cfg.intervalMinutes} onChange={e => setCfg({ ...cfg, intervalMinutes: Number(e.target.value) })}>{[[60, 'Every hour'], [120, 'Every 2 hours'], [360, 'Every 6 hours'], [720, 'Every 12 hours'], [1440, 'Daily'], [10080, 'Weekly']].map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select></Field>
            <Field label="Keep last" hint="Older backups are removed only after a new one is uploaded and verified."><select className="input" value={cfg.retention} onChange={e => setCfg({ ...cfg, retention: Number(e.target.value) })}>{status.data.retentionOptions.map((r: number) => <option key={r} value={r}>{r} backup{r > 1 ? 's' : ''}</option>)}</select></Field>
            <Field label="Retries on failure"><input className="input" type="number" min={0} max={10} value={cfg.retryCount} onChange={e => setCfg({ ...cfg, retryCount: Number(e.target.value) })} /></Field>
          </div>}
          <div className="mt-3 flex flex-wrap items-center justify-between gap-2 text-xs text-ink-400"><span>Last success: {ago(c.lastSuccessAt)} · Next run: {c.nextRunAt ? date(c.nextRunAt) : '—'}</span>{can('backup.create') && <button className="btn-primary btn-sm" disabled={!!busy} onClick={() => run('save', () => put(`/api/drive/servers/${id}`, { enabled: cfg.enabled, intervalMinutes: cfg.intervalMinutes, retention: cfg.retention, retryCount: cfg.retryCount, retryDelayMinutes: cfg.retryDelayMinutes }).then(reload), 'Drive backup settings saved')}>Save</button>}</div>
        </>}
      {data.backups.length > 0 && <div className="mt-4"><Table><thead><tr><th>Archive</th><th>Status</th><th>Size</th><th>Trigger</th><th>Created</th><th /></tr></thead><tbody>{data.backups.map((b: any) => <tr key={b.id}><td className="font-mono text-xs">{b.name}{b.error && <div className="font-sans text-red-400">{b.error}</div>}</td><td><Badge value={b.status} />{!!b.verified && <span className="ml-1 text-xs text-emerald-400">verified</span>}</td><td>{b.size_bytes ? bytes(b.size_bytes) : '—'}</td><td>{b.trigger_type}</td><td>{date(b.created_at)}</td><td className="text-right">{data.isOwner && b.status === 'completed' && can('backup.restore') && <button className="btn-ghost btn-sm" onClick={() => setRestore(b)}>Restore</button>}</td></tr>)}</tbody></Table></div>}
      <Confirm open={!!restore} onClose={() => setRestore(null)} danger title="Restore from Google Drive" confirmLabel="Restore" busy={busy === 'rs'} onConfirm={() => run('rs', () => post(`/api/drive/servers/${id}/restore/${restore.id}`, { confirm: true }).then(() => { setRestore(null); reload(); }), 'Restore completed')}>The server must be stopped. A local safety backup of the current files is created first; the archive is streamed from Drive and its checksum verified before files are replaced.</Confirm>
    </Card>
  );
}

// ---------------- Schedules
const ACTIONS = ['command', 'start', 'stop', 'restart', 'kill', 'backup', 'delete_old_backups', 'notify'];
const blank = () => ({ name: '', mode: 'cron', cron: '0 4 * * *', runOnceAt: '', timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC', enabled: true, onlyWhenOnline: false, notifyOnFailure: true, tasks: [{ action: 'command', payload: 'say Server restarting soon', delaySeconds: 0, continueOnFailure: false }] });
export function SchedulesTab() {
  const { id, can } = useServer(); const { data, error, loading, reload } = useApi<any>(`/api/servers/${id}/schedules`, [], 15000); const { busy, run } = useAction();
  const [ed, setEd] = useState<any>(null); const [preview, setPreview] = useState<string[] | null>(null); const [rm, setRm] = useState<any>(null);
  useEffect(() => { if (!ed || ed.mode !== 'cron' || !ed.cron) return setPreview(null); const t = setTimeout(() => post('/api/servers/schedules/preview', { cron: ed.cron, timezone: ed.timezone }).then(r => setPreview(r.next)).catch(e => setPreview([`Invalid: ${e.message}`])), 400); return () => clearTimeout(t); }, [ed?.cron, ed?.timezone, ed?.mode]);
  if (loading) return <Loading />; if (error) return <ErrorBox error={error} />;
  const m = can('schedule.manage');
  const save = () => run('save', async () => { const b = { name: ed.name, cron: ed.mode === 'cron' ? ed.cron : null, runOnceAt: ed.mode === 'once' ? new Date(ed.runOnceAt).toISOString() : null, timezone: ed.timezone, enabled: ed.enabled, onlyWhenOnline: ed.onlyWhenOnline, notifyOnFailure: ed.notifyOnFailure, tasks: ed.tasks.map((t: any) => ({ ...t, payload: t.payload || null, delaySeconds: Number(t.delaySeconds) || 0 })) }; if (ed.id) await put(`/api/servers/${id}/schedules/${ed.id}`, b); else await post(`/api/servers/${id}/schedules`, b); setEd(null); reload(); }, 'Schedule saved');
  const setTask = (i: number, patch: any) => setEd({ ...ed, tasks: ed.tasks.map((t: any, j: number) => j === i ? { ...t, ...patch } : t) });
  return (
    <>
      <Card title="Schedules" actions={m && <button className="btn-primary btn-sm" onClick={() => setEd(blank())}><Plus className="h-4 w-4" />New schedule</button>}>
        {!data.schedules.length ? <Empty title="No schedules" /> : <div className="space-y-3">{data.schedules.map((s: any) => <div key={s.id} className="rounded-lg border border-ink-800 p-3">
          <div className="flex flex-wrap items-center justify-between gap-2"><div><div className="flex items-center gap-2 font-semibold text-white">{s.name}<Badge value={s.enabled ? 'enabled' : 'disabled'} />{!!s.is_processing && <Badge value="running" />}</div><div className="font-mono text-xs text-ink-400">{s.cron || `once at ${date(s.run_once_at)}`} ({s.timezone}) · next {s.next_run_at ? date(s.next_run_at) : '—'} · last {ago(s.last_run_at)}</div></div>
            {m && <div className="flex gap-1"><button className="btn-secondary btn-sm" onClick={() => run(`run${s.id}`, () => post(`/api/servers/${id}/schedules/${s.id}/run`).then(reload), 'Schedule queued')}><Play className="h-4 w-4" />Run now</button><button className="btn-secondary btn-sm" onClick={() => setEd({ ...s, mode: s.cron ? 'cron' : 'once', runOnceAt: s.run_once_at ? new Date(s.run_once_at).toISOString().slice(0, 16) : '', enabled: !!s.enabled, onlyWhenOnline: !!s.only_when_online, notifyOnFailure: !!s.notify_on_failure, tasks: s.tasks.map((t: any) => ({ action: t.action, payload: t.payload || '', delaySeconds: t.delay_seconds, continueOnFailure: !!t.continue_on_failure })) })}>Edit</button><button className="btn-ghost btn-sm text-red-400" onClick={() => setRm(s)}><Trash2 className="h-4 w-4" /></button></div>}</div>
          <ol className="mt-2 list-inside list-decimal text-xs text-ink-400">{s.tasks.map((t: any) => <li key={t.id}>{t.delay_seconds ? `wait ${t.delay_seconds}s, then ` : ''}<b className="text-zinc-300">{t.action}</b>{t.payload ? <span className="font-mono"> {t.payload}</span> : ''}</li>)}</ol>
          {s.runs?.length > 0 && <details className="mt-2 text-xs"><summary className="cursor-pointer text-ink-500">Recent runs</summary><div className="mt-1 space-y-1">{s.runs.map((r: any) => <div key={r.id} className="flex gap-2"><Badge value={r.status} /><span>{date(r.started_at)}</span><span className="truncate text-ink-500">{r.output}</span></div>)}</div></details>}
        </div>)}</div>}
      </Card>
      <Modal open={!!ed} onClose={() => setEd(null)} wide title={ed?.id ? 'Edit schedule' : 'New schedule'} footer={<><button className="btn-secondary" onClick={() => setEd(null)}>Cancel</button><button className="btn-primary" disabled={!!busy || !ed?.name || !ed?.tasks?.length} onClick={save}>{busy && <Spinner />}Save</button></>}>
        {ed && <div className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-2"><Field label="Name"><input className="input" value={ed.name} onChange={e => setEd({ ...ed, name: e.target.value })} /></Field><Field label="Timezone"><input className="input" value={ed.timezone} onChange={e => setEd({ ...ed, timezone: e.target.value })} /></Field></div>
          <div className="flex gap-4 text-sm"><label className="flex items-center gap-2"><input type="radio" checked={ed.mode === 'cron'} onChange={() => setEd({ ...ed, mode: 'cron' })} />Repeating (cron)</label><label className="flex items-center gap-2"><input type="radio" checked={ed.mode === 'once'} onChange={() => setEd({ ...ed, mode: 'once' })} />One time</label></div>
          {ed.mode === 'cron' ? <Field label="Cron expression" hint={preview ? <>Next: {preview.map((p, i) => <span key={i} className="mr-2 font-mono">{isNaN(Date.parse(p)) ? p : new Date(p).toLocaleString()}</span>)}</> : 'minute hour day-of-month month day-of-week'}><input className="input font-mono" value={ed.cron} onChange={e => setEd({ ...ed, cron: e.target.value })} /></Field> : <Field label="Run at"><input className="input" type="datetime-local" value={ed.runOnceAt} onChange={e => setEd({ ...ed, runOnceAt: e.target.value })} /></Field>}
          <div className="flex flex-wrap gap-4"><Switch checked={ed.enabled} onChange={v => setEd({ ...ed, enabled: v })} label="Enabled" /><Switch checked={ed.onlyWhenOnline} onChange={v => setEd({ ...ed, onlyWhenOnline: v })} label="Only when server is online" /><Switch checked={ed.notifyOnFailure} onChange={v => setEd({ ...ed, notifyOnFailure: v })} label="Notify me on failure" /></div>
          <div><div className="label">Tasks (run in order)</div><div className="space-y-2">{ed.tasks.map((t: any, i: number) => <div key={i} className="grid gap-2 rounded-lg border border-ink-800 p-2 sm:grid-cols-12">
            <select className="input sm:col-span-3" value={t.action} onChange={e => setTask(i, { action: e.target.value })}>{ACTIONS.map(a => <option key={a} value={a}>{a.replace(/_/g, ' ')}</option>)}</select>
            <input className="input font-mono sm:col-span-5" placeholder={t.action === 'command' ? 'console command' : t.action === 'notify' ? 'message' : t.action === 'delete_old_backups' ? 'keep N (e.g. 3)' : t.action === 'backup' ? 'backup name (optional)' : '—'} disabled={['start', 'stop', 'restart', 'kill'].includes(t.action)} value={t.payload || ''} onChange={e => setTask(i, { payload: e.target.value })} />
            <input className="input sm:col-span-2" type="number" min={0} max={900} title="Delay seconds before this task" value={t.delaySeconds} onChange={e => setTask(i, { delaySeconds: e.target.value })} />
            <div className="flex items-center justify-between gap-1 sm:col-span-2"><label className="flex items-center gap-1 text-xs" title="Continue if this task fails"><input type="checkbox" checked={t.continueOnFailure} onChange={e => setTask(i, { continueOnFailure: e.target.checked })} />cont.</label><button className="btn-ghost btn-sm px-1 text-red-400" onClick={() => setEd({ ...ed, tasks: ed.tasks.filter((_: any, j: number) => j !== i) })}><Trash2 className="h-4 w-4" /></button></div></div>)}</div>
            <button className="btn-secondary btn-sm mt-2" disabled={ed.tasks.length >= 20} onClick={() => setEd({ ...ed, tasks: [...ed.tasks, { action: 'command', payload: '', delaySeconds: 0, continueOnFailure: false }] })}><Plus className="h-4 w-4" />Add task</button><p className="hint mt-1">Delay column = seconds to wait before the task (max 900).</p></div>
        </div>}
      </Modal>
      <Confirm open={!!rm} onClose={() => setRm(null)} danger title="Delete schedule" confirmLabel="Delete" onConfirm={() => run('rm', () => del(`/api/servers/${id}/schedules/${rm.id}`).then(() => { setRm(null); reload(); }), 'Schedule deleted')}>Delete <b>{rm?.name}</b>?</Confirm>
    </>
  );
}

// ---------------- Databases
export function DatabasesTab() {
  const { id, can } = useServer(); const { data, error, loading, reload } = useApi<any>(`/api/servers/${id}/databases`); const { busy, run } = useAction();
  const [name, setName] = useState(''); const [remote, setRemote] = useState('%'); const [show, setShow] = useState<Set<number>>(new Set()); const [rm, setRm] = useState<any>(null); const [newPw, setNewPw] = useState<string | null>(null);
  if (loading) return <Loading />; if (error) return <ErrorBox error={error} />;
  const m = can('database.manage');
  return (
    <Card title={`Databases (${data.databases.length}/${data.limit})`}>
      {m && <div className="mb-4 flex flex-wrap gap-2"><input className="input w-48" placeholder="Name, e.g. luckperms" value={name} onChange={e => setName(e.target.value)} /><input className="input w-36 font-mono" title="Allowed connection host (% = any)" value={remote} onChange={e => setRemote(e.target.value)} /><button className="btn-primary" disabled={!name || data.databases.length >= data.limit || !!busy} onClick={() => run('c', () => post(`/api/servers/${id}/databases`, { name, remote }).then(() => { setName(''); reload(); }), 'Database created')}>{busy === 'c' && <Spinner />}Create database</button></div>}
      {data.limit === 0 && <Notice>Your plan does not include databases.</Notice>}
      {!data.databases.length ? <Empty title="No databases" /> : <Table><thead><tr><th>Database</th><th>Host</th><th>Username</th><th>Password</th><th>Allowed from</th><th /></tr></thead><tbody>{data.databases.map((d: any) => <tr key={d.id}><td className="font-mono text-xs">{d.database_name}</td><td className="font-mono text-xs">{d.host}:{d.port}</td><td className="font-mono text-xs">{d.username} <button onClick={() => copy(d.username)}><Copy className="inline h-3 w-3" /></button></td>
        <td className="font-mono text-xs">{d.password ? <>{show.has(d.id) ? d.password : '••••••••'} <button onClick={() => setShow(s => { const x = new Set(s); x.has(d.id) ? x.delete(d.id) : x.add(d.id); return x; })}>{show.has(d.id) ? <EyeOff className="inline h-3 w-3" /> : <Eye className="inline h-3 w-3" />}</button> <button onClick={() => copy(d.password)}><Copy className="inline h-3 w-3" /></button></> : <span className="text-ink-500">hidden</span>}</td><td className="font-mono text-xs">{d.remote}</td>
        <td className="whitespace-nowrap text-right">{m && <><button className="btn-ghost btn-sm" onClick={() => run(`r${d.id}`, async () => { const r = await post(`/api/servers/${id}/databases/${d.id}/rotate`); setNewPw(r.password); reload(); })}>Rotate password</button><button className="btn-ghost btn-sm text-red-400" onClick={() => setRm(d)}><Trash2 className="h-4 w-4" /></button></>}</td></tr>)}</tbody></Table>}
      <p className="hint mt-3">Each database gets its own user limited to that database. Administrator credentials for the database host are never shown here.</p>
      <Modal open={!!newPw} onClose={() => setNewPw(null)} title="New password"><div className="break-all rounded-lg bg-ink-950 p-3 font-mono text-sm">{newPw}</div><button className="btn-secondary mt-3" onClick={() => copy(newPw!)}>Copy</button><p className="hint mt-2">Update your plugin configuration and restart the server.</p></Modal>
      <Confirm open={!!rm} onClose={() => setRm(null)} danger phrase={rm?.database_name} title="Delete database" confirmLabel="Delete" onConfirm={() => run('d', () => del(`/api/servers/${id}/databases/${rm.id}`).then(() => { setRm(null); reload(); }), 'Database deleted')}>All data in <span className="font-mono">{rm?.database_name}</span> will be permanently lost.</Confirm>
    </Card>
  );
}

// ---------------- Network
export function NetworkTab() {
  const { id, can, reload: reloadServer } = useServer(); const { data, error, loading, reload } = useApi<any>(`/api/servers/${id}/allocations`); const { busy, run } = useAction(); const [rm, setRm] = useState<any>(null);
  if (loading) return <Loading />; if (error) return <ErrorBox error={error} />;
  const m = can('allocation.manage');
  return (
    <Card title={`Ports (${data.allocations.length}/${data.limit})`} actions={m && <button className="btn-primary btn-sm" disabled={data.allocations.length >= data.limit || !!busy} onClick={() => run('a', () => post(`/api/servers/${id}/allocations`).then(() => { reload(); reloadServer(); }), 'Port added')}><Plus className="h-4 w-4" />Add port</button>}>
      <Notice className="mb-4">{data.note}{data.publicIp ? <> Node public IP: <span className="font-mono">{data.publicIp}</span>.</> : null} UDP ports (e.g. Bedrock, voice chat) cannot be verified by a TCP check.</Notice>
      <Table><thead><tr><th>Address</th><th>Protocol</th><th>Reachability</th><th>Notes</th><th /></tr></thead><tbody>{data.allocations.map((a: any) => <tr key={a.id}>
        <td className="font-mono">{a.alias || a.ip}:{a.port} {!!a.is_primary && <Badge value="primary" />}<button className="ml-1" onClick={() => copy(`${a.alias || a.ip}:${a.port}`)}><Copy className="inline h-3 w-3" /></button></td><td className="uppercase">{a.protocol || 'tcp'}</td>
        <td>{a.reachable === 'reachable' ? <span className="flex items-center gap-1 text-emerald-400"><CheckCircle2 className="h-4 w-4" />reachable</span> : a.reachable === 'unreachable' ? <span className="flex items-center gap-1 text-red-400"><AlertTriangle className="h-4 w-4" />not reachable</span> : <span className="text-ink-400">unknown</span>}{a.checked_at && <div className="text-[10px] text-ink-500">checked {ago(a.checked_at)}</div>}</td>
        <td><input className="input h-8 py-1 text-xs" defaultValue={a.notes || ''} disabled={!m} onBlur={e => e.target.value !== (a.notes || '') && run('n', () => patch(`/api/servers/${id}/allocations/${a.id}`, { notes: e.target.value || null }), 'Saved')} /></td>
        <td className="whitespace-nowrap text-right">{m && !a.is_primary && <><button className="btn-ghost btn-sm" title="Make primary" onClick={() => run('p', () => patch(`/api/servers/${id}/allocations/${a.id}`, { primary: true }).then(() => { reload(); reloadServer(); }), 'Primary port changed. Restart to apply.')}><Star className="h-4 w-4" /></button><button className="btn-ghost btn-sm text-red-400" onClick={() => setRm(a)}><Trash2 className="h-4 w-4" /></button></>}</td></tr>)}</tbody></Table>
      <Confirm open={!!rm} onClose={() => setRm(null)} danger title="Remove port" confirmLabel="Remove" onConfirm={() => run('d', () => del(`/api/servers/${id}/allocations/${rm.id}`).then(() => { setRm(null); reload(); }), 'Port removed')}>Release port {rm?.port}? Anything listening on it will stop being reachable after restart.</Confirm>
    </Card>
  );
}

// ---------------- Subusers
export function UsersTab() {
  const { id, can } = useServer(); const { data, error, loading, reload } = useApi<any>(`/api/servers/${id}/users`); const { busy, run } = useAction();
  const [ed, setEd] = useState<any>(null); const [rm, setRm] = useState<any>(null);
  if (loading) return <Loading />; if (error) return <ErrorBox error={error} />;
  const groups: Record<string, string[]> = {}; for (const p of data.permissions as string[]) (groups[p.split('.')[0]] ??= []).push(p);
  const m = can('user.manage');
  const save = () => run('s', async () => { if (ed.user_id) await put(`/api/servers/${id}/users/${ed.user_id}`, { permissions: ed.permissions }); else await post(`/api/servers/${id}/users`, { email: ed.email, permissions: ed.permissions }); setEd(null); reload(); }, 'Saved');
  return (
    <Card title="Subusers" actions={m && <button className="btn-primary btn-sm" onClick={() => setEd({ email: '', permissions: ['control.console', 'control.start', 'control.stop', 'control.restart', 'file.read'] })}><Plus className="h-4 w-4" />Add user</button>}>
      {!data.users.length ? <Empty title="No subusers">Invite other registered users to help manage this server.</Empty> : <Table><thead><tr><th>User</th><th>Permissions</th><th>Added</th><th /></tr></thead><tbody>{data.users.map((u: any) => { const perms = typeof u.permissions === 'string' ? JSON.parse(u.permissions) : u.permissions; return <tr key={u.id}><td><div className="font-semibold">{u.username}</div><div className="text-xs text-ink-500">{u.email}</div></td><td className="text-xs">{perms.length} permission{perms.length === 1 ? '' : 's'}</td><td>{date(u.created_at)}</td><td className="text-right">{m && <><button className="btn-ghost btn-sm" onClick={() => setEd({ ...u, permissions: perms })}>Edit</button><button className="btn-ghost btn-sm text-red-400" onClick={() => setRm(u)}><Trash2 className="h-4 w-4" /></button></>}</td></tr>; })}</tbody></Table>}
      <Modal open={!!ed} onClose={() => setEd(null)} wide title={ed?.user_id ? `Permissions for ${ed.username}` : 'Add subuser'} footer={<><button className="btn-secondary" onClick={() => setEd(null)}>Cancel</button><button className="btn-primary" disabled={!!busy || (!ed?.user_id && !ed?.email)} onClick={save}>Save</button></>}>
        {ed && <div className="space-y-4">{!ed.user_id && <Field label="Email of a registered user"><input className="input" type="email" value={ed.email} onChange={e => setEd({ ...ed, email: e.target.value })} /></Field>}
          <div className="grid gap-3 sm:grid-cols-2">{Object.entries(groups).map(([g, ps]) => <div key={g} className="rounded-lg border border-ink-800 p-3"><div className="mb-1 text-xs font-bold uppercase tracking-wide text-ink-400">{g}</div>{ps.map(p => <label key={p} className={cls('flex items-center gap-2 text-sm', !can(p) && 'opacity-50')}><input type="checkbox" disabled={!can(p)} checked={ed.permissions.includes(p)} onChange={e => setEd({ ...ed, permissions: e.target.checked ? [...ed.permissions, p] : ed.permissions.filter((x: string) => x !== p) })} /><span className="font-mono text-xs">{p}</span></label>)}</div>)}</div></div>}
      </Modal>
      <Confirm open={!!rm} onClose={() => setRm(null)} danger title="Remove subuser" confirmLabel="Remove" onConfirm={() => run('d', () => del(`/api/servers/${id}/users/${rm.user_id}`).then(() => { setRm(null); reload(); }), 'Removed')}>Remove {rm?.username}'s access to this server?</Confirm>
    </Card>
  );
}

// ---------------- Activity
export function ActivityTab() {
  const { id } = useServer(); const [page, setPage] = useState(1); const { data, error, loading } = useApi<any>(`/api/servers/${id}/activity?page=${page}&per_page=50`, [page]);
  if (loading && !data) return <Loading />; if (error) return <ErrorBox error={error} />;
  return <Card title="Activity log"><Table><thead><tr><th>Event</th><th>User</th><th>IP</th><th>Details</th><th>When</th></tr></thead><tbody>{data.activity.map((a: any) => <tr key={a.id}><td className="font-mono text-xs">{a.event}</td><td>{a.username || 'system'}</td><td className="font-mono text-xs">{a.ip || '—'}</td><td className="max-w-xs truncate font-mono text-[11px] text-ink-400" title={typeof a.metadata === 'string' ? a.metadata : JSON.stringify(a.metadata)}>{a.metadata ? (typeof a.metadata === 'string' ? a.metadata : JSON.stringify(a.metadata)) : ''}</td><td className="whitespace-nowrap text-xs">{date(a.created_at)}</td></tr>)}</tbody></Table>
    {!data.activity.length && <Empty title="No activity recorded" />}<Pager page={page} setPage={setPage} hasMore={data.activity.length >= 50} /></Card>;
}

// ---------------- Settings
export function SettingsTab() {
  const { id, server, can, reload, state } = useServer(); const { busy, run } = useAction(); const { user } = useAuth(); const nav = useNavigate();
  const [f, setF] = useState({ name: server.name, description: server.description || '', autoRestart: server.autoRestart }); const [re, setRe] = useState(false);
  return (
    <div className="grid gap-5 lg:grid-cols-2">
      <Card title="General">
        <div className="space-y-3"><Field label="Server name" hint="Names don't need to be unique; storage uses the numeric ID."><input className="input" value={f.name} disabled={!can('settings.rename')} onChange={e => setF({ ...f, name: e.target.value })} maxLength={100} /></Field>
          <Field label="Description"><textarea className="input min-h-20" value={f.description} disabled={!can('settings.rename')} onChange={e => setF({ ...f, description: e.target.value })} maxLength={2000} /></Field>
          <Switch checked={f.autoRestart} disabled={!can('settings.rename')} onChange={v => setF({ ...f, autoRestart: v })} label="Restart automatically after a crash" />
          {can('settings.rename') && <button className="btn-primary" disabled={!!busy} onClick={() => run('s', () => patch(`/api/servers/${id}/settings`, { name: f.name, description: f.description || null, autoRestart: f.autoRestart }).then(reload), 'Settings saved')}>Save</button>}</div>
      </Card>
      <Card title="Server information">
        <dl className="grid grid-cols-2 gap-y-2 text-sm"><dt className="text-ink-400">Server ID</dt><dd className="font-mono">{server.id}</dd><dt className="text-ink-400">Node / folder</dt><dd className="font-mono">Node-{server.nodeId} / {server.nodeServerId}</dd><dt className="text-ink-400">UUID</dt><dd className="truncate font-mono text-xs">{server.uuid}</dd><dt className="text-ink-400">Software</dt><dd>{server.egg.name}</dd><dt className="text-ink-400">RAM</dt><dd>{server.limits.memoryMb ? `${server.limits.memoryMb} MB` : 'unlimited'}</dd><dt className="text-ink-400">CPU</dt><dd>{server.limits.cpuPercent ? `${server.limits.cpuPercent}% (best-effort via cpulimit)` : 'unlimited'}</dd><dt className="text-ink-400">Disk</dt><dd>{server.limits.diskMb ? `${server.limits.diskMb} MB (application-level)` : 'unlimited'}</dd><dt className="text-ink-400">Created</dt><dd>{date(server.createdAt)}</dd></dl>
        <p className="hint mt-3">Need more resources? {user && <button className="link" onClick={() => nav('/billing')}>Upgrade your plan</button>}</p>
      </Card>
      {can('settings.reinstall') && <Card title="Reinstall" className="lg:col-span-2"><p className="mb-3 text-sm text-ink-400">Re-runs the installer for the current software and version. Server files may be overwritten; worlds and configs are usually kept but take a backup first.</p><button className="btn-danger" disabled={!['offline', 'crashed', 'install_failed'].includes(state) || server.securityBlocked} onClick={() => setRe(true)}>Reinstall server</button>{!['offline', 'crashed', 'install_failed'].includes(state) && <span className="ml-3 text-xs text-ink-500">Stop the server first.</span>}</Card>}
      <Confirm open={re} onClose={() => setRe(false)} danger phrase="REINSTALL" title="Reinstall server" confirmLabel="Reinstall" busy={busy === 'r'} onConfirm={() => run('r', () => post(`/api/servers/${id}/reinstall`, { confirm: true }).then(() => { setRe(false); reload(); }), 'Reinstall started')}>The installer will run again.</Confirm>
    </div>
  );
}

// ---------------- Security
export function SecurityTab() {
  const { id, server, reload: reloadServer, can } = useServer(); const { data, error, loading, reload } = useApi<any>(`/api/servers/${id}/security`); const { busy, run } = useAction(); const { user } = useAuth(); const [msg, setMsg] = useState('');
  if (loading) return <Loading />; if (error) return <ErrorBox error={error} />;
  const openAppeal = data.appeals.some((a: any) => a.status === 'open');
  return (
    <div className="space-y-5">
      <Card title="OGHOST Security Center" actions={can('file.read') && <button className="btn-secondary btn-sm" disabled={!!busy} onClick={() => run('scan', async () => { const r = await post(`/api/servers/${id}/security/rescan`); const n = r.results?.length || 0; const worst = r.results?.some((x: any) => x.level === 'high_risk') ? 'HIGH RISK found' : r.results?.some((x: any) => x.level === 'suspicious') ? 'suspicious files found' : 'no threats found'; toast(`Scanned ${n} JAR file${n === 1 ? '' : 's'}: ${worst}`, 'success'); reload(); reloadServer(); })}>{busy === 'scan' ? <Spinner /> : <RefreshCw className="h-4 w-4" />}Rescan JAR files</button>}>
        <div className="flex flex-wrap items-center gap-3 text-sm">Current classification: <Badge value={data.level || 'unscanned'} label={(data.level || 'unscanned').replace('_', ' ').toUpperCase()} />{data.blocked && <Badge value="high" label="on hold" />}{data.suspendedUntil && <span className="text-ink-400">Suspended until {date(data.suspendedUntil)}</span>}</div>
        {data.reason && <Notice kind="warn" className="mt-3">{data.reason}</Notice>}
        <p className="hint mt-3">JAR files are scanned statically (archive structure, manifest, bytecode patterns) and are never executed for testing. A file is not considered malicious merely because it is unfamiliar. Your files are never deleted automatically.</p>
      </Card>
      <Card title="Scan results">{!data.scans.length ? <Empty title="No scans yet" /> : <Table><thead><tr><th>File</th><th>Result</th><th>Reason</th><th>Review</th><th>When</th></tr></thead><tbody>{data.scans.map((s: any) => <tr key={s.id}><td className="max-w-56 truncate font-mono text-xs" title={s.sha256}>{s.file}</td><td><Badge value={s.level} label={String(s.level || '').replace('_', ' ').toUpperCase()} /></td><td className="max-w-md text-xs text-ink-400">{s.reason}</td><td className="text-xs">{s.review_status || '—'}</td><td className="whitespace-nowrap text-xs">{date(s.created_at)}</td></tr>)}</tbody></Table>}</Card>
      {data.incidents.length > 0 && <Card title="Incidents"><Table><thead><tr><th>#</th><th>Severity</th><th>Category</th><th>Status</th><th>Action</th><th>When</th></tr></thead><tbody>{data.incidents.map((i: any) => <tr key={i.id}><td>{i.id}</td><td><Badge value={i.severity} /></td><td>{i.category}</td><td>{i.status}</td><td className="text-xs">{i.action_taken}</td><td className="text-xs">{date(i.created_at)}</td></tr>)}</tbody></Table></Card>}
      {server.ownerId === user?.id && (data.blocked || data.incidents.length > 0 || data.appeals.length > 0) && <Card title="Appeal">
        {data.appeals.map((a: any) => <div key={a.id} className="mb-3 rounded-lg border border-ink-800 p-3 text-sm"><div className="flex items-center gap-2"><Badge value={a.status} /><span className="text-xs text-ink-500">{date(a.created_at)}</span></div><p className="mt-1 whitespace-pre-wrap">{a.message}</p>{a.response && <p className="mt-2 border-l-2 border-brand-700 pl-2 text-ink-300">Staff: {a.response}</p>}</div>)}
        {!openAppeal && <><textarea className="input min-h-24" placeholder="Explain what this file is and where it came from (at least 10 characters)…" value={msg} onChange={e => setMsg(e.target.value)} /><button className="btn-primary mt-2" disabled={msg.trim().length < 10 || !!busy} onClick={() => run('ap', () => post(`/api/servers/${id}/security/appeal`, { message: msg }).then(() => { setMsg(''); reload(); }), 'Appeal submitted')}>Submit appeal</button></>}
      </Card>}
    </div>
  );
}
