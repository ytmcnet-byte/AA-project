import fs from 'node:fs';
import { Readable } from 'node:stream';
import { md5File } from './backups';

/**
 * Google Drive v3 resumable upload, streamed from disk in 8 MiB chunks (never the whole file in RAM).
 * The agent receives only a short-lived ACCESS token from the panel; refresh tokens never leave the panel.
 */
const CHUNK = 32 * 256 * 1024; // 8 MiB, multiple of 256 KiB as required by Drive

export async function driveResumableUpload(opts: { apiBase: string; accessToken: string; parentId: string; name: string; file: string; onProgress?: (d: number, t: number) => void; retries?: number }) {
  const size = fs.statSync(opts.file).size; const localMd5 = await md5File(opts.file);
  const auth = { Authorization: `Bearer ${opts.accessToken}` };
  const init = await fetch(`${opts.apiBase}/upload/drive/v3/files?uploadType=resumable&fields=id,name,size,md5Checksum,createdTime`, {
    method: 'POST', headers: { ...auth, 'Content-Type': 'application/json; charset=UTF-8', 'X-Upload-Content-Type': 'application/zip', 'X-Upload-Content-Length': String(size) },
    body: JSON.stringify({ name: opts.name, parents: [opts.parentId], appProperties: { oghost: '1', md5: localMd5 } }),
  });
  if (!init.ok) throw driveError(init.status, await init.text());
  const session = init.headers.get('location'); if (!session) throw new Error('Drive did not return an upload session');
  let offset = 0; let attempts = 0; const fd = fs.openSync(opts.file, 'r'); let final: any = null;
  try {
    while (offset < size || size === 0) {
      const len = Math.min(CHUNK, size - offset); const buf = Buffer.alloc(len); fs.readSync(fd, buf, 0, len, offset);
      let r: Response;
      try {
        r = await fetch(session, { method: 'PUT', headers: { ...auth, 'Content-Length': String(len), 'Content-Range': size === 0 ? 'bytes */0' : `bytes ${offset}-${offset + len - 1}/${size}` }, body: buf });
      } catch (e) { if (++attempts > (opts.retries ?? 5)) throw e; await sleep(2 ** attempts * 500); offset = await queryOffset(session, auth, size); continue; }
      if (r.status === 308) { const range = r.headers.get('range'); offset = range ? Number(range.split('-')[1]) + 1 : 0; attempts = 0; opts.onProgress?.(offset, size); continue; }
      if (r.status === 200 || r.status === 201) { final = await r.json(); opts.onProgress?.(size, size); break; }
      if (r.status >= 500 || r.status === 429) { if (++attempts > (opts.retries ?? 5)) throw driveError(r.status, await r.text()); await sleep(2 ** attempts * 500); offset = await queryOffset(session, auth, size); continue; }
      throw driveError(r.status, await r.text());
    }
  } finally { fs.closeSync(fd); }
  if (!final?.id) throw new Error('Upload finished without a file id');
  // Integrity verification: Drive's server-side MD5 must equal the local archive MD5
  const bad = final.md5Checksum && final.md5Checksum !== localMd5 ? `Drive md5 ${final.md5Checksum} != local ${localMd5}` : Number(final.size) !== size ? `size ${final.size} != ${size}` : '';
  if (bad) {
    // remove the unverified upload so it is never mistaken for a good backup (previous backups are untouched)
    await fetch(`${opts.apiBase}/drive/v3/files/${encodeURIComponent(final.id)}`, { method: 'DELETE', headers: auth }).catch(() => {});
    throw Object.assign(new Error(`Integrity check failed: ${bad}`), { driveKind: 'verify' });
  }
  return { fileId: final.id as string, md5: localMd5, size, createdTime: final.createdTime as string, verified: !!final.md5Checksum };
}

async function queryOffset(session: string, auth: Record<string, string>, size: number) {
  const r = await fetch(session, { method: 'PUT', headers: { ...auth, 'Content-Range': `bytes */${size}`, 'Content-Length': '0' } });
  if (r.status === 308) { const range = r.headers.get('range'); return range ? Number(range.split('-')[1]) + 1 : 0; }
  return 0;
}

export async function driveDownload(opts: { apiBase: string; accessToken: string; fileId: string; file: string; maxBytes: number }) {
  const auth = { Authorization: `Bearer ${opts.accessToken}` };
  const meta = await fetch(`${opts.apiBase}/drive/v3/files/${encodeURIComponent(opts.fileId)}?fields=id,size,md5Checksum,name`, { headers: auth });
  if (!meta.ok) throw driveError(meta.status, await meta.text());
  const m: any = await meta.json();
  if (opts.maxBytes && Number(m.size) > opts.maxBytes) throw Object.assign(new Error('Backup is larger than the space available on this node'), { status: 507 });
  const r = await fetch(`${opts.apiBase}/drive/v3/files/${encodeURIComponent(opts.fileId)}?alt=media`, { headers: auth });
  if (!r.ok || !r.body) throw driveError(r.status, await r.text());
  await new Promise<void>((res, rej) => { const w = fs.createWriteStream(opts.file, { mode: 0o600 }); Readable.fromWeb(r.body as any).on('error', rej).pipe(w).on('finish', () => res()).on('error', rej); });
  const md5 = await md5File(opts.file);
  if (m.md5Checksum && md5 !== m.md5Checksum) { fs.rmSync(opts.file, { force: true }); throw new Error('Downloaded backup failed integrity verification'); }
  return { size: Number(m.size), md5 };
}

function driveError(status: number, body: string) {
  let reason = ''; try { reason = JSON.parse(body).error?.errors?.[0]?.reason || JSON.parse(body).error?.status || ''; } catch { /* */ }
  const kind = status === 401 ? 'auth' : /storageQuotaExceeded|quotaExceeded/.test(body) ? 'storage_full' : /rateLimitExceeded|userRateLimitExceeded/.test(reason) || status === 429 ? 'quota' : 'api';
  return Object.assign(new Error(`Google Drive error ${status} ${reason}: ${body.slice(0, 300)}`), { status: 502, driveKind: kind });
}
const sleep = (ms: number) => new Promise(r => setTimeout(r, ms));
