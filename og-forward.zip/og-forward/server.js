#!/usr/bin/env node
'use strict';
/**
 * OG Forward - SERVER
 * Public VPS par chalao (root ki zaroorat nahi, ports 1024+).
 *
 *   node server.js [server.config.json]
 *
 * Agent control port par connect hota hai, auth karta hai, aur batata hai
 * kaunse public ports chahiye (koi bhi port / "auto" / poori range).
 * Server wo ports khol deta hai (jo VPS par free hain), aur jab koi visitor
 * aata hai to agent ke through uski local service tak traffic bhej deta hai.
 */
const net = require('net');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { log, rand, send, mac, safeEq, lineStream, bridge } = require('./common');

// ---------- config ----------
const cfgFile = process.argv[2] || path.join(__dirname, 'server.config.json');
let raw;
try {
  raw = JSON.parse(fs.readFileSync(cfgFile, 'utf8'));
} catch (e) {
  console.error(`Config nahi padh paya (${cfgFile}): ${e.message}`);
  console.error('server.config.example.json ko server.config.json naam se copy karke edit karo.');
  process.exit(1);
}

const cfg = Object.assign(
  {
    controlHost: '0.0.0.0',
    controlPort: 7000,
    publicHost: '0.0.0.0',
    maxConnsPerTunnel: 200,   // ek port par max simultaneous visitors
    maxConnsPerUser: 2000,    // ek user ke saare ports mila ke
    maxTunnelsPerUser: 5000,  // ek user max kitne ports khol sakta hai
    autoPortRange: [10000, 60000], // "auto" port isi range se milega
    denyPorts: [],            // ye ports kabhi nahi khulenge
    pendingTimeoutMs: 10000,
    users: {},
  },
  raw
);

const userNames = Object.keys(cfg.users);
if (!userNames.length) {
  console.error('Config me kam se kam 1 user chahiye.');
  process.exit(1);
}
const denySet = new Set([cfg.controlPort, ...cfg.denyPorts.map(Number)]);

for (const name of userNames) {
  const u = cfg.users[name];
  if (!u || typeof u.token !== 'string' || u.token.length < 16) {
    console.error(`User "${name}": token kam se kam 16 characters ka chahiye.`);
    process.exit(1);
  }
  // "ports": "any" (ya na likho) = VPS ka koi bhi port 1024-65535
  if (u.ports === undefined || u.ports === 'any' || u.ports === 'all') {
    u.lo = 1024; u.hi = 65535;
  } else if (
    Array.isArray(u.ports) && u.ports.length === 2 &&
    Number.isInteger(u.ports[0]) && Number.isInteger(u.ports[1]) &&
    u.ports[0] >= 1024 && u.ports[1] <= 65535 && u.ports[0] <= u.ports[1]
  ) {
    [u.lo, u.hi] = u.ports;
  } else {
    console.error(`User "${name}": "ports" ya to "any" ho ya [from, to] (1024-65535).`);
    process.exit(1);
  }
}

// ---------- file descriptor budget ----------
// Har public port = 1 fd, har visitor = 2 fd (visitor + agent data connection).
// Ports itne hi kholte hain ki connections ke liye jagah bachi rahe.
function fdLimits() {
  try {
    const m = fs.readFileSync('/proc/self/limits', 'utf8').match(/Max open files\s+(\S+)\s+(\S+)/);
    if (!m) return null;
    const n = (v) => (v === 'unlimited' ? Infinity : Number(v));
    return { soft: n(m[1]), hard: n(m[2]) };
  } catch { return null; }
}
const fdInfo = fdLimits();
const fdSoft = fdInfo ? fdInfo.soft : Infinity;
const fdReserve = fdSoft === Infinity ? 0 : Math.min(Math.floor(fdSoft * 0.25), cfg.maxConnsPerUser * 2 + 200);
const portBudget = fdSoft === Infinity ? Infinity : Math.max(10, fdSoft - fdReserve - 50);
const FD_MSG = 'fd limit (./start-server.sh se chalao / ulimit -n badhao)';

// ---------- state ----------
const sessions = new Map();     // user -> session
const sessionsById = new Map(); // session id -> session
const portOwners = new Map();   // public port -> session

// ---------- brute-force protection ----------
const fails = new Map(); // ip -> { n, t, until }
function noteFail(ip) {
  const now = Date.now();
  let f = fails.get(ip);
  if (!f || now - f.t > 60000) f = { n: 0, t: now, until: 0 };
  f.n++;
  if (f.n >= 5) f.until = now + 5 * 60000;
  fails.set(ip, f);
}
const isBlocked = (ip) => {
  const f = fails.get(ip);
  return !!(f && f.until > Date.now());
};
setInterval(() => {
  const now = Date.now();
  for (const [ip, f] of fails) if (now - f.t > 10 * 60000 && f.until < now) fails.delete(ip);
}, 60000).unref();

// ---------- helpers ----------
function checkPort(u, port) {
  if (!Number.isInteger(port) || port < 1024 || port > 65535) return 'port 1024-65535 ke beech hona chahiye';
  if (port < u.lo || port > u.hi) return `allowed range ${u.lo}-${u.hi} ke bahar`;
  if (denySet.has(port)) return 'port reserved/denied hai';
  if (portOwners.has(port)) return 'port kisi aur agent ke paas hai';
  if (portOwners.size >= portBudget) return FD_MSG;
  return null;
}

function listenTunnel(s, port) {
  return new Promise((resolve) => {
    const srv = net.createServer((visitor) => onVisitor(s, port, visitor));
    srv.once('error', (e) => resolve({ remotePort: port, ok: false, error: e.code || e.message }));
    srv.listen(port, cfg.publicHost, () => {
      srv.removeAllListeners('error');
      srv.on('error', (e) => log(`[${s.user}] listener :${port} error: ${e.message}`));
      s.listeners.set(port, srv);
      s.counts.set(port, 0);
      portOwners.set(port, s);
      resolve({ remotePort: port, ok: true });
    });
  });
}

const bump = (obj, key, n = 1) => { obj[key] = (obj[key] || 0) + n; };

// Agent ki requests: { remotePort: N } | { remotePort: "auto" } | { portRange: [from, to] }
async function createSession(sock, user, reqs) {
  const u = cfg.users[user];
  const old = sessions.get(user);
  if (old) closeSession(old, 'naye agent ne replace kar diya', 'replaced');

  const s = {
    id: rand(16), user, sock, closed: false, total: 0,
    listeners: new Map(), pending: new Map(), counts: new Map(),
  };
  sessions.set(user, s);
  sessionsById.set(s.id, s);

  const tunnels = []; // single / auto ke results
  const ranges = [];  // range ke summaries

  // Fixed/auto ports pehle, poori ranges baad me - taaki "all" range baaki tunnels ka budget na kha jaye
  const isRange = (r) => (r && Array.isArray(r.portRange) ? 1 : 0);
  const order = [...reqs.slice(0, 200).keys()].sort((a, b) => isRange(reqs[a]) - isRange(reqs[b]));

  for (const idx of order) {
    const r = reqs[idx] || {};

    // ---- poori range ----
    if (Array.isArray(r.portRange)) {
      let from = Number(r.portRange[0]);
      let to = Number(r.portRange[1]);
      if (!Number.isInteger(from) || !Number.isInteger(to) || from > to) {
        ranges.push({ idx, from: 0, to: 0, opened: 0, skipped: 0, reasons: { 'range galat hai': 1 } });
        continue;
      }
      from = Math.max(from, u.lo);
      to = Math.min(to, u.hi);
      const rr = { idx, from, to, opened: 0, skipped: 0, reasons: {} };
      for (let p = from; p <= to; p++) {
        if (s.listeners.size >= cfg.maxTunnelsPerUser || portOwners.size >= portBudget) {
          bump(rr.reasons, s.listeners.size >= cfg.maxTunnelsPerUser ? 'maxTunnelsPerUser limit' : FD_MSG, to - p + 1);
          rr.skipped += to - p + 1;
          break;
        }
        const bad = checkPort(u, p);
        if (bad) { rr.skipped++; bump(rr.reasons, bad); continue; }
        const res = await listenTunnel(s, p);
        if (res.ok) { rr.opened++; continue; }
        rr.skipped++;
        bump(rr.reasons, res.error);
        if (res.error === 'EMFILE') { // file descriptor limit khatam
          bump(rr.reasons, 'EMFILE (ulimit -n badhao)', to - p);
          rr.skipped += to - p;
          break;
        }
      }
      ranges.push(rr);
      continue;
    }

    // ---- auto: server khud free port de ----
    if (r.remotePort === 'auto' || r.remotePort === 0) {
      let alo = Math.max(u.lo, cfg.autoPortRange[0]);
      let ahi = Math.min(u.hi, cfg.autoPortRange[1]);
      if (alo > ahi) { alo = u.lo; ahi = u.hi; }
      let got = null;
      let err = 'koi free port nahi mila';
      for (let i = 0; i < 200 && !got; i++) {
        const p = crypto.randomInt(alo, ahi + 1);
        const bad = checkPort(u, p);
        if (bad === FD_MSG) { err = bad; break; }
        if (bad) continue;
        const res = await listenTunnel(s, p);
        if (res.ok) got = res; else err = res.error;
      }
      tunnels.push(got ? { idx, ...got } : { idx, remotePort: 0, ok: false, error: err });
      continue;
    }

    // ---- ek fixed port ----
    const port = Number(r.remotePort);
    const bad = checkPort(u, port);
    tunnels.push({ idx, ...(bad ? { remotePort: port, ok: false, error: bad } : await listenTunnel(s, port)) });
  }

  send(sock, { t: 'ok', session: s.id, tunnels, ranges });
  const opened = s.listeners.size;
  log(`[${user}] agent connected - ${opened} public port(s) open`);
  for (const r of tunnels) if (!r.ok) log(`[${user}]   port ${r.remotePort} fail: ${r.error}`);
  for (const r of ranges) if (r.skipped) log(`[${user}]   range ${r.from}-${r.to}: ${r.opened} open, ${r.skipped} skipped ${JSON.stringify(r.reasons)}`);
  return s;
}

function closeSession(s, why, code) {
  if (s.closed) return;
  s.closed = true;
  log(`[${s.user}] session close: ${why}`);
  for (const [port, srv] of s.listeners) {
    srv.close();
    portOwners.delete(port);
  }
  for (const p of s.pending.values()) {
    clearTimeout(p.timer);
    p.visitor.destroy();
  }
  if (sessions.get(s.user) === s) sessions.delete(s.user);
  sessionsById.delete(s.id);
  if (code === 'replaced') {
    // purane agent ko batao taaki wo dobara reconnect karke ladai na kare
    s.sock.end(JSON.stringify({ t: 'err', code, msg: 'Same user ka naya agent connect ho gaya, ye agent band ho raha hai' }) + '\n');
    setTimeout(() => s.sock.destroy(), 2000).unref();
  } else {
    s.sock.destroy();
  }
}

// Public port par koi visitor aaya
function onVisitor(s, port, visitor) {
  visitor.on('error', () => {});
  if (s.closed || s.total >= cfg.maxConnsPerUser || (s.counts.get(port) || 0) >= cfg.maxConnsPerTunnel) {
    return visitor.destroy();
  }
  s.total++;
  s.counts.set(port, (s.counts.get(port) || 0) + 1);
  visitor.setNoDelay(true);
  visitor.setKeepAlive(true, 30000);
  visitor.pause(); // agent ka data connection aane tak data rok ke rakho

  const id = rand(8);
  const timer = setTimeout(() => visitor.destroy(), cfg.pendingTimeoutMs);
  s.pending.set(id, { visitor, timer, port });
  visitor.once('close', () => {
    const p = s.pending.get(id);
    if (p) { clearTimeout(p.timer); s.pending.delete(id); }
    s.total = Math.max(0, s.total - 1);
    s.counts.set(port, Math.max(0, (s.counts.get(port) || 1) - 1));
  });
  send(s.sock, { t: 'conn', id, remotePort: port });
}

// Agent ne is visitor ke liye naya data connection khola
function onDataConn(sock, m) {
  const s = sessionsById.get(String(m.session));
  const id = String(m.id);
  const p = s && !s.closed ? s.pending.get(id) : null;
  if (!p) return sock.destroy();
  clearTimeout(p.timer);
  s.pending.delete(id);
  sock.setNoDelay(true);
  sock.setKeepAlive(true, 30000);
  bridge(sock, p.visitor);
}

// ---------- control server ----------
const control = net.createServer((sock) => {
  const ip = sock.remoteAddress;
  sock.on('error', () => {});
  if (isBlocked(ip)) return sock.destroy();

  sock.setNoDelay(true);
  sock.setKeepAlive(true, 30000);
  sock.setTimeout(10000, () => sock.destroy()); // handshake timeout

  let state = 'first';
  let user = null;
  let nonce = null;
  let session = null;

  const ls = lineStream(sock, async (line) => {
    let m;
    try { m = JSON.parse(line); } catch { return sock.destroy(); }
    if (!m || typeof m !== 'object') return sock.destroy();

    if (state === 'first') {
      if (m.t === 'data') {
        ls.detach();
        sock.setTimeout(0);
        return onDataConn(sock, m);
      }
      if (m.t === 'hello' && typeof m.user === 'string' &&
          Object.prototype.hasOwnProperty.call(cfg.users, m.user)) {
        user = m.user;
        nonce = rand(16);
        state = 'auth';
        return send(sock, { t: 'challenge', nonce });
      }
      noteFail(ip);
      return sock.destroy();
    }

    if (state === 'auth') {
      if (m.t !== 'auth' || !safeEq(m.mac, mac(cfg.users[user].token, nonce, user))) {
        noteFail(ip);
        log(`[${user}] auth fail from ${ip}`);
        return sock.end(JSON.stringify({ t: 'err', code: 'auth', msg: 'Auth fail: user/token galat hai' }) + '\n');
      }
      state = 'busy';
      sock.setTimeout(0); // bade range setup me time lag sakta hai
      session = await createSession(sock, user, Array.isArray(m.tunnels) ? m.tunnels : []);
      if (sock.destroyed) return closeSession(session, 'agent setup ke beech gaya');
      state = 'ready';
      sock.setTimeout(45000, () => sock.destroy()); // agent har 15s ping bhejta hai
      return;
    }

    if (state === 'ready') {
      if (m.t === 'ping') return send(sock, { t: 'pong' });
      if (m.t === 'fail') {
        const p = session.pending.get(String(m.id));
        if (p) { clearTimeout(p.timer); p.visitor.destroy(); }
      }
    }
  });

  sock.on('close', () => {
    if (session) closeSession(session, 'agent disconnect');
  });
});

control.on('error', (e) => {
  console.error(`Control port ${cfg.controlPort} nahi khul paya: ${e.message}`);
  process.exit(1);
});
control.listen(cfg.controlPort, cfg.controlHost, () => {
  log(`OG Forward server ready - control ${cfg.controlHost}:${cfg.controlPort}, users: ${userNames.join(', ')}`);
  if (fdInfo) {
    log(`open files limit: soft=${fdInfo.soft} hard=${fdInfo.hard} -> max ~${portBudget === Infinity ? 'unlimited' : portBudget} public ports ` +
      `(baaki fds visitors ke liye reserve)`);
    if (fdInfo.soft !== fdInfo.hard) log('Zyada ports chahiye to ./start-server.sh se chalao - wo limit badha deta hai.');
  }
});

for (const sig of ['SIGINT', 'SIGTERM']) {
  process.on(sig, () => { log(`${sig} - band ho raha hai`); process.exit(0); });
}
