import { build } from 'esbuild';
import path from 'node:path';
const root = path.resolve(import.meta.dirname, '..');
const common = {
  bundle: true, platform: 'node', target: 'node20', format: 'esm', packages: 'external', sourcemap: true,
  alias: { '@oghost/shared': path.join(root, 'packages/shared/src/index.ts'), '@oghost/extension-sdk': path.join(root, 'packages/extension-sdk/src/index.ts') },
  banner: { js: "import { createRequire as __cr } from 'node:module'; const require = __cr(import.meta.url);" },
};
await build({ ...common, entryPoints: [path.join(root, 'apps/node-agent/src/index.ts')], outfile: path.join(root, 'dist/agent.mjs') });
await build({ ...common, entryPoints: [path.join(root, 'apps/panel/src/index.ts')], outfile: path.join(root, 'dist/panel.mjs') });
console.log('backend built -> dist/agent.mjs, dist/panel.mjs');
