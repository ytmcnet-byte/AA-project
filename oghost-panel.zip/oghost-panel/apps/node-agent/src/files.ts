import fs from 'node:fs';
import path from 'node:path';
import { Router, type Request, type Response } from 'express';
import { safeResolve, toRelative } from '@oghost/shared';
import { createZip, extractZip, zipDeclaredSize } from './archive';
import { dirSize } from './disk';
import { scanUploaded } from './security';
import type { ServerInstance } from './server';

type Get = (req: Request) => ServerInstance;
const TEXT_LIMIT = 8 * 1024 * 1024;
const isProtected = (rel: string) => /^\/?\.oghost(\/|$)/.test(rel.replace(/^\/+/, '/').replace(/^\//, ''));

export function fileRoutes(get: Get) {
  const r = Router({ mergeParams: true });
  const P = (inst: ServerInstance, p: unknown) => safeResolve(inst.dir, String(p ?? '/'));

  r.get('/list', async (req, res) => {
    const inst = get(req); const abs = P(inst, req.query.path);
    const ents = await fs.promises.readdir(abs, { withFileTypes: true });
    const out = await Promise.all(ents.map(async e => {
      const p = path.join(abs, e.name); const st = await fs.promises.lstat(p).catch(() => null); if (!st) return null;
      return { name: e.name, path: toRelative(inst.dir, p), directory: st.isDirectory(), symlink: st.isSymbolicLink(), size: st.size, mode: (st.mode & 0o777).toString(8).padStart(3, '0'), modified: st.mtime.toISOString(), editable: st.isFile() && st.size <= TEXT_LIMIT && !/\.(jar|zip|gz|tar|png|jpg|jpeg|gif|dat|mca|nbt|db|so|exe|phar)$/i.test(e.name) };
    }));
    res.json({ path: toRelative(inst.dir, abs), entries: out.filter(Boolean).sort((a: any, b: any) => Number(b.directory) - Number(a.directory) || a.name.localeCompare(b.name)) });
  });

  r.get('/contents', async (req, res) => {
    const inst = get(req); const abs = P(inst, req.query.path); const st = await fs.promises.stat(abs);
    if (!st.isFile()) throw Object.assign(new Error('Not a file'), { status: 400 });
    if (st.size > TEXT_LIMIT) throw Object.assign(new Error('File too large for the editor (8 MB max)'), { status: 413 });
    res.type('text/plain').send(await fs.promises.readFile(abs));
  });

  r.post('/write', async (req, res) => {
    const inst = get(req); const abs = P(inst, req.query.path); const body: Buffer = req.body instanceof Buffer ? req.body : Buffer.from(String(req.body ?? ''));
    const prev = await fs.promises.stat(abs).then(s => s.size).catch(() => 0);
    const resv = inst.disk.reserve(Math.max(0, body.length - prev));
    try { await fs.promises.mkdir(path.dirname(abs), { recursive: true }); await fs.promises.writeFile(abs, body, { mode: 0o640 }); resv.release(body.length - prev); }
    catch (e) { resv.release(0); throw e; }
    res.json({ ok: true, size: body.length });
  });

  /** Streaming upload. Size must be declared (X-File-Size or Content-Length) and is reserved up-front. */
  r.put('/upload', async (req, res) => {
    const inst = get(req); const dir = P(inst, req.query.directory || '/'); const name = String(req.query.name || '');
    if (!name || name.includes('/') || name === '..' || name === '.') throw Object.assign(new Error('Invalid file name'), { status: 400 });
    const abs = safeResolve(inst.dir, path.posix.join(toRelative(inst.dir, dir), name));
    const declared = Number(req.headers['x-file-size'] || req.headers['content-length'] || 0);
    const maxUpload = inst.spec.maxUploadMb * 1024 * 1024;
    if (!declared) throw Object.assign(new Error('Upload size must be declared'), { status: 411 });
    if (maxUpload && declared > maxUpload) throw Object.assign(new Error(`File exceeds upload limit of ${inst.spec.maxUploadMb} MB`), { status: 413 });
    const prev = await fs.promises.stat(abs).then(s => s.size).catch(() => 0);
    const resv = inst.disk.reserve(Math.max(0, declared - prev));
    const tmp = `${abs}.oghost-upload-${process.pid}-${Date.now()}`; let written = 0;
    try {
      await fs.promises.mkdir(path.dirname(abs), { recursive: true });
      await new Promise<void>((ok, fail) => {
        const w = fs.createWriteStream(tmp, { mode: 0o640 });
        req.on('data', (c: Buffer) => { written += c.length; if (written > declared) { req.unpipe(w); w.destroy(); fail(Object.assign(new Error('Upload larger than declared size'), { status: 413 })); } });
        req.on('aborted', () => { w.destroy(); fail(new Error('Upload aborted')); });
        w.on('error', fail); w.on('finish', () => ok()); req.pipe(w);
      });
      await fs.promises.rename(tmp, abs); resv.release(written - prev);
    } catch (e) { resv.release(0); await fs.promises.rm(tmp, { force: true }); throw e; }
    void scanUploaded(inst, abs);
    res.json({ ok: true, path: toRelative(inst.dir, abs), size: written });
  });

  r.get('/download', async (req, res) => {
    const inst = get(req); const abs = P(inst, req.query.path); const st = await fs.promises.stat(abs);
    if (!st.isFile()) throw Object.assign(new Error('Not a file'), { status: 400 });
    res.setHeader('Content-Length', st.size); res.setHeader('Content-Disposition', `attachment; filename="${path.basename(abs).replace(/"/g, '')}"`);
    res.type('application/octet-stream'); fs.createReadStream(abs).pipe(res);
  });

  r.post('/delete', async (req, res) => {
    const inst = get(req); const paths: string[] = req.body?.paths || [];
    for (const p of paths) { const abs = P(inst, p); if (abs === fs.realpathSync(inst.dir)) throw Object.assign(new Error('Cannot delete the server root'), { status: 400 }); await fs.promises.rm(abs, { recursive: true, force: true }); }
    inst.disk.rescan(); res.json({ ok: true, deleted: paths.length });
  });

  r.post('/rename', async (req, res) => {
    const inst = get(req); const items: Array<{ from: string; to: string }> = req.body?.items || [{ from: req.body.from, to: req.body.to }];
    for (const it of items) { const a = P(inst, it.from), b = P(inst, it.to); if (fs.existsSync(b)) throw Object.assign(new Error(`Target exists: ${it.to}`), { status: 409 }); await fs.promises.mkdir(path.dirname(b), { recursive: true }); await fs.promises.rename(a, b); }
    res.json({ ok: true });
  });

  r.post('/copy', async (req, res) => {
    const inst = get(req); const items: Array<{ from: string; to: string }> = req.body?.items || [];
    for (const it of items) {
      const a = P(inst, it.from); let b = P(inst, it.to);
      if (fs.existsSync(b)) { const ext = path.extname(b); b = b.slice(0, b.length - ext.length) + ` copy ${Date.now() % 100000}` + ext; }
      const size = (await fs.promises.lstat(a)).isDirectory() ? await dirSize(a) : (await fs.promises.stat(a)).size;
      const resv = inst.disk.reserve(size);
      try { await fs.promises.cp(a, b, { recursive: true, verbatimSymlinks: true, errorOnExist: true, filter: (src) => !fs.lstatSync(src).isSymbolicLink() }); resv.release(size); } catch (e) { resv.release(0); throw e; }
    }
    res.json({ ok: true });
  });

  r.post('/mkdir', async (req, res) => { const inst = get(req); await fs.promises.mkdir(P(inst, req.body.path), { recursive: true, mode: 0o750 }); res.json({ ok: true }); });

  r.post('/chmod', async (req, res) => {
    const inst = get(req); const mode = parseInt(String(req.body.mode), 8);
    if (!Number.isInteger(mode) || mode < 0 || mode > 0o777) throw Object.assign(new Error('Mode must be octal 000-777 (no setuid/setgid/sticky)'), { status: 400 });
    if ((mode & 0o600) !== 0o600) throw Object.assign(new Error('Owner must keep read/write permission'), { status: 400 });
    await fs.promises.chmod(P(inst, req.body.path), mode); res.json({ ok: true });
  });

  r.post('/compress', async (req, res) => {
    const inst = get(req); const paths: string[] = req.body.paths || []; const root = String(req.body.root || '/');
    const name = String(req.body.name || `archive-${new Date().toISOString().replace(/[:.]/g, '-')}.zip`).replace(/[^A-Za-z0-9._-]/g, '_');
    const out = P(inst, path.posix.join(root, name.endsWith('.zip') ? name : name + '.zip'));
    let est = 0; for (const p of paths) { const a = P(inst, p); const st = await fs.promises.lstat(a); est += st.isDirectory() ? await dirSize(a) : st.size; }
    const resv = inst.disk.reserve(Math.min(est, inst.disk.available()));
    try { const r = await createZip(inst.dir, paths, out, { maxBytes: inst.disk.available() + Math.min(est, inst.disk.available()) }); resv.release(r.size); res.json({ ok: true, path: toRelative(inst.dir, out), size: r.size }); }
    catch (e) { resv.release(0); throw e; }
  });

  r.post('/extract', async (req, res) => {
    const inst = get(req); const file = P(inst, req.body.file); const dest = String(req.body.destination || path.posix.dirname(toRelative(inst.dir, file)));
    if (!/\.(zip|jar)$/i.test(file)) throw Object.assign(new Error('Only .zip archives can be extracted'), { status: 400 });
    const declared = await zipDeclaredSize(file);
    const avail = inst.disk.available();
    if (!inst.disk.unlimited && declared.bytes > avail) throw Object.assign(new Error(`Archive expands to ${(declared.bytes / 1048576).toFixed(1)} MB but only ${(avail / 1048576).toFixed(1)} MB is available`), { status: 507 });
    const budget = inst.disk.unlimited ? 0 : avail; const resv = inst.disk.reserve(inst.disk.unlimited ? 0 : Math.min(declared.bytes, avail));
    try { const r = await extractZip(inst.dir, file, dest, budget); resv.release(r.bytes); res.json({ ok: true, ...r }); }
    catch (e) { resv.release(0); inst.disk.rescan(); throw e; }
  });

  r.get('/search', async (req, res) => {
    const inst = get(req); const q = String(req.query.q || '').toLowerCase(); if (q.length < 2) throw Object.assign(new Error('Query too short'), { status: 400 });
    const start = P(inst, req.query.path || '/'); const results: any[] = []; const stack = [start];
    while (stack.length && results.length < 500) {
      const d = stack.pop()!; let ents: fs.Dirent[] = []; try { ents = await fs.promises.readdir(d, { withFileTypes: true }); } catch { continue; }
      for (const e of ents) { const p = path.join(d, e.name); if (e.name.toLowerCase().includes(q)) { const st = await fs.promises.lstat(p); results.push({ name: e.name, path: toRelative(inst.dir, p), directory: e.isDirectory(), size: st.size }); } if (e.isDirectory() && !e.isSymbolicLink()) stack.push(p); }
    }
    res.json({ results });
  });

  r.get('/size', async (req, res) => { const inst = get(req); res.json({ bytes: await dirSize(P(inst, req.query.path)) }); });
  void isProtected; void ({} as Response);
  return r;
}
