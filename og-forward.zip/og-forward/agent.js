#!/usr/bin/env node
'use strict';
/**
 * OG Forward - AGENT
 * Jis machine par service chal rahi hai wahan chalao (NAT / firewall ke peeche bhi chalega).
 *
 *   node agent.js [agent.config.json]
 *
 * Ye VPS ke public IP:controlPort se connect hota hai, auth karta hai, aur
 * VPS ke public ports se aane wali traffic ko apni local services tak pahunchata hai.
 *
 * Tunnel ke 3 tarike (agent.config.json -> "tunnels"):
 *   { "localPort": 3000, "remotePort": 20001 }       fixed port
 *   { "localPort": 3000, "remotePort": "auto" }      server khud free port dega
 *   { "portRange": [20000, 20999] }                  VPS port N  ->  local port N  (poori range)
 *   { "portRange": "all" }                           VPS ke saare free ports (1024-65535)
 */
const net = require('net');
const fs = require('fs');
const path = require('path');
const { log, send, mac, lineStream, bridge } = require('./common');

// ---------- config ----------
const cfgFile = process.argv[2] || path.join(__dirname, 'agent.config.json');
let cfg;
try {
  cfg = JSON.parse(fs.readFileSync(cfgFile, 'utf8'));
} catch (e) {
  console.error(`Config nahi padh paya (${cfgFile}): ${e.message}`);
  console.error('agent.config.example.json ko agent.config.json naam se copy karke edit karo.');
  process.exit(1);
}
cfg.port = Number(cfg.port) || 7000;
if (!cfg.server || !cfg.user || !cfg.token) {
  console.error('Config me "server", "user", "token" zaroori hain.');
  process.exit(1);
}
if (!Array.isArray(cfg.tunnels) || !cfg.tunnels.length) {
  console.error('Config me kam se kam 1 tunnel chahiye.');
  process.exit(1);
}
const isPort = (n) => Number.isInteger(n) && n >= 1 && n <= 65535;
cfg.tunnels.forEach((t, i) => {
  if (t.portRange !== undefined) {
    if (t.portRange === 'all') t.portRange = [1024, 65535];
    if (!Array.isArray(t.portRange) || !isPort(t.portRange[0]) || !isPort(t.portRange[1]) ||
        t.portRange[0] > t.portRange[1]) {
      console.error(`Tunnel #${i + 1}: "portRange" [from, to] ya "all" hona chahiye.`);
      process.exit(1);
    }
    // VPS port N -> local port (localPortStart + N - from). Default: same number.
    if (t.localPortStart === undefined) t.localPortStart = t.portRange[0];
    if (!isPort(t.localPortStart) ||
        t.localPortStart + (t.portRange[1] - t.portRange[0]) > 65535) {
      console.error(`Tunnel #${i + 1}: "localPortStart" galat hai (range 65535 se bahar ja rahi hai).`);
      process.exit(1);
    }
  } else {
    if (t.remotePort !== 'auto' && !isPort(t.remotePort)) {
      console.error(`Tunnel #${i + 1}: "remotePort" number ya "auto" hona chahiye.`);
      process.exit(1);
    }
    if (!isPort(t.localPort)) {
      console.error(`Tunnel #${i + 1}: "localPort" number hona chahiye.`);
      process.exit(1);
    }
  }
});

// Server ko kya batana hai
const requests = cfg.tunnels.map((t) =>
  t.portRange ? { name: t.name, portRange: t.portRange } : { name: t.name, remotePort: t.remotePort }
);

// Connection errors ka log spam rokne ke liye (port scanners bahut aate hain)
const lastLog = new Map();
function logOnce(key, msg) {
  const now = Date.now();
  if (now - (lastLog.get(key) || 0) > 30000) { lastLog.set(key, now); log(msg); }
}

// ---------- control connection (auto reconnect) ----------
let backoff = 1000;

function connect() {
  log(`connecting to ${cfg.server}:${cfg.port} ...`);
  const sock = net.connect({ host: cfg.server, port: cfg.port });
  sock.setNoDelay(true);
  sock.setKeepAlive(true, 30000);

  let session = null;
  let route = null; // public port -> { host, port } (har session ke baad naya)
  let lastSeen = Date.now();
  let pingTimer = null;
  let fatal = false;

  sock.on('connect', () => send(sock, { t: 'hello', user: cfg.user }));

  lineStream(sock, (line) => {
    let m;
    try { m = JSON.parse(line); } catch { return sock.destroy(); }
    lastSeen = Date.now();

    switch (m.t) {
      case 'challenge':
        return send(sock, {
          t: 'auth',
          mac: mac(cfg.token, String(m.nonce), cfg.user),
          tunnels: requests,
        });

      case 'ok': {
        session = m.session;
        backoff = 1000;
        route = buildRoute(m);
        pingTimer = setInterval(() => {
          if (Date.now() - lastSeen > 45000) return sock.destroy(); // server dead
          send(sock, { t: 'ping' });
        }, 15000);
        return;
      }

      case 'err':
        log('Server error:', m.msg);
        if (m.code === 'auth' || m.code === 'replaced') fatal = true;
        return;

      case 'conn':
        if (session && route) onConn(sock, session, route, m);
        return;
    }
  });

  sock.on('error', (e) => log('control error:', e.code || e.message));
  sock.on('close', () => {
    clearInterval(pingTimer);
    if (fatal) {
      log('Agent band ho raha hai (auth fail ya doosra agent aa gaya). Exit.');
      process.exit(1);
    }
    log(`disconnected - ${backoff / 1000}s me dobara try karunga`);
    setTimeout(connect, backoff);
    backoff = Math.min(backoff * 2, 30000);
  });
}

// Server ke 'ok' reply se routing table banao + status print karo
function buildRoute(m) {
  const exact = new Map();
  const ranges = [];
  const host = (t) => t.localHost || '127.0.0.1';
  let open = 0;

  for (const r of m.tunnels || []) {
    const t = cfg.tunnels[r.idx];
    if (!t) continue;
    if (r.ok) {
      open++;
      exact.set(Number(r.remotePort), { host: host(t), port: t.localPort });
      log(`LIVE  ${cfg.server}:${r.remotePort}${t.remotePort === 'auto' ? ' (auto)' : ''}  ->  ${host(t)}:${t.localPort}`);
    } else {
      log(`FAIL  port ${r.remotePort || t.remotePort}: ${r.error}`);
    }
  }

  for (const r of m.ranges || []) {
    const t = cfg.tunnels[r.idx];
    if (!t || !t.portRange) continue;
    const from = Number(r.from);
    const to = Number(r.to);
    if (r.opened > 0) {
      open += r.opened;
      ranges.push({ from, to, host: host(t), base: t.portRange[0], start: t.localPortStart });
    }
    log(`RANGE ${cfg.server}:${from}-${to}  ->  ${host(t)}:${t.localPortStart + (from - t.portRange[0])}-${t.localPortStart + (to - t.portRange[0])}` +
      `  (${r.opened} open, ${r.skipped} skipped)`);
    if (r.skipped) log(`      skipped reasons: ${JSON.stringify(r.reasons)}`);
  }

  if (!open) log('Koi port nahi khula - config / server ke allowed ports check karo.');
  else log(`Total ${open} public port(s) live`);

  return {
    resolve(port) {
      const t = exact.get(port);
      if (t) return t;
      for (const r of ranges) {
        if (port >= r.from && port <= r.to) return { host: r.host, port: r.start + (port - r.base) };
      }
      return null;
    },
  };
}

// Server ne bola: naya visitor aaya hai -> local service se jodo
function onConn(ctrl, session, route, m) {
  const id = String(m.id);
  const dest = route.resolve(Number(m.remotePort));
  let local = null;
  let data = null;
  let bridged = false;
  let failed = false;

  const fail = (key, why) => {
    if (bridged || failed) return;
    failed = true;
    if (why) logOnce(key, `conn ${id}: ${why}`);
    send(ctrl, { t: 'fail', id });
    if (local) local.destroy();
    if (data) data.destroy();
  };

  if (!dest) return fail('unknown', `unknown remotePort ${m.remotePort}`);
  const name = `${dest.host}:${dest.port}`;

  local = net.connect({ host: dest.host, port: dest.port });
  local.setNoDelay(true);
  local.on('error', (e) => fail(name, `local ${name} connect fail (${e.code || e.message}) [port ${m.remotePort}]`));

  local.once('connect', () => {
    data = net.connect({ host: cfg.server, port: cfg.port });
    data.setNoDelay(true);
    data.on('error', (e) => fail('data', `server data connection fail (${e.code || e.message})`));
    data.once('connect', () => {
      bridged = true;
      data.write(JSON.stringify({ t: 'data', session, id }) + '\n');
      bridge(local, data);
    });
  });
}

connect();
