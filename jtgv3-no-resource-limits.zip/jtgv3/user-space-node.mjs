#!/usr/bin/env node
/** Rootless direct-process Minecraft node agent. Node.js 18+; no Docker required. */
import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import { spawn, execFile } from 'node:child_process';
import { promisify } from 'node:util';
import crypto from 'node:crypto';
const execFileAsync = promisify(execFile);
const PORT = Number(process.env.OG_NODE_PORT || 8787);
const TOKEN = process.env.OG_NODE_TOKEN;
const ROOT = path.resolve(process.env.OG_NODE_DATA || './og-node-data/servers');
if (!TOKEN || TOKEN.length < 24) { console.error('Set OG_NODE_TOKEN to a random secret of at least 24 characters.'); process.exit(1); }
await fs.mkdir(ROOT, { recursive: true });
const procs = new Map();
const metaPath = path.join(path.dirname(ROOT), 'servers.json');
async function readMeta(){ try{return JSON.parse(await fs.readFile(metaPath,'utf8'));}catch{return {};}}
async function writeMeta(x){await fs.writeFile(metaPath,JSON.stringify(x,null,2));}
function send(res, status, body){res.writeHead(status,{'content-type':'application/json','access-control-allow-origin':'*'});res.end(JSON.stringify(body));}
async function body(req){let s='';for await(const c of req)s+=c;if(s.length>1024*1024)throw new Error('Request body too large');return s?JSON.parse(s):{};}
function safeId(id){if(!/^[a-zA-Z0-9_-]{1,100}$/.test(String(id||'')))throw new Error('Invalid server ID');return String(id);}
function serverDir(id){return path.join(ROOT,safeId(id));}
async function resolveJava(version='21'){
 const v=String(version||'21'); const choices=[v, v.startsWith('java')?v:`java${v}`, process.env.JAVA_BIN, 'java'].filter(Boolean);
 for(const c of choices){ if(c.includes('/')){try{await fs.access(c);return c}catch{continue}} try{await execFileAsync('/bin/sh',['-lc',`command -v ${JSON.stringify(c)}`]);return c}catch{}}
 throw new Error(`Java executable '${v}' not found. Configure java8/java17/java21/java25 in PATH or provide an absolute path.`);
}
async function downloadJar(server, dir){
 const jar=path.join(dir, server.jarFile||'server.jar'); try{const st=await fs.stat(jar);if(st.size>500000)return jar}catch{}
 const ver=String(server.version||'1.21.1'); const url=`https://api.purpurmc.org/v2/purpur/${encodeURIComponent(ver==='latest'?'1.21.1':ver)}/latest/download`;
 const r=await fetch(url,{redirect:'follow'});if(!r.ok)throw new Error(`JAR download failed (${r.status}); upload your server.jar into ${dir}`);
 const bytes=Buffer.from(await r.arrayBuffer());if(bytes.length<500000)throw new Error('Downloaded file does not look like a server JAR');await fs.writeFile(jar,bytes);return jar;
}
async function start(id){const meta=await readMeta();const s=meta[id];if(!s)throw new Error('Server has not been created on this node');if(procs.has(id)&&procs.get(id).exitCode===null)return {running:true};
 const dir=serverDir(id);await fs.mkdir(dir,{recursive:true});const jar=await downloadJar(s,dir);await fs.writeFile(path.join(dir,'eula.txt'),'eula=true\n');const props=path.join(dir,'server.properties');try{await fs.access(props)}catch{await fs.writeFile(props,`server-port=${s.port||25565}\nserver-ip=0.0.0.0\n`)}const java=await resolveJava(s.javaVersion||'21');
 // No panel-enforced RAM/CPU/disk quotas. Java uses host defaults unless a custom startup command is supplied.
 const args=s.startupCommand?['-lc',s.startupCommand]:['-jar',path.basename(jar),'nogui'];
 const child=s.startupCommand?spawn('/bin/sh',args,{cwd:dir,env:{...process.env,SERVER_PORT:String(s.port||25565),PORT:String(s.port||25565)},stdio:['pipe','pipe','pipe']}):spawn(java,args,{cwd:dir,env:process.env,stdio:['pipe','pipe','pipe']});
 const log=path.join(dir,'panel.log');const stream=await fs.open(log,'a');const append=async b=>{const t=b.toString();await stream.appendFile(t).catch(()=>{});};child.stdout.on('data',append);child.stderr.on('data',append);child.on('close',()=>{procs.delete(id);stream.close().catch(()=>{});});procs.set(id,child);return {running:true,pid:child.pid};
}
const app=http.createServer(async(req,res)=>{try{
 if(req.method==='OPTIONS'){res.writeHead(204,{'access-control-allow-origin':'*','access-control-allow-headers':'authorization,content-type','access-control-allow-methods':'GET,POST,DELETE,OPTIONS'});return res.end();}
 if(req.headers.authorization!==`Bearer ${TOKEN}`)return send(res,401,{error:'Unauthorized'});
 const url=new URL(req.url,'http://localhost');const parts=url.pathname.split('/').filter(Boolean);
 if(req.method==='GET'&&url.pathname==='/api/system')return send(res,200,{status:'online',runtime:'user-space',docker:false,hostname:os.hostname(),platform:process.platform,arch:process.arch,java:await execFileAsync('/bin/sh',['-lc','java -version 2>&1']).then(x=>x.stderr||x.stdout).catch(()=>null)});
 if(parts[0]!=='api'||parts[1]!=='servers')return send(res,404,{error:'Not found'});
 if(req.method==='POST'&&parts.length===2){const s=await body(req);const id=s.id||s.uuid;safeId(id);const meta=await readMeta();meta[id]={...s,id};await writeMeta(meta);await fs.mkdir(serverDir(id),{recursive:true});return send(res,200,{success:true,id,path:serverDir(id)});}
 const id=safeId(parts[2]);const meta=await readMeta();
 if(req.method==='POST'&&parts[3]==='power'){const {action}=await body(req);if(action==='start')return send(res,200,await start(id));if(action==='stop'||action==='kill'){const c=procs.get(id);if(c){c.stdin?.write('stop\n');setTimeout(()=>{if(c.exitCode===null)c.kill('SIGTERM')},1500);}return send(res,200,{success:true});}if(action==='restart'){const c=procs.get(id);if(c){c.kill('SIGTERM');await new Promise(r=>setTimeout(r,500));}return send(res,200,await start(id));}return send(res,400,{error:'Unknown power action'});}
 if(req.method==='GET'&&parts.length===3){const c=procs.get(id);return send(res,200,{id,running:!!c&&c.exitCode===null,pid:c?.pid||null,server:meta[id]||null});}
 if(req.method==='GET'&&parts[3]==='logs'){const file=path.join(serverDir(id),'panel.log');return send(res,200,{logs:await fs.readFile(file,'utf8').catch(()=>'' )});}
 if(req.method==='POST'&&parts[3]==='command'){const {command}=await body(req);const c=procs.get(id);if(!c||c.exitCode!==null)return send(res,409,{error:'Server is not running'});if(typeof command!=='string'||command.length>4096)return send(res,400,{error:'Invalid command'});c.stdin.write(command+'\n');return send(res,200,{success:true});}
 if(req.method==='DELETE'&&parts.length===3){const c=procs.get(id);if(c)c.kill('SIGTERM');delete meta[id];await writeMeta(meta);return send(res,200,{success:true});}
 return send(res,404,{error:'Endpoint not found'});
 }catch(e){return send(res,500,{error:e.message||'Agent error'});}});
app.listen(PORT,'0.0.0.0',()=>console.log(`OGHost User-Space Node listening on 0.0.0.0:${PORT}; data=${ROOT}`));
