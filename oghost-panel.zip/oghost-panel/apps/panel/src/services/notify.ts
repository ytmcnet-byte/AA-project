import { exec, q } from '../db';
import { sendMail } from './mail';
import { io } from '../realtime';
import { config } from '../config';

export type NotifyType = 'server_crash' | 'node_offline' | 'storage' | 'payment' | 'renewal' | 'maintenance' | 'security' | 'backup' | 'ticket' | 'schedule' | 'system';
export async function notify(userId: number, type: NotifyType, title: string, body: string, opts: { link?: string; email?: boolean } = {}) {
  const r = await exec('INSERT INTO notifications (user_id, type, title, body, link) VALUES (?, ?, ?, ?, ?)', [userId, type, title.slice(0, 200), body, opts.link ?? null]);
  io()?.to(`user:${userId}`).emit('notification', { id: r.insertId, type, title, body, link: opts.link });
  if (opts.email) { const u = await q<{ email: string }>('SELECT email FROM users WHERE id = ?', [userId]); if (u[0]) sendMail(u[0].email, `[OGHOST] ${title}`, `${body}${opts.link ? `\n\n${config.appUrl}${opts.link}` : ''}`).catch(e => console.error('[notify] mail', e.message)); }
}
/** Notify all users holding a given admin permission (or super admins). */
export async function notifyAdmins(perm: string, type: NotifyType, title: string, body: string, opts: { link?: string; email?: boolean } = {}) {
  const roles = await q<{ id: number; permissions: any }>('SELECT id, permissions FROM roles');
  const ids = roles.filter(r => { const p: string[] = typeof r.permissions === 'string' ? JSON.parse(r.permissions) : r.permissions; return p.includes('*') || p.includes(perm); }).map(r => r.id);
  if (!ids.length) return;
  const users = await q<{ id: number }>(`SELECT id FROM users WHERE role_id IN (${ids.map(() => '?').join(',')}) AND suspended = 0`, ids);
  for (const u of users) await notify(u.id, type, title, body, opts);
}
