// Minimal Google OAuth + Drive v3 mock for testing OGHOST Drive backups without real credentials.
// Start the panel with GOOGLE_OAUTH_BASE=GOOGLE_DRIVE_API_BASE=http://127.0.0.1:<port> to use it.
// Implements: token (authorization_code, refresh_token), revoke, files list/create/get/delete/alt=media,
// resumable uploads (308 + Range). Control: POST /__mock/mode {mode: 'ok'|'quota'|'badmd5'}, GET /__mock/state.
import http from 'node:http';
import crypto from 'node:crypto';
export function startGoogleMock(port = 0) {
  const st = { files: new Map(), sessions: new Map(), tokens: new Set(), refresh: new Set(), revoked: [], mode: 'ok', requests: [], n: 0 };
  const id = () => 'f' + (++st.n).toString(36) + crypto.randomBytes(3).toString('hex');
  const meta = (f) => ({ id: f.id, name: f.name, mimeType: f.mimeType, parents: f.parents, trashed: false, ...(f.data ? { size: String(f.data.length), md5Checksum: f.md5 } : {}) });
  const server = http.createServer(async (req, res) => {
    const u = new URL(req.url, 'http://x'); const chunks = []; for await (const c of req) chunks.push(c); const raw = Buffer.concat(chunks);
    st.requests.push(`${req.method} ${u.pathname}`);
    const send = (code, body, headers = {}) => { res.writeHead(code, { 'content-type': 'application/json', ...headers }); res.end(body === undefined ? '' : JSON.stringify(body)); };
    const form = () => Object.fromEntries(new URLSearchParams(raw.toString()));
    if (u.pathname === '/__mock/mode') { st.mode = JSON.parse(raw.toString()).mode; return send(200, { ok: true }); }
    if (u.pathname === '/__mock/state') return send(200, { files: [...st.files.values()].map(meta), revoked: st.revoked, tokensIssued: st.tokens.size });
    if (u.pathname === '/token') {
      const f = form(); const at = 'ya29.mock-' + crypto.randomBytes(8).toString('hex');
      if (f.grant_type === 'authorization_code') {
        if (!f.code || !f.code_verifier || !f.client_secret) return send(400, { error: 'invalid_request' });
        const rt = '1//mock-refresh-' + crypto.randomBytes(8).toString('hex'); st.refresh.add(rt); st.tokens.add(at);
        const idt = ['e30', Buffer.from(JSON.stringify({ aud: f.client_id, sub: '1234567890', email: 'customer@example.com' })).toString('base64url'), 'sig'].join('.');
        return send(200, { access_token: at, refresh_token: rt, expires_in: 3599, scope: 'openid https://www.googleapis.com/auth/drive.file https://www.googleapis.com/auth/userinfo.email', id_token: idt, token_type: 'Bearer' });
      }
      if (f.grant_type === 'refresh_token') { if (!st.refresh.has(f.refresh_token)) return send(400, { error: 'invalid_grant' }); st.tokens.add(at); return send(200, { access_token: at, expires_in: 3599, scope: 'https://www.googleapis.com/auth/drive.file' }); }
      return send(400, { error: 'unsupported_grant_type' });
    }
    if (u.pathname === '/revoke') { const t = form().token; st.revoked.push(t); st.refresh.delete(t); return send(200, {}); }
    const auth = (req.headers.authorization || '').replace(/^Bearer /, '');
    if (!st.tokens.has(auth)) return send(401, { error: { code: 401, message: 'Invalid Credentials' } });
    if (u.pathname === '/upload/drive/v3/files' && req.method === 'POST') {
      if (st.mode === 'quota') return send(403, { error: { code: 403, message: 'The user has exceeded their Drive storage quota', errors: [{ reason: 'storageQuotaExceeded' }] } });
      const b = JSON.parse(raw.toString() || '{}'); const sid = crypto.randomBytes(8).toString('hex');
      st.sessions.set(sid, { name: b.name, parents: b.parents, total: Number(req.headers['x-upload-content-length']), data: Buffer.alloc(0) });
      return send(200, {}, { location: `http://${req.headers.host}/upload/session/${sid}` });
    }
    const sm = u.pathname.match(/^\/upload\/session\/(\w+)$/);
    if (sm && req.method === 'PUT') {
      const s = st.sessions.get(sm[1]); if (!s) return send(404, { error: { code: 404, message: 'session' } });
      const cr = String(req.headers['content-range'] || ''); const m = cr.match(/bytes (\d+)-(\d+)\/(\d+)/);
      if (m) { if (Number(m[1]) !== s.data.length) return send(308, undefined, { range: `bytes=0-${s.data.length - 1}` }); s.data = Buffer.concat([s.data, raw]); }
      if (s.data.length < s.total) return send(308, undefined, s.data.length ? { range: `bytes=0-${s.data.length - 1}` } : {});
      const f = { id: id(), name: s.name, parents: s.parents, mimeType: 'application/zip', data: s.data, md5: crypto.createHash('md5').update(s.data).digest('hex') };
      st.files.set(f.id, f); st.sessions.delete(sm[1]);
      const out = meta(f); if (st.mode === 'badmd5') out.md5Checksum = '0'.repeat(32);
      return send(200, out);
    }
    if (u.pathname === '/drive/v3/files' && req.method === 'GET') {
      const q = u.searchParams.get('q') || ''; const name = (q.match(/name = '((?:[^'\\]|\\.)*)'/) || [])[1]; const parent = (q.match(/'([^']+)' in parents/) || [])[1];
      const files = [...st.files.values()].filter(f => (!name || f.name === name) && (!parent || (parent === 'root' ? !f.parents?.length : f.parents?.includes(parent))));
      return send(200, { files: files.map(meta) });
    }
    if (u.pathname === '/drive/v3/files' && req.method === 'POST') { const b = JSON.parse(raw.toString()); const f = { id: id(), name: b.name, mimeType: b.mimeType, parents: b.parents || [] }; st.files.set(f.id, f); return send(200, { id: f.id }); }
    const fm = u.pathname.match(/^\/drive\/v3\/files\/([\w-]+)$/);
    if (fm) {
      const f = st.files.get(fm[1]); if (!f) return send(404, { error: { code: 404, message: 'File not found' } });
      if (req.method === 'DELETE') { st.files.delete(f.id); res.writeHead(204); return res.end(); }
      if (u.searchParams.get('alt') === 'media') { res.writeHead(200, { 'content-type': 'application/octet-stream' }); return res.end(f.data); }
      return send(200, meta(f));
    }
    send(404, { error: { code: 404, message: 'not mocked: ' + u.pathname } });
  });
  return new Promise(r => server.listen(port, '127.0.0.1', () => r({ server, state: st, port: server.address().port, close: () => new Promise(x => server.close(x)) })));
}
if (import.meta.url === `file://${process.argv[1]}`) { const m = await startGoogleMock(Number(process.argv[2] || 9555)); console.log(`Google mock on http://127.0.0.1:${m.port}`); }
