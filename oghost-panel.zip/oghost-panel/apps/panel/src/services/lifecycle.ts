import { q, one, exec, tx, txRetry, json, parse } from '../db';
import { HttpError } from '../lib/http';
import { getNode, agent, agentPipe } from './nodes';
import { getServer, getEgg, buildSpec, syncSpec, allocateNodeServerId, nodeCapacity, createServer, deleteServer } from './servers';
import { requestBackup, cleanupSafetyBackups } from './backups';
import { registerJob } from './jobs';
import { notify } from './notify';
import { serverActivity } from './audit';

const A = (id: number) => `/api/servers/${id}`;
async function assertStopped(serverId: number) {
  const s = await getServer(serverId); const n = await getNode(s.node_id);
  const st = await agent(n, 'GET', A(s.node_server_id), undefined, { serverId: s.node_server_id });
  if (!['offline', 'crashed', 'install_failed'].includes(st.state)) throw new HttpError(409, 'Server must be stopped');
}

/** Version / software change: optional full safety backup -> agent backs up JARs and reinstalls -> rollback on failure. */
registerJob('server.version', async (p: { serverId: number; eggId: number; variables: Record<string, string>; backup: boolean; userId: number }) => {
  const s = await getServer(p.serverId); const node = await getNode(s.node_id); const old = { egg_id: s.egg_id, variables: s.variables, startup: s.startup };
  let safety: any = null;
  if (p.backup) { safety = await requestBackup(s.id, `Before version change (${new Date().toISOString().slice(0, 16)})`, { safety: true, wait: true }); if (safety.status !== 'completed') throw Object.assign(new Error(`Safety backup failed: ${safety.error}`), { noRetry: true }); }
  const egg = await getEgg(p.eggId);
  await exec('UPDATE servers SET egg_id = ?, variables = ?, startup = ?, state = ? WHERE id = ?', [egg.id, json(p.variables), s.egg_id === egg.id ? s.startup : egg.definition.startup, 'installing', s.id]);
  const spec = await buildSpec(await getServer(s.id));
  try {
    const r = await agent(node, 'POST', `${A(s.node_server_id)}/version`, { spec }, { serverId: s.node_server_id, timeoutMs: 3 * 3600_000 });
    await exec("UPDATE servers SET state = 'offline', installed_version = COALESCE(?, installed_version), installed_build = COALESCE(?, installed_build), installed_at = NOW() WHERE id = ?", [r.resolvedVersion ?? p.variables.MC_VERSION ?? null, r.resolvedBuild ?? null, s.id]);
    await cleanupSafetyBackups(s.id, 3);
    await notify(s.owner_id, 'system', `Version change finished for ${s.name}`, `Installed ${egg.definition.name} ${r.resolvedVersion || p.variables.MC_VERSION || ''}. Rollback point: ${r.rollbackId}.`, { link: `/server/${s.id}/settings` });
    await serverActivity(null, s.id, 'server.version.changed', { egg: egg.slug, version: r.resolvedVersion, rollbackId: r.rollbackId });
    return { ...r, safetyBackup: safety?.uuid };
  } catch (e: any) {
    await exec('UPDATE servers SET egg_id = ?, variables = ?, startup = ?, state = ? WHERE id = ?', [old.egg_id, json(parse(old.variables, {})), old.startup, 'offline', s.id]);
    await syncSpec(s.id).catch(() => {});
    await notify(s.owner_id, 'system', `Version change failed for ${s.name}`, `${e.message}. Your previous server files were restored${safety ? ` and a full safety backup (${safety.uuid}) is available` : ''}.`, { link: `/server/${s.id}/settings`, email: true });
    throw Object.assign(e, { noRetry: true });
  }
});

/**
 * Transfer to another node. The source ID stays reserved (node_id_reservations) until the source
 * directory has been deleted, so it can never be reused while deletion is incomplete.
 */
export async function startTransfer(serverId: number, targetNodeId: number, allocationId?: number) {
  const s = await getServer(serverId); if (s.node_id === targetNodeId) throw new HttpError(400, 'Server is already on that node');
  const target = await getNode(targetNodeId); if (target.status !== 'online') throw new HttpError(409, 'Target node is offline'); if (target.maintenance) throw new HttpError(409, 'Target node is in maintenance');
  await assertStopped(serverId);
  const cap = await nodeCapacity(target); if (cap.memory + s.memory_mb > cap.memoryMax || cap.disk + s.disk_mb > cap.diskMax) throw new HttpError(409, 'Target node does not have enough capacity');
  await exec("UPDATE servers SET state = 'transferring', status_detail = ? WHERE id = ?", [`Transferring to node ${target.name}`, serverId]);
  return { targetNodeId, allocationId };
}
registerJob('server.transfer', async (p: { serverId: number; targetNodeId: number; allocationId?: number }) => {
  const s = await getServer(p.serverId); const src = await getNode(s.node_id); const dst = await getNode(p.targetNodeId);
  // 1) reserve a new ID + allocation on the target
  const plan = await txRetry(async (c) => {
    const newId = await allocateNodeServerId(c, dst.id);
    await exec('INSERT INTO node_id_reservations (node_id, node_server_id, reason) VALUES (?, ?, ?)', [dst.id, newId, `transfer-in:${s.id}`], c);
    const alloc: any = p.allocationId ? await one('SELECT * FROM allocations WHERE id = ? AND node_id = ? AND server_id IS NULL FOR UPDATE', [p.allocationId, dst.id], c) : await one('SELECT * FROM allocations WHERE node_id = ? AND server_id IS NULL ORDER BY port LIMIT 1 FOR UPDATE', [dst.id], c);
    if (!alloc) throw new HttpError(409, 'No free allocation on the target node');
    return { newId, alloc };
  });
  try {
    const spec = { ...(await buildSpec(s)), id: plan.newId, ports: [plan.alloc.port], primaryPort: plan.alloc.port, ip: plan.alloc.ip };
    await agent(dst, 'PUT', A(plan.newId), spec, { serverId: plan.newId });
    await agentPipe(src, `${A(s.node_server_id)}/archive`, s.node_server_id, dst, `${A(plan.newId)}/import?truncate=1`, plan.newId);
  } catch (e: any) {
    await agent(dst, 'DELETE', A(plan.newId), undefined, { serverId: plan.newId }).then(r => r.deleted && exec('DELETE FROM node_id_reservations WHERE node_id = ? AND node_server_id = ?', [dst.id, plan.newId])).catch(() => {});
    await exec("UPDATE servers SET state = 'offline', status_detail = ? WHERE id = ?", [`Transfer failed: ${String(e.message).slice(0, 200)}`, s.id]);
    throw Object.assign(e, { noRetry: true });
  }
  // 2) switch the row to the target; keep the source ID reserved until its directory is gone
  await txRetry(async (c) => {
    await exec('INSERT IGNORE INTO node_id_reservations (node_id, node_server_id, reason) VALUES (?, ?, ?)', [src.id, s.node_server_id, `transfer-out:${s.id}`], c);
    await exec('UPDATE allocations SET server_id = NULL, is_primary = 0, notes = NULL WHERE server_id = ?', [s.id], c);
    await exec('UPDATE allocations SET server_id = ?, is_primary = 1 WHERE id = ?', [s.id, plan.alloc.id], c);
    await exec("UPDATE servers SET node_id = ?, node_server_id = ?, state = 'offline', status_detail = NULL WHERE id = ?", [dst.id, plan.newId, s.id], c);
    await exec('DELETE FROM node_id_reservations WHERE node_id = ? AND node_server_id = ?', [dst.id, plan.newId], c);
  });
  await syncSpec(s.id).catch(() => {});
  await cleanupReservation(src.id, s.node_server_id);
  await serverActivity(null, s.id, 'server.transferred', { from: src.id, to: dst.id, newId: plan.newId });
  await notify(s.owner_id, 'system', `Server ${s.name} moved`, `Your server now runs on node ${dst.name}. The address may have changed: ${plan.alloc.ip}:${plan.alloc.port}.`, { link: `/server/${s.id}` });
  return { nodeId: dst.id, nodeServerId: plan.newId };
});
/** Delete a reserved directory on a node; the reservation is only removed after the node confirms deletion. */
export async function cleanupReservation(nodeId: number, nodeServerId: number) {
  const n = await getNode(nodeId);
  try { const r = await agent(n, 'DELETE', A(nodeServerId), undefined, { serverId: nodeServerId, timeoutMs: 120_000 }); if (r.deleted) await exec('DELETE FROM node_id_reservations WHERE node_id = ? AND node_server_id = ?', [nodeId, nodeServerId]); return !!r.deleted; }
  catch { return false; }
}
export async function retryReservations() { for (const r of await q("SELECT r.* FROM node_id_reservations r JOIN nodes n ON n.id = r.node_id WHERE n.status = 'online' AND r.reason LIKE 'transfer-out:%' AND r.created_at < DATE_SUB(NOW(), INTERVAL 5 MINUTE)")) await cleanupReservation(r.node_id, r.node_server_id); }

/** Clone: creates a new server (new numeric ID) with the same configuration and copies the files. */
registerJob('server.clone', async (p: { serverId: number; targetNodeId: number; name: string; ownerId: number }) => {
  const s = await getServer(p.serverId); const src = await getNode(s.node_id);
  const created = await createServer({ name: p.name, description: s.description ?? undefined, ownerId: p.ownerId, nodeId: p.targetNodeId, eggId: s.egg_id, memoryMb: s.memory_mb, cpuPercent: s.cpu_percent, diskMb: s.disk_mb, swapMb: s.swap_mb, variables: parse(s.variables, {}), javaPath: s.java_path, xmsMb: s.xms_mb, xmxMb: s.xmx_mb, startup: s.startup, databaseLimit: s.database_limit, allocationLimit: s.allocation_limit, backupLimit: s.backup_limit, backupStorageMb: s.backup_storage_mb, skipInstall: true });
  const c = await getServer(created.id); const dst = await getNode(c.node_id);
  try {
    await syncSpec(c.id);
    await agentPipe(src, `${A(s.node_server_id)}/archive`, s.node_server_id, dst, `${A(c.node_server_id)}/import?truncate=1`, c.node_server_id);
    await exec("UPDATE servers SET state = 'offline', installed_version = ?, installed_build = ?, installed_at = NOW(), security_level = ? WHERE id = ?", [s.installed_version, s.installed_build, s.security_level === 'safe' ? 'safe' : 'unscanned', c.id]);
  } catch (e) { await deleteServer(c.id).catch(() => {}); throw Object.assign(e as Error, { noRetry: true }); }
  await serverActivity(null, c.id, 'server.cloned', { from: s.id }); return { serverId: c.id };
});

/** Import a server archive (.zip) into a newly created server. Body is streamed straight to the node. */
export async function importIntoServer(serverId: number, body: ReadableStream | NodeJS.ReadableStream, size: number) {
  const s = await getServer(serverId); const n = await getNode(s.node_id); const { nodeToken, agentUrl } = await import('./nodes');
  const r = await fetch(`${agentUrl(n)}${A(s.node_server_id)}/import?truncate=1`, { method: 'PUT', headers: { Authorization: `Bearer ${nodeToken(n, { serverId: s.node_server_id }, 3600)}`, 'Content-Length': String(size), 'X-File-Size': String(size) }, body: body as any, duplex: 'half' } as any);
  const t = await r.text(); if (!r.ok) throw new HttpError(r.status, `Import failed: ${t}`);
  await exec("UPDATE servers SET state = 'offline', installed_at = NOW() WHERE id = ?", [serverId]); return JSON.parse(t);
}
