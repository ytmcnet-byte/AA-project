import { useState } from 'react';
import { Copy, Play, RotateCcw, Trash2, Plug } from 'lucide-react';
import { Crud } from './Crud';
import { useApi, useAction, toast } from '../../lib/hooks';
import { api } from '../../lib/api';
import { ago, bytes, date, money } from '../../lib/format';
import { Badge, Card, Confirm, Empty, ErrorBox, Loading, Modal, Notice, PageHeader, Pager, Stat, Table, Tabs } from '../../components/ui';

const yes = (v: any) => (v ? 'Yes' : 'No');

export function LocationsAdmin() {
  return <><PageHeader title="Locations" subtitle="Group nodes by datacenter or region." />
    <Crud title="Locations" endpoint="/api/admin/locations" listKey="locations" defaults={{ short: '', name: '' }} fromRow={r => ({ short: r.short, name: r.name })}
      columns={[{ label: 'ID', render: r => r.id }, { label: 'Short', render: r => <span className="font-mono">{r.short}</span> }, { label: 'Name', render: r => r.name }, { label: 'Nodes', render: r => r.nodes }]}
      fields={[{ key: 'short', label: 'Short code', hint: 'lowercase letters, digits, dashes (e.g. in-pat-1)' }, { key: 'name', label: 'Name' }]}
      canDelete={r => !Number(r.nodes)} /></>;
}

export function DatabaseHostsAdmin() {
  const nodes = useApi<any>('/api/admin/nodes'); const { run } = useAction();
  return <><PageHeader title="Database hosts" subtitle="MySQL/MariaDB servers where customer databases are created. Admin credentials are encrypted and never shown to customers." />
    <Crud title="Database hosts" endpoint="/api/admin/database-hosts" listKey="hosts" defaults={{ name: '', host: '127.0.0.1', port: 3306, publicHost: '', username: '', password: '', nodeId: null, maxDatabases: 0 }}
      fromRow={r => ({ name: r.name, host: r.host, port: r.port, publicHost: r.public_host || '', username: r.username, password: '', nodeId: r.node_id, maxDatabases: r.max_databases })}
      columns={[{ label: 'Name', render: r => r.name }, { label: 'Host', render: r => <span className="font-mono">{r.host}:{r.port}</span> }, { label: 'Public host', render: r => r.public_host || '—' }, { label: 'Databases', render: r => `${r.databases}${r.max_databases ? ` / ${r.max_databases}` : ''}` }]}
      fields={[{ key: 'name', label: 'Name' }, { key: 'host', label: 'Host (as reachable from the panel)' }, { key: 'port', label: 'Port', type: 'number' }, { key: 'publicHost', label: 'Public host shown to customers', nullable: true },
        { key: 'username', label: 'Admin username', hint: 'Needs CREATE USER and GRANT OPTION' }, { key: 'password', label: 'Admin password', type: 'password', placeholder: 'Leave empty to keep current' },
        { key: 'nodeId', label: 'Linked node', type: 'select', nullable: true, options: (nodes.data?.nodes || []).map((n: any) => ({ value: n.id, label: n.name })) }, { key: 'maxDatabases', label: 'Max databases (0 = unlimited)', type: 'number' }]}
      extraActions={r => <button className="btn-ghost btn-sm px-1.5" title="Test connection" onClick={() => run('t', async () => { const x = await api('POST', `/api/admin/database-hosts/${r.id}/test`); toast(x.version ? `Connected: ${x.version}` : 'Connected', 'success'); })}><Plug className="h-4 w-4" /></button>} /></>;
}

export function PluginReposAdmin() {
  return <><PageHeader title="Plugin repositories" subtitle="Sources the plugin installer may download from. Downloads are restricted to the listed hosts and are scanned, never executed, during installation." />
    <Crud title="Repositories" endpoint="/api/admin/plugin-repositories" listKey="repositories" defaults={{ name: '', type: 'custom', baseUrl: 'https://', downloadHosts: [], enabled: true }}
      fromRow={r => ({ name: r.name, type: r.type, baseUrl: r.base_url || '', downloadHosts: r.download_hosts || [], enabled: !!r.enabled })}
      columns={[{ label: 'Name', render: r => r.name }, { label: 'Type', render: r => r.type }, { label: 'Base URL', render: r => <span className="font-mono text-xs">{r.base_url || 'built-in'}</span> }, { label: 'Download hosts', render: r => <span className="font-mono text-xs">{(r.download_hosts || []).join(', ') || 'default'}</span> }, { label: 'Enabled', render: r => <Badge value={r.enabled ? 'active' : 'disabled'} label={yes(r.enabled)} /> }]}
      fields={[{ key: 'name', label: 'Name' }, { key: 'type', label: 'Type', type: 'select', createOnly: true, options: ['modrinth', 'hangar', 'spiget', 'github', 'custom'].map(v => ({ value: v, label: v })) }, { key: 'baseUrl', label: 'Base URL', hint: 'Required (https) for custom repositories', nullable: true },
        { key: 'downloadHosts', label: 'Allowed download hosts', type: 'list', placeholder: 'cdn.example.com, files.example.com' }, { key: 'enabled', label: 'Enabled', type: 'switch' }]} /></>;
}

export function AnnouncementsAdmin() {
  return <><PageHeader title="Announcements" subtitle="Shown on customer dashboards between the start and end time." />
    <Crud title="Announcements" endpoint="/api/admin/announcements" listKey="announcements" defaults={{ title: '', body: '', level: 'info', startsAt: null, endsAt: null, email: false }}
      fromRow={r => ({ title: r.title, body: r.body, level: r.level, startsAt: r.starts_at ? toLocal(r.starts_at) : null, endsAt: r.ends_at ? toLocal(r.ends_at) : null })}
      columns={[{ label: 'Title', render: r => r.title }, { label: 'Level', render: r => <Badge value={r.level === 'critical' ? 'high_risk' : r.level === 'warning' || r.level === 'maintenance' ? 'suspicious' : 'info'} label={r.level} /> }, { label: 'Window', render: r => <span className="text-xs">{date(r.starts_at)} → {r.ends_at ? date(r.ends_at) : 'no end'}</span> }, { label: 'Emailed', render: r => yes(r.email_sent) }]}
      fields={[{ key: 'title', label: 'Title', span: 2 }, { key: 'body', label: 'Message', type: 'textarea' }, { key: 'level', label: 'Level', type: 'select', options: ['info', 'warning', 'maintenance', 'critical'].map(v => ({ value: v, label: v })) },
        { key: 'startsAt', label: 'Starts', type: 'datetime' }, { key: 'endsAt', label: 'Ends', type: 'datetime' }, { key: 'email', label: 'Also email all verified users', type: 'switch', createOnly: true }]} /></>;
}
const toLocal = (s: string) => { const d = new Date(s); return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 16); };

export function RolesAdmin() {
  const { data } = useApi<any>('/api/admin/roles');
  return <><PageHeader title="Roles" subtitle="Built-in roles: Super Admin, Admin, Staff, Support, Customer. Create custom roles with specific permissions. You can only grant permissions you have." />
    <Crud title="Roles" endpoint="/api/admin/roles" listKey="roles" defaults={{ slug: '', name: '', permissions: [] }} fromRow={r => ({ slug: r.slug, name: r.name, permissions: r.permissions })}
      columns={[{ label: 'Name', render: r => <>{r.name}{r.is_system ? <span className="ml-2 badge border-ink-600 text-ink-400">built-in</span> : null}</> }, { label: 'Slug', render: r => <span className="font-mono">{r.slug}</span> }, { label: 'Permissions', render: r => <span className="text-xs text-ink-300">{r.permissions.includes('*') ? 'All permissions' : r.permissions.length ? r.permissions.join(', ') : 'None (customer)'}</span>, className: 'max-w-md' }, { label: 'Users', render: r => r.users }]}
      fields={[{ key: 'name', label: 'Name' }, { key: 'slug', label: 'Slug', hint: 'Cannot be changed on built-in roles' }, { key: 'permissions', label: 'Permissions', type: 'multiselect', options: (data?.available || []).map((p: string) => ({ value: p, label: p })) }]}
      canEdit={r => r.slug !== 'super_admin'} canDelete={r => !r.is_system && !Number(r.users)} /></>;
}

export function StoreAdmin() {
  const [tab, setTab] = useState<'plans' | 'products' | 'categories' | 'coupons'>('plans');
  const cats = useApi<any>('/api/admin/store/categories', [tab]); const prods = useApi<any>('/api/admin/store/products', [tab]); const plans = useApi<any>('/api/admin/store/plans', [tab]);
  const eggs = useApi<any>('/api/admin/eggs'); const nodes = useApi<any>('/api/admin/nodes'); const locs = useApi<any>('/api/admin/locations');
  const opt = (rows: any[] | undefined, label = (r: any) => r.name) => (rows || []).map(r => ({ value: r.id, label: label(r) }));
  return <><PageHeader title="Store" subtitle="Plans customers can buy. Paid orders provision servers automatically from the plan's egg, node or location and resources." />
    <Tabs value={tab} onChange={setTab} tabs={[{ id: 'plans', label: 'Plans' }, { id: 'products', label: 'Products' }, { id: 'categories', label: 'Categories' }, { id: 'coupons', label: 'Coupons' }]} />
    {tab === 'categories' && <Crud title="Categories" endpoint="/api/admin/store/categories" listKey="categories" defaults={{ name: '', slug: '', description: '', sort: 0, visible: true }} fromRow={r => ({ name: r.name, slug: r.slug, description: r.description || '', sort: r.sort, visible: !!r.visible })}
      columns={[{ label: 'Name', render: r => r.name }, { label: 'Slug', render: r => r.slug }, { label: 'Sort', render: r => r.sort }, { label: 'Visible', render: r => yes(r.visible) }]}
      fields={[{ key: 'name', label: 'Name' }, { key: 'slug', label: 'Slug' }, { key: 'description', label: 'Description', type: 'textarea' }, { key: 'sort', label: 'Sort', type: 'number' }, { key: 'visible', label: 'Visible', type: 'switch' }]} />}
    {tab === 'products' && <Crud title="Products" endpoint="/api/admin/store/products" listKey="products" defaults={{ categoryId: cats.data?.categories?.[0]?.id, name: '', slug: '', type: 'minecraft', description: '', visible: true, sort: 0 }}
      fromRow={r => ({ categoryId: r.category_id, name: r.name, slug: r.slug, type: r.type, description: r.description || '', visible: !!r.visible, sort: r.sort })}
      columns={[{ label: 'Name', render: r => r.name }, { label: 'Type', render: r => r.type }, { label: 'Category', render: r => cats.data?.categories?.find((c: any) => c.id === r.category_id)?.name || r.category_id }, { label: 'Plans', render: r => r.plans }, { label: 'Visible', render: r => yes(r.visible) }]}
      fields={[{ key: 'categoryId', label: 'Category', type: 'select', options: opt(cats.data?.categories) }, { key: 'name', label: 'Name' }, { key: 'slug', label: 'Slug' }, { key: 'type', label: 'Type', type: 'select', options: ['minecraft', 'vps', 'game', 'custom', 'addon_storage', 'addon_ram', 'addon_cpu'].map(v => ({ value: v, label: v })) }, { key: 'description', label: 'Description', type: 'textarea' }, { key: 'sort', label: 'Sort', type: 'number' }, { key: 'visible', label: 'Visible', type: 'switch' }]} canDelete={r => !Number(r.plans)} />}
    {tab === 'plans' && <Crud title="Plans" endpoint="/api/admin/store/plans" listKey="plans"
      defaults={{ productId: prods.data?.products?.[0]?.id, name: '', description: '', priceCents: 0, currency: 'INR', billingCycle: 'monthly', setupFeeCents: 0, memoryMb: 2048, cpuPercent: 100, diskMb: 5120, databases: 1, backups: 1, allocations: 1, eggId: null, nodeId: null, locationId: null, stock: null, visible: true, sort: 0, coinPrice: null, maxPerUser: null }}
      fromRow={r => ({ productId: r.product_id, name: r.name, description: r.description || '', priceCents: r.price_cents, currency: r.currency, billingCycle: r.billing_cycle, setupFeeCents: r.setup_fee_cents, memoryMb: r.memory_mb, cpuPercent: r.cpu_percent, diskMb: r.disk_mb, databases: r.databases, backups: r.backups, allocations: r.allocations, eggId: r.egg_id, nodeId: r.node_id, locationId: r.location_id, stock: r.stock, visible: !!r.visible, sort: r.sort, coinPrice: r.coin_price, maxPerUser: r.max_per_user })}
      columns={[{ label: 'Plan', render: r => <><div className="font-semibold">{r.name}</div><div className="text-xs text-ink-400">{r.product_name}</div></> }, { label: 'Price', render: r => <>{money(r.price_cents, r.currency)} / {r.billing_cycle}{r.coin_price != null && <div className="text-xs text-amber-300">{Number(r.coin_price).toLocaleString()} coins</div>}</> }, { label: 'Resources', render: r => <span className="text-xs">{r.memory_mb} MB RAM · {r.cpu_percent}% CPU · {r.disk_mb} MB disk</span> }, { label: 'Stock', render: r => r.stock ?? '∞' }, { label: 'Active', render: r => r.active_services }, { label: 'Visible', render: r => yes(r.visible) }]}
      fields={[{ key: 'productId', label: 'Product', type: 'select', options: opt(prods.data?.products) }, { key: 'name', label: 'Name' }, { key: 'description', label: 'Description', type: 'textarea' },
        { key: 'priceCents', label: 'Price', type: 'money' }, { key: 'currency', label: 'Currency', hint: 'ISO code, e.g. INR, USD' }, { key: 'billingCycle', label: 'Billing cycle', type: 'select', options: ['monthly', 'quarterly', 'semiannual', 'annual', 'one_time'].map(v => ({ value: v, label: v })) }, { key: 'setupFeeCents', label: 'Setup fee', type: 'money' },
        { key: 'coinPrice', label: 'OGCoins price per cycle (empty = not buyable with coins)', type: 'number', nullable: true, hint: 'Set Price 0 + a coin price for a coins-only plan' }, { key: 'maxPerUser', label: 'Max per customer (empty = unlimited)', type: 'number', nullable: true, hint: 'Useful for free / coin plans' },
        { key: 'memoryMb', label: 'RAM (MB)', type: 'number' }, { key: 'cpuPercent', label: 'CPU (% — 100 = 1 core)', type: 'number' }, { key: 'diskMb', label: 'Disk (MB)', type: 'number' }, { key: 'databases', label: 'Databases', type: 'number' }, { key: 'backups', label: 'Backups', type: 'number' }, { key: 'allocations', label: 'Ports', type: 'number' },
        { key: 'eggId', label: 'Egg (software)', type: 'select', nullable: true, options: opt(eggs.data?.eggs), hint: 'Empty: customer picks at checkout' }, { key: 'nodeId', label: 'Node', type: 'select', nullable: true, options: opt(nodes.data?.nodes) }, { key: 'locationId', label: 'Location', type: 'select', nullable: true, options: opt(locs.data?.locations), hint: 'Used when no node is fixed: the least-loaded node there is picked' },
        { key: 'stock', label: 'Stock (empty = unlimited)', type: 'number', nullable: true }, { key: 'sort', label: 'Sort', type: 'number' }, { key: 'visible', label: 'Visible in store', type: 'switch' }]}
      canDelete={r => !Number(r.active_services)} deleteNote={() => 'Plans with orders or services cannot be deleted; hide them instead.'} />}
    {tab === 'coupons' && <Crud title="Coupons" endpoint="/api/admin/store/coupons" listKey="coupons" defaults={{ code: '', type: 'percent', value: 10, maxUses: null, expiresAt: null, planIds: [], recurring: false, active: true }}
      fromRow={r => ({ code: r.code, type: r.type, value: r.value, maxUses: r.max_uses, expiresAt: r.expires_at ? toLocal(r.expires_at) : null, planIds: r.plan_ids || [], recurring: !!r.recurring, active: !!r.active })}
      columns={[{ label: 'Code', render: r => <span className="font-mono">{r.code}</span> }, { label: 'Discount', render: r => r.type === 'percent' ? `${r.value}%` : money(r.value) }, { label: 'Used', render: r => `${r.uses ?? 0}${r.max_uses ? ` / ${r.max_uses}` : ''}` }, { label: 'Expires', render: r => date(r.expires_at) }, { label: 'Active', render: r => yes(r.active) }]}
      fields={[{ key: 'code', label: 'Code' }, { key: 'type', label: 'Type', type: 'select', options: [{ value: 'percent', label: 'Percent' }, { value: 'fixed', label: 'Fixed amount (in minor units, e.g. paise)' }] }, { key: 'value', label: 'Value', type: 'number', hint: 'Percent 1-100, or amount in minor units (100 = ₹1)' },
        { key: 'maxUses', label: 'Max uses (empty = unlimited)', type: 'number', nullable: true }, { key: 'expiresAt', label: 'Expires', type: 'datetime' }, { key: 'planIds', label: 'Limit to plans (none = all)', type: 'multiselect', options: opt(plans.data?.plans, r => `${r.product_name} — ${r.name}`) }, { key: 'recurring', label: 'Applies to renewals', type: 'switch' }, { key: 'active', label: 'Active', type: 'switch' }]}
      deleteLabel="Deactivate" deleteNote={() => 'Coupons are deactivated, not deleted, so order history stays intact.'} />}
  </>;
}

export function WebhooksAdmin() {
  const hooks = useApi<any>('/api/admin/webhooks'); const keys = useApi<any>('/api/admin/api-keys'); const { busy, run } = useAction();
  const [secret, setSecret] = useState<string | null>(null); const [revoke, setRevoke] = useState<any>(null);
  return <><PageHeader title="Webhooks & API" subtitle={<>Outgoing webhooks are signed with HMAC-SHA256 (header X-OGHOST-Signature). The REST API is documented at <a className="link" href="/api/docs" target="_blank" rel="noreferrer">/api/docs</a> (OpenAPI).</>} />
    <div className="space-y-6">
      <Crud title="Outgoing webhooks" endpoint="/api/admin/webhooks" listKey="webhooks" defaults={{ url: 'https://', events: ['*'], enabled: true }} fromRow={r => ({ url: r.url, events: r.events, enabled: !!r.enabled })}
        columns={[{ label: 'URL', render: r => <span className="font-mono text-xs">{r.url}</span> }, { label: 'Events', render: r => <span className="text-xs">{r.events.join(', ')}</span>, className: 'max-w-xs' }, { label: 'Last delivery', render: r => r.last_delivery_at ? <>{ago(r.last_delivery_at)} <span className="text-xs text-ink-400">({r.last_status})</span></> : 'never' }, { label: 'Enabled', render: r => yes(r.enabled) }]}
        fields={[{ key: 'url', label: 'URL', span: 2 }, { key: 'events', label: 'Events', type: 'multiselect', options: ['*', ...(hooks.data?.events || [])].map((e: string) => ({ value: e, label: e === '*' ? '* (all events)' : e })) }, { key: 'enabled', label: 'Enabled', type: 'switch' }]}
        onCreated={r => setSecret(r.secret)}
        extraActions={r => <button className="btn-ghost btn-sm px-1.5" title="Send test ping" onClick={() => run('t', async () => { const x = await api('POST', `/api/admin/webhooks/${r.id}/test`); toast(`Delivered: ${x.status}`, 'info'); })}><Play className="h-4 w-4" /></button>} />
      <Card title="API keys (all users)">
        {keys.loading ? <Loading /> : keys.error ? <ErrorBox error={keys.error} /> : !keys.data.keys.length ? <Empty title="No API keys" >Users create keys under Account → API keys.</Empty> :
          <Table><thead><tr><th>User</th><th>Name</th><th>Prefix</th><th>Scopes</th><th>Allowed IPs</th><th>Last used</th><th>Expires</th><th /></tr></thead><tbody>{keys.data.keys.map((k: any) => <tr key={k.id}><td>{k.email}</td><td>{k.name}</td><td className="font-mono text-xs">ogh_{k.prefix}_…</td><td className="text-xs">{k.scopes.join(', ')}</td><td className="text-xs">{k.allowed_ips?.join(', ') || 'any'}</td><td>{ago(k.last_used_at)}</td><td>{date(k.expires_at)}</td><td><button className="btn-ghost btn-sm px-1.5 text-red-400" onClick={() => setRevoke(k)}><Trash2 className="h-4 w-4" /></button></td></tr>)}</tbody></Table>}
      </Card>
    </div>
    <Modal open={!!secret} onClose={() => setSecret(null)} title="Webhook signing secret"><Notice kind="warn">Copy this secret now; it is not shown again.</Notice><div className="mt-3 flex gap-2"><code className="input font-mono text-xs">{secret}</code><button className="btn-secondary" onClick={() => { navigator.clipboard.writeText(secret || ''); toast('Copied', 'success'); }}><Copy className="h-4 w-4" /></button></div></Modal>
    <Confirm open={!!revoke} onClose={() => setRevoke(null)} danger title="Revoke API key" confirmLabel="Revoke" busy={busy === 'rv'} onConfirm={() => run('rv', () => api('DELETE', `/api/admin/api-keys/${revoke.id}`).then(() => { setRevoke(null); keys.reload(); }), 'Key revoked')}>Applications using “{revoke?.name}” will stop working immediately.</Confirm>
  </>;
}

export function AuditAdmin() {
  const [page, setPage] = useState(1); const [action, setAction] = useState(''); const [user, setUser] = useState('');
  const qs = new URLSearchParams({ page: String(page), per_page: '50', ...(action ? { action } : {}), ...(user ? { user } : {}) }).toString();
  const { data, error, loading, reload } = useApi<any>(`/api/admin/audit?${qs}`);
  const [open, setOpen] = useState<any>(null);
  return <><PageHeader title="Audit log" subtitle="Every administrative and security-relevant action, with actor and IP address." />
    <Card actions={<div className="flex gap-2"><input className="input w-48" placeholder="Action prefix (admin.server)" value={action} onChange={e => { setAction(e.target.value); setPage(1); }} /><input className="input w-28" placeholder="User ID" value={user} onChange={e => { setUser(e.target.value.replace(/\D/g, '')); setPage(1); }} /></div>} title="Entries">
      {loading ? <Loading /> : error ? <ErrorBox error={error} onRetry={reload} /> : !data.logs.length ? <Empty title="No entries" /> :
        <Table><thead><tr><th>When</th><th>Actor</th><th>Action</th><th>Target</th><th>IP</th><th /></tr></thead><tbody>{data.logs.map((l: any) => <tr key={l.id}><td className="whitespace-nowrap text-xs">{date(l.created_at)}</td><td>{l.email || (l.user_id ? `#${l.user_id}` : 'system')}</td><td className="font-mono text-xs">{l.action}</td><td className="text-xs">{l.target_type ? `${l.target_type} #${l.target_id}` : '—'}</td><td className="font-mono text-xs">{l.ip || '—'}</td><td>{l.metadata && <button className="btn-ghost btn-sm" onClick={() => setOpen(l)}>Details</button>}</td></tr>)}</tbody></Table>}
      <Pager page={page} setPage={setPage} hasMore={(data?.logs?.length || 0) >= 50} />
    </Card>
    <Modal open={!!open} onClose={() => setOpen(null)} title={open?.action} wide><pre className="max-h-[60vh] overflow-auto rounded-lg bg-ink-950 p-3 text-xs">{JSON.stringify(open?.metadata, null, 2)}</pre><div className="mt-2 text-xs text-ink-400">{open?.user_agent}</div></Modal>
  </>;
}

export function JobsAdmin() {
  const [page, setPage] = useState(1); const [status, setStatus] = useState('');
  const { data, error, loading, reload } = useApi<any>(`/api/admin/jobs?page=${page}&per_page=50${status ? `&status=${status}` : ''}`, [], 5000); const { run } = useAction();
  const [open, setOpen] = useState<any>(null);
  return <><PageHeader title="Background jobs" subtitle="Installs, transfers, clones, backups, scheduled tasks and billing run in the persistent job queue." />
    <Card title="Jobs" actions={<select className="input w-40" value={status} onChange={e => { setStatus(e.target.value); setPage(1); }}><option value="">All</option>{['queued', 'running', 'completed', 'failed'].map(s => <option key={s}>{s}</option>)}</select>}>
      {loading ? <Loading /> : error ? <ErrorBox error={error} onRetry={reload} /> : !data.jobs.length ? <Empty title="No jobs" /> :
        <Table><thead><tr><th>ID</th><th>Type</th><th>Status</th><th>Attempts</th><th>Created</th><th>Finished</th><th>Error</th><th /></tr></thead><tbody>{data.jobs.map((j: any) => <tr key={j.id}><td>{j.id}</td><td className="font-mono text-xs">{j.type}</td><td><Badge value={j.status === 'completed' ? 'running' : j.status === 'failed' ? 'install_failed' : j.status === 'running' ? 'starting' : 'offline'} label={j.status} /></td><td>{j.attempts}/{j.max_attempts}</td><td className="text-xs">{date(j.created_at)}</td><td className="text-xs">{date(j.finished_at)}</td><td className="max-w-xs truncate text-xs text-red-300" title={j.last_error || ''}>{j.last_error || ''}</td>
          <td className="whitespace-nowrap"><button className="btn-ghost btn-sm" onClick={() => setOpen(j)}>Details</button>{j.status === 'failed' && <button className="btn-ghost btn-sm px-1.5" title="Retry" onClick={() => run('r', () => api('POST', `/api/admin/jobs/${j.id}/retry`).then(reload), 'Re-queued')}><RotateCcw className="h-4 w-4" /></button>}</td></tr>)}</tbody></Table>}
      <Pager page={page} setPage={setPage} hasMore={(data?.jobs?.length || 0) >= 50} />
    </Card>
    <Modal open={!!open} onClose={() => setOpen(null)} title={`Job #${open?.id} — ${open?.type}`} wide><pre className="max-h-[60vh] overflow-auto whitespace-pre-wrap rounded-lg bg-ink-950 p-3 text-xs">{JSON.stringify({ payload: open?.payload, result: open?.result, error: open?.last_error }, null, 2)}</pre></Modal>
  </>;
}

export function DriveAdmin() {
  const { data, error, loading, reload } = useApi<any>('/api/admin/drive', [], 15000);
  return <><PageHeader title="Google Drive backups" subtitle="Aggregate status only. Customer Drive tokens are encrypted, and administrators cannot browse customers' Drive files." />
    {loading ? <Loading /> : error ? <ErrorBox error={error} onRetry={reload} /> : <>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Stat label="Connected accounts" value={data.connections} sub={`${data.connectionErrors} with errors · ${data.revoked} revoked`} />
        <Stat label="Servers with Drive backups" value={data.serversEnabled} sub={`${data.running} running now · ${data.failing} failing`} />
        <Stat label="Last 24 hours" value={data.completed24h} sub={`${data.failed24h} failed`} />
        <Stat label="Stored in customer Drives" value={bytes(data.storedBytes)} sub="Not on this host's disk" />
      </div>
      <Card title="Recent failures" className="mt-6">{!data.recentFailures.length ? <Empty title="No failures" /> : <Table><thead><tr><th>Server</th><th>When</th><th>Error</th></tr></thead><tbody>{data.recentFailures.map((f: any, i: number) => <tr key={i}><td><a className="link" href={`/admin/servers/${f.server_id}`}>#{f.server_id}</a></td><td className="text-xs">{date(f.completed_at)}</td><td className="text-xs text-red-300">{f.error}</td></tr>)}</tbody></Table>}</Card>
    </>}
  </>;
}
