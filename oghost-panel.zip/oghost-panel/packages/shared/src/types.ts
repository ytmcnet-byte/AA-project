export type ServerState = 'installing' | 'install_failed' | 'offline' | 'starting' | 'running' | 'stopping' | 'crashed' | 'suspended' | 'deleting' | 'transferring';
export type SecurityLevel = 'safe' | 'suspicious' | 'high_risk' | 'unscanned';

export interface EggVariable { key: string; name: string; description?: string; default: string; userEditable: boolean; rules?: string; }
export interface EggDefinition {
  slug: string; name: string; category: 'minecraft-java' | 'minecraft-bedrock' | 'proxy' | 'custom';
  description: string;
  /** Install strategy implemented natively by the node agent (no shell scripts from users). */
  installer: 'vanilla' | 'paper' | 'purpur' | 'folia' | 'velocity' | 'waterfall' | 'fabric' | 'quilt' | 'forge' | 'neoforge' | 'pufferfish' | 'bungeecord' | 'spigot' | 'bedrock' | 'pocketmine' | 'minestom' | 'custom' | 'none';
  runtime: 'java' | 'native' | 'php';
  javaMin?: number; javaMax?: number;
  /** Startup template. Tokens: {{JAVA}} {{XMS}} {{XMX}} {{SERVER_JAR}} {{PORT}} {{JVM_FLAGS}} and any variable key. */
  startup: string;
  stopCommand: string; doneRegex?: string;
  variables: EggVariable[];
  configFiles?: Record<string, Record<string, string>>;
  notes?: string;
  /** Optional admin-authored bash install script (runs as the server user after the native installer). */
  installScript?: string;
}

export interface NodeHeartbeat {
  nodeId: number; version: string; arch: string; platform: string; uptime: number;
  cpu: { cores: number; load: number[]; usagePercent: number };
  memory: { total: number; free: number };
  disk: { total: number; free: number; quotaSupport: string; fsType: string };
  network: { rxBytes: number; txBytes: number };
  java: JavaInstall[]; cpulimit: string | null;
  servers: Array<{ id: number; state: ServerState; pid: number | null; cpu: number; memory: number; diskBytes: number }>;
  runningAsRoot: boolean;
}
export interface JavaInstall { path: string; version: string; major: number; vendor: string; arch: string; }

export interface AgentServerSpec {
  id: number; uuid: string; memoryMb: number; cpuPercent: number; diskMb: number; swapMb: number;
  xmsMb: number; xmxMb: number; javaPath: string | null; startup: string; stopCommand: string; doneRegex?: string;
  egg: EggDefinition; variables: Record<string, string>; ports: number[]; primaryPort: number; ip: string;
  suspended: boolean; securityBlocked: boolean; autoRestart: boolean; maxUploadMb: number;
  /** Version actually installed (resolved from "latest"), used to auto-select a compatible Java. */
  installedVersion?: string | null;
}
