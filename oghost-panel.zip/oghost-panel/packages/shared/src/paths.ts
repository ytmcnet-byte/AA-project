import path from 'node:path';
import fs from 'node:fs';

export class PathSecurityError extends Error { status = 400; }

/**
 * Resolve a client-supplied relative path inside `root`, rejecting traversal and symlink escapes.
 * Every existing component is lstat'd: a symlink anywhere in the chain that resolves outside the
 * root, or that is dangling, is rejected — also for paths that do not exist yet (create/upload targets).
 */
export function safeResolve(root: string, relative: string): string {
  const rootReal = fs.realpathSync(root);
  const rel = String(relative ?? '').replace(/\\/g, '/');
  if (rel.includes('\0')) throw new PathSecurityError('Invalid path');
  const target = path.resolve(rootReal, '.' + path.posix.sep + rel.replace(/^\/+/, ''));
  if (target !== rootReal && !target.startsWith(rootReal + path.sep)) throw new PathSecurityError('Path escapes server directory');
  // Walk every component below the root with lstat. Any symlink must resolve (realpath) inside the root;
  // a dangling symlink is rejected because writing through it would create its (possibly external) target.
  const inside = (p: string) => p === rootReal || p.startsWith(rootReal + path.sep);
  let cur = rootReal;
  for (const seg of path.relative(rootReal, target).split(path.sep).filter(Boolean)) {
    cur = path.join(cur, seg);
    let st: fs.Stats; try { st = fs.lstatSync(cur); } catch { break; } // the rest of the path does not exist yet
    if (st.isSymbolicLink()) {
      let real: string; try { real = fs.realpathSync(cur); } catch { throw new PathSecurityError('Broken symlink in path'); }
      if (!inside(real)) throw new PathSecurityError('Symlink escapes server directory');
    }
  }
  return target;
}

export function toRelative(root: string, abs: string) {
  return '/' + path.relative(fs.realpathSync(root), abs).split(path.sep).join('/');
}
