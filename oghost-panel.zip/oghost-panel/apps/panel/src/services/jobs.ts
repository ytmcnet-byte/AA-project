import { pool, q, exec, json, parse } from '../db';

/**
 * Durable DB-backed background job queue. Workers claim jobs with SELECT ... FOR UPDATE SKIP LOCKED
 * so several panel processes can run safely. Jobs left "running" by a crashed process are re-queued
 * after their lock expires.
 */
type Handler = (payload: any, job: { id: number; attempts: number }) => Promise<unknown>;
const handlers = new Map<string, Handler>();
export function registerJob(type: string, fn: Handler) { handlers.set(type, fn); }

export async function enqueue(type: string, payload: unknown, opts: { uniqueKey?: string; runAt?: Date; maxAttempts?: number } = {}) {
  try {
    const r = await exec('INSERT INTO jobs (type, payload, run_at, max_attempts, unique_key) VALUES (?, ?, ?, ?, ?)', [type, json(payload), opts.runAt ?? new Date(), opts.maxAttempts ?? 3, opts.uniqueKey ?? null]);
    return r.insertId;
  } catch (e: any) {
    if (e.code === 'ER_DUP_ENTRY') return null; // an identical job is already queued/running
    throw e;
  }
}

let running = 0; const MAX = 4; let timer: NodeJS.Timeout | null = null;
async function claim() {
  const c = await pool.getConnection();
  try {
    await c.beginTransaction();
    const [rows]: any = await c.query("SELECT * FROM jobs WHERE status = 'queued' AND run_at <= NOW() ORDER BY run_at, id LIMIT 1 FOR UPDATE SKIP LOCKED");
    const j = rows[0]; if (!j) { await c.commit(); return null; }
    await c.query("UPDATE jobs SET status = 'running', locked_at = NOW(), attempts = attempts + 1 WHERE id = ?", [j.id]);
    await c.commit(); return { ...j, attempts: j.attempts + 1 };
  } catch (e) { await c.rollback().catch(() => {}); throw e; } finally { c.release(); }
}
async function runOne(j: any) {
  const h = handlers.get(j.type);
  try {
    if (!h) throw new Error(`No handler for job type ${j.type}`);
    const result = await h(parse(j.payload, {}), { id: j.id, attempts: j.attempts });
    // unique_key is cleared on completion so the same logical job can be queued again later
    await exec("UPDATE jobs SET status = 'done', result = ?, finished_at = NOW(), unique_key = NULL WHERE id = ?", [json(result ?? null), j.id]);
  } catch (e: any) {
    const retry = j.attempts < j.max_attempts && !e.noRetry;
    const delay = Math.min(3600, 30 * 2 ** (j.attempts - 1));
    await exec(`UPDATE jobs SET status = ?, last_error = ?, run_at = DATE_ADD(NOW(), INTERVAL ? SECOND), finished_at = IF(? = 'failed', NOW(), NULL), unique_key = IF(? = 'failed', NULL, unique_key) WHERE id = ?`,
      [retry ? 'queued' : 'failed', String(e.stack || e.message).slice(0, 4000), delay, retry ? 'queued' : 'failed', retry ? 'queued' : 'failed', j.id]);
    console.error(`[jobs] ${j.type}#${j.id} attempt ${j.attempts} failed: ${e.message}${retry ? ` (retry in ${delay}s)` : ''}`);
  }
}
export function startJobWorker() {
  const tick = async () => {
    try {
      await exec("UPDATE jobs SET status = 'queued', locked_at = NULL WHERE status = 'running' AND locked_at < DATE_SUB(NOW(), INTERVAL 6 HOUR)");
      while (running < MAX) { const j = await claim(); if (!j) break; running++; runOne(j).finally(() => { running--; }); }
    } catch (e: any) { console.error('[jobs] worker error', e.message); }
    timer = setTimeout(tick, 2000);
  };
  // Jobs that were "running" when this process last stopped are re-queued at startup
  exec("UPDATE jobs SET status = 'queued', locked_at = NULL WHERE status = 'running'").catch(() => {}).finally(tick);
}
export function stopJobWorker() { if (timer) clearTimeout(timer); }
export async function jobStatus(id: number) { return (await q('SELECT id, type, status, attempts, last_error, result, created_at, finished_at FROM jobs WHERE id = ?', [id]))[0] ?? null; }
