# OGCoins Discord bot (example)

A small discord.js v14 bot that lets staff credit OGCoins after selling them on Discord and lets members check their balance.
It talks to the panel only through the documented admin API (see `documentation/COINS.md`).

Status: example code. It is syntax-checked but has NOT been run against a real Discord bot account.

```bash
cd integrations/discord-bot
npm install
cp .env.example .env   # fill in the values
node --env-file=.env bot.mjs --register   # once, registers /balance and /givecoins
node --env-file=.env bot.mjs
```

- Create the API key in the panel (Account → API keys) while logged in as an admin whose role has `admin.coins`; give it the `admin.*` scope and, ideally, restrict it to the bot host's IP.
- `/givecoins` is limited to members with `STAFF_ROLE_ID`.
- Use a unique `reference` per sale (order ID, UPI transaction ID, ticket number). Re-running the command with the same reference never double-credits.
- No root, no Docker: run it with `node` under any user (or pm2 / a systemd user service).
