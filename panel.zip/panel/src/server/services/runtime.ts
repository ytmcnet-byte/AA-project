import {
  createLocalServer, startLocalServer, stopLocalServer, restartLocalServer,
  deleteLocalServer, getLocalServerStatus, getLocalServerStats,
  getLocalServerLogs, attachLocalServerSocket, sendLocalServerCommand
} from './local.js';

// Local-process-only runtime. Docker is intentionally not used by this build.
export const createServerRuntime = async (serverData: any, _nodeId?: string) => createLocalServer(serverData);
export const startServerRuntime = async (server: any) => startLocalServer(server.id, server);
export const stopServerRuntime = async (server: any) => stopLocalServer(server.id);
export const restartServerRuntime = async (server: any) => restartLocalServer(server.id, server);
export const deleteServerRuntime = async (server: any) => deleteLocalServer(server.id);
export const getServerRuntimeStatus = async (server: any) => getLocalServerStatus(server.id);
export const getServerRuntimeStats = async (server: any) => getLocalServerStats(server.id);
export const getServerRuntimeLogs = async (server: any) => getLocalServerLogs(server.id);
export const attachServerRuntimeSocket = async (server: any, serverId: string) => attachLocalServerSocket(server.id, serverId);
export const sendServerRuntimeCommand = async (server: any, command: string) => sendLocalServerCommand(server.id, command);
