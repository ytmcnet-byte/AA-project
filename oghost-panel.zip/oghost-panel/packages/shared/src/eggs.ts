import type { EggDefinition, EggVariable } from './types';

const JAVA_START = '{{JAVA}} -Xms{{XMS}}M -Xmx{{XMX}}M {{JVM_FLAGS}} -jar {{SERVER_JAR}} nogui';
const v = (key: string, name: string, def: string, rules = '^[A-Za-z0-9._+\\-]{1,64}$', userEditable = true, description = ''): EggVariable => ({ key, name, default: def, rules, userEditable, description });
const MC_VERSION = v('MC_VERSION', 'Minecraft version', 'latest', '^(latest|[0-9A-Za-z._\\-]{1,32})$', true, 'Game version or "latest"');
const BUILD = v('BUILD', 'Build', 'latest', '^(latest|[0-9]{1,8})$', true, 'Build number or "latest"');
const JAR = v('SERVER_JAR', 'Server JAR file', 'server.jar', '^[A-Za-z0-9._\\-]{1,64}\\.jar$');
const FLAGS = v('JVM_FLAGS', 'Extra JVM flags', '-XX:+UseG1GC -XX:+ParallelRefProcEnabled -XX:MaxGCPauseMillis=200', '^[A-Za-z0-9 :+=\\-._/]{0,512}$');

const mcJava = (slug: string, name: string, installer: EggDefinition['installer'], description: string, extra: Partial<EggDefinition> = {}): EggDefinition => ({
  slug, name, category: 'minecraft-java', description, installer, runtime: 'java', javaMin: 8,
  startup: JAVA_START, stopCommand: 'stop', doneRegex: 'Done \\(', variables: [MC_VERSION, BUILD, JAR, FLAGS],
  configFiles: { 'server.properties': { 'server-port': '{{PORT}}', 'server-ip': '0.0.0.0', 'query.port': '{{PORT}}' }, 'eula.txt': { eula: 'false' } },
  ...extra,
});

export const BUILTIN_EGGS: EggDefinition[] = [
  mcJava('vanilla', 'Vanilla', 'vanilla', 'Official Mojang server from the Piston launcher manifest.'),
  mcJava('paper', 'Paper', 'paper', 'High-performance Spigot fork (PaperMC Fill API v3).'),
  mcJava('purpur', 'Purpur', 'purpur', 'Paper fork with extra configurability (api.purpurmc.org).'),
  mcJava('pufferfish', 'Pufferfish', 'pufferfish', 'Paper fork focused on performance (Pufferfish CI).'),
  mcJava('folia', 'Folia', 'folia', 'Regionised multithreading Paper fork. Most plugins are NOT compatible.', { javaMin: 21 }),
  mcJava('spigot', 'Spigot', 'spigot', 'Built locally with the official SpigotMC BuildTools (takes several minutes, needs ~1.5 GB RAM).', { notes: 'BuildTools compiles from source; Spigot does not permit redistribution of binaries.' }),
  mcJava('bukkit', 'Bukkit (CraftBukkit)', 'spigot', 'CraftBukkit built locally with BuildTools --compile craftbukkit.', { variables: [MC_VERSION, BUILD, JAR, FLAGS, v('BUILDTOOLS_TARGET', 'BuildTools target', 'craftbukkit', '^(craftbukkit)$', false)] }),
  mcJava('fabric', 'Fabric', 'fabric', 'Fabric server launcher from meta.fabricmc.net.', { variables: [MC_VERSION, v('LOADER_VERSION', 'Loader version', 'latest'), v('SERVER_JAR', 'Server JAR file', 'fabric-server-launch.jar', '^[A-Za-z0-9._\\-]{1,64}\\.jar$'), FLAGS] }),
  mcJava('quilt', 'Quilt', 'quilt', 'Quilt server installed with the official Quilt installer.', { variables: [MC_VERSION, v('LOADER_VERSION', 'Loader version', 'latest'), v('SERVER_JAR', 'Server JAR file', 'quilt-server-launch.jar', '^[A-Za-z0-9._\\-]{1,64}\\.jar$'), FLAGS] }),
  mcJava('forge', 'Forge', 'forge', 'Minecraft Forge installed with the official installer (--installServer).', {
    startup: '{{JAVA}} -Xms{{XMS}}M -Xmx{{XMX}}M {{JVM_FLAGS}} {{FORGE_ARGS}} nogui',
    variables: [MC_VERSION, v('FORGE_VERSION', 'Forge version', 'recommended', '^(recommended|latest|[0-9.\\-]{1,40})$'), FLAGS, v('FORGE_ARGS', 'Launch target (set by installer)', '-jar server.jar', '^[A-Za-z0-9 @/._\\-]{1,256}$', false)],
  }),
  mcJava('neoforge', 'NeoForge', 'neoforge', 'NeoForge installed with the official installer (--installServer).', {
    javaMin: 17, startup: '{{JAVA}} -Xms{{XMS}}M -Xmx{{XMX}}M {{JVM_FLAGS}} {{FORGE_ARGS}} nogui',
    variables: [MC_VERSION, v('NEOFORGE_VERSION', 'NeoForge version', 'latest', '^(latest|[0-9.\\-a-z]{1,40})$'), FLAGS, v('FORGE_ARGS', 'Launch target (set by installer)', '-jar server.jar', '^[A-Za-z0-9 @/._\\-]{1,256}$', false)],
  }),
  { ...mcJava('velocity', 'Velocity', 'velocity', 'Modern high-performance proxy (PaperMC).'), category: 'proxy', javaMin: 17, startup: '{{JAVA}} -Xms{{XMS}}M -Xmx{{XMX}}M {{JVM_FLAGS}} -jar {{SERVER_JAR}}', stopCommand: 'end', doneRegex: 'Done \\(', configFiles: { 'velocity.toml': { bind: '"0.0.0.0:{{PORT}}"' } } },
  { ...mcJava('waterfall', 'Waterfall', 'waterfall', 'BungeeCord fork by PaperMC (end-of-life, legacy).'), category: 'proxy', startup: '{{JAVA}} -Xms{{XMS}}M -Xmx{{XMX}}M {{JVM_FLAGS}} -jar {{SERVER_JAR}}', stopCommand: 'end', doneRegex: 'Listening on', configFiles: { 'config.yml': { host: '0.0.0.0:{{PORT}}' } } },
  { ...mcJava('bungeecord', 'BungeeCord', 'bungeecord', 'Official BungeeCord proxy from ci.md-5.net.'), category: 'proxy', startup: '{{JAVA}} -Xms{{XMS}}M -Xmx{{XMX}}M {{JVM_FLAGS}} -jar {{SERVER_JAR}}', stopCommand: 'end', doneRegex: 'Listening on', configFiles: { 'config.yml': { host: '0.0.0.0:{{PORT}}' } } },
  { slug: 'bedrock', name: 'Bedrock Dedicated Server', category: 'minecraft-bedrock', description: 'Official Mojang Bedrock Dedicated Server (Linux x86_64 only).', installer: 'bedrock', runtime: 'native',
    startup: './bedrock_server', stopCommand: 'stop', doneRegex: 'Server started', variables: [v('BEDROCK_VERSION', 'Bedrock version', 'latest', '^(latest|[0-9.]{1,20})$')],
    configFiles: { 'server.properties': { 'server-port': '{{PORT}}', 'server-portv6': '{{PORT_V6}}' } }, notes: 'Mojang only ships x86_64 Linux binaries. ARM64 nodes cannot run BDS natively.' },
  { slug: 'pocketmine', name: 'PocketMine-MP', category: 'minecraft-bedrock', description: 'PHP Bedrock server software (requires a PHP 8 binary with pmmp extensions on the node).', installer: 'pocketmine', runtime: 'php',
    startup: '{{PHP_BINARY}} PocketMine-MP.phar --no-wizard --disable-ansi', stopCommand: 'stop', doneRegex: 'Done \\(', variables: [v('PMMP_VERSION', 'PocketMine version', 'latest', '^(latest|[0-9.]{1,20})$'), v('PHP_BINARY', 'PHP binary path', 'bin/php7/bin/php', '^[A-Za-z0-9._/\\-]{1,128}$', false, 'Path to pmmp PHP binary (admin configured)')],
    configFiles: { 'server.properties': { 'server-port': '{{PORT}}' } } },
  { ...mcJava('minestom', 'Minestom (custom build)', 'custom', 'Minestom is a library: upload your compiled Minestom server JAR as server.jar.'), category: 'custom', configFiles: {} , doneRegex: undefined },
  { ...mcJava('custom-jar', 'Custom server JAR', 'custom', 'Upload any Minecraft server JAR. It is scanned by the OGHOST Security Center before first start.'), category: 'custom' },
];
