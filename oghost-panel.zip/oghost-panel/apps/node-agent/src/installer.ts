import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { spawn } from 'node:child_process';
import { hashFile, type AgentServerSpec } from '@oghost/shared';
import { downloadTo, fetchJson } from './download';
import { extractZip } from './archive';
import type { DiskAccount } from './disk';
import { config, dirs } from './config';

export interface InstallContext { dir: string; spec: AgentServerSpec; disk: DiskAccount; log: (line: string) => void; javaPath: string | null; }
export interface InstallResult { variables?: Record<string, string>; resolvedVersion?: string; resolvedBuild?: string; }

const FILL = 'https://fill.papermc.io/v3/projects';
const pct = (log: (s: string) => void) => { let last = -1; return (d: number, t: number) => { const p = t ? Math.floor(d / t * 100) : -1; if (p !== last && p % 10 === 0) { last = p; log(`  download ${p}% (${(d / 1048576).toFixed(1)} MB)`); } }; };

async function paperFamily(project: string, ver: string, build: string, ctx: InstallContext, jar: string): Promise<InstallResult> {
  let version = ver;
  if (version === 'latest') {
    const vs = await fetchJson<any>(`${FILL}/${project}/versions`);
    const list = (vs.versions || []).filter((x: any) => (x.builds || []).length);
    const stable = list.find((x: any) => !/pre|rc|snapshot/i.test(x.version.id) && x.version.support?.status !== 'UNSUPPORTED') || list[0];
    if (!stable) throw new Error(`No versions available for ${project}`);
    version = stable.version.id;
  }
  const b = await fetchJson<any>(`${FILL}/${project}/versions/${encodeURIComponent(version)}/builds/${build === 'latest' ? 'latest' : encodeURIComponent(build)}`);
  const dl = b.downloads?.['server:default']; if (!dl) throw new Error('Build has no server download');
  ctx.log(`Downloading ${dl.name} (${project} ${version} build ${b.id})`);
  await downloadTo(dl.url, path.join(ctx.dir, jar), { disk: ctx.disk, hash: { algo: 'sha256', value: dl.checksums.sha256 }, onProgress: pct(ctx.log) });
  return { resolvedVersion: version, resolvedBuild: String(b.id) };
}

function runJava(ctx: InstallContext, args: string[], timeoutMs = 30 * 60_000): Promise<void> {
  if (!ctx.javaPath) throw new Error('No Java executable selected for this server (needed by the official installer)');
  return runProc(ctx, ctx.javaPath, args, timeoutMs);
}
function runProc(ctx: InstallContext, cmd: string, args: string[], timeoutMs: number, extraEnv: Record<string, string> = {}): Promise<void> {
  return new Promise((res, rej) => {
    ctx.log(`$ ${path.basename(cmd)} ${args.join(' ')}`);
    const p = spawn(cmd, args, { cwd: ctx.dir, env: { PATH: process.env.PATH || '/usr/bin:/bin', HOME: ctx.dir, LANG: 'C.UTF-8', ...extraEnv }, stdio: ['ignore', 'pipe', 'pipe'] });
    const t = setTimeout(() => { p.kill('SIGKILL'); rej(new Error('Installer timed out')); }, timeoutMs);
    const onData = (d: Buffer) => d.toString().split(/\r?\n/).filter(Boolean).forEach(l => ctx.log(l));
    p.stdout.on('data', onData); p.stderr.on('data', onData);
    p.on('error', (e) => { clearTimeout(t); rej(e); });
    p.on('close', (code) => { clearTimeout(t); code === 0 ? res() : rej(new Error(`Installer exited with code ${code}`)); });
  });
}

export async function latestVanilla(): Promise<string> { return (await fetchJson<any>('https://piston-meta.mojang.com/mc/game/version_manifest_v2.json')).latest.release; }

export async function runInstaller(ctx: InstallContext): Promise<InstallResult> {
  const { spec } = ctx; const egg = spec.egg; const V = spec.variables; const jar = V.SERVER_JAR || 'server.jar';
  await fs.promises.mkdir(ctx.dir, { recursive: true });
  ctx.log(`[OGHOST] Installing ${egg.name} using native installer "${egg.installer}"`);
  let result: InstallResult = {};
  switch (egg.installer) {
    case 'vanilla': {
      const m = await fetchJson<any>('https://piston-meta.mojang.com/mc/game/version_manifest_v2.json');
      const ver = V.MC_VERSION === 'latest' ? m.latest.release : V.MC_VERSION;
      const entry = m.versions.find((x: any) => x.id === ver); if (!entry) throw new Error(`Unknown Minecraft version ${ver}`);
      const vj = await fetchJson<any>(entry.url); const s = vj.downloads?.server; if (!s) throw new Error(`Version ${ver} has no official server download`);
      ctx.log(`Downloading Mojang server ${ver}`);
      await downloadTo(s.url, path.join(ctx.dir, jar), { disk: ctx.disk, hash: { algo: 'sha1', value: s.sha1 }, onProgress: pct(ctx.log) });
      result = { resolvedVersion: ver }; break;
    }
    case 'paper': case 'folia': case 'velocity': case 'waterfall':
      result = await paperFamily(egg.installer, V.MC_VERSION || 'latest', V.BUILD || 'latest', ctx, jar); break;
    case 'purpur': {
      const ver = V.MC_VERSION === 'latest' ? (await fetchJson<any>('https://api.purpurmc.org/v2/purpur')).metadata.current : V.MC_VERSION;
      const info = await fetchJson<any>(`https://api.purpurmc.org/v2/purpur/${ver}/${V.BUILD || 'latest'}`);
      ctx.log(`Downloading Purpur ${ver} build ${info.build}`);
      await downloadTo(`https://api.purpurmc.org/v2/purpur/${ver}/${info.build}/download`, path.join(ctx.dir, jar), { disk: ctx.disk, hash: info.md5 ? { algo: 'md5', value: info.md5 } : undefined, onProgress: pct(ctx.log) });
      result = { resolvedVersion: ver, resolvedBuild: String(info.build) }; break;
    }
    case 'pufferfish': {
      const ver = V.MC_VERSION === 'latest' ? '1.21' : V.MC_VERSION.split('.').slice(0, 2).join('.');
      const job = `https://ci.pufferfish.host/job/Pufferfish-${ver}/${V.BUILD && V.BUILD !== 'latest' ? V.BUILD : 'lastSuccessfulBuild'}`;
      const b = await fetchJson<any>(`${job}/api/json`); const art = (b.artifacts || []).find((a: any) => /\.jar$/.test(a.fileName) && !/sources|javadoc/.test(a.fileName));
      if (!art) throw new Error('No Pufferfish artifact found'); ctx.log(`Downloading ${art.fileName}`);
      await downloadTo(`${job}/artifact/${art.relativePath}`, path.join(ctx.dir, jar), { disk: ctx.disk, onProgress: pct(ctx.log) });
      result = { resolvedVersion: ver, resolvedBuild: String(b.number) }; break;
    }
    case 'bungeecord':
      ctx.log('Downloading BungeeCord (ci.md-5.net lastSuccessfulBuild)');
      await downloadTo('https://ci.md-5.net/job/BungeeCord/lastSuccessfulBuild/artifact/bootstrap/target/BungeeCord.jar', path.join(ctx.dir, jar), { disk: ctx.disk, onProgress: pct(ctx.log) }); break;
    case 'fabric': {
      const mc = V.MC_VERSION === 'latest' ? (await fetchJson<any[]>('https://meta.fabricmc.net/v2/versions/game')).find(g => g.stable).version : V.MC_VERSION;
      const loader = V.LOADER_VERSION && V.LOADER_VERSION !== 'latest' ? V.LOADER_VERSION : (await fetchJson<any[]>(`https://meta.fabricmc.net/v2/versions/loader/${mc}`))[0].loader.version;
      const inst = (await fetchJson<any[]>('https://meta.fabricmc.net/v2/versions/installer')).find(i => i.stable).version;
      ctx.log(`Downloading Fabric server launcher (MC ${mc}, loader ${loader}, installer ${inst})`);
      await downloadTo(`https://meta.fabricmc.net/v2/versions/loader/${mc}/${loader}/${inst}/server/jar`, path.join(ctx.dir, jar), { disk: ctx.disk, onProgress: pct(ctx.log) });
      result = { resolvedVersion: mc, resolvedBuild: loader }; break;
    }
    case 'quilt': {
      const mc = V.MC_VERSION === 'latest' ? await latestVanilla() : V.MC_VERSION;
      const meta = await fetchJson<any>('https://maven.quiltmc.org/repository/release/org/quiltmc/quilt-installer/maven-metadata.xml').catch(() => null);
      void meta;
      const xml = await (await fetch('https://maven.quiltmc.org/repository/release/org/quiltmc/quilt-installer/maven-metadata.xml')).text();
      const iv = xml.match(/<release>([^<]+)<\/release>/)?.[1]; if (!iv) throw new Error('Cannot resolve Quilt installer version');
      const instJar = path.join(ctx.dir, '.oghost-quilt-installer.jar');
      await downloadTo(`https://maven.quiltmc.org/repository/release/org/quiltmc/quilt-installer/${iv}/quilt-installer-${iv}.jar`, instJar, { disk: ctx.disk });
      const args = ['-jar', instJar, 'install', 'server', mc]; if (V.LOADER_VERSION && V.LOADER_VERSION !== 'latest') args.push(V.LOADER_VERSION);
      await runJava(ctx, [...args, '--download-server', '--install-dir=.']); await fs.promises.rm(instJar, { force: true });
      result = { resolvedVersion: mc }; break;
    }
    case 'forge': {
      const promos = await fetchJson<any>('https://files.minecraftforge.net/net/minecraftforge/forge/promotions_slim.json');
      const mc = V.MC_VERSION === 'latest' ? await latestVanilla() : V.MC_VERSION;
      const fv = /^\d/.test(V.FORGE_VERSION || '') ? V.FORGE_VERSION : (promos.promos[`${mc}-${V.FORGE_VERSION === 'latest' ? 'latest' : 'recommended'}`] || promos.promos[`${mc}-latest`]);
      if (!fv) throw new Error(`No Forge build for Minecraft ${mc}`);
      const full = `${mc}-${fv}`; const inst = path.join(ctx.dir, '.oghost-forge-installer.jar');
      ctx.log(`Downloading Forge installer ${full}`);
      await downloadTo(`https://maven.minecraftforge.net/net/minecraftforge/forge/${full}/forge-${full}-installer.jar`, inst, { disk: ctx.disk, onProgress: pct(ctx.log) });
      await runJava(ctx, ['-jar', inst, '--installServer']); await fs.promises.rm(inst, { force: true }); await fs.promises.rm(inst + '.log', { force: true });
      const argsFile = `libraries/net/minecraftforge/forge/${full}/unix_args.txt`;
      let FORGE_ARGS: string;
      if (fs.existsSync(path.join(ctx.dir, argsFile))) { if (!fs.existsSync(path.join(ctx.dir, 'user_jvm_args.txt'))) fs.writeFileSync(path.join(ctx.dir, 'user_jvm_args.txt'), ''); FORGE_ARGS = `@user_jvm_args.txt @${argsFile}`; }
      else { const j = fs.readdirSync(ctx.dir).find(f => /^forge-.*\.jar$/.test(f) && !/installer/.test(f)) || fs.readdirSync(ctx.dir).find(f => /^minecraft_server.*\.jar$/.test(f)); if (!j) throw new Error('Forge installer did not produce a launch target'); FORGE_ARGS = `-jar ${j}`; }
      result = { resolvedVersion: mc, resolvedBuild: fv, variables: { FORGE_ARGS } }; break;
    }
    case 'neoforge': {
      const all = (await fetchJson<any>('https://maven.neoforged.net/api/maven/versions/releases/net/neoforged/neoforge')).versions as string[];
      let nv = V.NEOFORGE_VERSION;
      if (!nv || nv === 'latest') {
        const mc = V.MC_VERSION === 'latest' ? null : V.MC_VERSION;
        const prefix = mc ? (mc.startsWith('1.') ? (mc.split('.').length === 2 ? `${mc.split('.')[1]}.0.` : `${mc.split('.')[1]}.${mc.split('.')[2]}.`) : `${mc}.`) : '';
        const cands = all.filter(x => x.startsWith(prefix) && !/beta|alpha/.test(x)); nv = (cands.length ? cands : all.filter(x => x.startsWith(prefix))).at(-1)!;
        if (!nv) throw new Error(`No NeoForge release for Minecraft ${V.MC_VERSION}`);
      }
      const inst = path.join(ctx.dir, '.oghost-neoforge-installer.jar'); ctx.log(`Downloading NeoForge installer ${nv}`);
      await downloadTo(`https://maven.neoforged.net/releases/net/neoforged/neoforge/${nv}/neoforge-${nv}-installer.jar`, inst, { disk: ctx.disk, onProgress: pct(ctx.log) });
      await runJava(ctx, ['-jar', inst, '--installServer']); await fs.promises.rm(inst, { force: true }); await fs.promises.rm(inst + '.log', { force: true });
      if (!fs.existsSync(path.join(ctx.dir, 'user_jvm_args.txt'))) fs.writeFileSync(path.join(ctx.dir, 'user_jvm_args.txt'), '');
      result = { resolvedBuild: nv, variables: { FORGE_ARGS: `@user_jvm_args.txt @libraries/net/neoforged/neoforge/${nv}/unix_args.txt`, NEOFORGE_VERSION: nv } }; break;
    }
    case 'spigot': {
      const mc = V.MC_VERSION === 'latest' ? 'latest' : V.MC_VERSION;
      const bt = path.join(ctx.dir, '.oghost-buildtools', 'BuildTools.jar');
      ctx.log('Downloading official SpigotMC BuildTools');
      await downloadTo('https://hub.spigotmc.org/jenkins/job/BuildTools/lastSuccessfulBuild/artifact/target/BuildTools.jar', bt, { disk: ctx.disk });
      const target = V.BUILDTOOLS_TARGET === 'craftbukkit' ? ['--compile', 'craftbukkit'] : [];
      const prevDir = ctx.dir; ctx.dir = path.dirname(bt);
      try { await runJava(ctx, ['-Xmx1500M', '-jar', bt, '--rev', mc, ...target, '--output-dir', prevDir], 60 * 60_000); } finally { ctx.dir = prevDir; }
      const built = fs.readdirSync(ctx.dir).find(f => /^(spigot|craftbukkit)-.*\.jar$/.test(f)); if (!built) throw new Error('BuildTools did not produce a server JAR');
      await fs.promises.rename(path.join(ctx.dir, built), path.join(ctx.dir, jar)); await fs.promises.rm(path.dirname(bt), { recursive: true, force: true });
      result = { resolvedVersion: mc }; break;
    }
    case 'bedrock': {
      if (os.arch() !== 'x64') throw new Error(`Bedrock Dedicated Server only ships x86_64 Linux binaries; this node is ${os.arch()}`);
      const links = await fetchJson<any>('https://net-secondary.web.minecraft-services.net/api/v1.0/download/links');
      let url = links.result.links.find((l: any) => l.downloadType === 'serverBedrockLinux')?.downloadUrl as string;
      if (V.BEDROCK_VERSION && V.BEDROCK_VERSION !== 'latest') url = url.replace(/bedrock-server-[\d.]+\.zip/, `bedrock-server-${V.BEDROCK_VERSION}.zip`);
      const zip = path.join(ctx.dir, '.oghost-bedrock.zip'); ctx.log(`Downloading ${path.basename(url)}`);
      await downloadTo(url, zip, { disk: ctx.disk, onProgress: pct(ctx.log) });
      const keep = ['server.properties', 'permissions.json', 'allowlist.json'].filter(f => fs.existsSync(path.join(ctx.dir, f)));
      for (const f of keep) fs.copyFileSync(path.join(ctx.dir, f), path.join(ctx.dir, f + '.oghost-keep'));
      await extractZip(ctx.dir, zip, '/', ctx.disk.available());
      for (const f of keep) fs.renameSync(path.join(ctx.dir, f + '.oghost-keep'), path.join(ctx.dir, f));
      await fs.promises.rm(zip, { force: true }); fs.chmodSync(path.join(ctx.dir, 'bedrock_server'), 0o750);
      result = { resolvedVersion: url.match(/bedrock-server-([\d.]+)\.zip/)?.[1] }; break;
    }
    case 'pocketmine': {
      const rel = await fetchJson<any>(V.PMMP_VERSION && V.PMMP_VERSION !== 'latest' ? `https://api.github.com/repos/pmmp/PocketMine-MP/releases/tags/${V.PMMP_VERSION}` : 'https://api.github.com/repos/pmmp/PocketMine-MP/releases/latest');
      const a = rel.assets.find((x: any) => x.name === 'PocketMine-MP.phar'); if (!a) throw new Error('Release has no PocketMine-MP.phar');
      await downloadTo(a.browser_download_url, path.join(ctx.dir, 'PocketMine-MP.phar'), { disk: ctx.disk, onProgress: pct(ctx.log) });
      ctx.log('NOTE: PocketMine requires a pmmp PHP binary. The administrator must provide it at PHP_BINARY.');
      result = { resolvedVersion: rel.tag_name }; break;
    }
    case 'custom': ctx.log(`Custom software: upload your server JAR as ${jar}. It will be security-scanned before the first start.`); break;
    case 'none': break;
  }
  if ((egg as any).installScript) {
    // Admin-authored egg install scripts only (customers cannot edit eggs). Runs as the server user, clean env, no panel secrets.
    const script = path.join(ctx.dir, '.oghost-install.sh'); fs.writeFileSync(script, String((egg as any).installScript), { mode: 0o700 });
    try { await runProc(ctx, '/bin/bash', [script], 30 * 60_000, Object.fromEntries(Object.entries(spec.variables).map(([k, v]) => [k, String(v)]))); } finally { fs.rmSync(script, { force: true }); }
  }
  if (spec.egg.runtime === 'java' && !fs.existsSync(path.join(ctx.dir, 'eula.txt'))) fs.writeFileSync(path.join(ctx.dir, 'eula.txt'), '# Set to true to accept https://aka.ms/MinecraftEULA\neula=false\n');
  await recordProvenance(ctx, jar).catch(e => ctx.log(`[OGHOST] Could not record download provenance: ${e.message}`));
  ctx.log('[OGHOST] Installation finished.');
  void config;
  return result;
}

/** Records the SHA-256 of a server JAR fetched by a native installer from its official, checksum-verified source.
 * Stored in node metadata (outside the customer-writable server directory) so it cannot be forged by the customer.
 * The pre-start scan still runs; provenance only lets official builds pass medium-severity heuristic findings. */
export const provenanceFile = (serverId: number) => path.join(dirs.metadata, 'provenance', `${serverId}.json`);
async function recordProvenance(ctx: InstallContext, jar: string) {
  const f = provenanceFile(ctx.spec.id); fs.mkdirSync(path.dirname(f), { recursive: true, mode: 0o700 });
  const abs = path.join(ctx.dir, jar);
  if (['custom', 'none'].includes(ctx.spec.egg.installer) || !fs.existsSync(abs)) { fs.rmSync(f, { force: true }); return; }
  fs.writeFileSync(f, JSON.stringify({ sha256: await hashFile(abs), installer: ctx.spec.egg.installer, file: jar, at: new Date().toISOString() }), { mode: 0o600 });
}
