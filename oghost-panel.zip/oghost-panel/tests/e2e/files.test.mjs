// File manager security: traversal, symlinks in archives, server-side disk enforcement.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { ZipArchive } from 'archiver';
import { skip, admin, mkServer, rmServer } from './common.mjs';
const bin = { headers: { 'content-type': 'application/octet-stream' } };

test('file API blocks traversal, ignores archive symlinks and enforces disk limits', { skip }, async () => {
  const c = await admin(); const a = await mkServer(c, 'e2e files A', { diskMb: 256 }); const b = await mkServer(c, 'e2e files B');
  try {
    const A = `/api/servers/${a.id}/files`;
    await c.post(`${A}/write?path=hello.txt`, Buffer.from('hi'), bin);
    assert.equal(await c.get(`${A}/contents?path=hello.txt`), 'hi');
    for (const p of ['../../../../etc/passwd', `../${b.nodeServerId}/hello.txt`, '/../x', 'a/../../x']) {
      const r = await c.get(`${A}/contents?path=${encodeURIComponent(p)}`, { allowError: true });
      assert.ok(r.status === 400 || r.status === 403 || r.status === 404, `${p} -> ${r.status}`);
      assert.ok(!String(JSON.stringify(r.data)).includes('root:x:0:0'));
    }
    const w = await c.call('POST', `${A}/write?path=${encodeURIComponent('../escape.txt')}`, Buffer.from('x'), { ...bin, allowError: true });
    assert.ok(w.status >= 400, 'write outside the server folder refused');

    // zip containing a symlink to / and a normal file
    const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'e2e-zip-')); const zf = path.join(tmp, 'x.zip');
    await new Promise((res, rej) => { const z = new ZipArchive(); const o = fs.createWriteStream(zf); o.on('close', res); z.on('error', rej); z.pipe(o); z.symlink('rootlink', '/', 0o777); z.append('ok', { name: 'inner/ok.txt' }); z.finalize(); });
    await c.post(`${A}/write?path=x.zip`, fs.readFileSync(zf), bin);
    await c.post(`${A}/extract`, { file: 'x.zip', destination: '/' });
    const list = await c.get(`${A}/list?directory=/`);
    assert.ok(!list.entries.some(f => f.name === 'rootlink'), 'symlink entries are not extracted');
    assert.equal(await c.get(`${A}/contents?path=inner/ok.txt`), 'ok');

    // 256 MB allocation. Declared oversize upload is refused before any byte is stored:
    const MB = 1024 * 1024;
    const pre = await c.call('PUT', `${A}/upload?directory=/&name=huge.bin`, Buffer.alloc(1), { headers: { 'content-type': 'application/octet-stream', 'x-file-size': String(300 * MB) }, allowError: true });
    assert.ok(pre.status === 507 || pre.status === 413, `declared 300 MB upload -> ${pre.status}`);
    // fill 230 MB, then a 40 MB write must be refused by the agent (never by the client)
    const chunk = Buffer.alloc(230 * MB);
    const fill = await c.call('PUT', `${A}/upload?directory=/&name=fill.bin`, chunk, { headers: { 'content-type': 'application/octet-stream', 'x-file-size': String(chunk.length) }, allowError: true });
    assert.ok(fill.status < 300, `fill upload -> ${fill.status} ${JSON.stringify(fill.data)}`);
    const big = await c.call('POST', `${A}/write?path=big.bin`, chunk.subarray(0, 40 * MB), { ...bin, allowError: true });
    assert.ok(big.status === 507 || big.status === 413, `oversized write -> ${big.status} ${JSON.stringify(big.data).slice(0, 200)}`);
    const small = await c.call('POST', `${A}/write?path=small.bin`, Buffer.alloc(MB), bin);
    assert.ok(small.ok, 'writes that fit are still accepted');
  } finally { await rmServer(c, a); await rmServer(c, b); }
});
