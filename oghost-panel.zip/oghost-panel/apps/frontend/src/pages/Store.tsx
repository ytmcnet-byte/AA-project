import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Cpu, HardDrive, MemoryStick, Database, Archive, Network, Check, Coins } from 'lucide-react';
import { useApi, useAction, toast } from '../lib/hooks';
import { post } from '../lib/api';
import { useAuth } from '../lib/auth';
import { mb, money, cls } from '../lib/format';
import { Card, ErrorBox, Field, Loading, Modal, Notice, PageHeader, Spinner, Empty } from '../components/ui';

const coinOnly = (pl: any) => pl.coin_price != null && pl.price_cents === 0 && !pl.setup_fee_cents;
const CYCLE: Record<string, string> = { monthly: '/mo', quarterly: '/quarter', semiannual: '/6 mo', annual: '/yr', one_time: ' one-time' };

export function Store() {
  const { data, error, loading } = useApi<any>('/api/store/catalog');
  const { user } = useAuth();
  const [cat, setCat] = useState<number | null>(null);
  const [plan, setPlan] = useState<any>(null);
  const products = useMemo(() => (data?.products || []).filter((p: any) => !cat || p.category_id === cat), [data, cat]);
  if (loading) return <Loading />;
  if (error) return <ErrorBox error={error} />;
  if (!data.enabled) return <><PageHeader title="Store" /><Notice kind="warn">The store is currently disabled.</Notice></>;
  return (
    <>
      <PageHeader title="Store" subtitle="Choose a plan. Your server is created automatically once payment is confirmed by the gateway or approved by an administrator." />
      {data.categories.length > 1 && <div className="mb-5 flex flex-wrap gap-2"><button className={cls('btn-sm', !cat ? 'btn-primary' : 'btn-secondary')} onClick={() => setCat(null)}>All</button>{data.categories.map((c: any) => <button key={c.id} className={cls('btn-sm', cat === c.id ? 'btn-primary' : 'btn-secondary')} onClick={() => setCat(c.id)}>{c.name}</button>)}</div>}
      {!products.length && <div className="card"><Empty title="No products available" /></div>}
      {products.map((p: any) => {
        const plans = data.plans.filter((x: any) => x.product_id === p.id);
        return (
          <section key={p.id} className="mb-8">
            <h2 className="text-lg font-bold text-white">{p.name}</h2>{p.description && <p className="mt-1 text-sm text-ink-400">{p.description}</p>}
            <div className="mt-4 grid gap-4 md:grid-cols-2 xl:grid-cols-3">{plans.map((pl: any, i: number) => (
              <div key={pl.id} className={cls('card relative flex flex-col p-5', i === 1 && 'border-brand-700/80 shadow-[0_0_40px_-12px_rgba(220,38,38,0.5)]')}>
                {i === 1 && <span className="absolute -top-2.5 right-4 rounded-full bg-brand-600 px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wider text-white">Popular</span>}
                <div className="text-sm font-extrabold uppercase tracking-widest text-brand-400">{pl.name}</div>
                {coinOnly(pl) ? <div className="mt-2 flex items-center gap-2 text-3xl font-extrabold text-amber-200"><Coins className="h-6 w-6" />{pl.coin_price.toLocaleString()}<span className="text-sm font-medium text-ink-400">{data.coins.name}{CYCLE[pl.billing_cycle]}</span></div>
                  : <div className="mt-2 text-3xl font-extrabold text-white">{money(pl.price_cents, pl.currency)}<span className="text-sm font-medium text-ink-400">{CYCLE[pl.billing_cycle]}</span></div>}
                {!coinOnly(pl) && data.coins.enabled && pl.coin_price != null && <div className="mt-1 flex items-center gap-1.5 text-sm font-semibold text-amber-200"><Coins className="h-4 w-4" />or {pl.coin_price.toLocaleString()} {data.coins.name}{CYCLE[pl.billing_cycle]}</div>}
                {pl.max_per_user && <div className="text-xs text-ink-400">Limit: {pl.max_per_user} per account</div>}
                {pl.setup_fee_cents > 0 && <div className="text-xs text-ink-400">+ {money(pl.setup_fee_cents, pl.currency)} setup</div>}
                {pl.description && <p className="mt-2 text-sm text-ink-400">{pl.description}</p>}
                <ul className="mt-4 flex-1 space-y-2 text-sm text-ink-300">
                  <li className="flex items-center gap-2"><MemoryStick className="h-4 w-4 text-brand-500" />{mb(pl.memory_mb)} RAM</li>
                  <li className="flex items-center gap-2"><Cpu className="h-4 w-4 text-brand-500" />{pl.cpu_percent ? `${pl.cpu_percent / 100} CPU core${pl.cpu_percent > 100 ? 's' : ''} (best-effort limit)` : 'Shared CPU'}</li>
                  <li className="flex items-center gap-2"><HardDrive className="h-4 w-4 text-brand-500" />{mb(pl.disk_mb)} disk</li>
                  <li className="flex items-center gap-2"><Database className="h-4 w-4 text-brand-500" />{pl.databases} database{pl.databases === 1 ? '' : 's'}</li>
                  <li className="flex items-center gap-2"><Archive className="h-4 w-4 text-brand-500" />{pl.backups} backup slot{pl.backups === 1 ? '' : 's'} + Google Drive backups</li>
                  <li className="flex items-center gap-2"><Network className="h-4 w-4 text-brand-500" />{pl.allocations} port{pl.allocations === 1 ? '' : 's'}</li>
                </ul>
                {pl.stock === 0 ? <button className="btn-secondary mt-5" disabled>Out of stock</button> : <button className="btn-primary mt-5" onClick={() => user ? setPlan(pl) : (window.location.href = '/login')}>Order {pl.name}</button>}
              </div>))}</div>
          </section>
        );
      })}
      <CheckoutModal key={plan?.id ?? 0} plan={plan} catalog={data} onClose={() => setPlan(null)} />
    </>
  );
}

function CheckoutModal({ plan, catalog, onClose }: { plan: any; catalog: any; onClose: () => void }) {
  const nav = useNavigate(); const { busy, run } = useAction(); const { user } = useAuth();
  const [name, setName] = useState('My Server'); const [eggId, setEggId] = useState<number | ''>(''); const [loc, setLoc] = useState<number | ''>(''); const [coupon, setCoupon] = useState(''); const [quote, setQuote] = useState<any>(null); const [payWith, setPayWith] = useState<'money' | 'ogcoins' | null>(null);
  const wallet = useApi<any>(plan && catalog.coins.enabled && plan.coin_price != null ? '/api/coins/balance' : null, [plan?.id]);
  if (!plan) return null;
  const canCoins = catalog.coins.enabled && plan.coin_price != null; const method = payWith ?? (coinOnly(plan) ? 'ogcoins' : 'money'); const cn = catalog.coins.name;
  const bal = wallet.data?.balance ?? null; const short = method === 'ogcoins' && bal != null && bal < plan.coin_price;
  const eggs = catalog.eggs.filter((e: any) => !plan.egg_id || true);
  const apply = () => run('coupon', async () => setQuote(await post('/api/store/coupon', { code: coupon, planId: plan.id })));
  const order = () => run('order', async () => { const r = await post('/api/store/checkout', { planId: plan.id, serverName: name, eggId: eggId || undefined, locationId: loc || undefined, coupon: method === 'money' && quote ? coupon : undefined, payWith: method }); onClose(); if (r.paidWithCoins) { toast(`Paid with ${cn}. Your server is being created.`, 'success'); window.dispatchEvent(new Event('oghost:coins')); nav('/billing'); } else nav(`/billing/invoices/${r.invoiceId}`); });
  const subtotal = plan.price_cents + plan.setup_fee_cents;
  return (
    <Modal open onClose={onClose} title={`Order ${plan.name}`} footer={<><button className="btn-secondary" onClick={onClose}>Cancel</button><button className="btn-primary" disabled={!!busy || !name.trim() || !user?.email_verified || short} onClick={order}>{busy === 'order' && <Spinner />}{method === 'ogcoins' ? `Pay ${plan.coin_price.toLocaleString()} ${cn}` : 'Place order'}</button></>}>
      <div className="space-y-4">
        {!user?.email_verified && <Notice kind="warn">Verify your email address before ordering.</Notice>}
        <Field label="Server name" hint="Names can repeat — servers are stored by numeric ID."><input className="input" value={name} onChange={e => setName(e.target.value)} maxLength={100} /></Field>
        <Field label="Server software" hint={plan.egg_id ? 'Default set by the plan; you can change it later in Settings → Version.' : undefined}><select className="input" value={eggId || plan.egg_id || ''} onChange={e => setEggId(Number(e.target.value) || '')}>{!plan.egg_id && <option value="">Choose…</option>}{eggs.map((e: any) => <option key={e.id} value={e.id}>{e.name}</option>)}</select></Field>
        {catalog.locations.length > 1 && !plan.location_id && <Field label="Location"><select className="input" value={loc} onChange={e => setLoc(Number(e.target.value) || '')}><option value="">Any available</option>{catalog.locations.map((l: any) => <option key={l.id} value={l.id} disabled={!l.online_nodes}>{l.name}{!l.online_nodes ? ' (unavailable)' : ''}</option>)}</select></Field>}
        {canCoins && !coinOnly(plan) && <Field label="Pay with"><div className="grid grid-cols-2 gap-2">{(['money', 'ogcoins'] as const).map(m => <button key={m} type="button" className={cls('rounded-lg border px-3 py-2 text-left text-sm', method === m ? 'border-brand-600 bg-brand-600/10 text-white' : 'border-ink-700 text-ink-300 hover:border-ink-500')} onClick={() => setPayWith(m)}><div className="font-semibold">{m === 'money' ? 'Money' : cn}</div><div className="text-xs text-ink-400">{m === 'money' ? money(subtotal, plan.currency) : `${plan.coin_price.toLocaleString()} ${cn}`}</div></button>)}</div></Field>}
        {method === 'ogcoins' && <div className="rounded-lg border border-amber-800/50 bg-amber-950/20 p-3 text-sm"><div className="flex justify-between"><span className="text-ink-400">Your balance</span><span className="font-semibold text-amber-200">{bal == null ? '…' : `${bal.toLocaleString()} ${cn}`}</span></div><div className="flex justify-between"><span className="text-ink-400">Price{CYCLE[plan.billing_cycle]}</span><span className="font-semibold">{plan.coin_price.toLocaleString()} {cn}</span></div>{short && <div className="mt-2 text-amber-300">You need {(plan.coin_price - bal!).toLocaleString()} more {cn}. <a className="link" href="/coins">Get {cn}</a></div>}</div>}
        {method === 'money' && <><Field label="Coupon"><div className="flex gap-2"><input className="input" value={coupon} onChange={e => { setCoupon(e.target.value); setQuote(null); }} placeholder="Optional" /><button className="btn-secondary" disabled={!coupon || busy === 'coupon'} onClick={apply}>Apply</button></div></Field>
        <div className="rounded-lg border border-ink-700 bg-ink-850 p-3 text-sm">
          <div className="flex justify-between"><span className="text-ink-400">Subtotal</span><span>{money(subtotal, plan.currency)}</span></div>
          {quote && <div className="flex justify-between text-emerald-400"><span className="flex items-center gap-1"><Check className="h-3.5 w-3.5" />{quote.code}</span><span>-{money(quote.discount, plan.currency)}</span></div>}
          <div className="mt-1 flex justify-between border-t border-ink-700 pt-1 font-bold text-white"><span>Total due now</span><span>{money(quote ? quote.total : subtotal, plan.currency)}</span></div>
        </div>
        </>}
        <p className="hint">{method === 'ogcoins' ? `${cn} are deducted immediately and the server is created automatically. Renewals can also be paid with ${cn}.` : 'An invoice is created; choose a payment method on the next page.'}</p>
      </div>
    </Modal>
  );
}
