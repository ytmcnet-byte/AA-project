import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { ZipArchive } from 'archiver';
import yauzl from 'yauzl';
import { safeResolve } from '@oghost/shared';

export interface ArchiveProgress { (done: number, total: number): void }

/** Stream a set of paths (relative to root) into a zip file. Never loads files fully into RAM. */
export async function createZip(root: string, relPaths: string[], outFile: string, opts: { exclude?: RegExp; onProgress?: ArchiveProgress; maxBytes?: number } = {}) {
  await fs.promises.mkdir(path.dirname(outFile), { recursive: true });
  const out = fs.createWriteStream(outFile);
  const zip = new ZipArchive({ zlib: { level: 6 } });
  const hash = crypto.createHash('md5'); let written = 0;
  const done = new Promise<{ size: number; md5: string }>((res, rej) => {
    out.on('close', () => res({ size: written, md5: hash.digest('hex') }));
    zip.on('error', rej); out.on('error', rej);
  });
  zip.on('data', (d: Buffer) => { written += d.length; hash.update(d); if (opts.maxBytes && written > opts.maxBytes) zip.abort(); });
  zip.on('progress', (p: any) => opts.onProgress?.(p.fs.processedBytes, p.fs.totalBytes));
  zip.pipe(out);
  for (const rel of relPaths) {
    const abs = safeResolve(root, rel);
    const st = await fs.promises.lstat(abs);
    const name = path.relative(root, abs) || path.basename(abs);
    if (st.isSymbolicLink()) continue;
    if (st.isDirectory()) zip.glob('**/*', { cwd: abs, dot: true, follow: false, ignore: opts.exclude ? [] : [] }, { prefix: name === '.' || abs === fs.realpathSync(root) ? '' : name });
    else zip.file(abs, { name });
  }
  await zip.finalize();
  const r = await done;
  if (opts.maxBytes && written > opts.maxBytes) { await fs.promises.rm(outFile, { force: true }); const e: any = new Error('Archive exceeds the available storage allocation'); e.status = 507; throw e; }
  return r;
}

function open(file: string): Promise<yauzl.ZipFile> {
  return new Promise((res, rej) => yauzl.open(file, { lazyEntries: true, autoClose: true, validateEntrySizes: true }, (e, z) => (e || !z ? rej(e) : res(z))));
}

/** Total declared uncompressed size, used to pre-check against the disk allocation. */
export async function zipDeclaredSize(file: string): Promise<{ bytes: number; entries: number }> {
  const z = await open(file); let bytes = 0, entries = 0;
  return new Promise((res, rej) => { z.on('entry', (e: yauzl.Entry) => { bytes += e.uncompressedSize; entries++; z.readEntry(); }); z.on('end', () => res({ bytes, entries })); z.on('error', rej); z.readEntry(); });
}

/**
 * Extract a zip into destDir (inside root). Enforces: path traversal checks per entry, no symlink
 * entries, entry-count limit, and a hard byte budget counted while streaming (zip-bomb safe even
 * if headers lie).
 */
export async function extractZip(root: string, file: string, destRel: string, budgetBytes: number, opts: { maxEntries?: number; onProgress?: ArchiveProgress } = {}) {
  const dest = safeResolve(root, destRel);
  await fs.promises.mkdir(dest, { recursive: true });
  const z = await open(file); let written = 0, entries = 0; const maxEntries = opts.maxEntries ?? 100_000;
  const declared = await zipDeclaredSize(file);
  return new Promise<{ bytes: number; entries: number }>((res, rej) => {
    const fail = (e: any) => { z.close(); rej(e); };
    z.on('entry', (e: yauzl.Entry) => {
      if (++entries > maxEntries) return fail(Object.assign(new Error('Archive has too many entries'), { status: 413 }));
      const mode = (e.externalFileAttributes >>> 16) & 0o170000;
      if (mode === 0o120000) return z.readEntry(); // skip symlinks
      let target: string;
      try { target = safeResolve(root, path.posix.join(destRel, e.fileName)); } catch (err) { return fail(err); }
      if (e.fileName.endsWith('/')) { fs.promises.mkdir(target, { recursive: true }).then(() => z.readEntry(), fail); return; }
      fs.promises.mkdir(path.dirname(target), { recursive: true }).then(() => {
        z.openReadStream(e, (err, s) => {
          if (err || !s) return fail(err);
          const w = fs.createWriteStream(target, { mode: 0o640 });
          s.on('data', (c: Buffer) => { written += c.length; opts.onProgress?.(written, declared.bytes); if (budgetBytes > 0 && written > budgetBytes) { s.destroy(); w.destroy(); fail(Object.assign(new Error('Extraction stopped: disk allocation would be exceeded'), { status: 507 })); } });
          s.pipe(w); w.on('finish', () => z.readEntry()); w.on('error', fail); s.on('error', fail);
        });
      }, fail);
    });
    z.on('end', () => res({ bytes: written, entries })); z.on('error', fail); z.readEntry();
  });
}
