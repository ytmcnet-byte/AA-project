import { Router } from 'express';
import { q, one, exec } from '../db';
import { body, z, HttpError, idParam } from '../lib/http';
import { requireAuth } from '../lib/auth';
import { serverAccess, assertWritable } from '../lib/access';
import { authUrl, handleCallback, disconnectDrive, getConfig, restoreDriveBackup, RETENTION_OPTIONS } from '../services/drive';
import { enqueue } from '../services/jobs';
import { getSetting } from '../services/settings';
import { getNode, agent } from '../services/nodes';
import { serverActivity } from '../services/audit';

export const driveRouter = Router();
driveRouter.use(requireAuth);
driveRouter.get('/status', async (req, res) => {
  const c: any = await one('SELECT google_email, status, last_error, created_at, scopes FROM drive_connections WHERE user_id = ?', [req.user!.id]);
  res.json({ configured: !!(await getSetting('google.clientId')) && !!(await getSetting('google.clientSecret')) && !!(await getSetting('drive.enabled')), connection: c, retentionOptions: RETENTION_OPTIONS });
});
driveRouter.post('/connect', async (req, res) => { const b = body(z.object({ returnTo: z.string().max(300).default('/account') }), req); res.json({ url: await authUrl(req.user!.id, b.returnTo) }); });
driveRouter.get('/callback', async (req, res) => {
  if (req.query.error) return res.redirect(`/account?drive=denied`);
  try { const back = await handleCallback(req.user!.id, String(req.query.state || ''), String(req.query.code || '')); res.redirect(`${back}${back.includes('?') ? '&' : '?'}drive=connected`); }
  catch (e: any) { res.redirect(`/account?drive=error&message=${encodeURIComponent(e.message)}`); }
});
driveRouter.post('/disconnect', async (req, res) => { await disconnectDrive(req.user!.id); res.json({ ok: true }); });

driveRouter.get('/servers/:id', async (req, res) => {
  const s = await serverAccess(req, 'backup.read'); const cfg = await getConfig(s.id);
  const conn: any = await one('SELECT google_email, status FROM drive_connections WHERE user_id = ?', [s.owner_id]);
  res.json({ config: { enabled: !!cfg.enabled, intervalMinutes: cfg.interval_minutes, retention: cfg.retention, retryCount: cfg.retry_count, retryDelayMinutes: cfg.retry_delay_minutes, running: !!cfg.running, lastSuccessAt: cfg.last_success_at, lastAttemptAt: cfg.last_attempt_at, nextRunAt: cfg.next_run_at, lastError: cfg.last_error, failuresInRow: cfg.failures_in_row },
    ownerConnection: conn ? { email: s.owner_id === req.user!.id ? conn.google_email : null, status: conn.status } : null, isOwner: s.owner_id === req.user!.id,
    backups: await q("SELECT id, name, size_bytes, md5, verified, status, trigger_type, error, created_at, completed_at FROM drive_backups WHERE server_id = ? AND status <> 'deleted' ORDER BY id DESC LIMIT 50", [s.id]) });
});
driveRouter.put('/servers/:id', async (req, res) => {
  const b = body(z.object({ enabled: z.boolean(), intervalMinutes: z.number().int().min(15).max(10080).default(60), retention: z.number().int().refine(v => RETENTION_OPTIONS.includes(v), 'Retention must be 1, 2, 3, 5 or 7'), retryCount: z.number().int().min(0).max(10).default(3), retryDelayMinutes: z.number().int().min(1).max(120).default(5) }), req);
  const s = await serverAccess(req, 'backup.create'); if (s.owner_id !== req.user!.id) throw new HttpError(403, 'Only the server owner can configure backups to their own Google Drive');
  if (b.retention > Number(await getSetting('drive.maxRetention') || 7)) throw new HttpError(422, 'Retention exceeds the administrator limit');
  if (b.enabled) { const c: any = await one("SELECT status FROM drive_connections WHERE user_id = ?", [req.user!.id]); if (!c || c.status === 'revoked') throw new HttpError(409, 'Connect Google Drive first'); }
  await getConfig(s.id);
  await exec('UPDATE drive_backup_configs SET enabled = ?, interval_minutes = ?, retention = ?, retry_count = ?, retry_delay_minutes = ?, failures_in_row = 0, next_run_at = IF(? = 1, COALESCE(IF(enabled = 1, next_run_at, NULL), DATE_ADD(NOW(), INTERVAL 2 MINUTE)), NULL) WHERE server_id = ?', [b.enabled ? 1 : 0, b.intervalMinutes, b.retention, b.retryCount, b.retryDelayMinutes, b.enabled ? 1 : 0, s.id]);
  await serverActivity(req, s.id, 'server.drive_backup.configured', b); res.json({ ok: true });
});
driveRouter.post('/servers/:id/run', async (req, res) => {
  const s = await serverAccess(req, 'backup.create'); assertWritable(s); if (s.owner_id !== req.user!.id) throw new HttpError(403, 'Only the server owner can back up to their Google Drive');
  const j = await enqueue('drive.backup', { serverId: s.id, trigger: 'manual' }, { uniqueKey: `drive:${s.id}`, maxAttempts: 1 }); if (!j) throw new HttpError(409, 'A Google Drive backup is already queued or running');
  res.status(202).json({ jobId: j });
});
driveRouter.post('/servers/:id/restore/:bid', async (req, res) => {
  body(z.object({ confirm: z.literal(true) }), req);
  const s = await serverAccess(req, 'backup.restore'); assertWritable(s); if (s.owner_id !== req.user!.id) throw new HttpError(403, 'Only the server owner can restore from their Google Drive');
  const st = await agent(await getNode(s.node_id), 'GET', `/api/servers/${s.node_server_id}`, undefined, { serverId: s.node_server_id }); if (!['offline', 'crashed'].includes(st.state)) throw new HttpError(409, 'Stop the server before restoring');
  res.json(await restoreDriveBackup(s.id, idParam(req, 'bid')));
});
