import crypto from 'node:crypto';
import type { PoolConnection } from 'mysql2/promise';
import { recommendedHeap, validateHeap, validateVariables, type AgentServerSpec, type EggDefinition } from '@oghost/shared';
import { q, one, exec, tx, txRetry, json, parse } from '../db';
import { getNode, agent, type NodeRow } from './nodes';
import { HttpError } from '../lib/http';
import { getSetting } from './settings';

export interface ServerRow { id: number; uuid: string; node_id: number; node_server_id: number; owner_id: number; name: string; description: string | null; egg_id: number; state: string; status_detail: string | null; memory_mb: number; cpu_percent: number; disk_mb: number; swap_mb: number; xms_mb: number; xmx_mb: number; java_path: string | null; startup: string; variables: any; database_limit: number; allocation_limit: number; backup_limit: number; backup_storage_mb: number; max_upload_mb: number; auto_restart: number; suspended_at: Date | null; suspended_until: Date | null; suspension_reason: string | null; security_level: string; security_blocked: number; installed_version: string | null; installed_build: string | null; deleting_at: Date | null; service_id: number | null; created_at: Date; }

export async function getServer(id: number): Promise<ServerRow> { const s = await one<ServerRow>('SELECT * FROM servers WHERE id = ?', [id]); if (!s) throw new HttpError(404, 'Server not found'); return s; }
export async function getEgg(id: number): Promise<{ id: number; slug: string; definition: EggDefinition }> { const e: any = await one('SELECT * FROM eggs WHERE id = ?', [id]); if (!e) throw new HttpError(404, 'Egg not found'); return { ...e, definition: parse(e.definition, {}) }; }

/**
 * Atomic per-node server ID allocation. The node row is locked FOR UPDATE so concurrent creations on
 * the same node serialise; the lowest free positive integer is chosen. Rows in state "deleting" still
 * occupy their ID, so an ID is only reusable after the node confirmed the directory is gone and the row
 * was removed. UNIQUE(node_id, node_server_id) is a second safety net.
 */
export async function allocateNodeServerId(conn: PoolConnection, nodeId: number): Promise<number> {
  await q('SELECT id FROM nodes WHERE id = ? FOR UPDATE', [nodeId], conn);
  const used = (await q<{ n: number }>('SELECT node_server_id AS n FROM servers WHERE node_id = ? UNION SELECT node_server_id FROM node_id_reservations WHERE node_id = ? ORDER BY n', [nodeId, nodeId], conn)).map(r => Number(r.n));
  let id = 1; for (const u of used) { if (u === id) id++; else if (u > id) break; }
  return id;
}

export async function nodeCapacity(node: NodeRow, conn?: PoolConnection) {
  const r: any = await one('SELECT COUNT(*) AS c, COALESCE(SUM(memory_mb),0) AS mem, COALESCE(SUM(disk_mb),0) AS disk, COALESCE(SUM(cpu_percent),0) AS cpu FROM servers WHERE node_id = ?', [node.id], conn as any);
  return { servers: Number(r.c), memory: Number(r.mem), disk: Number(r.disk), cpu: Number(r.cpu), memoryMax: node.memory_mb * (1 + node.memory_overalloc / 100), diskMax: node.disk_mb * (1 + node.disk_overalloc / 100) };
}

export interface CreateServerInput { name: string; description?: string; ownerId: number; nodeId: number; eggId: number; memoryMb: number; cpuPercent: number; diskMb: number; swapMb?: number; allocationId?: number; additionalAllocations?: number; databaseLimit?: number; allocationLimit?: number; backupLimit?: number; backupStorageMb?: number; variables?: Record<string, string>; javaPath?: string | null; xmsMb?: number; xmxMb?: number; startup?: string; serviceId?: number; skipInstall?: boolean; autoRestart?: boolean; }

export async function createServer(input: CreateServerInput) {
  const node = await getNode(input.nodeId);
  if (node.maintenance || node.emergency) throw new HttpError(409, `Node ${node.name} is in maintenance mode`);
  const egg = await getEgg(input.eggId);
  const variables = validateVariables(egg.definition, input.variables || {}, true);
  const heap = input.xmxMb ? { xmsMb: input.xmsMb || Math.min(input.xmxMb, 512), xmxMb: input.xmxMb } : recommendedHeap(input.memoryMb);
  if (egg.definition.runtime === 'java') validateHeap(input.memoryMb, heap.xmsMb, heap.xmxMb);
  const maxUpload = Number(await getSetting('uploads.maxMb')) || 1024;
  const created = await txRetry(async (c) => {
    // Lock the node row first: serialises creations per node so capacity, allocation and ID checks see committed state.
    await q('SELECT id FROM nodes WHERE id = ? FOR UPDATE', [node.id], c);
    const cap = await nodeCapacity(node, c);
    if (node.max_servers && cap.servers >= node.max_servers) throw new HttpError(409, `Node ${node.name} reached its server limit (${node.max_servers})`);
    if (cap.memory + input.memoryMb > cap.memoryMax) throw new HttpError(409, `Node ${node.name} does not have enough RAM (${cap.memoryMax - cap.memory} MB free)`);
    if (cap.disk + input.diskMb > cap.diskMax) throw new HttpError(409, `Node ${node.name} does not have enough disk (${cap.diskMax - cap.disk} MB free)`);
    let alloc: any;
    if (input.allocationId) { alloc = await one('SELECT * FROM allocations WHERE id = ? AND node_id = ? FOR UPDATE', [input.allocationId, node.id], c); if (!alloc || alloc.server_id) throw new HttpError(409, 'Allocation is not available'); }
    else { alloc = await one('SELECT * FROM allocations WHERE node_id = ? AND server_id IS NULL ORDER BY port LIMIT 1 FOR UPDATE', [node.id], c); if (!alloc) throw new HttpError(409, `Node ${node.name} has no free allocations (ports)`); }
    const nodeServerId = await allocateNodeServerId(c, node.id);
    const uuid = crypto.randomUUID();
    const r = await exec(`INSERT INTO servers (uuid, node_id, node_server_id, owner_id, name, description, egg_id, state, memory_mb, cpu_percent, disk_mb, swap_mb, xms_mb, xmx_mb, java_path, startup, variables, database_limit, allocation_limit, backup_limit, backup_storage_mb, max_upload_mb, auto_restart, service_id) VALUES (?, ?, ?, ?, ?, ?, ?, 'installing', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [uuid, node.id, nodeServerId, input.ownerId, input.name, input.description ?? null, egg.id, input.memoryMb, input.cpuPercent, input.diskMb, input.swapMb ?? 0, heap.xmsMb, heap.xmxMb, input.javaPath ?? null, input.startup || egg.definition.startup, json(variables), input.databaseLimit ?? 0, Math.max(1, input.allocationLimit ?? 1 + (input.additionalAllocations ?? 0)), input.backupLimit ?? 3, input.backupStorageMb ?? 0, maxUpload, input.autoRestart === false ? 0 : 1, input.serviceId ?? null], c);
    await exec('UPDATE allocations SET server_id = ?, is_primary = 1 WHERE id = ?', [r.insertId, alloc.id], c);
    if (input.additionalAllocations) {
      const extra = await q('SELECT id FROM allocations WHERE node_id = ? AND server_id IS NULL ORDER BY port LIMIT ? FOR UPDATE', [node.id, input.additionalAllocations], c);
      for (const a of extra) await exec('UPDATE allocations SET server_id = ? WHERE id = ?', [r.insertId, a.id], c);
    }
    return { id: r.insertId, nodeServerId };
  });
  if (!input.skipInstall) await pushAndInstall(created.id, false);
  return created;
}

export async function buildSpec(s: ServerRow): Promise<AgentServerSpec> {
  const egg = await getEgg(s.egg_id);
  const allocs = await q<{ ip: string; port: number; is_primary: number }>('SELECT ip, port, is_primary FROM allocations WHERE server_id = ? ORDER BY is_primary DESC, port', [s.id]);
  const primary = allocs[0];
  return {
    id: s.node_server_id, uuid: s.uuid, memoryMb: s.memory_mb, cpuPercent: s.cpu_percent, diskMb: s.disk_mb, swapMb: s.swap_mb, xmsMb: s.xms_mb, xmxMb: s.xmx_mb,
    javaPath: s.java_path, startup: s.startup, stopCommand: egg.definition.stopCommand, doneRegex: egg.definition.doneRegex, egg: egg.definition,
    variables: parse(s.variables, {}), ports: allocs.map(a => a.port), primaryPort: primary?.port ?? 25565, ip: primary?.ip ?? '0.0.0.0',
    suspended: !!s.suspended_at, securityBlocked: !!s.security_blocked, autoRestart: !!s.auto_restart, maxUploadMb: s.max_upload_mb,
    installedVersion: s.installed_version ?? null,
  };
}

export async function syncSpec(serverId: number) {
  const s = await getServer(serverId); const node = await getNode(s.node_id);
  return agent(node, 'PUT', `/api/servers/${s.node_server_id}`, await buildSpec(s), { serverId: s.node_server_id });
}

export async function pushAndInstall(serverId: number, reinstall: boolean) {
  const s = await getServer(serverId);
  try {
    await syncSpec(serverId);
    await exec("UPDATE servers SET state = 'installing', status_detail = NULL WHERE id = ?", [serverId]);
    const node = await getNode(s.node_id);
    await agent(node, 'POST', `/api/servers/${s.node_server_id}/install`, { reinstall }, { serverId: s.node_server_id });
  } catch (e: any) {
    await exec("UPDATE servers SET state = 'install_failed', status_detail = ? WHERE id = ?", [String(e.message).slice(0, 250), serverId]);
    throw e;
  }
}

/** Two-phase deletion: mark deleting (ID stays reserved) -> node confirms removal -> row deleted (ID reusable). */
export async function deleteServer(serverId: number) {
  const s = await getServer(serverId); const node = await getNode(s.node_id);
  await exec("UPDATE servers SET state = 'deleting', deleting_at = COALESCE(deleting_at, NOW()), status_detail = 'Deletion in progress' WHERE id = ?", [serverId]);
  try {
    const r = await agent<{ deleted: boolean }>(node, 'DELETE', `/api/servers/${s.node_server_id}`, undefined, { serverId: s.node_server_id, timeoutMs: 120_000 });
    if (!r.deleted) throw new HttpError(502, 'Node did not confirm that the server directory was removed');
  } catch (e: any) {
    await exec("UPDATE servers SET status_detail = ? WHERE id = ?", [`Deletion incomplete: ${String(e.message).slice(0, 200)}. ID ${s.node_server_id} stays reserved until deletion succeeds.`, serverId]);
    throw e;
  }
  await txRetry(async (c) => {
    await exec('UPDATE allocations SET server_id = NULL, is_primary = 0 WHERE server_id = ?', [serverId], c);
    await exec("UPDATE services SET server_id = NULL, status = IF(status = 'active', 'terminated', status) WHERE server_id = ?", [serverId], c);
    await exec('DELETE FROM servers WHERE id = ?', [serverId], c);
  });
  return { ok: true, freedId: s.node_server_id, node: node.id };
}

/** Recovery: cancel a stuck/failed deletion if the node still has the server files. */
export async function recoverServer(serverId: number) {
  const s = await getServer(serverId); if (s.state !== 'deleting') throw new HttpError(409, 'Server is not being deleted');
  await exec("UPDATE servers SET state = 'offline', deleting_at = NULL, status_detail = 'Recovered from incomplete deletion' WHERE id = ?", [serverId]);
  await syncSpec(serverId).catch(() => {}); return { ok: true };
}

export async function power(serverId: number, action: string) {
  const s = await getServer(serverId);
  if (s.state === 'deleting') throw new HttpError(409, 'Server is being deleted');
  if (action === 'start' || action === 'restart') {
    if (s.suspended_at) throw new HttpError(403, `Server is suspended${s.suspension_reason ? `: ${s.suspension_reason}` : ''}`);
    if (s.security_blocked) throw new HttpError(403, 'Server execution is blocked by the OGHOST Security Center pending review');
    const node = await getNode(s.node_id); if (node.emergency) throw new HttpError(409, 'Node is in emergency maintenance mode');
  }
  const node = await getNode(s.node_id);
  return agent(node, 'POST', `/api/servers/${s.node_server_id}/power`, { action }, { serverId: s.node_server_id });
}

export async function setSuspension(serverId: number, suspended: boolean, reason: string | null, hours: number | null) {
  if (suspended) await exec('UPDATE servers SET suspended_at = NOW(), suspended_until = ?, suspension_reason = ? WHERE id = ?', [hours ? new Date(Date.now() + hours * 3600_000) : null, reason, serverId]);
  else await exec('UPDATE servers SET suspended_at = NULL, suspended_until = NULL, suspension_reason = NULL WHERE id = ?', [serverId]);
  await syncSpec(serverId).catch(e => console.error('[suspend] sync failed', e.message));
}

export const toNodeServer = async (nodeId: number, nodeServerId: number) => one<ServerRow>('SELECT * FROM servers WHERE node_id = ? AND node_server_id = ?', [nodeId, nodeServerId]);
