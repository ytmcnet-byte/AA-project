import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { execFile } from 'node:child_process';
import type { JavaInstall } from '@oghost/shared';
import { config } from './config';

const run = (file: string, args: string[], timeout = 8000) => new Promise<{ out: string; code: number }>((res) => {
  execFile(file, args, { timeout, env: { PATH: process.env.PATH || '/usr/bin:/bin' } }, (err, stdout, stderr) => res({ out: `${stdout}${stderr}`, code: err ? 1 : 0 }));
});

export function parseJavaVersion(out: string): { version: string; major: number; vendor: string } | null {
  const m = out.match(/version "([^"]+)"/); if (!m) return null;
  const version = m[1]; const parts = version.split(/[.+_-]/).map(Number);
  const major = parts[0] === 1 ? parts[1] : parts[0];
  const vendor = /OpenJDK/i.test(out) ? (out.match(/\((?:build )?[^)]*\)/) ? (/(Temurin|Zulu|Corretto|GraalVM|Microsoft|Semeru|Liberica)/i.exec(out)?.[1] || 'OpenJDK') : 'OpenJDK') : /Java\(TM\)/.test(out) ? 'Oracle' : 'Unknown';
  return { version, major, vendor };
}

export async function inspectJava(p: string): Promise<JavaInstall | null> {
  try { fs.accessSync(p, fs.constants.X_OK); } catch { return null; }
  const { out } = await run(p, ['-version']);
  const v = parseJavaVersion(out); if (!v) return null;
  const arch = /aarch64|arm64/i.test(out) ? 'arm64' : /64-Bit/i.test(out) ? os.arch() : os.arch();
  return { path: p, ...v, arch };
}

export const JAVA_CMD = /^java[-_]?\d*$/;

/** Detect Java installations without assuming fixed paths. */
export async function detectJava(): Promise<JavaInstall[]> {
  const home = os.homedir();
  const candidates = new Set<string>();
  const roots = ['/usr/lib/jvm', '/usr/java', '/opt/java', '/opt', '/usr/local/java', path.join(home, '.sdkman/candidates/java'), path.join(home, '.jdks'), path.join(home, 'java'), path.join(home, '.java'), path.join(home, 'jdk'), path.join(home, '.local/share/java'), ...config.javaSearchPaths];
  for (const r of roots) {
    try {
      for (const e of fs.readdirSync(r)) {
        const bin = path.join(r, e, 'bin', 'java');
        if (fs.existsSync(bin)) candidates.add(fs.realpathSync(bin));
        const bin2 = path.join(r, e, 'Contents/Home/bin/java'); if (fs.existsSync(bin2)) candidates.add(fs.realpathSync(bin2));
      }
      const direct = path.join(r, 'bin', 'java'); if (fs.existsSync(direct)) candidates.add(fs.realpathSync(direct));
    } catch { /* not present */ }
  }
  // Commands such as java, java8, java17, java-21, java_25 (binaries, symlinks or small wrapper scripts).
  // Wrapper scripts are kept as-is (not resolved) so their own exec target is used.
  const addCmd = (p: string) => { try { const st = fs.lstatSync(p); candidates.add(st.isSymbolicLink() ? fs.realpathSync(p) : p); } catch { /* dangling */ } };
  const cmdDirs = [...(process.env.PATH || '').split(':'), path.join(home, 'bin'), path.join(home, '.local/bin'), ...config.javaSearchPaths];
  for (const dir of cmdDirs) {
    try {
      if (fs.statSync(dir).isFile()) { addCmd(dir); continue; } // JAVA_SEARCH_PATHS may list an executable directly
      for (const e of fs.readdirSync(dir)) if (JAVA_CMD.test(e)) addCmd(path.join(dir, e));
    } catch { /* */ }
  }
  if (process.env.JAVA_HOME) { const p = path.join(process.env.JAVA_HOME, 'bin/java'); if (fs.existsSync(p)) candidates.add(fs.realpathSync(p)); }
  const found = (await Promise.all([...candidates].map(inspectJava))).filter(Boolean) as JavaInstall[];
  // Same JVM reachable via several names (java17 -> /usr/lib/jvm/.../bin/java): keep one, prefer the real bin/java.
  const uniq = new Map<string, JavaInstall>();
  for (const j of found) { const k = `${j.version}|${j.vendor}|${j.arch}`; const cur = uniq.get(k); if (!cur || (!/\/bin\/java$/.test(cur.path) && /\/bin\/java$/.test(j.path))) uniq.set(k, j); }
  return [...uniq.values()].sort((a, b) => a.major - b.major);
}

let cache: { at: number; list: JavaInstall[] } | null = null;
export async function javaList(force = false) {
  if (!cache || force || Date.now() - cache.at > 10 * 60_000) cache = { at: Date.now(), list: await detectJava() };
  return cache.list;
}

export function detectCpulimit(): string | null {
  const cands = [config.cpulimitPath, path.join(os.homedir(), 'bin/cpulimit'), ...(process.env.PATH || '').split(':').map(d => path.join(d, 'cpulimit'))];
  for (const c of cands) { try { fs.accessSync(c, fs.constants.X_OK); return c; } catch { /* */ } }
  return null;
}
