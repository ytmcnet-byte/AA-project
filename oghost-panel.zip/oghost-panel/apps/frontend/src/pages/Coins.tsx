import { useEffect, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { Coins, ExternalLink, Gift, Link2, MessageCircle, Unlink } from 'lucide-react';
import { useApi, useAction, toast } from '../lib/hooks';
import { api, post } from '../lib/api';
import { useAuth } from '../lib/auth';
import { date } from '../lib/format';
import { Badge, Card, Empty, ErrorBox, Loading, Notice, PageHeader, Pager, Spinner, Table } from '../components/ui';

const LV: Record<string, [string, 'success' | 'error' | 'info']> = {
  ok: ['Link completed. Coins were added to your wallet.', 'success'],
  used: ['This link was already used. Coins are given only once per completed link.', 'info'],
  invalid: ['That link session is not valid. Start a new link from this page.', 'error'],
  expired: ['That link session expired. Start a new one.', 'error'],
  too_fast: ['The link was finished too quickly to be counted. Start a new link and complete it normally.', 'error'],
  not_verified: ['Linkvertise did not confirm the completion (bypassed or expired). No coins were added.', 'error'],
  verify_error: ['Could not reach Linkvertise to verify the link. Try again in a few minutes.', 'error'],
  daily_limit: ['Daily earning limit reached. Come back tomorrow.', 'info'],
  wrong_account: ['This link was started from a different account.', 'error'],
  login: ['Sign in first, then start the link from this page.', 'error'],
  disabled: ['Earning through Linkvertise is currently disabled.', 'info'],
};
const DC: Record<string, [string, 'success' | 'error' | 'info']> = {
  linked: ['Discord account linked.', 'success'],
  taken: ['That Discord account is already linked to another panel account.', 'error'],
  state: ['The Discord login session expired or was invalid. Try again.', 'error'],
  denied: ['Discord authorization was cancelled.', 'info'],
  token: ['Discord did not accept the login. Try again.', 'error'],
  login: ['Sign in first, then link Discord.', 'error'],
  disabled: ['Discord linking is not configured.', 'info'],
};
const TYPE: Record<string, string> = { linkvertise: 'Linkvertise', redeem: 'Code', discord: 'Discord', admin: 'Admin', purchase: 'Purchase', renewal: 'Renewal', upgrade: 'Upgrade', refund: 'Refund' };

function useCountdown(until: string | null | undefined) {
  const [now, setNow] = useState(Date.now());
  useEffect(() => { if (!until) return; const t = setInterval(() => setNow(Date.now()), 1000); return () => clearInterval(t); }, [until]);
  return until ? Math.max(0, Math.ceil((new Date(until).getTime() - now) / 1000)) : 0;
}

export function CoinsPage() {
  const { config } = useAuth(); const [sp, setSp] = useSearchParams();
  const { data, error, loading, reload } = useApi<any>('/api/coins/wallet');
  const { busy, run } = useAction(); const [code, setCode] = useState(''); const [page, setPage] = useState(1);
  const hist = useApi<any>(`/api/coins/transactions?page=${page}&per_page=20`, [page]);
  const wait = useCountdown(data?.linkvertise?.cooldownUntil);
  useEffect(() => {
    const lv = sp.get('lv'), dc = sp.get('discord');
    if (lv && LV[lv]) toast(lv === 'ok' && sp.get('coins') ? `+${sp.get('coins')} ${config?.coins?.name || 'OGCoins'}. ${LV.ok[0]}` : LV[lv][0], LV[lv][1]);
    if (dc && DC[dc]) toast(DC[dc][0], DC[dc][1]);
    if (lv || dc) { setSp({}, { replace: true }); window.dispatchEvent(new Event('oghost:coins')); }
  }, []);
  useEffect(() => { if (data && wait === 0 && data.linkvertise?.cooldownUntil) reload(); }, [wait]);
  if (loading) return <Loading />; if (error) return <ErrorBox error={error} onRetry={reload} />;
  const n = data.name; const lv = data.linkvertise; const dc = data.discord;
  const refresh = () => { reload(); hist.reload(); window.dispatchEvent(new Event('oghost:coins')); };
  if (!data.enabled) return <><PageHeader title={n} /><Notice kind="warn">{n} are currently disabled.</Notice></>;
  const earn = () => run('lv', async () => { const r = await post('/api/coins/linkvertise/start'); window.location.href = r.url; });
  const redeem = () => run('redeem', async () => { const r = await post('/api/coins/redeem', { code: code.trim() }); setCode(''); toast(`+${r.coins} ${n} added`, 'success'); refresh(); });
  const connect = () => run('dc', async () => { const r = await api('GET', '/api/coins/discord/connect'); window.location.href = r.url; });
  const unlink = () => run('unlink', async () => { await post('/api/coins/discord/unlink'); refresh(); }, 'Discord unlinked');
  return (
    <>
      <PageHeader title={`${n} Wallet`} subtitle={`Earn or buy ${n}, then use them to buy servers and renew plans.`} />
      <div className="grid gap-5 lg:grid-cols-3">
        <div className="card card-pad flex flex-col justify-between bg-gradient-to-br from-amber-950/40 to-ink-900">
          <div className="text-xs font-bold uppercase tracking-widest text-amber-300/80">Balance</div>
          <div className="mt-2 flex items-center gap-3 text-4xl font-extrabold text-amber-100"><Coins className="h-9 w-9 text-amber-400" />{data.balance.toLocaleString()}</div>
          <div className="mt-1 text-sm text-ink-400">{n}</div>
          <div className="mt-4 flex flex-wrap gap-2"><Link to="/store" className="btn-primary btn-sm">Buy a server</Link><Link to="/billing" className="btn-secondary btn-sm">Renew plans</Link></div>
        </div>

        <Card title={<span className="flex items-center gap-2"><Link2 className="h-4 w-4 text-brand-500" />Earn with Linkvertise</span>}>
          {!lv.enabled ? <p className="text-sm text-ink-400">Not available right now.</p> : <div className="space-y-3 text-sm">
            <p className="text-ink-300">Complete a Linkvertise link and get <b className="text-amber-200">{lv.coinsPerLink} {n}</b>. Coins are added only after Linkvertise confirms the completion to our server.</p>
            <div className="flex justify-between text-ink-400"><span>Today</span><span className="text-zinc-200">{lv.completedToday} / {lv.dailyLimit}</span></div>
            <button className="btn-primary w-full" disabled={!!busy || lv.remainingToday <= 0 || wait > 0} onClick={earn}>{busy === 'lv' ? <Spinner /> : <ExternalLink className="h-4 w-4" />}{lv.remainingToday <= 0 ? 'Daily limit reached' : wait > 0 ? `Wait ${wait}s` : `Earn ${lv.coinsPerLink} ${n}`}</button>
            <p className="hint">Do not use bypass tools; bypassed links are rejected by Linkvertise and give no coins.</p>
          </div>}
        </Card>

        <Card title={<span className="flex items-center gap-2"><Gift className="h-4 w-4 text-brand-500" />Redeem a code</span>}>
          <p className="mb-3 text-sm text-ink-300">Bought {n} on Discord or got a giveaway code? Redeem it here.</p>
          <div className="flex gap-2"><input className="input font-mono uppercase" value={code} onChange={e => setCode(e.target.value)} onKeyDown={e => e.key === 'Enter' && code.trim().length >= 4 && redeem()} placeholder="OG-XXXX-XXXX-XXXX" maxLength={60} /><button className="btn-primary" disabled={code.trim().length < 4 || !!busy} onClick={redeem}>{busy === 'redeem' && <Spinner />}Redeem</button></div>
        </Card>
      </div>

      {(dc.enabled || dc.inviteUrl || dc.shopText) && <Card className="mt-5" title={<span className="flex items-center gap-2"><MessageCircle className="h-4 w-4 text-brand-500" />Buy {n} on Discord</span>}>
        <div className="flex flex-wrap items-start gap-5 text-sm">
          <div className="min-w-[240px] flex-1 space-y-2 text-ink-300">
            {dc.shopText ? <p className="whitespace-pre-line">{dc.shopText}</p> : <p>Buy {n} from our team on Discord. They are credited to your linked account or given as a redeem code.</p>}
            {dc.inviteUrl && <a className="btn-secondary btn-sm inline-flex" href={dc.inviteUrl} target="_blank" rel="noopener noreferrer"><ExternalLink className="h-4 w-4" />Join our Discord</a>}
          </div>
          {dc.enabled && <div className="min-w-[240px] rounded-lg border border-ink-700 bg-ink-850 p-3">
            {dc.linked ? <><div className="text-xs text-ink-400">Linked Discord account</div><div className="font-semibold text-white">{dc.username}</div><div className="font-mono text-[11px] text-ink-400">ID {dc.discordId}</div><button className="btn-secondary btn-sm mt-2" disabled={!!busy} onClick={unlink}><Unlink className="h-4 w-4" />Unlink</button></>
              : <><div className="mb-2 text-ink-300">Link Discord so staff can send {n} straight to your wallet.</div><button className="btn-primary btn-sm" disabled={!!busy} onClick={connect}>{busy === 'dc' && <Spinner />}Link Discord</button></>}
          </div>}
        </div>
      </Card>}

      <Card className="mt-5" title="History">
        {!hist.data ? <Loading /> : !hist.data.transactions.length ? <Empty title="No transactions yet" /> : <>
          <Table><thead><tr><th>Date</th><th>Type</th><th>Description</th><th className="text-right">Amount</th><th className="text-right">Balance</th></tr></thead><tbody>
            {hist.data.transactions.map((t: any) => <tr key={t.id}><td className="whitespace-nowrap text-xs">{date(t.created_at)}</td><td><Badge value={t.type} label={TYPE[t.type] || t.type} /></td><td className="text-sm">{t.description}{t.invoice_id && <> · <Link className="link" to={`/billing/invoices/${t.invoice_id}`}>invoice</Link></>}</td><td className={`text-right font-semibold ${t.amount > 0 ? 'text-emerald-400' : 'text-red-400'}`}>{t.amount > 0 ? '+' : ''}{Number(t.amount).toLocaleString()}</td><td className="text-right text-ink-300">{Number(t.balance_after).toLocaleString()}</td></tr>)}
          </tbody></Table>
          <Pager page={page} setPage={setPage} hasMore={page * 20 < hist.data.total} /></>}
      </Card>
    </>
  );
}
