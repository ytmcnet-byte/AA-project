import type http from 'node:http';
import { Server as IOServer, type Socket } from 'socket.io';
import { io as ioClient, type Socket as ClientSocket } from 'socket.io-client';
import { sha256 } from '@oghost/shared';
import { one } from './db';
import { loadUserById, COOKIE } from './lib/auth';
import { serverAccess } from './lib/access';
import { getNode, agentUrl, wsToken } from './services/nodes';
import { config } from './config';
import { serverActivity } from './services/audit';

let ioRef: IOServer | null = null;
export const io = () => ioRef;
/** Panel-originated server events (state from node events, job progress) for every browser watching that server. */
export function emitServer(serverId: number, event: string, data: unknown) { ioRef?.to(`server:${serverId}`).emit(event, { serverId, data }); }

function cookieValue(header: string | undefined, name: string) {
  for (const part of String(header || '').split(';')) { const [k, ...v] = part.trim().split('='); if (k === name) return decodeURIComponent(v.join('=')); }
  return null;
}

export function attachRealtime(server: http.Server) {
  const allowed = new URL(config.appUrl).origin;
  const ioS = new IOServer(server, { path: '/ws', maxHttpBufferSize: 1e5, cors: { origin: (o, cb) => cb(null, !o || o === allowed || config.env !== 'production'), credentials: true } });
  ioRef = ioS;
  ioS.use(async (socket, next) => {
    try {
      const token = cookieValue(socket.handshake.headers.cookie, COOKIE); if (!token) throw new Error('No session');
      const s: any = await one('SELECT * FROM sessions WHERE id = ? AND expires_at > NOW() AND two_factor_pending = 0', [sha256(token)]);
      if (!s) throw new Error('Session expired');
      const user = await loadUserById(s.user_id); if (!user) throw new Error('User disabled');
      (socket.data as any).user = user; next();
    } catch (e: any) { next(new Error(`Unauthorized: ${e.message}`)); }
  });
  ioS.on('connection', (socket: Socket) => {
    const user = (socket.data as any).user; socket.join(`user:${user.id}`);
    const upstreams = new Map<number, ClientSocket>();
    socket.on('subscribe', async (serverId: number, ack?: (r: any) => void) => {
      try {
        const s = await serverAccess({ user, params: { id: String(serverId) } } as any, 'control.console');
        const node = await getNode(s.node_id);
        upstreams.get(s.id)?.disconnect(); socket.join(`server:${s.id}`);
        const up = ioClient(agentUrl(node), { path: '/ws', transports: ['websocket'], reconnection: true, reconnectionDelay: 2000, auth: (cb) => cb({ token: wsToken(node, s.node_server_id, s._perms) }) });
        upstreams.set(s.id, up);
        const tag = (ev: string) => (payload: unknown) => socket.emit(ev, { serverId: s.id, data: payload });
        for (const ev of ['console', 'status', 'stats', 'backlog', 'backup-progress']) up.on(ev, tag(ev));
        up.on('connect', () => socket.emit('upstream', { serverId: s.id, connected: true }));
        up.on('disconnect', () => socket.emit('upstream', { serverId: s.id, connected: false }));
        up.on('connect_error', (e) => socket.emit('upstream', { serverId: s.id, connected: false, error: e.message }));
        ack?.({ ok: true, perms: s._perms });
      } catch (e: any) { ack?.({ error: e.message }); }
    });
    socket.on('unsubscribe', (serverId: number) => { socket.leave(`server:${serverId}`); upstreams.get(serverId)?.disconnect(); upstreams.delete(serverId); });
    socket.on('command', async ({ serverId, command }: { serverId: number; command: string }, ack?: (r: any) => void) => {
      const up = upstreams.get(serverId); if (!up) return ack?.({ error: 'Not subscribed' });
      up.emit('command', String(command).slice(0, 4096), (r: any) => { ack?.(r); if (!r?.error) serverActivity({ user, ip: socket.handshake.address } as any, serverId, 'console.command', { command: String(command).slice(0, 200) }); });
    });
    socket.on('disconnect', () => { for (const u of upstreams.values()) u.disconnect(); upstreams.clear(); });
  });
  return ioS;
}
