import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { createZip, extractZip, zipDeclaredSize } from './archive';
import { backupDir, dirs } from './config';
import { diskInfo } from './system';
import type { ServerInstance } from './server';

export const backupFile = (serverId: number, uuid: string) => {
  if (!/^[a-zA-Z0-9-]{8,64}$/.test(uuid)) throw Object.assign(new Error('Invalid backup id'), { status: 400 });
  return path.join(backupDir(serverId), `${uuid}.zip`);
};

export async function createLocalBackup(inst: ServerInstance, uuid: string, maxBytes: number, onProgress?: (d: number, t: number) => void) {
  const file = backupFile(inst.id, uuid);
  const free = diskInfo().free; const est = inst.disk.used;
  if (est > free * 0.9) throw Object.assign(new Error('Not enough free disk on the node for this backup'), { status: 507 });
  return { file, ...(await createZip(inst.dir, ['/'], file, { maxBytes: maxBytes > 0 ? maxBytes : undefined, onProgress })) };
}

export async function restoreArchive(inst: ServerInstance, file: string, truncate: boolean) {
  if (inst.isActive()) throw Object.assign(new Error('Stop the server before restoring'), { status: 409 });
  const declared = await zipDeclaredSize(file);
  if (truncate) {
    if (!inst.disk.unlimited && declared.bytes > inst.disk.limitBytes) throw Object.assign(new Error('Backup is larger than the server disk allocation'), { status: 507 });
    for (const e of await fs.promises.readdir(inst.dir)) await fs.promises.rm(path.join(inst.dir, e), { recursive: true, force: true });
    await inst.disk.rescan();
  }
  const budget = inst.disk.unlimited ? 0 : inst.disk.available();
  const r = await extractZip(inst.dir, file, '/', budget);
  await inst.disk.rescan(); return r;
}

export const md5File = (file: string) => new Promise<string>((res, rej) => { const h = crypto.createHash('md5'); fs.createReadStream(file).on('data', d => h.update(d)).on('end', () => res(h.digest('hex'))).on('error', rej); });
export const tempFile = (name: string) => path.join(dirs.temporary, `${Date.now()}-${crypto.randomBytes(4).toString('hex')}-${name.replace(/[^A-Za-z0-9._-]/g, '_')}`);
