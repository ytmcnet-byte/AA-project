import { io, type Socket } from 'socket.io-client';
let sock: Socket | null = null;
/** One shared, auto-reconnecting Socket.IO connection to the panel (session cookie auth). */
export function socket(): Socket {
  if (!sock) sock = io({ path: '/ws', transports: ['websocket', 'polling'], withCredentials: true, reconnection: true, reconnectionDelay: 1000, reconnectionDelayMax: 8000 });
  return sock;
}
export function closeSocket() { sock?.close(); sock = null; }
