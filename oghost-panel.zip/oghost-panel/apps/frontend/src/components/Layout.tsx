import { useEffect, useState, type ReactNode } from 'react';
import { NavLink, Link, useLocation, useNavigate } from 'react-router-dom';
import { LayoutDashboard, Server, ShoppingCart, Receipt, LifeBuoy, User, Shield, Bell, LogOut, Menu, X, Users, HardDrive, Boxes, Network, Egg, Store, Settings, FileClock, Puzzle, KeyRound, Webhook, Megaphone, Activity, Database, MapPin, CreditCard, Coins } from 'lucide-react';
import { useAuth, hasPerm, isAdmin } from '../lib/auth';
import { api } from '../lib/api';
import { ago, cls } from '../lib/format';
import { Logo } from './ui';

type Item = { to: string; label: string; icon: any; perm?: string; end?: boolean };
const MAIN: Item[] = [
  { to: '/', label: 'Dashboard', icon: LayoutDashboard, end: true },
  { to: '/servers', label: 'My Servers', icon: Server },
  { to: '/store', label: 'Store', icon: ShoppingCart },
  { to: '/billing', label: 'Billing', icon: Receipt },
  { to: '/coins', label: 'OGCoins', icon: Coins },
  { to: '/tickets', label: 'Support', icon: LifeBuoy },
  { to: '/account', label: 'Account', icon: User },
];
const ADMIN: Item[] = [
  { to: '/admin', label: 'Overview', icon: Activity, perm: 'admin.overview', end: true },
  { to: '/admin/security', label: 'Security Center', icon: Shield, perm: 'admin.security' },
  { to: '/admin/servers', label: 'Servers', icon: Server, perm: 'admin.servers' },
  { to: '/admin/nodes', label: 'Nodes', icon: HardDrive, perm: 'admin.nodes' },
  { to: '/admin/locations', label: 'Locations', icon: MapPin, perm: 'admin.nodes' },
  { to: '/admin/eggs', label: 'Eggs', icon: Egg, perm: 'admin.eggs' },
  { to: '/admin/users', label: 'Users', icon: Users, perm: 'admin.users.read' },
  { to: '/admin/roles', label: 'Roles', icon: KeyRound, perm: 'admin.roles' },
  { to: '/admin/store', label: 'Store', icon: Store, perm: 'admin.store' },
  { to: '/admin/coins', label: 'OGCoins', icon: Coins, perm: 'admin.coins' },
  { to: '/admin/orders', label: 'Orders & Payments', icon: CreditCard, perm: 'admin.orders' },
  { to: '/admin/tickets', label: 'Tickets', icon: LifeBuoy, perm: 'admin.tickets' },
  { to: '/admin/databases', label: 'Database Hosts', icon: Database, perm: 'admin.databases' },
  { to: '/admin/plugins', label: 'Plugin Repos', icon: Boxes, perm: 'admin.plugins' },
  { to: '/admin/extensions', label: 'Extensions', icon: Puzzle, perm: 'admin.extensions' },
  { to: '/admin/announcements', label: 'Announcements', icon: Megaphone, perm: 'admin.announcements' },
  { to: '/admin/webhooks', label: 'Webhooks & API', icon: Webhook, perm: 'admin.apikeys' },
  { to: '/admin/drive', label: 'Drive Backups', icon: Network, perm: 'admin.drive' },
  { to: '/admin/audit', label: 'Audit Log', icon: FileClock, perm: 'admin.audit' },
  { to: '/admin/jobs', label: 'Jobs', icon: Activity, perm: 'admin.overview' },
  { to: '/admin/settings', label: 'Settings', icon: Settings, perm: 'admin.settings' },
];

function NavList({ items, onNav }: { items: Item[]; onNav: () => void }) {
  return <nav className="space-y-0.5">{items.map(i => <NavLink key={i.to} to={i.to} end={i.end} onClick={onNav} className={({ isActive }) => cls('flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition', isActive ? 'bg-brand-600/15 text-white ring-1 ring-brand-600/40' : 'text-ink-300 hover:bg-ink-800 hover:text-white')}><i.icon className="h-4 w-4 shrink-0" />{i.label}</NavLink>)}</nav>;
}

function Notifications() {
  const [open, setOpen] = useState(false); const [data, setData] = useState<any>(null); const nav = useNavigate();
  const load = () => api('GET', '/api/account/notifications').then(setData).catch(() => {});
  useEffect(() => { load(); const t = setInterval(load, 30000); return () => clearInterval(t); }, []);
  const read = async (ids: number[]) => { if (ids.length) await api('POST', '/api/account/notifications/read', { ids }).catch(() => {}); load(); };
  return (
    <div className="relative">
      <button className="btn-ghost relative px-2.5" onClick={() => setOpen(!open)} aria-label="Notifications"><Bell className="h-5 w-5" />{data?.unread > 0 && <span className="absolute right-1 top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-brand-600 px-1 text-[10px] font-bold text-white">{data.unread > 99 ? '99+' : data.unread}</span>}</button>
      {open && <>
        <div className="fixed inset-0 z-30" onClick={() => setOpen(false)} />
        <div className="card absolute right-0 z-40 mt-2 w-[min(92vw,380px)] overflow-hidden">
          <div className="flex items-center justify-between border-b border-ink-700 px-4 py-2.5"><span className="text-sm font-bold">Notifications</span>{data?.unread > 0 && <button className="link text-xs" onClick={() => read(data.notifications.filter((n: any) => !n.read_at).map((n: any) => n.id))}>Mark all read</button>}</div>
          <div className="max-h-[60vh] overflow-y-auto">{!data?.notifications?.length ? <div className="p-6 text-center text-sm text-ink-400">No notifications yet.</div> : data.notifications.map((n: any) => (
            <button key={n.id} className={cls('block w-full border-b border-ink-800 px-4 py-3 text-left hover:bg-ink-850', !n.read_at && 'bg-brand-600/5')} onClick={() => { read([n.id]); setOpen(false); if (n.link) nav(n.link); }}>
              <div className="flex items-center gap-2 text-sm font-semibold text-zinc-100">{!n.read_at && <span className="h-1.5 w-1.5 rounded-full bg-brand-500" />}{n.title}</div>
              {n.body && <div className="mt-0.5 line-clamp-2 text-xs text-ink-400">{n.body}</div>}<div className="mt-1 text-[11px] text-ink-400">{ago(n.created_at)}</div>
            </button>))}</div>
        </div>
      </>}
    </div>
  );
}

function CoinChip() {
  const [b, setB] = useState<{ balance: number; name: string } | null>(null);
  useEffect(() => { const load = () => api('GET', '/api/coins/balance').then(setB).catch(() => {}); load(); const t = setInterval(load, 60000); window.addEventListener('oghost:coins', load); return () => { clearInterval(t); window.removeEventListener('oghost:coins', load); }; }, []);
  if (!b) return null;
  return <Link to="/coins" title={`${b.name} balance`} className="flex items-center gap-1.5 rounded-full border border-amber-700/50 bg-amber-950/30 px-3 py-1 text-sm font-semibold text-amber-200 hover:bg-amber-900/40"><Coins className="h-4 w-4" />{b.balance.toLocaleString()}<span className="hidden text-xs font-normal text-amber-300/80 sm:inline">{b.name}</span></Link>;
}

export function Footer() {
  return <footer className="mt-10 border-t border-ink-800 px-4 py-5 text-center text-xs text-ink-400"><div className="font-semibold text-ink-300">OGHOST PANEL <span className="text-ink-400">·</span> Powering the Next Generation of Game Hosting.</div><div className="mt-1">Powered by <span className="font-bold text-brand-500">SHIVAMBROOG</span></div></footer>;
}

export function Layout({ children }: { children: ReactNode }) {
  const { user, logout, config, refresh } = useAuth(); const [open, setOpen] = useState(false); const loc = useLocation();
  useEffect(() => setOpen(false), [loc.pathname]);
  const adminItems = ADMIN.filter(i => !i.perm || hasPerm(user, i.perm));
  const main = MAIN.filter(i => (i.to !== '/store' || config?.storeEnabled) && (i.to !== '/coins' || config?.coins?.enabled)).map(i => i.to === '/coins' && config?.coins?.name ? { ...i, label: config.coins.name } : i);
  const sidebar = (
    <div className="flex h-full flex-col">
      <div className="flex h-16 items-center justify-between px-4"><Link to="/"><Logo /></Link><button className="btn-ghost px-2 lg:hidden" onClick={() => setOpen(false)} aria-label="Close menu"><X className="h-5 w-5" /></button></div>
      <div className="flex-1 space-y-6 overflow-y-auto px-3 pb-6">
        <NavList items={main} onNav={() => setOpen(false)} />
        {isAdmin(user) && adminItems.length > 0 && <div><div className="mb-2 px-3 text-[11px] font-bold uppercase tracking-widest text-brand-500">Administration</div><NavList items={adminItems} onNav={() => setOpen(false)} /></div>}
      </div>
      <div className="border-t border-ink-800 p-3 text-[11px] text-ink-400">Powered by <span className="font-bold text-brand-500">SHIVAMBROOG</span></div>
    </div>
  );
  return (
    <div className="flex min-h-full">
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-64 border-r border-ink-800 bg-ink-900 lg:block">{sidebar}</aside>
      {open && <div className="fixed inset-0 z-40 lg:hidden"><div className="absolute inset-0 bg-black/70" onClick={() => setOpen(false)} /><aside className="absolute inset-y-0 left-0 w-72 border-r border-ink-800 bg-ink-900">{sidebar}</aside></div>}
      <div className="flex min-w-0 flex-1 flex-col lg:pl-64">
        <header className="sticky top-0 z-20 flex h-16 items-center gap-2 border-b border-ink-800 bg-ink-950/85 px-3 backdrop-blur sm:px-6">
          <button className="btn-ghost px-2 lg:hidden" onClick={() => setOpen(true)} aria-label="Open menu"><Menu className="h-5 w-5" /></button>
          <div className="lg:hidden"><Logo size={28} withText={false} /></div>
          <div className="flex-1" />
          {config?.coins?.enabled && <CoinChip />}
          <Notifications />
          <Link to="/account" className="flex items-center gap-2 rounded-lg px-2 py-1.5 hover:bg-ink-800">
            {user?.avatar_url ? <img src={user.avatar_url} alt="" className="h-8 w-8 rounded-full object-cover" referrerPolicy="no-referrer" /> : <div className="flex h-8 w-8 items-center justify-center rounded-full bg-brand-600/20 text-sm font-bold text-brand-400">{user?.username?.[0]?.toUpperCase()}</div>}
            <div className="hidden text-left leading-tight sm:block"><div className="text-sm font-semibold text-white">{user?.username}</div><div className="text-[11px] text-ink-400">{user?.role_name}</div></div>
          </Link>
          <button className="btn-ghost px-2.5" title="Sign out" onClick={logout}><LogOut className="h-4 w-4" /></button>
        </header>
        {user && !user.email_verified && config?.requireEmailVerification && <div className="border-b border-amber-900/50 bg-amber-950/40 px-4 py-2 text-center text-sm text-amber-200">Please verify your email address. <button className="link" onClick={() => api('POST', '/api/auth/resend-verification').then(() => { window.dispatchEvent(new CustomEvent('oghost:toast', { detail: { message: 'Verification email sent', kind: 'success' } })); refresh(); }).catch(e => window.dispatchEvent(new CustomEvent('oghost:toast', { detail: { message: e.message, kind: 'error' } })))}>Resend email</button></div>}
        {config?.announcements?.map(a => <div key={a.id} className={cls('border-b px-4 py-2 text-center text-sm', a.level === 'critical' ? 'border-red-900/60 bg-red-950/50 text-red-200' : a.level === 'warning' || a.level === 'maintenance' ? 'border-amber-900/50 bg-amber-950/40 text-amber-200' : 'border-sky-900/50 bg-sky-950/30 text-sky-200')}><b>{a.title}</b>{a.body ? ` — ${a.body}` : ''}</div>)}
        <main className="mx-auto w-full max-w-7xl flex-1 px-3 py-5 sm:px-6 sm:py-7">{children}</main>
        <Footer />
      </div>
    </div>
  );
}
