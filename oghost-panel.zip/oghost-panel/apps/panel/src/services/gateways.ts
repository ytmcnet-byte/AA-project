import crypto from 'node:crypto';
import QRCode from 'qrcode';
import { one, exec, json } from '../db';
import { HttpError } from '../lib/http';
import { getSetting } from './settings';
import { config } from '../config';
import { markInvoicePaid } from './billing';
import { notifyAdmins } from './notify';
import { safeEqual } from '@oghost/shared';

/**
 * Payment gateways. An invoice is only ever marked paid after server-side verification:
 *  - Razorpay: HMAC signature check + payment lookup via the Razorpay API, or signed webhook.
 *  - Stripe: signed webhook (Stripe-Signature) or Checkout Session lookup via the Stripe API.
 *  - Cashfree: signed webhook or order lookup via the Cashfree API.
 *  - UPI / manual: administrator approval only. Redirects and screenshots are never trusted.
 */
export type Gateway = 'razorpay' | 'stripe' | 'cashfree' | 'upi' | 'manual';
export async function enabledGateways() {
  const out: Array<{ id: Gateway; name: string; publicKey?: string; mode?: string }> = [];
  if (await getSetting('payments.razorpay.enabled') && await getSetting('razorpay.keyId')) out.push({ id: 'razorpay', name: 'Razorpay (cards, UPI, netbanking)', publicKey: await getSetting('razorpay.keyId') });
  if (await getSetting('payments.cashfree.enabled') && await getSetting('cashfree.appId')) out.push({ id: 'cashfree', name: 'Cashfree', mode: (await getSetting('cashfree.env')) === 'production' ? 'production' : 'sandbox' });
  if (await getSetting('payments.stripe.enabled') && await getSetting('stripe.secretKey')) out.push({ id: 'stripe', name: 'Stripe (cards)' });
  if (await getSetting('payments.upi.enabled') && await getSetting('upi.vpa')) out.push({ id: 'upi', name: 'UPI (manual verification)' });
  if (await getSetting('payments.manual.enabled')) out.push({ id: 'manual', name: 'Bank transfer / manual payment' });
  return out;
}

async function loadInvoice(invoiceId: number, userId: number) {
  const inv: any = await one('SELECT * FROM invoices WHERE id = ? AND user_id = ?', [invoiceId, userId]); if (!inv) throw new HttpError(404, 'Invoice not found');
  if (inv.status !== 'unpaid') throw new HttpError(409, `Invoice is ${inv.status}`); if (inv.total_cents <= 0) throw new HttpError(409, 'Nothing to pay');
  return inv;
}
const newPayment = async (inv: any, gateway: Gateway, status = 'created', extra: Record<string, unknown> = {}) => (await exec('INSERT INTO payments (invoice_id, user_id, gateway, amount_cents, currency, status, gateway_order_id, reference, raw) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)', [inv.id, inv.user_id, gateway, inv.total_cents, inv.currency, status, extra.orderId ?? null, extra.reference ?? null, json(extra.raw ?? null)])).insertId;

// ---------------- Razorpay
const rzAuth = async () => 'Basic ' + Buffer.from(`${await getSetting('razorpay.keyId')}:${await getSetting('razorpay.keySecret')}`).toString('base64');
async function rz(method: string, path: string, body?: unknown) { const r = await fetch(`https://api.razorpay.com/v1${path}`, { method, headers: { Authorization: await rzAuth(), 'Content-Type': 'application/json' }, body: body ? JSON.stringify(body) : undefined }); const d: any = await r.json().catch(() => ({})); if (!r.ok) throw new HttpError(502, `Razorpay: ${d.error?.description || r.status}`); return d; }

// ---------------- Stripe
async function stripe(method: string, path: string, form?: Record<string, string>) { const r = await fetch(`https://api.stripe.com/v1${path}`, { method, headers: { Authorization: `Bearer ${await getSetting('stripe.secretKey')}`, 'Content-Type': 'application/x-www-form-urlencoded' }, body: form ? new URLSearchParams(form) : undefined }); const d: any = await r.json().catch(() => ({})); if (!r.ok) throw new HttpError(502, `Stripe: ${d.error?.message || r.status}`); return d; }

// ---------------- Cashfree
const cfBase = async () => (await getSetting('cashfree.env')) === 'production' ? 'https://api.cashfree.com/pg' : 'https://sandbox.cashfree.com/pg';
async function cf(method: string, path: string, body?: unknown) { const r = await fetch(`${await cfBase()}${path}`, { method, headers: { 'x-client-id': String(await getSetting('cashfree.appId')), 'x-client-secret': String(await getSetting('cashfree.secretKey')), 'x-api-version': '2023-08-01', 'Content-Type': 'application/json' }, body: body ? JSON.stringify(body) : undefined }); const d: any = await r.json().catch(() => ({})); if (!r.ok) throw new HttpError(502, `Cashfree: ${d.message || r.status}`); return d; }

export async function startPayment(invoiceId: number, user: { id: number; email: string; name?: string | null }, gateway: Gateway, opts: { phone?: string; reference?: string; note?: string } = {}) {
  const gws = await enabledGateways(); if (!gws.some(g => g.id === gateway)) throw new HttpError(400, 'Payment method is not available');
  const inv = await loadInvoice(invoiceId, user.id);
  if (gateway === 'razorpay') {
    const order = await rz('POST', '/orders', { amount: inv.total_cents, currency: inv.currency, receipt: inv.number, notes: { invoice_id: String(inv.id) } });
    const pid = await newPayment(inv, 'razorpay', 'created', { orderId: order.id, raw: order });
    return { gateway, paymentId: pid, keyId: await getSetting('razorpay.keyId'), orderId: order.id, amount: inv.total_cents, currency: inv.currency, name: await getSetting('app.name'), description: `Invoice ${inv.number}`, prefill: { email: user.email, name: user.name || '' } };
  }
  if (gateway === 'stripe') {
    const pid = await newPayment(inv, 'stripe');
    const s = await stripe('POST', '/checkout/sessions', { mode: 'payment', 'line_items[0][quantity]': '1', 'line_items[0][price_data][currency]': inv.currency.toLowerCase(), 'line_items[0][price_data][unit_amount]': String(inv.total_cents), 'line_items[0][price_data][product_data][name]': `Invoice ${inv.number}`, client_reference_id: String(pid), customer_email: user.email, 'metadata[invoice_id]': String(inv.id), 'metadata[payment_id]': String(pid), success_url: `${config.appUrl}/billing/invoices/${inv.id}?checkout=return`, cancel_url: `${config.appUrl}/billing/invoices/${inv.id}?checkout=cancel` });
    await exec('UPDATE payments SET gateway_order_id = ?, status = ? WHERE id = ?', [s.id, 'pending', pid]);
    return { gateway, paymentId: pid, url: s.url };
  }
  if (gateway === 'cashfree') {
    if (!opts.phone || !/^\+?[0-9]{10,13}$/.test(opts.phone)) throw new HttpError(422, 'A valid phone number is required by Cashfree');
    const orderId = `oghost_${inv.id}_${Date.now()}`;
    const o = await cf('POST', '/orders', { order_id: orderId, order_amount: inv.total_cents / 100, order_currency: inv.currency, customer_details: { customer_id: `u${user.id}`, customer_email: user.email, customer_phone: opts.phone.replace(/^\+91/, '') }, order_meta: { return_url: `${config.appUrl}/billing/invoices/${inv.id}?checkout=return&cf_order={order_id}`, notify_url: `${config.appUrl}/api/webhooks/cashfree` }, order_note: `Invoice ${inv.number}` });
    const pid = await newPayment(inv, 'cashfree', 'pending', { orderId, raw: { cf_order_id: o.cf_order_id } });
    return { gateway, paymentId: pid, paymentSessionId: o.payment_session_id, mode: (await getSetting('cashfree.env')) === 'production' ? 'production' : 'sandbox' };
  }
  if (gateway === 'upi') {
    const vpa = String(await getSetting('upi.vpa')); const payee = String(await getSetting('upi.payee') || await getSetting('app.name'));
    const pid = await newPayment(inv, 'upi', 'pending');
    const uri = `upi://pay?${new URLSearchParams({ pa: vpa, pn: payee, am: (inv.total_cents / 100).toFixed(2), cu: inv.currency, tn: `Invoice ${inv.number}`, tr: `OGH${pid}` })}`;
    return { gateway, paymentId: pid, uri, qr: await QRCode.toDataURL(uri), vpa, payee, amount: inv.total_cents, note: 'After paying, submit your UPI transaction reference (UTR). An administrator verifies it against the bank statement before the invoice is marked paid.' };
  }
  // manual
  const pid = await newPayment(inv, 'manual', 'pending');
  return { gateway, paymentId: pid, instructions: await getSetting('payments.manual.instructions') || 'Transfer the amount and submit the transaction reference. An administrator will approve the payment.' };
}

/** Customer submits a UTR / bank reference for UPI or manual payments. This only queues it for admin approval. */
export async function submitReference(paymentId: number, userId: number, reference: string) {
  const p: any = await one("SELECT * FROM payments WHERE id = ? AND user_id = ? AND gateway IN ('upi','manual')", [paymentId, userId]); if (!p) throw new HttpError(404, 'Payment not found');
  if (!['pending', 'created'].includes(p.status)) throw new HttpError(409, `Payment is ${p.status}`);
  if (!/^[A-Za-z0-9\-_/ ]{6,64}$/.test(reference)) throw new HttpError(422, 'Enter the transaction reference exactly as shown by your bank/UPI app');
  const dup: any = await one("SELECT id FROM payments WHERE reference = ? AND id <> ? AND status IN ('awaiting_approval','succeeded')", [reference.trim(), paymentId]); if (dup) throw new HttpError(409, 'This reference was already submitted');
  await exec("UPDATE payments SET reference = ?, status = 'awaiting_approval' WHERE id = ?", [reference.trim(), paymentId]);
  await notifyAdmins('admin.payments', 'payment', `Payment awaiting approval (#${paymentId})`, `${p.gateway.toUpperCase()} reference ${reference.trim()} for ${(p.amount_cents / 100).toFixed(2)} ${p.currency}.`, { link: '/admin/payments' });
}

export async function verifyRazorpayCheckout(userId: number, b: { razorpay_order_id: string; razorpay_payment_id: string; razorpay_signature: string }) {
  const p: any = await one("SELECT * FROM payments WHERE gateway = 'razorpay' AND gateway_order_id = ? AND user_id = ?", [b.razorpay_order_id, userId]); if (!p) throw new HttpError(404, 'Payment not found');
  const expected = crypto.createHmac('sha256', String(await getSetting('razorpay.keySecret'))).update(`${b.razorpay_order_id}|${b.razorpay_payment_id}`).digest('hex');
  if (!safeEqual(expected, String(b.razorpay_signature))) { await exec("UPDATE payments SET status = 'failed', failure_reason = 'Invalid signature' WHERE id = ?", [p.id]); throw new HttpError(400, 'Payment signature verification failed'); }
  // Signature is valid; additionally confirm with Razorpay's API that the payment is captured for the right amount
  const pay = await rz('GET', `/payments/${encodeURIComponent(b.razorpay_payment_id)}`);
  if (pay.order_id !== b.razorpay_order_id || Number(pay.amount) !== p.amount_cents) throw new HttpError(400, 'Payment does not match the order');
  if (pay.status === 'authorized') await rz('POST', `/payments/${pay.id}/capture`, { amount: pay.amount, currency: pay.currency });
  else if (pay.status !== 'captured') throw new HttpError(402, `Payment status is ${pay.status}`);
  await exec('UPDATE payments SET gateway_payment_id = ? WHERE id = ?', [pay.id, p.id]);
  return markInvoicePaid(p.invoice_id, { gateway: 'razorpay', paymentId: p.id, reference: pay.id });
}

/** Server-to-server status refresh (used when the customer returns from Stripe/Cashfree). */
export async function refreshPayment(paymentId: number, userId: number) {
  const p: any = await one('SELECT * FROM payments WHERE id = ? AND user_id = ?', [paymentId, userId]); if (!p) throw new HttpError(404, 'Payment not found');
  if (p.status === 'succeeded') return { status: 'succeeded' };
  if (p.gateway === 'stripe' && p.gateway_order_id) { const s = await stripe('GET', `/checkout/sessions/${p.gateway_order_id}`); if (s.payment_status === 'paid' && Number(s.amount_total) === p.amount_cents) { await exec('UPDATE payments SET gateway_payment_id = ? WHERE id = ?', [s.payment_intent, p.id]); await markInvoicePaid(p.invoice_id, { gateway: 'stripe', paymentId: p.id, reference: s.payment_intent }); return { status: 'succeeded' }; } return { status: s.payment_status }; }
  if (p.gateway === 'cashfree' && p.gateway_order_id) { const o = await cf('GET', `/orders/${p.gateway_order_id}`); if (o.order_status === 'PAID' && Math.round(Number(o.order_amount) * 100) === p.amount_cents) { await markInvoicePaid(p.invoice_id, { gateway: 'cashfree', paymentId: p.id, reference: o.cf_order_id }); return { status: 'succeeded' }; } return { status: o.order_status }; }
  return { status: p.status };
}

async function once(gateway: string, eventId: string, type: string, payload: unknown, fn: () => Promise<void>) {
  try { await exec('INSERT INTO webhook_events (gateway, event_id, type, payload) VALUES (?, ?, ?, ?)', [gateway, eventId.slice(0, 191), type.slice(0, 100), json(payload)]); }
  catch (e: any) { if (e.code === 'ER_DUP_ENTRY') { const ev: any = await one('SELECT processed_at FROM webhook_events WHERE gateway = ? AND event_id = ?', [gateway, eventId]); if (ev?.processed_at) return; } else throw e; }
  await fn(); await exec('UPDATE webhook_events SET processed_at = NOW() WHERE gateway = ? AND event_id = ?', [gateway, eventId]);
}

export async function razorpayWebhook(raw: Buffer, sig: string, eventId: string) {
  const secret = String(await getSetting('razorpay.webhookSecret') || ''); if (!secret) throw new HttpError(503, 'Webhook secret not configured');
  const exp = crypto.createHmac('sha256', secret).update(raw).digest('hex'); if (!safeEqual(exp, sig || '')) throw new HttpError(400, 'Invalid signature');
  const ev = JSON.parse(raw.toString()); const pay = ev.payload?.payment?.entity;
  await once('razorpay', eventId || `${ev.event}:${pay?.id}`, ev.event, ev, async () => {
    if (!pay?.order_id) return; const p: any = await one("SELECT * FROM payments WHERE gateway = 'razorpay' AND gateway_order_id = ?", [pay.order_id]); if (!p) return;
    if ((ev.event === 'payment.captured' || ev.event === 'order.paid') && Number(pay.amount) === p.amount_cents) { await exec('UPDATE payments SET gateway_payment_id = ? WHERE id = ?', [pay.id, p.id]); await markInvoicePaid(p.invoice_id, { gateway: 'razorpay', paymentId: p.id, reference: pay.id }); }
    else if (ev.event === 'payment.failed') await exec("UPDATE payments SET status = 'failed', failure_reason = ? WHERE id = ? AND status <> 'succeeded'", [String(pay.error_description || 'failed').slice(0, 500), p.id]);
    else if (ev.event === 'refund.processed') await exec("UPDATE payments SET refunded_cents = LEAST(amount_cents, refunded_cents + ?), status = IF(refunded_cents >= amount_cents, 'refunded', 'partially_refunded') WHERE id = ?", [Number(ev.payload?.refund?.entity?.amount || 0), p.id]);
  });
}
export async function stripeWebhook(raw: Buffer, header: string) {
  const secret = String(await getSetting('stripe.webhookSecret') || ''); if (!secret) throw new HttpError(503, 'Webhook secret not configured');
  const parts = Object.fromEntries(String(header || '').split(',').map(kv => kv.split('=') as [string, string])); const t = Number(parts.t);
  if (!t || Math.abs(Date.now() / 1000 - t) > 300) throw new HttpError(400, 'Stale or missing timestamp');
  const exp = crypto.createHmac('sha256', secret).update(`${t}.${raw.toString()}`).digest('hex');
  const sigs = String(header).split(',').filter(x => x.startsWith('v1=')).map(x => x.slice(3)); if (!sigs.some(s => safeEqual(s, exp))) throw new HttpError(400, 'Invalid signature');
  const ev = JSON.parse(raw.toString());
  await once('stripe', ev.id, ev.type, ev, async () => {
    const o = ev.data?.object; if (ev.type === 'checkout.session.completed' || ev.type === 'checkout.session.async_payment_succeeded') {
      if (o.payment_status !== 'paid') return; const p: any = await one("SELECT * FROM payments WHERE gateway = 'stripe' AND gateway_order_id = ?", [o.id]); if (!p || Number(o.amount_total) !== p.amount_cents) return;
      await exec('UPDATE payments SET gateway_payment_id = ? WHERE id = ?', [o.payment_intent, p.id]); await markInvoicePaid(p.invoice_id, { gateway: 'stripe', paymentId: p.id, reference: o.payment_intent });
    } else if (ev.type === 'checkout.session.async_payment_failed' || ev.type === 'checkout.session.expired') await exec("UPDATE payments SET status = 'failed', failure_reason = ? WHERE gateway = 'stripe' AND gateway_order_id = ? AND status <> 'succeeded'", [ev.type, o.id]);
    else if (ev.type === 'charge.refunded') await exec("UPDATE payments SET refunded_cents = LEAST(amount_cents, ?), status = IF(? >= amount_cents, 'refunded', 'partially_refunded') WHERE gateway = 'stripe' AND gateway_payment_id = ?", [o.amount_refunded, o.amount_refunded, o.payment_intent]);
  });
}
export async function cashfreeWebhook(raw: Buffer, sig: string, ts: string) {
  const secret = String(await getSetting('cashfree.secretKey') || ''); if (!secret) throw new HttpError(503, 'Cashfree not configured');
  const exp = crypto.createHmac('sha256', secret).update(ts + raw.toString()).digest('base64'); if (!safeEqual(exp, sig || '')) throw new HttpError(400, 'Invalid signature');
  const ev = JSON.parse(raw.toString()); const orderId = ev.data?.order?.order_id; const payId = String(ev.data?.payment?.cf_payment_id || '');
  await once('cashfree', `${ev.type}:${orderId}:${payId}`, ev.type, ev, async () => {
    const p: any = await one("SELECT * FROM payments WHERE gateway = 'cashfree' AND gateway_order_id = ?", [orderId]); if (!p) return;
    if (ev.type === 'PAYMENT_SUCCESS_WEBHOOK' && ev.data.payment.payment_status === 'SUCCESS') {
      const o = await cf('GET', `/orders/${orderId}`); // confirm with the API
      if (o.order_status === 'PAID' && Math.round(Number(o.order_amount) * 100) === p.amount_cents) { await exec('UPDATE payments SET gateway_payment_id = ? WHERE id = ?', [payId, p.id]); await markInvoicePaid(p.invoice_id, { gateway: 'cashfree', paymentId: p.id, reference: payId }); }
    } else if (ev.type === 'PAYMENT_FAILED_WEBHOOK') await exec("UPDATE payments SET status = 'failed', failure_reason = ? WHERE id = ? AND status <> 'succeeded'", [String(ev.data?.payment?.payment_message || 'failed').slice(0, 500), p.id]);
  });
}

export async function refund(paymentId: number, amountCents: number | null, adminId: number) {
  const p: any = await one('SELECT * FROM payments WHERE id = ?', [paymentId]); if (!p || !['succeeded', 'partially_refunded'].includes(p.status)) throw new HttpError(409, 'Only succeeded payments can be refunded');
  const amount = Math.min(amountCents ?? p.amount_cents - p.refunded_cents, p.amount_cents - p.refunded_cents); if (amount <= 0) throw new HttpError(409, 'Nothing left to refund');
  if (p.gateway === 'razorpay') await rz('POST', `/payments/${p.gateway_payment_id}/refund`, { amount });
  else if (p.gateway === 'stripe') await stripe('POST', '/refunds', { payment_intent: p.gateway_payment_id, amount: String(amount) });
  else if (p.gateway === 'cashfree') await cf('POST', `/orders/${p.gateway_order_id}/refunds`, { refund_amount: amount / 100, refund_id: `r${p.id}_${Date.now()}` });
  // upi/manual: refund is performed outside the panel by the administrator; we record it.
  const total = p.refunded_cents + amount;
  await exec('UPDATE payments SET refunded_cents = ?, status = ?, approved_by = COALESCE(approved_by, ?) WHERE id = ?', [total, total >= p.amount_cents ? 'refunded' : 'partially_refunded', adminId, p.id]);
  if (total >= p.amount_cents) await exec("UPDATE invoices SET status = 'refunded' WHERE id = ?", [p.invoice_id]);
  return { refunded: amount, manual: ['upi', 'manual'].includes(p.gateway) };
}
