import fs from 'fs';
import { downloadJar } from './src/server/services/jarDownloader.ts'; // Wait I can't import .ts easily from node directly unless I compile or use tsx
