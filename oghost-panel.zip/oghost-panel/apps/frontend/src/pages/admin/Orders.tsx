import { useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Plus, Trash2 } from 'lucide-react';
import { useApi, useAction, toast } from '../../lib/hooks';
import { api } from '../../lib/api';
import { date, money } from '../../lib/format';
import { Badge, Card, Empty, ErrorBox, Field, Loading, Modal, Notice, PageHeader, Pager, Spinner, Switch, Table, Tabs } from '../../components/ui';

type Tab = 'payments' | 'invoices' | 'orders' | 'services';
const st = (s: string) => ({ paid: 'running', succeeded: 'running', active: 'running', completed: 'running', unpaid: 'suspicious', pending: 'suspicious', awaiting_approval: 'suspicious', failed: 'install_failed', cancelled: 'offline', refunded: 'offline', partially_refunded: 'suspicious', suspended: 'suspended', terminated: 'offline' } as any)[s] || s;

function useList(path: string, status: string, page: number) { return useApi<any>(`${path}?page=${page}&per_page=25${status ? `&status=${status}` : ''}`); }

export function OrdersAdmin() {
  const [sp, setSp] = useSearchParams(); const tab = (sp.get('tab') as Tab) || 'payments';
  return <><PageHeader title="Orders & payments" subtitle="Orders are only marked paid after verified gateway webhooks or an administrator approves a UPI/manual payment. Browser redirects and screenshots never mark an invoice paid." />
    <Tabs value={tab} onChange={t => setSp({ tab: t }, { replace: true })} tabs={[{ id: 'payments', label: 'Payments' }, { id: 'invoices', label: 'Invoices' }, { id: 'orders', label: 'Orders' }, { id: 'services', label: 'Services' }]} />
    {tab === 'payments' && <Payments />}{tab === 'invoices' && <Invoices />}{tab === 'orders' && <Orders />}{tab === 'services' && <Services />}
  </>;
}

function Payments() {
  const [status, setStatus] = useState('awaiting_approval'); const [page, setPage] = useState(1); const { data, error, loading, reload } = useList('/api/admin/payments', status, page); const { busy, run } = useAction();
  const [act, setAct] = useState<any>(null); const [text, setText] = useState(''); const [amt, setAmt] = useState('');
  const go = () => run('a', async () => {
    if (act.kind === 'approve') await api('POST', `/api/admin/payments/${act.p.id}/approve`, { note: text || undefined });
    if (act.kind === 'reject') await api('POST', `/api/admin/payments/${act.p.id}/reject`, { reason: text });
    if (act.kind === 'refund') { const r = await api('POST', `/api/admin/payments/${act.p.id}/refund`, { amountCents: amt ? Math.round(Number(amt) * 100) : null, reason: text || undefined }); if (r.note) toast(r.note, 'info'); }
    setAct(null); reload();
  }, 'Done');
  return <Card title="Payments" actions={<select className="input w-48" value={status} onChange={e => { setStatus(e.target.value); setPage(1); }}><option value="">All</option>{['awaiting_approval', 'pending', 'succeeded', 'failed', 'refunded', 'partially_refunded'].map(s => <option key={s} value={s}>{s.replace(/_/g, ' ')}</option>)}</select>}>
    {status === 'awaiting_approval' && <Notice className="mb-3">Check your bank statement or UPI app for the reference before approving. Approval marks the invoice paid and provisions or renews the service.</Notice>}
    {loading ? <Loading /> : error ? <ErrorBox error={error} onRetry={reload} /> : !data.payments.length ? <Empty title="No payments" /> :
      <Table><thead><tr><th>ID</th><th>Invoice</th><th>Customer</th><th>Gateway</th><th>Amount</th><th>Reference</th><th>Status</th><th>Created</th><th /></tr></thead><tbody>{data.payments.map((p: any) => <tr key={p.id}>
        <td>{p.id}</td><td>{p.invoice_number}</td><td className="text-xs">{p.email}</td><td>{p.gateway}</td><td>{money(p.amount_cents, p.currency)}{p.refunded_cents ? <div className="text-xs text-ink-400">refunded {money(p.refunded_cents, p.currency)}</div> : null}</td>
        <td className="max-w-[12rem] break-all font-mono text-xs">{p.reference || p.gateway_payment_id || '—'}</td><td><Badge value={st(p.status)} label={p.status.replace(/_/g, ' ')} />{p.failure_reason && <div className="text-xs text-red-300">{p.failure_reason}</div>}</td><td className="text-xs">{date(p.created_at)}</td>
        <td className="whitespace-nowrap text-right">{['awaiting_approval', 'pending'].includes(p.status) && ['upi', 'manual'].includes(p.gateway) && <button className="btn-primary btn-sm" onClick={() => { setAct({ kind: 'approve', p }); setText(''); }}>Approve</button>}
          {!['succeeded', 'refunded', 'failed'].includes(p.status) && <button className="btn-ghost btn-sm text-red-400" onClick={() => { setAct({ kind: 'reject', p }); setText(''); }}>Reject</button>}
          {['succeeded', 'partially_refunded'].includes(p.status) && <button className="btn-ghost btn-sm" onClick={() => { setAct({ kind: 'refund', p }); setText(''); setAmt(''); }}>Refund</button>}</td></tr>)}</tbody></Table>}
    <Pager page={page} setPage={setPage} hasMore={(data?.payments?.length || 0) >= 25} />
    <Modal open={!!act} onClose={() => setAct(null)} title={act ? `${act.kind[0].toUpperCase() + act.kind.slice(1)} payment #${act.p.id} (${money(act.p.amount_cents, act.p.currency)})` : ''} footer={<><button className="btn-secondary" onClick={() => setAct(null)}>Cancel</button><button className={act?.kind === 'approve' ? 'btn-primary' : 'btn-danger'} disabled={!!busy || (act?.kind === 'reject' && !text)} onClick={go}>{busy && <Spinner />}Confirm</button></>}>
      {act?.kind === 'refund' && <><Notice className="mb-3">Gateway payments are refunded through the gateway API. UPI/manual refunds are recorded here, but you must send the money back yourself.</Notice><Field label="Amount (empty = full remaining amount)" className="mb-3"><input className="input" type="number" step="0.01" value={amt} onChange={e => setAmt(e.target.value)} /></Field></>}
      <Field label={act?.kind === 'reject' ? 'Reason (sent to the customer)' : 'Note'}><textarea className="input" value={text} onChange={e => setText(e.target.value)} /></Field>
    </Modal>
  </Card>;
}

function Invoices() {
  const [status, setStatus] = useState(''); const [page, setPage] = useState(1); const { data, error, loading, reload } = useList('/api/admin/invoices', status, page); const { busy, run } = useAction();
  const [open, setOpen] = useState<number | null>(null); const det = useApi<any>(open ? `/api/admin/invoices/${open}` : null, [open]);
  const [create, setCreate] = useState<any>(null); const [userQ, setUserQ] = useState(''); const users = useApi<any>(userQ.length >= 2 ? `/api/admin/users?per_page=8&search=${encodeURIComponent(userQ)}` : null, [userQ]);
  return <Card title="Invoices" actions={<div className="flex gap-2"><select className="input w-36" value={status} onChange={e => { setStatus(e.target.value); setPage(1); }}><option value="">All</option>{['unpaid', 'paid', 'cancelled', 'refunded'].map(s => <option key={s}>{s}</option>)}</select><button className="btn-primary btn-sm" onClick={() => setCreate({ user: null, currency: 'INR', dueDays: 7, items: [{ description: '', amount: '' }] })}><Plus className="h-4 w-4" />New invoice</button></div>}>
    {loading ? <Loading /> : error ? <ErrorBox error={error} onRetry={reload} /> : !data.invoices.length ? <Empty title="No invoices" /> :
      <Table><thead><tr><th>Number</th><th>Customer</th><th>Total</th><th>Status</th><th>Due</th><th>Paid</th><th /></tr></thead><tbody>{data.invoices.map((i: any) => <tr key={i.id}><td className="font-mono">{i.number}</td><td className="text-xs">{i.email}</td><td>{money(i.total_cents, i.currency)}</td><td><Badge value={st(i.status)} label={i.status} /></td><td className="text-xs">{date(i.due_at)}</td><td className="text-xs">{date(i.paid_at)}</td><td><button className="btn-ghost btn-sm" onClick={() => setOpen(i.id)}>View</button></td></tr>)}</tbody></Table>}
    <Pager page={page} setPage={setPage} hasMore={(data?.invoices?.length || 0) >= 25} />
    <Modal open={!!open} onClose={() => setOpen(null)} wide title={`Invoice ${det.data?.invoice?.number || ''}`} footer={det.data?.invoice?.status === 'unpaid' && <button className="btn-danger" onClick={() => run('c', () => api('POST', `/api/admin/invoices/${open}/cancel`).then(() => { setOpen(null); reload(); }), 'Invoice cancelled')}>Cancel invoice</button>}>
      {det.loading ? <Loading /> : det.error ? <ErrorBox error={det.error} /> : det.data && <>
        <div className="mb-3 text-sm">{det.data.invoice.email} · <Badge value={st(det.data.invoice.status)} label={det.data.invoice.status} /> · due {date(det.data.invoice.due_at)}</div>
        <Table><tbody>{det.data.invoice.items.map((it: any, k: number) => <tr key={k}><td>{it.description}</td><td className="text-right">{money(it.amount_cents, det.data.invoice.currency)}</td></tr>)}<tr><td className="font-semibold">Total</td><td className="text-right font-semibold">{money(det.data.invoice.total_cents, det.data.invoice.currency)}</td></tr></tbody></Table>
        <h4 className="mb-1 mt-4 text-sm font-semibold">Payment attempts</h4>{!det.data.payments.length ? <p className="text-sm text-ink-400">None</p> : <Table><tbody>{det.data.payments.map((p: any) => <tr key={p.id}><td>{p.gateway}</td><td>{money(p.amount_cents, p.currency)}</td><td><Badge value={st(p.status)} label={p.status} /></td><td className="font-mono text-xs">{p.reference || p.gateway_payment_id || ''}</td><td className="text-xs">{date(p.created_at)}</td></tr>)}</tbody></Table>}
      </>}
    </Modal>
    <Modal open={!!create} onClose={() => setCreate(null)} wide title="New invoice" footer={<><button className="btn-secondary" onClick={() => setCreate(null)}>Cancel</button><button className="btn-primary" disabled={!create?.user || !!busy} onClick={() => run('n', async () => { await api('POST', '/api/admin/invoices', { userId: create.user.id, currency: create.currency, dueDays: Number(create.dueDays), items: create.items.filter((x: any) => x.description).map((x: any) => ({ description: x.description, amount_cents: Math.round(Number(x.amount) * 100) })) }); setCreate(null); reload(); }, 'Invoice created and customer notified')}>Create</button></>}>
      {create && <div className="grid gap-4">
        <Field label="Customer">{create.user ? <div className="input flex justify-between">{create.user.email}<button className="text-xs text-brand-400" onClick={() => setCreate({ ...create, user: null })}>Change</button></div> : <><input className="input" placeholder="Search users" value={userQ} onChange={e => setUserQ(e.target.value)} />{users.data?.users?.map((u: any) => <button key={u.id} className="block w-full px-2 py-1 text-left text-sm hover:bg-ink-800" onClick={() => { setCreate({ ...create, user: u }); setUserQ(''); }}>{u.email}</button>)}</>}</Field>
        <div className="grid grid-cols-2 gap-4"><Field label="Currency"><input className="input" value={create.currency} onChange={e => setCreate({ ...create, currency: e.target.value.toUpperCase() })} /></Field><Field label="Due in days"><input className="input" type="number" value={create.dueDays} onChange={e => setCreate({ ...create, dueDays: e.target.value })} /></Field></div>
        {create.items.map((it: any, k: number) => <div key={k} className="flex gap-2"><input className="input flex-1" placeholder="Description" value={it.description} onChange={e => setCreate({ ...create, items: create.items.map((x: any, j: number) => j === k ? { ...x, description: e.target.value } : x) })} /><input className="input w-32" type="number" step="0.01" placeholder="Amount" value={it.amount} onChange={e => setCreate({ ...create, items: create.items.map((x: any, j: number) => j === k ? { ...x, amount: e.target.value } : x) })} /><button className="btn-ghost text-red-400" onClick={() => setCreate({ ...create, items: create.items.filter((_: any, j: number) => j !== k) })}><Trash2 className="h-4 w-4" /></button></div>)}
        <button className="btn-secondary btn-sm w-fit" onClick={() => setCreate({ ...create, items: [...create.items, { description: '', amount: '' }] })}><Plus className="h-4 w-4" />Line item</button>
      </div>}
    </Modal>
  </Card>;
}

function Orders() {
  const [status, setStatus] = useState(''); const [page, setPage] = useState(1); const { data, error, loading, reload } = useList('/api/admin/orders', status, page);
  return <Card title="Orders" actions={<select className="input w-36" value={status} onChange={e => { setStatus(e.target.value); setPage(1); }}><option value="">All</option>{['pending', 'paid', 'active', 'failed', 'cancelled', 'refunded'].map(s => <option key={s}>{s}</option>)}</select>}>
    {loading ? <Loading /> : error ? <ErrorBox error={error} onRetry={reload} /> : !data.orders.length ? <Empty title="No orders" /> :
      <Table><thead><tr><th>ID</th><th>Customer</th><th>Plan</th><th>Type</th><th>Total</th><th>Status</th><th>Created</th></tr></thead><tbody>{data.orders.map((o: any) => <tr key={o.id}><td>{o.id}</td><td className="text-xs">{o.email}</td><td>{o.plan_name}</td><td className="text-xs">{o.kind}</td><td>{money(o.amount_cents, o.currency)}</td><td><Badge value={st(o.status)} label={o.status} /></td><td className="text-xs">{date(o.created_at)}</td></tr>)}</tbody></Table>}
    <Pager page={page} setPage={setPage} hasMore={(data?.orders?.length || 0) >= 25} />
  </Card>;
}

function Services() {
  const [page, setPage] = useState(1); const { data, error, loading, reload } = useList('/api/admin/services', '', page); const { busy, run } = useAction();
  const [ed, setEd] = useState<any>(null);
  return <Card title="Services">
    {loading ? <Loading /> : error ? <ErrorBox error={error} onRetry={reload} /> : !data.services.length ? <Empty title="No services" /> :
      <Table><thead><tr><th>ID</th><th>Customer</th><th>Plan</th><th>Server</th><th>Price</th><th>Status</th><th>Next due</th><th /></tr></thead><tbody>{data.services.map((s: any) => <tr key={s.id}><td>{s.id}</td><td className="text-xs">{s.email}</td><td>{s.plan_name}</td><td>{s.server_name || '—'}</td><td>{money(s.price_cents, s.currency)}</td><td><Badge value={st(s.status)} label={s.status} /></td><td className="text-xs">{date(s.next_due_at)}</td><td>{['active', 'suspended'].includes(s.status) && <button className="btn-ghost btn-sm" onClick={() => setEd({ s, extendMonths: '', priceCents: s.price_cents, status: s.status, immediate: false })}>Manage</button>}</td></tr>)}</tbody></Table>}
    <Pager page={page} setPage={setPage} hasMore={(data?.services?.length || 0) >= 25} />
    <Modal open={!!ed} onClose={() => setEd(null)} title={`Service #${ed?.s.id}`} footer={<><button className="btn-danger" disabled={!!busy} onClick={() => run('c', () => api('POST', `/api/admin/services/${ed.s.id}/cancel`, { immediate: ed.immediate }).then(() => { setEd(null); reload(); }), 'Service cancelled')}>Cancel service</button><button className="btn-primary" disabled={!!busy} onClick={() => run('s', () => api('PATCH', `/api/admin/services/${ed.s.id}`, { extendMonths: ed.extendMonths ? Number(ed.extendMonths) : undefined, priceCents: Number(ed.priceCents), status: ed.status }).then(() => { setEd(null); reload(); }), 'Saved')}>Save</button></>}>
      {ed && <div className="grid gap-4">
        <Field label="Extend due date by months"><input className="input" type="number" value={ed.extendMonths} onChange={e => setEd({ ...ed, extendMonths: e.target.value })} /></Field>
        <Field label="Recurring price"><input className="input" type="number" step="0.01" value={ed.priceCents / 100} onChange={e => setEd({ ...ed, priceCents: Math.round(Number(e.target.value) * 100) })} /></Field>
        <Field label="Status" hint="Suspending also suspends the linked server"><select className="input" value={ed.status} onChange={e => setEd({ ...ed, status: e.target.value })}><option value="active">Active</option><option value="suspended">Suspended</option></select></Field>
        <Switch checked={ed.immediate} onChange={v => setEd({ ...ed, immediate: v })} label="Cancel immediately (otherwise at the end of the period)" />
      </div>}
    </Modal>
  </Card>;
}
