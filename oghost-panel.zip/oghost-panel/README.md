# OGHOST PANEL

**Powering the Next Generation of Game Hosting.**
Developer credit: Powered by SHIVAMBROOG

OGHOST PANEL is a self-hosted Minecraft and game-server hosting panel with a multi-node agent, customer area, store with billing, Security Center and Google Drive backups. It runs as native Node.js and Java processes. It does not use Docker, Docker Compose or any container runtime, and it does not need root.

## Components

| Path | What it is |
| --- | --- |
| `apps/panel` | Panel backend: Express 5 + TypeScript, REST API, Socket.IO console relay, background job queue, MySQL/MariaDB |
| `apps/node-agent` | Node agent: runs on each game host, manages Java/native processes, files, backups, versions, plugins, JAR scanning, Drive uploads |
| `apps/frontend` | React 19 + TypeScript + Tailwind 4 single-page app (dark red/black theme, responsive) |
| `packages/shared` | Shared code: path safety, startup rendering, Java selection, node tokens, crypto, TOTP |
| `packages/extension-sdk` | SDK and manifest validator for OGHOST extensions |
| `database/migrations` | SQL migrations (run with `node dist/panel.mjs migrate`) |
| `installer/install.sh` | Non-root installer for the panel or an agent |
| `scripts/` | Build, launcher (`run.sh`), nohup service helper (`oghost.sh`) |
| `extensions/server-notes` | Example extension |
| `tests/` | Unit tests, end-to-end tests, Google OAuth/Drive mock |

## Quick start

```bash
# Requirements: Node.js 20+, MariaDB 10.6+ or MySQL 8, a normal (non-root) Linux user
bash installer/install.sh            # panel
bash installer/install.sh --agent    # node agent (on each game host)
```

Manual setup, database creation and reverse proxy setup are described in [documentation/INSTALL.md](documentation/INSTALL.md) and [documentation/DEPLOYMENT.md](documentation/DEPLOYMENT.md).

## Documentation

- [INSTALL.md](documentation/INSTALL.md): requirements, installer, manual install, first admin
- [DATABASE.md](documentation/DATABASE.md): database setup, migrations, schema overview, backups
- [DEPLOYMENT.md](documentation/DEPLOYMENT.md): non-root deployment, reverse proxy, TLS, systemd --user or nohup
- [SECURITY.md](documentation/SECURITY.md): security model and honest limitations (isolation, disk quotas, CPU limits)
- [EXTENSIONS.md](documentation/EXTENSIONS.md): extension SDK, manifest, permissions
- [PAYMENTS.md](documentation/PAYMENTS.md): Razorpay, Cashfree, Stripe, UPI and manual payments, webhook URLs
- [DRIVE.md](documentation/DRIVE.md): per-customer Google Drive backups
- [COINS.md](documentation/COINS.md): OGCoins currency, Linkvertise earning, Discord purchases and bot API, coin plans and auto-renew
- [TESTING.md](documentation/TESTING.md): running the unit and end-to-end tests
- API reference: served by the panel at `/api/docs` (OpenAPI JSON at `/api/docs/openapi.json`)

## Feature summary

- **Servers:** create, delete (with confirmation and recovery), reinstall, suspend, start/stop/restart/kill, rename, description, node transfer, startup editing, RAM/CPU/disk/allocation limits, owner change, subusers with permissions, clone, import/export.
- **Storage layout:** `.server/nodes/<node>/servers/<numeric id>/` plus `backups/`, `temporary/`, `metadata/`. IDs are allocated atomically per node in the database, reused only after deletion has fully completed, and display names are never used as folder names.
- **Console:** live WebSocket console from the real process (ANSI colours, history, reconnect, crash detection). No simulated output.
- **Files:** file manager with editor, upload/download, archive/extract, permissions. Path traversal and symlink escapes are blocked, and every write is checked against the server's disk allocation on the node.
- **Java:** detects installed JDKs and JREs (no fixed path assumed). Each Minecraft version maps to the Java it requires. Xmx is validated against assigned RAM.
- **Eggs:** Vanilla, Paper, Purpur, Pufferfish, Folia, Spigot (BuildTools), Bukkit, Fabric, Forge, NeoForge, Quilt, Velocity, Waterfall, BungeeCord, Bedrock Dedicated Server, PocketMine-MP, Minestom, Custom JAR. Each has its own install and startup logic.
- **Versions and plugins:** version changer with automatic backup and rollback. Plugin installer for Modrinth, Hangar, SpigotMC, GitHub releases and admin repositories. Downloaded files are never executed during installation.
- **Backups, schedules, databases, allocations:** local backups and restore, cron schedules, per-server MySQL databases (admin credentials are never shown to customers), and port allocations with a public reachability check.
- **Accounts:** roles (Super Admin, Admin, Staff, Support, Customer and custom roles), TOTP 2FA, session management, API keys, email verification and password reset, Google sign-in through Firebase with backend token verification.
- **Store:** STARTER, PRO and ULTIMATE plans, coupons, invoices, renewals and suspension. Payments through Razorpay, Cashfree, Stripe, UPI and manual approval. An order is only marked paid after a verified webhook or an admin approval.
- **OGCoins:** a panel currency. Customers earn coins through Linkvertise (credited only after a server-side anti-bypass check), redeem codes, a linked Discord account with bot or staff grants, and admin adjustments. Coins buy servers and renew plans, by hand or with auto-renew. The ledger is atomic: no double spends, and retries are idempotent.
- **OGHOST Security Center:** static JAR scanning (SAFE / SUSPICIOUS / HIGH RISK), 48-hour suspension of only the affected server, evidence preservation, appeals, trusted hashes. Unknown JARs are never executed.
- **Google Drive backups:** per-customer OAuth with the `drive.file` scope and encrypted tokens. Hourly by default, retention of 1/2/3/5/7 backups, and the previous backup is kept until the new one is uploaded and verified. Restores take a safety backup first.
- **Extensions:** OGHOST's own SDK. Pterodactyl Blueprint packages are not compatible.
- **Nodes:** multi-node with TLS, signed short-lived tokens, heartbeat, offline detection and maintenance mode.

## Important limitations

Please read [SECURITY.md](documentation/SECURITY.md) before using this in production. In short:

- In non-root mode all game servers on a node run as the same Unix user as the agent. The panel only lets customers act through its API (no shell commands), but there is no kernel-level separation between servers on one node.
- Disk limits are enforced by the application. This is not a kernel filesystem quota. An optional host-admin `QUOTA_HOOK` can apply real quotas.
- CPU limits use `cpulimit`, which is best-effort throttling and not hard CPU isolation.
- The Linkvertise and Discord integrations were tested against local mocks, not real accounts. See [COINS.md](documentation/COINS.md).

## License

Proprietary. Copyright OGHOST. Powered by SHIVAMBROOG.
